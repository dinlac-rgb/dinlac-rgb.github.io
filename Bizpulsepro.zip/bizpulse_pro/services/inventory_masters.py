"""
Inventory masters (Masters › Create / Alter): Stock Groups, Units of Measure, Stock Items,
Stock Categories, Godowns and Currencies (the voucher screen's Exchange Rate box offers these).

    InventoryStore(db_path)      everything MasterStore does (Group, Ledger, GST Classification) plus:

    bp_stock_groups   name, under_group ('Primary' or another stock group), add_quantities (1/0)
    bp_units          symbol, formal_name, unit_type (Simple / Compound), decimals (0-4),
                      first_unit, conversion, second_unit (Compound only)
    bp_stock_items    name, alias, under_group, unit, gst_applicable (Yes/No),
                      gst_classification, opening_qty, opening_rate_paise

    A new Stock Item is also written to YOUR inventory_stock_registry in the same transaction:
    product_sku = the item name, qty_on_hand = the opening quantity (min_safety_floor 0 and
    last_audit_date today, where those columns exist). An item whose name is already a
    product_sku there is linked to that row instead; its quantity is left alone, so an opening
    quantity is refused for it (it would be counted twice). Altering a linked item's opening
    quantity moves qty_on_hand by the difference.

    The opening rate is the item's cost: the Stock Summary uses it when inventory_pricing_rules
    has no rate for the item.

Quantities: qty_on_hand is a whole-number column, so opening quantities are whole numbers, and
vouchers still take whole quantities whatever a unit's decimal places say.
All checks happen here, every write is one transaction with parameters only, and nothing here
touches Tk: the forms call it from a background thread.
"""
from __future__ import annotations

import sqlite3
from datetime import date, datetime
from decimal import Decimal, InvalidOperation

from services import audit
from services.masters import CENT, MAX_NAME, MasterError, MasterStore, clean

INVENTORY_DDL = """
CREATE TABLE IF NOT EXISTS bp_currencies (
    code TEXT PRIMARY KEY COLLATE NOCASE, name TEXT NOT NULL, symbol TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL, updated_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS bp_stock_categories (
    name TEXT PRIMARY KEY COLLATE NOCASE, under_category TEXT NOT NULL DEFAULT 'Primary',
    created_at TEXT NOT NULL, updated_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS bp_godowns (
    name TEXT PRIMARY KEY COLLATE NOCASE, under_godown TEXT NOT NULL DEFAULT 'Primary', address TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL, updated_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS bp_stock_groups (
    name           TEXT PRIMARY KEY COLLATE NOCASE,
    under_group    TEXT NOT NULL DEFAULT 'Primary',
    add_quantities INTEGER NOT NULL DEFAULT 1,
    created_at     TEXT NOT NULL,
    updated_at     TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS bp_units (
    symbol         TEXT PRIMARY KEY COLLATE NOCASE,
    formal_name    TEXT NOT NULL DEFAULT '',
    unit_type      TEXT NOT NULL DEFAULT 'Simple',
    decimals       INTEGER NOT NULL DEFAULT 0 CHECK (decimals BETWEEN 0 AND 4),
    first_unit     TEXT NOT NULL DEFAULT '',
    conversion     TEXT NOT NULL DEFAULT '',
    second_unit    TEXT NOT NULL DEFAULT '',
    created_at     TEXT NOT NULL,
    updated_at     TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS bp_stock_items (
    name               TEXT PRIMARY KEY COLLATE NOCASE,
    alias              TEXT COLLATE NOCASE UNIQUE,
    under_group        TEXT NOT NULL DEFAULT 'Primary',
    unit               TEXT NOT NULL,
    gst_applicable     TEXT NOT NULL DEFAULT 'Yes',
    gst_classification TEXT NOT NULL DEFAULT '',
    opening_qty        INTEGER NOT NULL DEFAULT 0 CHECK (opening_qty >= 0),
    opening_rate_paise INTEGER NOT NULL DEFAULT 0 CHECK (opening_rate_paise >= 0),
    linked_existing    INTEGER NOT NULL DEFAULT 0,     -- 1: the SKU was already in inventory_stock_registry
    created_at         TEXT NOT NULL,
    updated_at         TEXT NOT NULL
)
"""
PRIMARY = "Primary"
UNIT_TYPES = ["Simple", "Compound"]
YES_NO = ["Yes", "No"]
REGISTRY = "inventory_stock_registry"


def yes_no(raw: str, what: str) -> str:
    text = str(raw or "").strip().title()
    if text in ("Y", "Yes"):
        return "Yes"
    if text in ("N", "No"):
        return "No"
    raise MasterError(f"{what}: answer Yes or No.")


def whole(raw: str, what: str, low: int = 0, high: int | None = None) -> int:
    text = str(raw or "").replace(",", "").strip() or "0"
    if not text.isdigit():
        raise MasterError(f"{what} must be a whole number{f' from {low} to {high}' if high is not None else ''}.")
    value = int(text)
    if value < low or (high is not None and value > high):
        raise MasterError(f"{what} must be from {low} to {high}.")
    return value


def rupees(raw: str, what: str) -> Decimal:
    text = str(raw or "").replace(",", "").replace("₹", "").strip()
    if not text:
        return Decimal("0.00")
    try:
        value = Decimal(text)
    except InvalidOperation:
        raise MasterError(f"{what} '{raw}' is not an amount.") from None
    if not value.is_finite() or value < 0 or value != value.quantize(CENT) or value > Decimal("999999999.99"):
        raise MasterError(f"{what} must be a positive amount with at most 2 decimals.")
    return value.quantize(CENT)


class InventoryStore(MasterStore):
    # ---- writes (inventory tables share MasterStore's transaction helper) ---------------
    def _write(self, statements, extra=None) -> None:
        """MasterStore._write, with the inventory tables created too. `extra(con)` runs inside
        the same transaction (stock registry changes)."""
        con = self._connect(write=True)
        try:
            con.execute("BEGIN IMMEDIATE")
            from services.masters import DDL
            for stmt in filter(None, (s.strip() for s in (DDL + ";" + INVENTORY_DDL).split(";"))):
                con.execute(stmt)
            audit.begin(con, source="BizPulse Masters", mode="row")     # the row triggers log each change
            for sql, args in statements:
                con.execute(sql, args)
            if extra is not None:
                extra(con)
            audit.end(con)
            con.execute("COMMIT")
        except MasterError:
            if con.in_transaction:
                con.execute("ROLLBACK")
            raise
        except sqlite3.Error as exc:
            if con.in_transaction:
                con.execute("ROLLBACK")
            if isinstance(exc, sqlite3.IntegrityError):
                raise MasterError(f"Not saved: that name already exists ({exc}).") from exc
            if "locked" in str(exc).lower():
                raise MasterError("The database is busy (another program is writing to it). Try again.") from exc
            raise MasterError(f"Not saved: {exc}") from exc
        finally:
            con.close()

    # ---- reads -------------------------------------------------------------------------
    def stock_groups(self) -> dict[str, str]:
        return dict(self._read("SELECT name, under_group FROM bp_stock_groups ORDER BY name COLLATE NOCASE",
                               table="bp_stock_groups"))

    def stock_group_names(self) -> list[str]:
        return list(self.stock_groups())

    def stock_group_catalogue(self) -> list[tuple[str, list[str]]]:
        return [("Primary", [PRIMARY])] + ([("Stock groups", self.stock_group_names())] if self.stock_groups() else [])

    def unit_names(self) -> list[str]:
        return [r[0] for r in self._read("SELECT symbol FROM bp_units ORDER BY symbol COLLATE NOCASE", table="bp_units")]

    def simple_units(self) -> list[str]:
        return [r[0] for r in self._read("SELECT symbol FROM bp_units WHERE unit_type = 'Simple' "
                                         "ORDER BY symbol COLLATE NOCASE", table="bp_units")]

    def item_names(self) -> list[str]:
        return [r[0] for r in self._read("SELECT name FROM bp_stock_items ORDER BY name COLLATE NOCASE",
                                         table="bp_stock_items")]

    def opening_rates(self) -> dict[str, Decimal]:
        """Item name (lower) -> opening rate, for the Stock Summary."""
        return {n.strip().lower(): (Decimal(p) / 100).quantize(CENT) for n, p in self._read(
            "SELECT name, opening_rate_paise FROM bp_stock_items WHERE opening_rate_paise > 0", table="bp_stock_items")}

    def load(self, kind: str, name: str) -> dict | None:
        if kind == "Stock Group":
            rows = self._read("SELECT name, under_group, add_quantities FROM bp_stock_groups WHERE name = ?",
                              (name.strip(),), "bp_stock_groups")
            return {"name": rows[0][0], "under": rows[0][1], "add": "Yes" if rows[0][2] else "No"} if rows else None
        if kind == "Unit":
            rows = self._read("SELECT symbol, unit_type, formal_name, decimals, first_unit, conversion, second_unit "
                              "FROM bp_units WHERE symbol = ?", (name.strip(),), "bp_units")
            if not rows:
                return None
            sym, utype, formal, dec, first, conv, second = rows[0]
            return {"symbol": sym, "type": utype, "formal": formal, "decimals": str(dec), "first": first,
                    "conversion": conv, "second": second}
        if kind == "Stock Item":
            rows = self._read("SELECT name, alias, under_group, unit, gst_applicable, gst_classification, opening_qty, "
                              "opening_rate_paise FROM bp_stock_items WHERE name = ?", (name.strip(),), "bp_stock_items")
            if not rows:
                return None
            n, alias, under, unit, gst, cls, qty, rate = rows[0]
            rate_d = (Decimal(rate) / 100).quantize(CENT)
            return {"name": n, "alias": alias or "", "under": under, "unit": unit, "gst": gst, "classification": cls,
                    "qty": str(qty) if qty else "", "rate": f"{rate_d:,.2f}" if rate else "",
                    "value": f"{(rate_d * qty).quantize(CENT):,.2f}" if qty and rate else ""}
        if kind == "Currency":
            rows = self._read("SELECT code, name, symbol FROM bp_currencies WHERE code = ?", (name.strip(),),
                              "bp_currencies")
            return dict(zip(("code", "name", "symbol"), rows[0])) if rows else None
        if kind == "Stock Category":
            rows = self._read("SELECT name, under_category FROM bp_stock_categories WHERE name = ?", (name.strip(),),
                              "bp_stock_categories")
            return {"name": rows[0][0], "under": rows[0][1]} if rows else None
        if kind == "Godown":
            rows = self._read("SELECT name, under_godown, address FROM bp_godowns WHERE name = ?", (name.strip(),),
                              "bp_godowns")
            return dict(zip(("name", "under", "address"), rows[0])) if rows else None
        return super().load(kind, name)

    # ---- Currency, Stock Category, Godown --------------------------------------------------
    def currency_names(self) -> list[str]:
        return [r[0] for r in self._read("SELECT code FROM bp_currencies ORDER BY code", table="bp_currencies")]

    def currency_list(self) -> list[tuple[str, str]]:
        """(code, name) for the voucher screen's Exchange Rate box."""
        return [(c, n) for c, n in self._read("SELECT code, name FROM bp_currencies ORDER BY code",
                                              table="bp_currencies")]

    def _tree(self, table: str, parent_col: str) -> dict[str, str]:
        return dict(self._read(f"SELECT name, {parent_col} FROM {table} ORDER BY name COLLATE NOCASE", table=table))

    def stock_category_names(self) -> list[str]:
        return list(self._tree("bp_stock_categories", "under_category"))

    def stock_category_catalogue(self) -> list[tuple[str, list[str]]]:
        names = self.stock_category_names()
        return [("Primary", [PRIMARY])] + ([("Stock categories", names)] if names else [])

    def godown_names(self) -> list[str]:
        return list(self._tree("bp_godowns", "under_godown"))

    def godown_catalogue(self) -> list[tuple[str, list[str]]]:
        names = self.godown_names()
        return [("Primary", [PRIMARY])] + ([("Godowns", names)] if names else [])

    def save_currency(self, values: dict, alter: bool = False) -> str:
        code = clean(values.get("code"), "Currency Code", required=True, limit=3).upper()
        if not (len(code) == 3 and code.isalpha()):
            raise MasterError("Currency Code must be three letters (USD, EUR …).")
        if code == "INR":
            raise MasterError("INR is the base currency of the books; it needs no master.")
        name = clean(values.get("name"), "Formal Name", required=True, limit=MAX_NAME)
        symbol = clean(values.get("symbol"), "Symbol", limit=4)
        exists = code in {c.upper() for c in self.currency_names()}
        if exists != alter:
            raise MasterError(f"Currency '{code}' {'does not exist' if alter else 'already exists'}.")
        now = datetime.now().isoformat(timespec="seconds")
        if alter:
            self._write([("UPDATE bp_currencies SET name = ?, symbol = ?, updated_at = ? WHERE code = ?",
                          (name, symbol, now, code))])
        else:
            self._write([("INSERT INTO bp_currencies (code, name, symbol, created_at, updated_at) VALUES (?, ?, ?, ?, ?)",
                          (code, name, symbol, now, now))])
        return f"Currency {code} ({name}) {'altered' if alter else 'created'}."

    def _save_tree(self, kind: str, table: str, parent_col: str, values: dict, alter: bool,
                   extra: tuple[str, str] | None = None) -> str:
        name = clean(values.get("name"), f"{kind} Name", required=True, limit=MAX_NAME)
        under = clean(values.get("under"), "Under", limit=MAX_NAME) or PRIMARY
        tree = self._tree(table, parent_col)
        lower = {k.lower(): k for k in tree}
        if name.lower() == PRIMARY.lower():
            raise MasterError("'Primary' is reserved; choose another name.")
        if (name.lower() in lower) != alter:
            raise MasterError(f"{kind} '{name}' {'does not exist' if alter else 'already exists'}.")
        if under.lower() != PRIMARY.lower():
            if under.lower() not in lower:
                raise MasterError(f"Under '{under}' does not exist.")
            under = lower[under.lower()]
            step, seen = under, set()                       # no loops: walk up to Primary
            while step.lower() != PRIMARY.lower():
                if step.lower() == name.lower() or step.lower() in seen:
                    raise MasterError(f"'{name}' cannot be put under '{under}' (that is inside '{name}' itself).")
                seen.add(step.lower())
                step = tree.get(lower.get(step.lower(), ""), PRIMARY)
        else:
            under = PRIMARY
        now = datetime.now().isoformat(timespec="seconds")
        cols, args = [parent_col], [under]
        if extra:
            cols.append(extra[0])
            args.append(clean(values.get(extra[1]), extra[1].title()))
        if alter:
            sets = ", ".join(f"{c} = ?" for c in cols)
            self._write([(f"UPDATE {table} SET {sets}, updated_at = ? WHERE name = ?", (*args, now, name))])
        else:
            self._write([(f"INSERT INTO {table} (name, {', '.join(cols)}, created_at, updated_at) "
                          f"VALUES (?, {', '.join('?' * len(cols))}, ?, ?)", (name, *args, now, now))])
        return f"{kind} '{name}' {'altered' if alter else 'created'} under {under}."

    def save_stock_category(self, values: dict, alter: bool = False) -> str:
        return self._save_tree("Stock Category", "bp_stock_categories", "under_category", values, alter)

    def save_godown(self, values: dict, alter: bool = False) -> str:
        return self._save_tree("Godown", "bp_godowns", "under_godown", values, alter, extra=("address", "address"))

    # ---- Stock Group -----------------------------------------------------------------------
    def save_stock_group(self, values: dict, alter: bool = False) -> str:
        name = clean(values.get("name"), "Stock Group Name", required=True, limit=MAX_NAME)
        under = clean(values.get("under"), "Under", limit=MAX_NAME) or PRIMARY
        add = yes_no(values.get("add") or "Yes", "Should quantities of items be added")
        groups = self.stock_groups()
        lower = {g.lower(): g for g in groups}
        if name.lower() == PRIMARY.lower():
            raise MasterError("'Primary' is reserved; choose another name.")
        if not alter and name.lower() in lower:
            raise MasterError(f"Stock Group '{name}' already exists.")
        if alter and name.lower() not in lower:
            raise MasterError(f"Stock Group '{name}' does not exist.")
        if under.lower() == PRIMARY.lower():
            under = PRIMARY
        elif under.lower() in lower:
            under = lower[under.lower()]
        else:
            raise MasterError(f"Under '{under}' is not Primary or an existing stock group.")
        parent, seen = under, set()                       # no loops: walk up from the new parent
        while parent != PRIMARY:
            if parent.lower() == name.lower() or parent.lower() in seen:
                raise MasterError(f"'{name}' cannot be put under '{under}' (that is inside '{name}' itself).")
            seen.add(parent.lower())
            parent = groups.get(lower.get(parent.lower(), ""), PRIMARY)
        now = datetime.now().isoformat(timespec="seconds")
        flag = 1 if add == "Yes" else 0
        if alter:
            self._write([("UPDATE bp_stock_groups SET under_group = ?, add_quantities = ?, updated_at = ? WHERE name = ?",
                          (under, flag, now, name))])
        else:
            self._write([("INSERT INTO bp_stock_groups (name, under_group, add_quantities, created_at, updated_at) "
                          "VALUES (?, ?, ?, ?, ?)", (name, under, flag, now, now))])
        return f"Stock Group '{name}' {'altered' if alter else 'created'} under {under}."

    # ---- Unit ------------------------------------------------------------------------------------
    def save_unit(self, values: dict, alter: bool = False) -> str:
        utype = clean(values.get("type"), "Type").title() or "Simple"
        if utype not in UNIT_TYPES:
            raise MasterError("Type must be Simple or Compound.")
        decimals = whole(values.get("decimals"), "Number of decimal places", 0, 4)
        existing = {u.lower(): u for u in self.unit_names()}
        if utype == "Simple":
            symbol = clean(values.get("symbol"), "Symbol", required=True, limit=12)
            if " " in symbol:
                raise MasterError("A unit symbol is one word (e.g. Pcs, Nos, Kgs).")
            formal = clean(values.get("formal"), "Formal Name", limit=MAX_NAME)
            first = conversion = second = ""
        else:
            simple = {u.lower(): u for u in self.simple_units()}
            first = simple.get(clean(values.get("first"), "First unit").lower(), "")
            second = simple.get(clean(values.get("second"), "Second unit").lower(), "")
            if not first or not second:
                raise MasterError("A Compound unit needs two existing Simple units (First unit and Second unit).")
            if first.lower() == second.lower():
                raise MasterError("First unit and Second unit must be different.")
            conv = rupees(values.get("conversion"), "Conversion")
            if not conv:
                raise MasterError("Enter how many Second units make one First unit (Conversion).")
            conversion = f"{conv.normalize():f}"
            symbol = clean(values.get("symbol"), "Symbol", limit=40) or f"{first} of {conversion} {second}"
            formal = clean(values.get("formal"), "Formal Name", limit=MAX_NAME)
            decimals = 0
        if not alter and symbol.lower() in existing:
            raise MasterError(f"Unit '{symbol}' already exists.")
        if alter and symbol.lower() not in existing:
            raise MasterError(f"Unit '{symbol}' does not exist.")
        now = datetime.now().isoformat(timespec="seconds")
        if alter:
            self._write([("UPDATE bp_units SET formal_name = ?, unit_type = ?, decimals = ?, first_unit = ?, "
                          "conversion = ?, second_unit = ?, updated_at = ? WHERE symbol = ?",
                          (formal, utype, decimals, first, conversion, second, now, symbol))])
        else:
            self._write([("INSERT INTO bp_units (symbol, formal_name, unit_type, decimals, first_unit, conversion, "
                          "second_unit, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                          (symbol, formal, utype, decimals, first, conversion, second, now, now))])
        return f"Unit '{symbol}' {'altered' if alter else 'created'} ({utype.lower()}, {decimals} decimal places)."

    # ---- Stock Item --------------------------------------------------------------------------------
    def save_stock_item(self, values: dict, alter: bool = False) -> str:
        name = clean(values.get("name"), "Stock Item Name", required=True, limit=MAX_NAME)
        alias = clean(values.get("alias"), "Alias", limit=MAX_NAME)
        under = clean(values.get("under"), "Under", limit=MAX_NAME) or PRIMARY
        groups = {g.lower(): g for g in self.stock_group_names()}
        if under.lower() == PRIMARY.lower():
            under = PRIMARY
        elif under.lower() in groups:
            under = groups[under.lower()]
        else:
            raise MasterError(f"Under '{under}' is not Primary or an existing stock group.")
        units = {u.lower(): u for u in self.unit_names()}
        unit = units.get(clean(values.get("unit"), "Units", required=True).lower())
        if unit is None:
            raise MasterError("Units: choose a unit from the list (create one in Masters › Create › Unit first).")
        gst = yes_no(values.get("gst") or "Yes", "GST Applicable")
        cls = clean(values.get("classification"), "GST Classification", limit=MAX_NAME)
        if gst == "No":
            cls = ""
        elif cls:
            classes = {c.lower(): c for c in self.classification_names()}
            if cls.lower() not in classes:
                raise MasterError(f"GST Classification '{cls}' does not exist (create it in Masters first).")
            cls = classes[cls.lower()]
        qty = whole(values.get("qty"), "Opening Quantity")
        rate = rupees(values.get("rate"), "Rate per unit")

        items = {n.lower() for n in self.item_names()}
        aliases = {r[0].lower(): r[1] for r in self._read("SELECT alias, name FROM bp_stock_items WHERE alias IS NOT NULL "
                                                          "AND alias != ''", table="bp_stock_items")}
        if not alter and name.lower() in items:
            raise MasterError(f"Stock Item '{name}' already exists.")
        if alter and name.lower() not in items:
            raise MasterError(f"Stock Item '{name}' does not exist.")
        if name.lower() in aliases and aliases[name.lower()].lower() != name.lower():
            raise MasterError(f"'{name}' is already the alias of {aliases[name.lower()]}.")
        if alias:
            if alias.lower() == name.lower():
                alias = ""
            elif alias.lower() in items or (alias.lower() in aliases and aliases[alias.lower()].lower() != name.lower()):
                raise MasterError(f"Alias '{alias}' is already used by another stock item.")

        now = datetime.now().isoformat(timespec="seconds")
        rate_paise = int(rate * 100)
        old = self._read("SELECT opening_qty, linked_existing FROM bp_stock_items WHERE name = ?", (name,),
                         "bp_stock_items") if alter else []

        def registry(con: sqlite3.Connection) -> None:
            cols = {r[1] for r in con.execute(f"PRAGMA table_info({REGISTRY})")}
            if not {"product_sku", "qty_on_hand"} <= cols:
                raise MasterError(f"{REGISTRY} (product_sku, qty_on_hand) is missing; nothing was saved.")
            row = con.execute(f"SELECT product_sku, qty_on_hand FROM {REGISTRY} "
                              "WHERE lower(trim(product_sku)) = lower(?)", (name,)).fetchone()
            if alter:
                old_qty, _linked = old[0]
                if row is None:
                    raise MasterError(f"'{name}' is no longer in {REGISTRY}; nothing was saved.")
                if qty != old_qty:
                    con.execute(f"UPDATE {REGISTRY} SET qty_on_hand = qty_on_hand + ? WHERE product_sku = ?",
                                (qty - old_qty, row[0]))
                return
            if row is not None:
                if qty:
                    raise MasterError(f"'{name}' is already in {REGISTRY} with {row[1]} on hand: leave the opening "
                                      "quantity blank to link the item to it (it would be counted twice).")
                con.execute("UPDATE bp_stock_items SET linked_existing = 1 WHERE name = ?", (name,))
                return
            names, args = ["product_sku", "qty_on_hand"], [name, qty]
            if "min_safety_floor" in cols:
                names.append("min_safety_floor"); args.append(0)
            if "last_audit_date" in cols:
                names.append("last_audit_date"); args.append(date.today().isoformat())
            con.execute(f"INSERT INTO {REGISTRY} ({', '.join(names)}) VALUES ({', '.join('?' * len(args))})", args)

        if alter:
            self._write([("UPDATE bp_stock_items SET alias = ?, under_group = ?, unit = ?, gst_applicable = ?, "
                          "gst_classification = ?, opening_qty = ?, opening_rate_paise = ?, updated_at = ? WHERE name = ?",
                          (alias or None, under, unit, gst, cls, qty, rate_paise, now, name))], extra=registry)
        else:
            self._write([("INSERT INTO bp_stock_items (name, alias, under_group, unit, gst_applicable, gst_classification, "
                          "opening_qty, opening_rate_paise, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                          (name, alias or None, under, unit, gst, cls, qty, rate_paise, now, now))], extra=registry)
        value = f", opening {qty} {unit} @ {rate:,.2f} = {(rate * qty).quantize(CENT):,.2f}" if qty else ""
        return f"Stock Item '{name}' {'altered' if alter else 'created'} under {under}{value}."
