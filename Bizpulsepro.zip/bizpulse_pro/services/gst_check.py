"""
Offline structure checks for a GSTIN and an HSN/SAC code — what can be known WITHOUT the
GST portal. Run from a background thread by the Ledger and GST Classification forms when the
cursor leaves the field.

What is checked:
    GSTIN   15 characters in the right pattern; the check digit (mod-36 checksum); the state
            code (01-38, 97) and its state; the PAN inside it; intra-state (CGST + SGST)
            against West Bengal (19) or inter-state (IGST).
    HSN/SAC 4, 6 or 8 digits; SAC (services) when it starts with 99; the goods chapter (01-98).

What is NOT checked, and is never claimed: whether the GSTIN is registered or active, and the
legal business name. Only the GST portal (through a GST Suvidha Provider and credentials) can
say that, so the badge reads "FORMAT VALID", never "ACTIVE".
"""
from __future__ import annotations

from dataclasses import dataclass

from services.gst import STATE_NAMES, check_gstin, check_hsn

PORTAL_NOTE = "registration status and legal name are not checked (that needs the GST portal)"


@dataclass
class CheckResult:
    ok: bool
    badge: str          # short: "FORMAT VALID" / "NOT VALID"
    detail: str


def check_gstin_structure(raw: str, company_state: str = "19") -> CheckResult:
    text = raw.strip().upper().replace(" ", "")
    if not text:
        return CheckResult(True, "", "No GSTIN: an unregistered party.")
    try:
        gstin = check_gstin(text)
    except ValueError as exc:
        return CheckResult(False, "NOT VALID", str(exc))
    code = gstin[:2]
    state = STATE_NAMES.get(code, f"state {code}")
    supply = ("same state as the company: CGST + SGST" if code == company_state
              else f"other state than {STATE_NAMES.get(company_state, company_state)}: IGST")
    return CheckResult(True, "FORMAT VALID",
                       f"{gstin} · {state} ({code}) · PAN {gstin[2:12]} · check digit correct · {supply} · {PORTAL_NOTE}.")


def check_hsn_structure(raw: str) -> CheckResult:
    text = raw.strip().replace(" ", "")
    if not text:
        return CheckResult(False, "NOT VALID", "Enter the HSN/SAC code.")
    try:
        code = check_hsn(text)
    except ValueError as exc:
        return CheckResult(False, "NOT VALID", str(exc))
    if code.startswith("99"):
        return CheckResult(True, "FORMAT VALID", f"SAC {code}: a services code (chapter 99).")
    chapter = int(code[:2])
    if chapter == 0 or chapter == 77 or chapter > 98:
        return CheckResult(False, "NOT VALID", f"HSN {code}: chapter {code[:2]} is not a goods chapter in use.")
    return CheckResult(True, "FORMAT VALID", f"HSN {code}: goods, chapter {code[:2]} ({len(code)} digits).")
