"""
Background script runner and the read-only database check.

Every job runs in a daemon thread with subprocess.run() (same Python interpreter, never a
shell, no keyboard input, with a timeout). Results reach the window only through `post`,
which is SubsystemMonitor.post — so worker threads never touch Tk widgets.

Messages posted:
    ("log",  text)       a line for the monitor
    ("done", task name)  the job finished (the window calls mark_done on the UI thread)
"""
from __future__ import annotations

import subprocess
import sys
import threading
from datetime import datetime
from pathlib import Path
from typing import Callable

from config import settings as S

# Child-process code: opens the database READ-ONLY (never creates or writes it) and prints
# the number of tables. argv[1] is the database's file: URI.
DB_CHECK_CODE = (
    "import sqlite3, sys\n"
    "con = sqlite3.connect(sys.argv[1] + '?mode=ro', uri=True, timeout=5)\n"
    "try:\n"
    "    n = con.execute(\"SELECT count(*) FROM sqlite_master WHERE type='table'\").fetchone()[0]\n"
    "    print(n)\n"
    "finally:\n"
    "    con.close()\n"
)
DB_CHECK_TASK = "database check"
NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0)   # no console flash on Windows


class ScriptRunner:
    def __init__(self, post: Callable[[str, str], None], app_dir: Path = S.APP_DIR) -> None:
        self._post = post
        self.app_dir = app_dir
        self.running: set[str] = set()   # UI thread only (updated through mark_done)

    # ---- UI thread ---------------------------------------------------------------------
    def mark_done(self, task: str) -> None:
        self.running.discard(task)

    def run_script(self, script: str, title: str, keywords: tuple[str, ...] | None = None) -> bool:
        """Starts `script` (a file beside main.py) in the background. False if not started."""
        path = self.app_dir / script
        if not path.is_file():
            self._post("log", f"[{title}] {script} not found in {self.app_dir}.")
            return False
        if script in self.running:
            self._post("log", f"[{title}] {script} is already running.")
            return False
        self.running.add(script)
        self._post("log", f"[{title}] running {script} …")
        threading.Thread(target=self._script_worker, args=(path, title, keywords), daemon=True).start()
        return True

    def check_database(self, title: str, followup: str | None = None) -> bool:
        """Opens bizpulse_local.db read-only in a child process and counts its tables.
        followup: an extra monitor line after a successful check."""
        db = self.app_dir / S.LOCAL_DB
        if not db.is_file():
            self._post("log", f"[{title}] database check failed: {S.LOCAL_DB} not found in {self.app_dir}.")
            return False
        if DB_CHECK_TASK in self.running:
            self._post("log", f"[{title}] a database check is already running.")
            return False
        self.running.add(DB_CHECK_TASK)
        self._post("log", f"[{title}] checking database connection …")
        threading.Thread(target=self._db_check_worker, args=(db, title, followup), daemon=True).start()
        return True

    def describe_local_database(self) -> str:
        """Start-up presence check: reads the 16-byte header only, never opens or locks the file."""
        db = self.app_dir / S.LOCAL_DB
        if not db.is_file():
            return f"WARNING: {S.LOCAL_DB} not found in {self.app_dir}. Scripts that need it will fail."
        try:
            with db.open("rb") as fh:
                header = fh.read(len(S.SQLITE_HEADER))
            st = db.stat()
        except OSError as exc:
            return f"WARNING: {S.LOCAL_DB} found but cannot be read: {exc}"
        if header != S.SQLITE_HEADER:
            return f"WARNING: {S.LOCAL_DB} is not a SQLite database (or is damaged). Check it before running database scripts."
        stamp = datetime.fromtimestamp(st.st_mtime).strftime("%d-%m-%Y %H:%M")
        return f"Local database found: {S.LOCAL_DB} ({st.st_size / 1024:,.0f} KB, last changed {stamp})."

    # ---- worker threads ----------------------------------------------------------------
    def _script_worker(self, path: Path, title: str, keywords: tuple[str, ...] | None) -> None:
        try:
            result = subprocess.run(
                [sys.executable, str(path)],
                cwd=str(self.app_dir), capture_output=True, stdin=subprocess.DEVNULL,
                text=True, encoding="utf-8", errors="replace",
                timeout=S.SCRIPT_TIMEOUT_S, creationflags=NO_WINDOW,
            )
            lines = [ln.rstrip() for ln in result.stdout.splitlines() if ln.strip()]
            failed = result.returncode != 0
            if keywords:
                # A summary is shown only when the script finished cleanly, so a crash
                # half-way through never passes for a complete report.
                if failed:
                    lines = []
                else:
                    lines = [ln for ln in lines if any(k in ln.upper() for k in keywords)]
                    if not lines:
                        self._post("log", f"[{title}] finished: no {' or '.join(keywords)} lines reported.")
            for ln in lines:
                self._post("log", f"[{title}] {ln}")
            if failed:
                err = (result.stderr.strip().splitlines() or ["(no error text)"])[-1]
                self._post("log", f"[{title}] exited with code {result.returncode}: {err}")
                if keywords:
                    self._post("log", f"[{title}] summary not shown because the script did not finish cleanly.")
            else:
                self._post("log", f"[{title}] done.")
        except subprocess.TimeoutExpired:
            self._post("log", f"[{title}] stopped: no finish after {S.SCRIPT_TIMEOUT_S} s.")
        except OSError as exc:
            self._post("log", f"[{title}] could not start: {exc}")
        finally:
            self._post("done", path.name)

    def _db_check_worker(self, db: Path, title: str, followup: str | None) -> None:
        try:
            result = subprocess.run(
                [sys.executable, "-c", DB_CHECK_CODE, db.resolve().as_uri()],
                cwd=str(self.app_dir), capture_output=True, stdin=subprocess.DEVNULL,
                text=True, encoding="utf-8", errors="replace",
                timeout=S.DB_CHECK_TIMEOUT_S, creationflags=NO_WINDOW,
            )
            out = result.stdout.strip()
            if result.returncode == 0 and out.isdigit():
                self._post("log", f"[{title}] database connected: {S.LOCAL_DB} ({out} tables, opened read-only).")
                if followup:
                    self._post("log", f"[{title}] {followup}")
            else:
                err = (result.stderr.strip().splitlines() or ["(no error text)"])[-1]
                self._post("log", f"[{title}] database check failed: {err}")
        except subprocess.TimeoutExpired:
            self._post("log", f"[{title}] database check stopped: no answer after {S.DB_CHECK_TIMEOUT_S} s (database busy?).")
        except OSError as exc:
            self._post("log", f"[{title}] database check could not start: {exc}")
        finally:
            self._post("done", DB_CHECK_TASK)
