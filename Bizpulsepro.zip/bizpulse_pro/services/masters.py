"""
Masters created in BizPulse Pro (Masters › Create / Alter): Groups, Ledgers, GST Classifications.

Tables (BizPulse's own, created on first save; your existing tables are not changed):

    bp_groups               name, under_group                          new groups under the 28 reserved ones
    bp_ledgers              name, under_group, mailing_name, address,  ledgers, with opening balance in paise
                            state, pan, gstin, opening_paise            (+ = Dr, - = Cr)
    bp_gst_classifications  name, hsn_sac, gst_rate, cess_type

Everything is checked here before it is written (the forms check too, but this is the last
word): text is trimmed, inner runs of spaces collapsed, control characters refused; names are
unique without regard to capitals; a ledger cannot share a group's name; an "Under" group must
exist; a group cannot be put under itself or its own sub-group; PAN, GSTIN (checksum), HSN/SAC
and the GST rate are validated; a GSTIN must match the State and the PAN; Profit & Loss
ledgers cannot carry an opening balance. Every write is one transaction (BEGIN IMMEDIATE) with
parameters only — no text is pasted into SQL. Call these from a background thread; they never
touch Tk.

How the reports use them (services/reports.py): a ledger here is placed by its group (a new
group counts as the reserved group it sits under), and its opening balance is part of the
Balance Sheet. A ledger here takes precedence over the same name in config/ledger_groups.py.
"""
from __future__ import annotations

import re
import sqlite3
from datetime import datetime
from decimal import Decimal, InvalidOperation
from pathlib import Path

from config.ledger_groups import PROFIT_AND_LOSS_GROUPS, RESERVED_GROUPS
from config.settings import GST_RATES
from services import audit
from services.gst import STATE_CODE_OF, STATE_NAMES, check_gstin, check_hsn

DDL = """
CREATE TABLE IF NOT EXISTS bp_groups (
    name          TEXT PRIMARY KEY COLLATE NOCASE,
    under_group   TEXT NOT NULL,
    created_at    TEXT NOT NULL,
    updated_at    TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS bp_ledgers (
    name          TEXT PRIMARY KEY COLLATE NOCASE,
    under_group   TEXT NOT NULL,
    mailing_name  TEXT NOT NULL DEFAULT '',
    address       TEXT NOT NULL DEFAULT '',
    state         TEXT NOT NULL DEFAULT '',
    pan           TEXT NOT NULL DEFAULT '',
    gstin         TEXT NOT NULL DEFAULT '',
    opening_paise INTEGER NOT NULL DEFAULT 0,      -- + Dr, - Cr
    created_at    TEXT NOT NULL,
    updated_at    TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS bp_gst_classifications (
    name          TEXT PRIMARY KEY COLLATE NOCASE,
    hsn_sac       TEXT NOT NULL,
    gst_rate      TEXT NOT NULL,
    cess_type     TEXT NOT NULL,
    created_at    TEXT NOT NULL,
    updated_at    TEXT NOT NULL
)
"""
CESS_TYPES = ["None", "Based on Value %", "Based on Quantity per Unit"]
PAN_RE = re.compile(r"^[A-Z]{5}[0-9]{4}[A-Z]$")
CONTROL = re.compile(r"[\x00-\x1f\x7f]")
MAX_NAME, MAX_TEXT = 60, 200
CENT = Decimal("0.01")


class MasterError(Exception):
    """A message the user can act on; nothing was saved."""


def clean(raw: str, what: str, required: bool = False, limit: int = MAX_TEXT) -> str:
    text = " ".join(str(raw or "").split())
    if CONTROL.search(text):
        raise MasterError(f"{what} contains a control character.")
    if required and not text:
        raise MasterError(f"Enter the {what}.")
    if len(text) > limit:
        raise MasterError(f"{what} is longer than {limit} characters.")
    return text


def check_pan(raw: str) -> str:
    pan = raw.strip().upper().replace(" ", "")
    if pan and not PAN_RE.match(pan):
        raise MasterError("PAN must look like ABCDE1234F (5 letters, 4 digits, 1 letter).")
    return pan


def parse_opening(raw: str) -> Decimal:
    text = str(raw or "").replace(",", "").replace("₹", "").strip()
    if not text:
        return Decimal("0.00")
    try:
        value = Decimal(text)
    except InvalidOperation:
        raise MasterError(f"Opening balance '{raw}' is not an amount.") from None
    if not value.is_finite() or value < 0 or value != value.quantize(CENT) or value > Decimal("999999999999.99"):
        raise MasterError("Opening balance must be a positive amount with at most 2 decimals (choose Dr or Cr).")
    return value.quantize(CENT)


class MasterStore:
    def __init__(self, db_path: Path) -> None:
        self.db_path = Path(db_path)

    # ---- connection --------------------------------------------------------------------
    def _connect(self, write: bool = False) -> sqlite3.Connection:
        if not self.db_path.is_file():
            raise MasterError(f"{self.db_path.name} was not found in {self.db_path.parent}. Nothing was saved.")
        try:
            if write:
                return sqlite3.connect(str(self.db_path), timeout=5, isolation_level=None)
            return sqlite3.connect(self.db_path.resolve().as_uri() + "?mode=ro", uri=True, timeout=5)
        except sqlite3.Error as exc:
            raise MasterError(f"Could not open {self.db_path.name}: {exc}") from exc

    @staticmethod
    def _has(con: sqlite3.Connection, table: str) -> bool:
        return con.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", (table,)).fetchone() is not None

    def _read(self, sql: str, args: tuple = (), table: str = "") -> list[tuple]:
        try:
            con = self._connect()
        except MasterError:
            return []
        try:
            if table and not self._has(con, table):
                return []
            return con.execute(sql, args).fetchall()
        except sqlite3.Error:
            return []
        finally:
            con.close()

    # ---- reads -------------------------------------------------------------------------
    def custom_groups(self) -> dict[str, str]:
        return dict(self._read("SELECT name, under_group FROM bp_groups ORDER BY name COLLATE NOCASE",
                               table="bp_groups"))

    def group_names(self) -> list[str]:
        """The 28 reserved groups, then the new ones."""
        return list(RESERVED_GROUPS) + [g for g in self.custom_groups() if g not in RESERVED_GROUPS]

    def group_catalogue(self) -> list[tuple[str, list[str]]]:
        custom = sorted(self.custom_groups(), key=str.lower)
        return [("Reserved groups", list(RESERVED_GROUPS))] + ([("Your groups", custom)] if custom else [])

    def ledger_names(self) -> list[str]:
        return [r[0] for r in self._read("SELECT name FROM bp_ledgers ORDER BY name COLLATE NOCASE", table="bp_ledgers")]

    def classification_names(self) -> list[str]:
        return [r[0] for r in self._read("SELECT name FROM bp_gst_classifications ORDER BY name COLLATE NOCASE",
                                         table="bp_gst_classifications")]

    def load(self, kind: str, name: str) -> dict | None:
        """One master's values in the form's field names (Alter)."""
        if kind == "Group":
            rows = self._read("SELECT name, under_group FROM bp_groups WHERE name = ?", (name.strip(),), "bp_groups")
            return {"name": rows[0][0], "under": rows[0][1]} if rows else None
        if kind == "Ledger":
            rows = self._read("SELECT name, under_group, mailing_name, address, state, pan, gstin, opening_paise "
                              "FROM bp_ledgers WHERE name = ?", (name.strip(),), "bp_ledgers")
            if not rows:
                return None
            n, under, mail, addr, state, pan, gstin, paise = rows[0]
            amount = (Decimal(abs(paise)) / 100).quantize(CENT)
            return {"name": n, "under": under, "mailing_name": mail, "address": addr, "state": state, "pan": pan,
                    "gstin": gstin, "opening": f"{amount:.2f}" if paise else "", "drcr": "Cr" if paise < 0 else "Dr"}
        if kind == "GST Classification":
            rows = self._read("SELECT name, hsn_sac, gst_rate, cess_type FROM bp_gst_classifications WHERE name = ?",
                              (name.strip(),), "bp_gst_classifications")
            return dict(zip(("name", "hsn", "rate", "cess"), rows[0])) if rows else None
        return None

    def primary_of(self, group: str, custom: dict[str, str] | None = None) -> str | None:
        """The reserved group a (possibly new) group sits under; None if unknown or circular."""
        custom = self.custom_groups() if custom is None else custom
        lower = {k.lower(): (k, v) for k, v in custom.items()}
        seen = set()
        while group and group not in RESERVED_GROUPS:
            key = group.lower()
            if key in seen or key not in lower:
                return None
            seen.add(key)
            group = lower[key][1]
        return group or None

    # ---- writes ------------------------------------------------------------------------
    def _write(self, statements: list[tuple[str, tuple]]) -> None:
        con = self._connect(write=True)
        try:
            con.execute("BEGIN IMMEDIATE")
            for stmt in filter(None, (s.strip() for s in DDL.split(";"))):
                con.execute(stmt)
            audit.begin(con, source="BizPulse Masters", mode="row")     # the row triggers log each change
            for sql, args in statements:
                con.execute(sql, args)
            audit.end(con)
            con.execute("COMMIT")
        except sqlite3.Error as exc:
            if con.in_transaction:
                con.execute("ROLLBACK")
            if isinstance(exc, sqlite3.IntegrityError):
                raise MasterError(f"Not saved: that name already exists ({exc}).") from exc
            if "locked" in str(exc).lower():
                raise MasterError("The database is busy (another program is writing to it). Try again.") from exc
            raise MasterError(f"Not saved: {exc}") from exc
        finally:
            con.close()

    def _name_free(self, name: str, kind: str, alter: bool) -> None:
        low = name.lower()
        groups = {g.lower() for g in self.group_names()}
        ledgers = {n.lower() for n in self.ledger_names()}
        classes = {n.lower() for n in self.classification_names()}
        if kind == "Group":
            if low in {g.lower() for g in RESERVED_GROUPS}:
                raise MasterError(f"'{name}' is a reserved group; choose another name.")
            if low in ledgers:
                raise MasterError(f"'{name}' is already a ledger.")
            if not alter and low in groups:
                raise MasterError(f"Group '{name}' already exists.")
            if alter and low not in groups:
                raise MasterError(f"Group '{name}' does not exist.")
        elif kind == "Ledger":
            if low in groups:
                raise MasterError(f"'{name}' is already a group.")
            if not alter and low in ledgers:
                raise MasterError(f"Ledger '{name}' already exists.")
            if alter and low not in ledgers:
                raise MasterError(f"Ledger '{name}' does not exist.")
        else:
            if not alter and low in classes:
                raise MasterError(f"GST Classification '{name}' already exists.")
            if alter and low not in classes:
                raise MasterError(f"GST Classification '{name}' does not exist.")

    def save_group(self, values: dict, alter: bool = False) -> str:
        name = clean(values.get("name"), "Group Name", required=True, limit=MAX_NAME)
        under = clean(values.get("under"), "Under group", required=True, limit=MAX_NAME)
        self._name_free(name, "Group", alter)
        custom = self.custom_groups()
        match = next((g for g in self.group_names() if g.lower() == under.lower()), None)
        if match is None:
            raise MasterError(f"Under group '{under}' does not exist.")
        trial = {k: v for k, v in custom.items() if k.lower() != name.lower()}
        trial[name] = match
        if self.primary_of(name, trial) is None:
            raise MasterError(f"'{name}' cannot be put under '{match}' (that is inside '{name}' itself).")
        now = datetime.now().isoformat(timespec="seconds")
        if alter:
            self._write([("UPDATE bp_groups SET under_group = ?, updated_at = ? WHERE name = ?", (match, now, name))])
        else:
            self._write([("INSERT INTO bp_groups (name, under_group, created_at, updated_at) VALUES (?, ?, ?, ?)",
                          (name, match, now, now))])
        return f"Group '{name}' {'altered' if alter else 'created'} under {match}."

    def save_ledger(self, values: dict, alter: bool = False) -> str:
        name = clean(values.get("name"), "Ledger Name", required=True, limit=MAX_NAME)
        under = clean(values.get("under"), "Under group", required=True, limit=MAX_NAME)
        self._name_free(name, "Ledger", alter)
        match = next((g for g in self.group_names() if g.lower() == under.lower()), None)
        if match is None:
            raise MasterError(f"Under group '{under}' does not exist.")
        primary = self.primary_of(match)
        mailing = clean(values.get("mailing_name"), "Mailing Name", limit=MAX_NAME) or name
        address = clean(values.get("address"), "Address")
        state = clean(values.get("state"), "State", limit=MAX_NAME)
        code = ""
        if state:
            code = STATE_CODE_OF.get(state.lower(), "")
            if not code:
                raise MasterError(f"State '{state}' is not a state or union territory name.")
            state = STATE_NAMES[code]
        pan = check_pan(values.get("pan", ""))
        try:
            gstin = check_gstin(values.get("gstin", ""))
        except ValueError as exc:
            raise MasterError(str(exc)) from None
        if gstin:
            if code and gstin[:2] != code:
                raise MasterError(f"GSTIN {gstin} is from state {gstin[:2]}, but the State is {state} ({code}).")
            if pan and gstin[2:12] != pan:
                raise MasterError(f"GSTIN {gstin} does not contain the PAN {pan}.")
        amount = parse_opening(values.get("opening", ""))
        side = (values.get("drcr") or "Dr").strip().title()
        if side not in ("Dr", "Cr"):
            raise MasterError("Opening balance side must be Dr or Cr.")
        if amount and primary in PROFIT_AND_LOSS_GROUPS:
            raise MasterError(f"{match} is a Profit & Loss group: its ledgers start each year at nil, "
                              "so leave the opening balance blank.")
        paise = int(amount * 100) * (1 if side == "Dr" else -1)
        now = datetime.now().isoformat(timespec="seconds")
        if alter:
            self._write([("UPDATE bp_ledgers SET under_group = ?, mailing_name = ?, address = ?, state = ?, pan = ?, "
                          "gstin = ?, opening_paise = ?, updated_at = ? WHERE name = ?",
                          (match, mailing, address, state, pan, gstin, paise, now, name))])
        else:
            self._write([("INSERT INTO bp_ledgers (name, under_group, mailing_name, address, state, pan, gstin, "
                          "opening_paise, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                          (name, match, mailing, address, state, pan, gstin, paise, now, now))])
        opening = f", opening {amount:,.2f} {side}" if amount else ""
        return f"Ledger '{name}' {'altered' if alter else 'created'} under {match}{opening}."

    def save_classification(self, values: dict, alter: bool = False) -> str:
        name = clean(values.get("name"), "Classification Name", required=True, limit=MAX_NAME)
        self._name_free(name, "GST Classification", alter)
        try:
            hsn = check_hsn(values.get("hsn", ""))
        except ValueError as exc:
            raise MasterError(str(exc)) from None
        rate = str(values.get("rate", "")).strip().rstrip("%").strip()
        if rate not in GST_RATES:
            raise MasterError(f"GST Rate must be one of {', '.join(GST_RATES)} %.")
        cess = clean(values.get("cess"), "Cess Type") or "None"
        cess = next((c for c in CESS_TYPES if c.lower() == cess.lower()), None)
        if cess is None:
            raise MasterError(f"Cess Type must be one of: {', '.join(CESS_TYPES)}.")
        now = datetime.now().isoformat(timespec="seconds")
        if alter:
            self._write([("UPDATE bp_gst_classifications SET hsn_sac = ?, gst_rate = ?, cess_type = ?, updated_at = ? "
                          "WHERE name = ?", (hsn, rate, cess, now, name))])
        else:
            self._write([("INSERT INTO bp_gst_classifications (name, hsn_sac, gst_rate, cess_type, created_at, "
                          "updated_at) VALUES (?, ?, ?, ?, ?, ?)", (name, hsn, rate, cess, now, now))])
        return f"GST Classification '{name}' {'altered' if alter else 'created'}: HSN/SAC {hsn}, {rate} %, cess {cess}."
