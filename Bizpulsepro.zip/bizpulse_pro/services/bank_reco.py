"""
Bank reconciliation helper: your bank book (vouchers on a bank ledger) against a statement
file from the bank, matched by date and amount.

    bank_ledgers(db_path)                         ledgers grouped Bank Accounts / Bank OD A/c
    bank_book(db_path, ledger)                    one entry per voucher: +deposit / -withdrawal
    read_statement(path)                          the bank's CSV (or .txt) statement
    match(book, statement)                        pairs with the same date, amount and direction
    record_matches(db_path, ledger, pairs, file)  the audit trail (bp_bank_reconciliation)

Statement files: comma, semicolon or tab separated, with a header row somewhere in the first
20 lines. Recognised headings (any capitals): a date column (Date, Txn Date, Transaction Date,
Value Date), a description (Description, Narration, Particulars, Remarks), and either
Withdrawal/Debit + Deposit/Credit columns, or one Amount column (negative or marked Dr =
withdrawal). Dates like 05-10-2026, 05/10/2026, 2026-10-05, 05-Oct-2026 and 05/10/26 are read.
Rows whose date cannot be read are skipped and counted.

Matching is one-to-one: each bank-book entry and each statement row is used once, earliest
first. Entries already in the audit trail are shown as matched and are not paired again. The
trail table is BizPulse's own; nothing else in the database is changed.
"""
from __future__ import annotations

import csv
import sqlite3
from dataclasses import dataclass, field
from datetime import date, datetime
from decimal import Decimal, InvalidOperation
from pathlib import Path

from services.reports import _group_lookup, connect_ro, has_table, live_filter

BANK_GROUPS = ("Bank Accounts", "Bank OD A/c")
DATE_FORMATS = ("%d-%m-%Y", "%d/%m/%Y", "%Y-%m-%d", "%d-%b-%Y", "%d %b %Y", "%d/%m/%y", "%d-%m-%y", "%d-%b-%y",
                "%d.%m.%Y")
DATE_HEADS = ("date", "txn date", "transaction date", "value date", "tran date", "posting date")
DESC_HEADS = ("description", "narration", "particulars", "remarks", "details", "transaction details")
OUT_HEADS = ("withdrawal", "withdrawals", "withdrawal amt", "withdrawal amount", "debit", "debit amount", "dr")
IN_HEADS = ("deposit", "deposits", "deposit amt", "deposit amount", "credit", "credit amount", "cr")
AMOUNT_HEADS = ("amount", "transaction amount", "amt")
CENT = Decimal("0.01")

DDL = """CREATE TABLE IF NOT EXISTS bp_bank_reconciliation (
    id                    INTEGER PRIMARY KEY AUTOINCREMENT,
    bank_ledger           TEXT NOT NULL,
    voucher_id            INTEGER NOT NULL,
    voucher_date          TEXT NOT NULL,
    amount_paise          INTEGER NOT NULL,          -- + deposit, - withdrawal
    statement_date        TEXT NOT NULL,
    statement_description TEXT NOT NULL DEFAULT '',
    statement_file        TEXT NOT NULL DEFAULT '',
    matched_at            TEXT NOT NULL,
    UNIQUE (bank_ledger, voucher_id)
)"""


class RecoError(Exception):
    pass


@dataclass
class BookEntry:
    voucher_id: int
    date: date
    vtype: str
    number: str
    particulars: str
    amount: Decimal               # + deposit, - withdrawal
    matched: bool = False


@dataclass
class StatementRow:
    line: int
    date: date
    description: str
    amount: Decimal
    matched: bool = False


@dataclass
class Statement:
    rows: list[StatementRow]
    skipped: int = 0
    notes: list[str] = field(default_factory=list)


# ---- bank book ------------------------------------------------------------------------------
def bank_ledgers(db_path: Path) -> list[str]:
    from config.ledger_groups import LEDGER_GROUPS
    con = connect_ro(db_path)
    try:
        lookup = _group_lookup(con)
        names = {n.strip().lower(): n.strip() for n, g in LEDGER_GROUPS.items() if g in BANK_GROUPS}
        if has_table(con, "bp_ledgers"):
            for (n,) in con.execute("SELECT name FROM bp_ledgers"):
                if lookup.get(n.strip().lower()) in BANK_GROUPS:
                    names[n.strip().lower()] = n.strip()
        if has_table(con, "bp_voucher_lines"):
            for (n,) in con.execute("SELECT DISTINCT ledger FROM bp_voucher_lines"):
                if lookup.get(n.strip().lower()) in BANK_GROUPS:
                    names.setdefault(n.strip().lower(), n.strip())
        return sorted(names.values(), key=str.lower)
    finally:
        con.close()


def bank_book(db_path: Path, ledger: str) -> list[BookEntry]:
    con = connect_ro(db_path)
    try:
        if not has_table(con, "bp_vouchers"):
            return []
        rows = con.execute(
            "SELECT v.id, v.voucher_date, v.voucher_type, coalesce(v.invoice_no, v.voucher_no), "
            "sum(CASE l.side WHEN 'Dr' THEN l.amount_paise ELSE -l.amount_paise END) "
            "FROM bp_voucher_lines l JOIN bp_vouchers v ON v.id = l.voucher_id "
            f"WHERE lower(trim(l.ledger)) = lower(trim(?)){live_filter(con)} "
            "GROUP BY v.id ORDER BY v.voucher_date, v.id", (ledger,)).fetchall()
        done = set()
        if has_table(con, "bp_bank_reconciliation"):
            done = {r[0] for r in con.execute("SELECT voucher_id FROM bp_bank_reconciliation "
                                              "WHERE lower(bank_ledger) = lower(?)", (ledger,))}
        out = []
        for vid, vdate, vtype, number, paise in rows:
            if not paise:
                continue
            other = con.execute("SELECT ledger FROM bp_voucher_lines WHERE voucher_id = ? AND "
                                "lower(trim(ledger)) != lower(trim(?)) ORDER BY line_no LIMIT 1", (vid, ledger)).fetchone()
            out.append(BookEntry(vid, date.fromisoformat(vdate), vtype, str(number), other[0] if other else "",
                                 (Decimal(paise) / 100).quantize(CENT), vid in done))
        return out
    finally:
        con.close()


def reconciled_trail(db_path: Path, ledger: str) -> list[tuple[str, int, str]]:
    """(statement_date, amount_paise, description) already matched for this ledger."""
    con = connect_ro(db_path)
    try:
        if not has_table(con, "bp_bank_reconciliation"):
            return []
        return con.execute("SELECT statement_date, amount_paise, statement_description FROM bp_bank_reconciliation "
                           "WHERE lower(bank_ledger) = lower(?)", (ledger,)).fetchall()
    finally:
        con.close()


# ---- statement file ---------------------------------------------------------------------------
def _date(text: str) -> date | None:
    text = text.strip()
    for fmt in DATE_FORMATS:
        try:
            return datetime.strptime(text, fmt).date()
        except ValueError:
            continue
    return None


def _amount(text: str) -> Decimal | None:
    raw = str(text).replace(",", "").replace("₹", "").replace("INR", "").strip()
    sign = 1
    if raw.upper().endswith("DR"):
        raw, sign = raw[:-2].strip(), -1
    elif raw.upper().endswith("CR"):
        raw = raw[:-2].strip()
    if raw.startswith("(") and raw.endswith(")"):
        raw, sign = raw[1:-1], -1
    if not raw or raw in ("-", "--"):
        return None
    try:
        return (Decimal(raw) * sign).quantize(CENT)
    except InvalidOperation:
        return None


def read_statement(path: Path) -> Statement:
    path = Path(path)
    try:
        text = path.read_text(encoding="utf-8-sig", errors="replace")
    except OSError as exc:
        raise RecoError(f"Could not read {path.name}: {exc}") from exc
    sample = text[:4096]
    delimiter = max((",", ";", "\t"), key=sample.count)
    table = list(csv.reader(text.splitlines(), delimiter=delimiter))
    header_at, cols = None, {}
    for i, row in enumerate(table[:20]):
        heads = [c.strip().lower() for c in row]
        d = next((j for j, h in enumerate(heads) if h in DATE_HEADS), None)
        if d is None:
            continue
        cols = {"date": d,
                "desc": next((j for j, h in enumerate(heads) if h in DESC_HEADS), None),
                "out": next((j for j, h in enumerate(heads) if h in OUT_HEADS), None),
                "in": next((j for j, h in enumerate(heads) if h in IN_HEADS), None),
                "amount": next((j for j, h in enumerate(heads) if h in AMOUNT_HEADS), None)}
        if (cols["out"] is not None and cols["in"] is not None) or cols["amount"] is not None:
            header_at = i
            break
    if header_at is None:
        raise RecoError(f"{path.name}: no header row with a Date column and Withdrawal/Deposit (or Amount) "
                        "columns was found in the first 20 lines.")
    out = Statement([])
    for n, row in enumerate(table[header_at + 1:], start=header_at + 2):
        if not any(c.strip() for c in row):
            continue
        get = lambda k: row[cols[k]] if cols[k] is not None and cols[k] < len(row) else ""  # noqa: E731
        d = _date(get("date"))
        if d is None:
            out.skipped += 1
            continue
        if cols["out"] is not None and cols["in"] is not None:
            w, dep = _amount(get("out")), _amount(get("in"))
            amount = (abs(dep) if dep else Decimal("0")) - (abs(w) if w else Decimal("0"))
        else:
            amount = _amount(get("amount")) or Decimal("0")
        if not amount:
            out.skipped += 1
            continue
        out.rows.append(StatementRow(n, d, get("desc").strip(), amount.quantize(CENT)))
    if out.skipped:
        out.notes.append(f"{out.skipped} line(s) without a readable date or amount were skipped.")
    return out


# ---- matching ---------------------------------------------------------------------------------
def mark_previous(statement: Statement, trail: list[tuple[str, int, str]]) -> int:
    """Statement rows already in the audit trail are shown as matched."""
    pool = [(d, p, desc) for d, p, desc in trail]
    count = 0
    for row in statement.rows:
        key = (row.date.isoformat(), int(row.amount * 100), row.description)
        if key in pool:
            pool.remove(key)
            row.matched = True
            count += 1
    return count


def match(book: list[BookEntry], statement: Statement) -> list[tuple[BookEntry, StatementRow]]:
    """Same date, same amount, same direction; one-to-one, earliest first."""
    free = [r for r in statement.rows if not r.matched]
    pairs = []
    for entry in book:
        if entry.matched:
            continue
        hit = next((r for r in free if r.date == entry.date and r.amount == entry.amount), None)
        if hit is not None:
            free.remove(hit)
            pairs.append((entry, hit))
    return pairs


def record_matches(db_path: Path, ledger: str, pairs: list[tuple[BookEntry, StatementRow]], file_name: str) -> int:
    """Writes the audit trail (one transaction). Returns how many pairs were recorded."""
    if not pairs:
        return 0
    con = sqlite3.connect(str(db_path), timeout=5, isolation_level=None)
    try:
        con.execute("BEGIN IMMEDIATE")
        con.execute(DDL)
        now = datetime.now().isoformat(timespec="seconds")
        added = 0
        for entry, row in pairs:
            cur = con.execute(
                "INSERT OR IGNORE INTO bp_bank_reconciliation (bank_ledger, voucher_id, voucher_date, amount_paise, "
                "statement_date, statement_description, statement_file, matched_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                (ledger, entry.voucher_id, entry.date.isoformat(), int(entry.amount * 100), row.date.isoformat(),
                 row.description, file_name, now))
            added += cur.rowcount
        con.execute("COMMIT")
        return added
    except sqlite3.Error as exc:
        if con.in_transaction:
            con.execute("ROLLBACK")
        raise RecoError(f"Matches not recorded: {exc}") from exc
    finally:
        con.close()
