"""
Stock Summary figures: quantities from inventory_stock_registry, rates from
inventory_pricing_rules. Read-only (mode=ro); nothing is written.

    load_stock_summary(db_path, rate_column=None) -> StockSummary

inventory_stock_registry (your table): product_sku, qty_on_hand, min_safety_floor, last_audit_date.

inventory_pricing_rules: its layout is read from the database itself, because the app does not
fix it. The SKU column is the first of SKU_COLUMNS that exists; the rate column is the one
named in config/stock_valuation.py (STOCK_RATE_COLUMN), or else the first of COST_COLUMNS, or else the first of
PRICE_COLUMNS. A selling price is not a valuation rate, so if only a selling price is found the
screen says the stock is valued at selling price. When a SKU has several rules, the newest one
is used (by the first of DATE_COLUMNS that exists, else the last row entered).

Value = quantity × rate, rounded to paise. SKUs with no rate are listed with their quantity
and left out of the value total (the screen counts them).
"""
from __future__ import annotations

import sqlite3
from dataclasses import dataclass, field
from decimal import Decimal, InvalidOperation
from pathlib import Path

from services.reports import ZERO, ReportError, connect_ro, has_table

REGISTRY = "inventory_stock_registry"
PRICING = "inventory_pricing_rules"
SKU_COLUMNS = ("product_sku", "sku", "item_sku", "product_code", "item_code")
COST_COLUMNS = ("cost_price", "unit_cost", "cost_rate", "purchase_rate", "purchase_price", "valuation_rate",
                "cost", "landed_cost")
PRICE_COLUMNS = ("rate", "unit_rate", "unit_price", "base_price", "price", "standard_rate", "list_price",
                 "selling_price", "sale_price", "mrp")
SELLING_COLUMNS = {"selling_price", "sale_price", "mrp", "list_price"}
DATE_COLUMNS = ("effective_from", "effective_date", "valid_from", "start_date", "updated_at", "last_updated",
                "created_at")
CENT = Decimal("0.01")


@dataclass
class StockLine:
    sku: str
    quantity: int
    rate: Decimal | None
    value: Decimal | None
    min_floor: int | None
    last_audit: str | None

    @property
    def below_floor(self) -> bool:
        return self.min_floor is not None and self.quantity < self.min_floor


@dataclass
class StockSummary:
    lines: list[StockLine]
    total_quantity: int
    total_value: Decimal
    rate_source: str                       # e.g. "inventory_pricing_rules.cost_price"
    notes: list[str] = field(default_factory=list)

    @property
    def unpriced(self) -> int:
        return sum(1 for ln in self.lines if ln.rate is None)

    @property
    def at_cost(self) -> bool:
        """True when the rate column is a cost (not a selling price / MRP): only then may the
        value go into the books (services/reports.py)."""
        if self.rate_source == "none":
            return False
        return self.rate_source.split(".", 1)[1].lower() not in SELLING_COLUMNS


def _columns(con: sqlite3.Connection, table: str) -> list[str]:
    return [r[1] for r in con.execute(f'PRAGMA table_info("{table}")')]


def _decimal(x) -> Decimal | None:
    if x is None or x == "":
        return None
    try:
        return Decimal(str(x))
    except InvalidOperation:
        return None


def _pick(cols: list[str], candidates) -> str | None:
    lower = {c.lower(): c for c in cols}
    return next((lower[c] for c in candidates if c in lower), None)


def _rates(con: sqlite3.Connection, rate_column: str | None, notes: list[str]) -> tuple[dict[str, Decimal], str]:
    if not has_table(con, PRICING):
        notes.append(f"{PRICING} was not found, so no item is valued.")
        return {}, "none"
    cols = _columns(con, PRICING)
    sku_col = _pick(cols, SKU_COLUMNS)
    if rate_column:
        rate_col = _pick(cols, (rate_column.lower(),))
        if rate_col is None:
            notes.append(f"STOCK_RATE_COLUMN is '{rate_column}', but {PRICING} has no such column "
                         f"(it has: {', '.join(cols)}). No item is valued.")
            return {}, "none"
    else:
        rate_col = _pick(cols, COST_COLUMNS) or _pick(cols, PRICE_COLUMNS)
    if sku_col is None or rate_col is None:
        notes.append(f"Could not tell which columns of {PRICING} hold the SKU and the rate (it has: "
                     f"{', '.join(cols)}). Set STOCK_RATE_COLUMN in config/stock_valuation.py. No item is valued.")
        return {}, "none"
    date_col = _pick(cols, DATE_COLUMNS)
    order = f'"{date_col}", rowid' if date_col else "rowid"
    rates: dict[str, Decimal] = {}
    counts: dict[str, int] = {}
    for sku, rate in con.execute(f'SELECT "{sku_col}", "{rate_col}" FROM "{PRICING}" ORDER BY {order}'):
        if sku is None:
            continue
        key = str(sku).strip().upper()
        counts[key] = counts.get(key, 0) + 1
        value = _decimal(rate)
        if value is not None:
            rates[key] = value               # later rows (newer) replace earlier ones
    multi = sum(1 for n in counts.values() if n > 1)
    if multi:
        notes.append(f"{multi} SKU(s) have more than one pricing rule; the newest "
                     f"({'by ' + date_col if date_col else 'last entered'}) is used.")
    if rate_col.lower() in SELLING_COLUMNS:
        notes.append(f"Valued at {rate_col} (a selling price), not at cost: set STOCK_RATE_COLUMN in "
                     "config/stock_valuation.py to a cost column if you have one.")
    return rates, f"{PRICING}.{rate_col}"


def load_stock_summary(db_path: Path, rate_column: str | None = None) -> StockSummary:
    con = connect_ro(db_path)
    notes: list[str] = []
    try:
        if not has_table(con, REGISTRY):
            raise ReportError(f"{REGISTRY} was not found in {db_path.name}.")
        rates, source = _rates(con, rate_column, notes)
        # Stock Items created in Masters carry an opening rate (cost): used where pricing has none.
        master_rates = {}
        if has_table(con, "bp_stock_items"):
            master_rates = {str(n).strip().upper(): Decimal(p) / 100 for n, p in con.execute(
                "SELECT name, opening_rate_paise FROM bp_stock_items WHERE opening_rate_paise > 0")}
        rows = con.execute(f"SELECT product_sku, qty_on_hand, min_safety_floor, last_audit_date FROM {REGISTRY} "
                           "ORDER BY product_sku COLLATE NOCASE").fetchall()
    except sqlite3.Error as exc:
        raise ReportError(f"Could not read {db_path.name}: {exc}") from exc
    finally:
        con.close()

    lines: list[StockLine] = []
    total_qty, total_value = 0, ZERO
    from_masters = 0
    for sku, qty, floor, audit in rows:
        qty = int(qty or 0)
        rate = rates.get(str(sku).strip().upper())
        if rate is None and str(sku).strip().upper() in master_rates:
            rate = master_rates[str(sku).strip().upper()]
            from_masters += 1
        value = (Decimal(qty) * rate).quantize(CENT) if rate is not None else None
        lines.append(StockLine(str(sku), qty, rate.quantize(CENT) if rate is not None else None, value,
                               int(floor) if floor is not None else None, audit))
        total_qty += qty
        if value is not None:
            total_value += value
    if from_masters:
        if source == "none":
            source = "bp_stock_items.opening_rate"
            notes[:] = [n for n in notes if "no item is valued" not in n.lower()]
        notes.append(f"{from_masters} item(s) valued at the opening rate in their Stock Item master "
                     "(no rate in inventory_pricing_rules).")
    summary = StockSummary(lines, total_qty, total_value.quantize(CENT), source, notes)
    if summary.unpriced and rates:
        notes.append(f"{summary.unpriced} SKU(s) have no rate and are not in the value total.")
    return summary
