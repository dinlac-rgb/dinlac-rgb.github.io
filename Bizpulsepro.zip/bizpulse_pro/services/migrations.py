"""
One-time database upgrades for bizpulse_local.db, run in a background thread at start-up.

    igst_rate        gst_sales_ledger gets `igst_rate REAL NOT NULL DEFAULT 0`, so inter-state
                     sales can be recorded. Existing rows (all intra-state) get 0.
    place_of_supply  gst_sales_ledger gets `place_of_supply TEXT` (2-digit state code), so
                     GSTR-1 can group intra-state / inter-state for registered and unregistered
                     customers. Existing rows are filled in where the answer is certain:
                       - customer has a GSTIN           -> its first two digits
                       - no GSTIN and igst_rate = 0     -> the company's state (e.g. 19), since
                                                           CGST + SGST means the sale was intra-state
                       - no GSTIN and igst_rate > 0     -> left empty (NULL): the state is not
                                                           recorded anywhere; fill it in by hand

Before changing anything, ONE full copy of the database is written beside it
(bizpulse_local.pre-upgrade-YYYYMMDD-HHMMSS.db) using SQLite's online backup, which is safe
even while another program has the database open. If the copy fails, nothing is changed.
All changes run in one transaction. Running again does nothing once the columns exist.
"""
from __future__ import annotations

import sqlite3
from datetime import datetime
from pathlib import Path

from services import audit

SALES_TABLE = "gst_sales_ledger"

# (column, DDL) in the order they are added.
UPGRADES = [
    ("igst_rate", f"ALTER TABLE {SALES_TABLE} ADD COLUMN igst_rate REAL NOT NULL DEFAULT 0"),
    ("place_of_supply", f"ALTER TABLE {SALES_TABLE} ADD COLUMN place_of_supply TEXT"),
]


def _columns(con: sqlite3.Connection, table: str) -> set[str]:
    return {row[1] for row in con.execute(f"PRAGMA table_info({table})")}   # constant table name


def backup_copy(db_path: Path, label: str) -> Path:
    """Consistent copy of the live database next to it. Returns the copy's path."""
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    target = db_path.with_name(f"{db_path.stem}.{label}-{stamp}{db_path.suffix}")
    src = sqlite3.connect(str(db_path), timeout=5)
    try:
        dst = sqlite3.connect(str(target))
        try:
            src.backup(dst)
        finally:
            dst.close()
    finally:
        src.close()
    return target


def upgrade_database(db_path: Path, company_state: str) -> list[str]:
    """Adds any missing gst_sales_ledger columns. Returns lines for the monitor. Never raises."""
    if not db_path.is_file():
        return [f"Database upgrade skipped: {db_path.name} not found."]
    try:
        con = sqlite3.connect(str(db_path), timeout=5, isolation_level=None)
    except sqlite3.Error as exc:
        return [f"Database upgrade skipped: could not open {db_path.name} ({exc})."]
    try:
        cols = _columns(con, SALES_TABLE)
    finally:
        con.close()
    if not cols:
        return [f"Database upgrade skipped: {SALES_TABLE} is not in {db_path.name}."]
    todo = [(name, ddl) for name, ddl in UPGRADES if name not in cols]
    if not todo:
        return [f"{SALES_TABLE} is up to date (igst_rate, place_of_supply)."]

    try:
        copy = backup_copy(db_path, "pre-upgrade")
    except (sqlite3.Error, OSError) as exc:
        return [f"Database upgrade NOT done: the safety copy failed ({exc}). Nothing was changed."]

    messages = []
    con = sqlite3.connect(str(db_path), timeout=5, isolation_level=None)
    try:
        con.execute("BEGIN IMMEDIATE")
        current = _columns(con, SALES_TABLE)            # another copy of the app may have done some
        for name, ddl in todo:
            if name not in current:
                con.execute(ddl)
                messages.append(f"Added {name} to {SALES_TABLE}.")
        audit.ensure(con, refresh=True)                 # the row triggers see the new columns
        audit.begin(con, source="BizPulse upgrade", mode="row")
        if "place_of_supply" not in current:
            filled_gstin = con.execute(
                f"UPDATE {SALES_TABLE} SET place_of_supply = substr(upper(trim(customer_gstin)), 1, 2) "
                "WHERE place_of_supply IS NULL AND customer_gstin IS NOT NULL AND length(trim(customer_gstin)) = 15"
            ).rowcount
            filled_home = con.execute(
                f"UPDATE {SALES_TABLE} SET place_of_supply = ? "
                "WHERE place_of_supply IS NULL AND (customer_gstin IS NULL OR trim(customer_gstin) = '') "
                "AND coalesce(igst_rate, 0) = 0", (company_state,)
            ).rowcount
            unknown = con.execute(
                f"SELECT count(*) FROM {SALES_TABLE} WHERE place_of_supply IS NULL").fetchone()[0]
            messages.append(f"place_of_supply filled for {filled_gstin} row(s) from the GSTIN and {filled_home} "
                            f"unregistered intra-state row(s) as {company_state}.")
            if unknown:
                messages.append(f"{unknown} older row(s) still have no place_of_supply (unregistered customer "
                                "charged IGST): fill them in before filing GSTR-1.")
        audit.end(con)
        con.execute("COMMIT")
    except sqlite3.Error as exc:
        if con.in_transaction:
            con.execute("ROLLBACK")
        return [f"Database upgrade NOT done: {exc}. Nothing was changed (safety copy: {copy.name})."]
    finally:
        con.close()
    messages.append(f"Safety copy made first: {copy.name}.")
    return messages


def ensure_igst_column(db_path: Path, company_state: str = "19") -> str:
    """Kept for earlier callers and tests: runs the full upgrade and returns one line."""
    return " ".join(upgrade_database(db_path, company_state))
