"""
Import › Masters and Import › Vouchers CSV: read a CSV, show what will happen, then post.

    plan_ledgers(path, store) -> list[dict]       READ ONLY: one row per ledger, status Ready / Exists / Error
    post_ledgers(rows, store) -> (done, failed)   MasterStore.save_ledger for each Ready row
    plan_vouchers(path, db_path) -> list[dict]    READ ONLY: one row per voucher (rows grouped by Ref)
    post_vouchers(rows, store) -> (done, failed)  VoucherStore.save for each Ready voucher

Ledger file headings (any capitals): Name (or Ledger / Ledger Name / Account), Under (or Group),
and optionally Opening Balance, Dr/Cr (or a negative opening = Cr), GSTIN, State, PAN, Address.
The group must exist (the 28 reserved groups or one created in Masters).

Voucher file headings: Ref (or Voucher Ref / Entry / Voucher No), Date, Type, Ledger, and either
Debit + Credit columns or Amount + Dr/Cr; optional Narration. Rows with the same Ref make one
voucher. Types: Payment, Receipt, Contra, Journal. Sales and Purchase are not imported here:
their GST register rows need the voucher screen or Import › E-commerce Orders. Each voucher must
balance. A voucher is stored with the detail "Import Ref" = file#ref, so importing the same file
again posts nothing twice. Every posted voucher is an ordinary Regular voucher (audit trail,
balances, reports), saved one transaction each.
"""
from __future__ import annotations

import sqlite3
from datetime import datetime
from decimal import Decimal
from pathlib import Path

from services.ecommerce import _date, _find, _money, _rows

REF_FIELD = "Import Ref"
TYPES = ("Payment", "Receipt", "Contra", "Journal")


def _header(rows: list[list[str]], must: tuple[tuple[str, ...], ...]) -> int | None:
    return next((i for i, r in enumerate(rows[:20]) if all(_find(r, heads) is not None for heads in must)), None)


def _cell(r: list[str], i: int | None) -> str:
    return r[i].strip() if i is not None and i < len(r) else ""


# ---- ledgers ---------------------------------------------------------------------------------
NAME = ("name", "ledger", "ledger name", "account", "account name")
UNDER = ("under", "group", "under group", "parent")


def plan_ledgers(path: Path, store) -> list[dict]:
    rows = _rows(Path(path))
    at = _header(rows, (NAME, UNDER))
    if at is None:
        raise ValueError("No header row with a Name and an Under (group) column in the first 20 lines.")
    h = rows[at]
    col = {k: _find(h, heads) for k, heads in (
        ("name", NAME), ("under", UNDER), ("opening", ("opening balance", "opening", "balance")),
        ("drcr", ("dr/cr", "dr cr", "type", "side")), ("gstin", ("gstin", "gstin/uin")), ("state", ("state",)),
        ("pan", ("pan", "pan/it no.")), ("address", ("address",)))}
    groups = {g.lower(): g for g in store.group_names()}
    existing = {n.lower() for n in store.ledger_names()}
    seen: set[str] = set()
    out = []
    for n, r in enumerate(rows[at + 1:], start=at + 2):
        if not any(c.strip() for c in r):
            continue
        name, under = _cell(r, col["name"]), _cell(r, col["under"])
        row = {"line": n, "name": name, "under": under, "opening": "", "drcr": "Dr", "status": "Ready", "note": "",
               "gstin": _cell(r, col["gstin"]), "state": _cell(r, col["state"]), "pan": _cell(r, col["pan"]),
               "address": _cell(r, col["address"])}
        try:
            if not name:
                raise ValueError("no name")
            if name.lower() in seen:
                raise ValueError("this name is in the file twice")
            if under.lower() not in groups:
                raise ValueError(f"group '{under}' does not exist")
            row["under"] = groups[under.lower()]
            raw = _cell(r, col["opening"])
            if raw:
                negative = raw.strip().startswith("-")
                amount = _money(raw.lstrip("-").strip())
                side = _cell(r, col["drcr"]).title()[:2] or ("Cr" if negative else "Dr")
                if side not in ("Dr", "Cr"):
                    raise ValueError(f"Dr/Cr '{_cell(r, col['drcr'])}' is not Dr or Cr")
                row["opening"], row["drcr"] = (f"{amount:.2f}" if amount else ""), ("Cr" if negative else side)
        except ValueError as exc:
            row["status"], row["note"] = "Error", str(exc)
        else:
            seen.add(name.lower())
            if name.lower() in existing:
                row["status"], row["note"] = "Exists", "already a ledger; not changed"
        out.append(row)
    return out


def post_ledgers(rows: list[dict], store) -> tuple[list[dict], list[dict]]:
    from services.masters import MasterError
    done, failed = [], []
    for row in rows:
        if row["status"] != "Ready":
            continue
        values = {k: row[k] for k in ("name", "under", "opening", "drcr", "gstin", "state", "pan", "address")}
        values["mailing_name"] = row["name"]
        try:
            store.save_ledger(values)
        except MasterError as exc:
            row["status"], row["note"] = "Failed", str(exc)
            failed.append(row)
            continue
        row["status"], row["note"] = "Created", ""
        done.append(row)
    return done, failed


# ---- vouchers --------------------------------------------------------------------------------
REF = ("ref", "voucher ref", "entry", "entry no", "voucher no", "voucher number")
LEDGER = ("ledger", "account", "particulars", "ledger name")


def _imported(db_path: Path) -> set[str]:
    con = sqlite3.connect(Path(db_path).resolve().as_uri() + "?mode=ro", uri=True, timeout=5)
    try:
        tables = {r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type = 'table'")}
        if not {"bp_voucher_details", "bp_vouchers"} <= tables:
            return set()
        status = any(r[1] == "status" for r in con.execute("PRAGMA table_info(bp_vouchers)"))
        live = " AND coalesce(v.status, 'Regular') != 'Cancelled'" if status else ""
        return {v for (v,) in con.execute("SELECT d.value FROM bp_voucher_details d JOIN bp_vouchers v ON "
                                          f"v.id = d.voucher_id WHERE d.field = ?{live}", (REF_FIELD,))}
    finally:
        con.close()


def plan_vouchers(path: Path, db_path: Path) -> list[dict]:
    path = Path(path)
    rows = _rows(path)
    at = _header(rows, (REF, ("date", "voucher date"), ("type", "voucher type", "vch type"), LEDGER))
    if at is None:
        raise ValueError("No header row with Ref, Date, Type and Ledger columns in the first 20 lines.")
    h = rows[at]
    col = {k: _find(h, heads) for k, heads in (
        ("ref", REF), ("date", ("date", "voucher date")), ("type", ("type", "voucher type", "vch type")),
        ("ledger", LEDGER), ("debit", ("debit", "dr amount", "debit amount")),
        ("credit", ("credit", "cr amount", "credit amount")), ("amount", ("amount",)),
        ("side", ("dr/cr", "dr cr", "side")), ("narration", ("narration", "remarks", "description")))}
    if col["debit"] is None and (col["amount"] is None or col["side"] is None):
        raise ValueError("The file needs Debit and Credit columns, or Amount and Dr/Cr columns.")
    done = _imported(db_path)
    groups: dict[str, dict] = {}
    for n, r in enumerate(rows[at + 1:], start=at + 2):
        if not any(c.strip() for c in r):
            continue
        ref = _cell(r, col["ref"])
        g = groups.setdefault(ref, {"ref": ref, "lines": [], "errors": [], "dates": set(), "types": set(),
                                    "narration": "", "first_line": n})
        try:
            if not ref:
                raise ValueError("no Ref")
            g["dates"].add(_date(_cell(r, col["date"])))
            vtype = _cell(r, col["type"]).title()
            if vtype not in TYPES:
                raise ValueError(f"type '{_cell(r, col['type'])}' (only {', '.join(TYPES)})")
            g["types"].add(vtype)
            ledger = _cell(r, col["ledger"])
            if not ledger:
                raise ValueError("no ledger")
            if col["debit"] is not None:
                dr, cr = _cell(r, col["debit"]), _cell(r, col["credit"])
                if bool(dr) == bool(cr):
                    raise ValueError("give either a Debit or a Credit amount")
                side, amount = ("Dr", _money(dr)) if dr else ("Cr", _money(cr))
            else:
                side = _cell(r, col["side"]).title()[:2]
                if side not in ("Dr", "Cr"):
                    raise ValueError(f"Dr/Cr '{_cell(r, col['side'])}' is not Dr or Cr")
                amount = _money(_cell(r, col["amount"]))
            if not amount:
                raise ValueError("amount is 0")
            g["lines"].append({"side": side, "ledger": ledger, "amount": amount})
            g["narration"] = g["narration"] or _cell(r, col["narration"])
        except ValueError as exc:
            g["errors"].append(f"line {n}: {exc}")
    out = []
    for g in groups.values():
        key = f"{path.name}#{g['ref']}"
        dr = sum((ln["amount"] for ln in g["lines"] if ln["side"] == "Dr"), Decimal("0"))
        cr = sum((ln["amount"] for ln in g["lines"] if ln["side"] == "Cr"), Decimal("0"))
        status, note = "Ready", ""
        if g["errors"]:
            status, note = "Error", "; ".join(g["errors"])
        elif len(g["dates"]) != 1 or len(g["types"]) != 1:
            status, note = "Error", "the rows of this Ref have different dates or types"
        elif not dr or not cr:
            status, note = "Error", "needs at least one debit and one credit"
        elif dr != cr:
            status, note = "Error", f"debits {dr:,.2f} and credits {cr:,.2f} do not agree"
        elif key in done:
            status, note = "Already imported", "posted before; not posted again"
        out.append({"ref": g["ref"], "key": key, "date": min(g["dates"]) if g["dates"] else None,
                    "type": next(iter(g["types"]), ""), "lines": g["lines"], "total": dr, "narration": g["narration"],
                    "status": status, "note": note})
    return sorted(out, key=lambda x: (x["date"] or datetime.max.date(), x["ref"]))


def post_vouchers(rows: list[dict], store) -> tuple[list[dict], list[dict]]:
    from services.voucher_store import StoreError
    done, failed = [], []
    for row in rows:
        if row["status"] != "Ready":
            continue
        voucher = {"type": row["type"], "date": row["date"], "lines": row["lines"], "total": row["total"],
                   "narration": row["narration"] or f"Imported ({row['key']})", "entered_at": datetime.now(),
                   "gst": None, "details": {REF_FIELD: row["key"]}, "items": [], "status": "Regular"}
        try:
            saved = store.save(voucher)
        except StoreError as exc:
            row["status"], row["note"] = "Failed", str(exc)
            failed.append(row)
            continue
        row["status"], row["note"] = "Posted", f"{row['type']} No. {saved.number}"
        done.append(row)
    return done, failed
