"""
Saving accepted vouchers into bizpulse_local.db.

What is written, all in ONE transaction (all of it is saved, or none of it):

    every voucher        bp_vouchers + bp_voucher_lines     the full voucher: type, number, date,
                                                            every Dr/Cr line, narration. The
                                                            Day Book reads these. Created on first
                                                            use (CREATE TABLE IF NOT EXISTS).
    Sales                gst_sales_ledger                   one GSTR-1 row per invoice: CGST + SGST rates
                                                            within West Bengal, igst_rate for other states,
                                                            and place_of_supply (2-digit state code)
    any voucher type     corporate_ledger_summary           outstanding_balance of an account whose
                                                            account_name matches a line's ledger:
                                                            + debit, - credit (receivable view)

    Item Invoice         bp_voucher_items                   one row per item (name, quantity, rate, per, amount)
                         inventory_stock_registry           qty_on_hand: Sales take the quantity off, Purchases
                                                            add it. An item must already be a product_sku there.

Status (bp_vouchers.status; the column is added to older databases on the first save):
    Regular      everything above happens
    Optional     saved and listed in the Day Book, but left out of the reports: no invoice
                 number, no gst_sales_ledger row, no balance or stock change
    Post-Dated   Payment / Receipt / Contra / Journal dated after today. Saved now; the balance
                 change in corporate_ledger_summary waits until the date arrives (realise_post_dated,
                 run at start-up), then the voucher becomes Regular. Reports include it from its date.
    Cancelled    set by Alt+X (VoucherBook.cancel). The voucher keeps its number (and a Sales voucher
                 its invoice number), so the series has no hole; its effects are taken back and every
                 report, register and balance leaves it out. Its lines stay on file for the audit trail.

Foreign currency (services/forex.py): bp_voucher_lines always hold RUPEES (the rate applied);
bp_voucher_forex keeps each line's foreign amount, the currency and the rate, so the voucher
reopens as typed.

Cost centres (services/cost_centres.py): a line's "allocations" go to bp_cost_allocations, one
row per share; the shares must add up to the line exactly or nothing is saved.

Not touched by vouchers: workforce_payroll.

Audit trail (services/audit.py): every save, alteration, cancellation and post-dated voucher
falling due also writes one entry to bp_system_audit_logs IN THE SAME TRANSACTION (time, login,
voucher type and number, original and new voucher text and totals, balances moved), so a change
is never in the books without its entry, and an entry never exists for a change that failed.

Money: the new bp_ tables store whole paise (INTEGER), so totals are exact. Your existing
tables use REAL columns, so values written there are rounded to 2 decimals first.

Safety: the database must already exist (it is never created here), its existing tables are
checked for the expected columns before anything is written, and every statement uses
parameters (no text pasted into SQL).
"""
from __future__ import annotations

import sqlite3
from dataclasses import dataclass, field
from datetime import date, datetime
from decimal import Decimal
from pathlib import Path

from services import audit, cost_centres
from services.gst import invoice_number

SALES_TABLE = "gst_sales_ledger"
SUMMARY_TABLE = "corporate_ledger_summary"
EXPECTED_COLUMNS = {
    SALES_TABLE: {"invoice_no", "customer_name", "customer_gstin", "hsn_code", "taxable_value", "cgst_rate",
                  "sgst_rate", "igst_rate", "place_of_supply"},
    SUMMARY_TABLE: {"account_id", "account_name", "outstanding_balance", "credit_ceiling"},
}
INVOICE_MAX_LEN = 16
STOCK_TABLE = "inventory_stock_registry"
REGULAR, OPTIONAL, POST_DATED, CANCELLED = "Regular", "Optional", "Post-Dated", "Cancelled"
POST_DATED_TYPES = ("Payment", "Receipt", "Contra", "Journal")

DDL = """
CREATE TABLE IF NOT EXISTS bp_vouchers (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    voucher_type  TEXT    NOT NULL,
    voucher_no    INTEGER NOT NULL,
    voucher_date  TEXT    NOT NULL,             -- YYYY-MM-DD
    narration     TEXT    NOT NULL DEFAULT '',
    total_paise   INTEGER NOT NULL CHECK (total_paise > 0),
    invoice_no    TEXT,                         -- Sales: the row in gst_sales_ledger
    entered_at    TEXT    NOT NULL,
    UNIQUE (voucher_type, voucher_no)
);
CREATE TABLE IF NOT EXISTS bp_voucher_lines (
    voucher_id    INTEGER NOT NULL REFERENCES bp_vouchers(id),
    line_no       INTEGER NOT NULL,
    side          TEXT    NOT NULL CHECK (side IN ('Dr', 'Cr')),
    ledger        TEXT    NOT NULL,
    amount_paise  INTEGER NOT NULL CHECK (amount_paise > 0),
    PRIMARY KEY (voucher_id, line_no)
);
CREATE INDEX IF NOT EXISTS bp_vouchers_by_date ON bp_vouchers (voucher_date, id);
CREATE TABLE IF NOT EXISTS bp_voucher_items (
    voucher_id    INTEGER NOT NULL REFERENCES bp_vouchers(id),
    line_no       INTEGER NOT NULL,
    item          TEXT    NOT NULL,
    quantity      INTEGER NOT NULL CHECK (quantity > 0),
    rate_paise    INTEGER NOT NULL CHECK (rate_paise >= 0),
    per           TEXT    NOT NULL DEFAULT 'Nos',
    amount_paise  INTEGER NOT NULL CHECK (amount_paise >= 0),
    PRIMARY KEY (voucher_id, line_no)
);
CREATE TABLE IF NOT EXISTS bp_voucher_details (
    voucher_id    INTEGER NOT NULL REFERENCES bp_vouchers(id),
    field         TEXT    NOT NULL,             -- Party A/c, Name of Item, Supplier Invoice No., …
    value         TEXT    NOT NULL,
    PRIMARY KEY (voucher_id, field)
);
CREATE TABLE IF NOT EXISTS bp_voucher_forex (
    voucher_id    INTEGER NOT NULL REFERENCES bp_vouchers(id),
    line_no       INTEGER NOT NULL,             -- the bp_voucher_lines row it belongs to
    currency      TEXT    NOT NULL,             -- USD, EUR, …
    rate          TEXT    NOT NULL,             -- rupees for 1 unit, exact decimal text
    foreign_cents INTEGER NOT NULL CHECK (foreign_cents > 0),
    PRIMARY KEY (voucher_id, line_no)
);
"""


class StoreError(Exception):
    """A message the user can act on; nothing was saved."""


@dataclass
class SaveResult:
    voucher_id: int
    number: int
    invoice_no: str | None = None
    account_updates: list[str] = field(default_factory=list)   # "Gupta Stores: 12,000.00 -> 20,500.00"
    unmatched_parties: list[str] = field(default_factory=list)
    stock_updates: list[str] = field(default_factory=list)


@dataclass
class StockShortfall:
    item: str
    on_hand: int
    wanted: int


@dataclass
class CreditWarning:
    account: str
    after: Decimal
    ceiling: Decimal


def write_forex(con: sqlite3.Connection, voucher_id: int, voucher: dict) -> None:
    """A foreign-currency voucher: one bp_voucher_forex row per line (its foreign amount)."""
    fx = voucher.get("forex")
    if not fx:
        return
    if len(fx["amounts"]) != len(voucher["lines"]):
        raise StoreError("The foreign amounts do not match the voucher lines. Nothing was saved.")
    con.executemany("INSERT INTO bp_voucher_forex (voucher_id, line_no, currency, rate, foreign_cents) "
                    "VALUES (?, ?, ?, ?, ?)",
                    [(voucher_id, i + 1, fx["currency"], str(fx["rate"]), to_paise(a))
                     for i, a in enumerate(fx["amounts"])])


def to_paise(amount: Decimal) -> int:
    return int((amount * 100).to_integral_value())


def from_paise(paise: int) -> Decimal:
    return Decimal(paise) / 100


def _real(amount: Decimal) -> float:
    return float(amount.quantize(Decimal("0.01")))


class VoucherStore:
    def __init__(self, db_path: Path, invoice_prefix: str) -> None:
        self.db_path = db_path
        self.invoice_prefix = invoice_prefix

    # ---- connection --------------------------------------------------------------------
    def _connect(self) -> sqlite3.Connection:
        if not self.db_path.is_file():
            raise StoreError(f"{self.db_path.name} was not found in {self.db_path.parent}. Nothing was saved.")
        try:
            con = sqlite3.connect(str(self.db_path), timeout=5, isolation_level=None)
        except sqlite3.Error as exc:
            raise StoreError(f"Could not open {self.db_path.name}: {exc}") from exc
        con.execute("PRAGMA foreign_keys = ON")
        return con

    @staticmethod
    def _columns(con: sqlite3.Connection, table: str) -> set[str]:
        return {row[1] for row in con.execute(f"PRAGMA table_info({table})")}   # table names are constants

    def _check_table(self, con: sqlite3.Connection, table: str, required: bool) -> bool:
        cols = self._columns(con, table)
        if not cols:
            if required:
                raise StoreError(f"Table {table} is missing from {self.db_path.name}. Nothing was saved.")
            return False
        missing = EXPECTED_COLUMNS[table] - cols
        if missing and missing <= {"igst_rate", "place_of_supply"}:
            raise StoreError(f"gst_sales_ledger has no {' / '.join(sorted(missing))} column yet (the start-up "
                             "upgrade did not run; see the monitor). Restart BizPulse Pro. Nothing was saved.")
        if missing:
            raise StoreError(f"Table {table} has no column(s) {', '.join(sorted(missing))}. Nothing was saved.")
        return True

    @staticmethod
    def _has_bp_tables(con: sqlite3.Connection) -> bool:
        return con.execute("SELECT count(*) FROM sqlite_master WHERE type='table' AND name='bp_vouchers'").fetchone()[0] == 1

    # ---- reads -------------------------------------------------------------------------
    def next_number(self, voucher_type: str) -> int:
        """Next voucher number for a type (1 if nothing saved yet or the database is missing)."""
        try:
            con = self._connect()
        except StoreError:
            return 1
        try:
            if not self._has_bp_tables(con):
                return 1
            row = con.execute("SELECT max(voucher_no) FROM bp_vouchers WHERE voucher_type = ?", (voucher_type,)).fetchone()
            return (row[0] or 0) + 1
        finally:
            con.close()

    def next_invoice_no(self, d: date) -> str:
        try:
            con = self._connect()
        except StoreError:
            return invoice_number(self.invoice_prefix, d, 1)
        try:
            return self._next_invoice_no(con, d)
        finally:
            con.close()

    def _next_invoice_no(self, con: sqlite3.Connection, d: date) -> str:
        if not self._columns(con, SALES_TABLE):
            return invoice_number(self.invoice_prefix, d, 1)
        stem = invoice_number(self.invoice_prefix, d, 0)[:-4]          # 'SRJ/26-27/'
        rows = con.execute("SELECT invoice_no FROM gst_sales_ledger WHERE invoice_no LIKE ? ESCAPE '\\'",
                           (stem.replace("%", "\\%").replace("_", "\\_") + "%",)).fetchall()
        if "invoice_no" in self._columns(con, "bp_vouchers"):      # a cancelled invoice keeps its number
            rows += con.execute("SELECT invoice_no FROM bp_vouchers WHERE invoice_no LIKE ? ESCAPE '\\'",
                                (stem.replace("%", "\\%").replace("_", "\\_") + "%",)).fetchall()
        seqs = [int(r[0][len(stem):]) for r in rows if r[0][len(stem):].isdigit()]
        nxt = max(seqs, default=0) + 1
        if nxt > 9999:
            raise StoreError(f"Invoice numbers for {stem} are used up (9999).")
        return invoice_number(self.invoice_prefix, d, nxt)

    def credit_warnings(self, voucher: dict) -> list[CreditWarning]:
        """Accounts this voucher would push over their credit ceiling (checked before saving)."""
        try:
            con = self._connect()
        except StoreError:
            return []
        try:
            if not self._columns(con, SUMMARY_TABLE):
                return []
            out = []
            for name, delta in self._deltas(voucher).items():
                if delta <= 0:
                    continue
                rows = self._find_account(con, name)
                if len(rows) != 1:
                    continue
                _id, acc_name, balance, ceiling = rows[0]
                after = Decimal(str(balance or 0)) + delta
                if ceiling and after > Decimal(str(ceiling)):
                    out.append(CreditWarning(acc_name, after, Decimal(str(ceiling))))
            return out
        finally:
            con.close()

    def stock_shortfalls(self, voucher: dict) -> list[StockShortfall]:
        """Sales items that would take qty_on_hand below zero (checked before saving)."""
        if voucher["type"] != "Sales" or voucher.get("status", REGULAR) != REGULAR or not voucher.get("items"):
            return []
        try:
            con = self._connect()
        except StoreError:
            return []
        try:
            if not self._columns(con, STOCK_TABLE):
                return []
            out = []
            for name, qty in self._item_totals(voucher).items():
                row = con.execute(f"SELECT product_sku, qty_on_hand FROM {STOCK_TABLE} "
                                  "WHERE lower(trim(product_sku)) = lower(trim(?))", (name,)).fetchone()
                if row is not None and (row[1] or 0) < qty:
                    out.append(StockShortfall(row[0], int(row[1] or 0), qty))
            return out
        finally:
            con.close()

    def unused_numbers(self, voucher_type: str) -> list[int]:
        """Voucher numbers below the highest one that no saved voucher of this type uses."""
        try:
            con = self._connect()
        except StoreError:
            return []
        try:
            if not self._has_bp_tables(con):
                return []
            used = {r[0] for r in con.execute("SELECT voucher_no FROM bp_vouchers WHERE voucher_type = ?",
                                              (voucher_type,))}
            return [n for n in range(1, max(used, default=0) + 1) if n not in used]
        finally:
            con.close()

    def last_voucher_for(self, voucher_type: str, party: str) -> dict | None:
        """Autofill: the newest saved voucher of this type with a line for `party` (lines, items, details)."""
        party = party.strip()
        if not party:
            return None
        try:
            con = self._connect()
        except StoreError:
            return None
        try:
            if not self._has_bp_tables(con):
                return None
            live = (f" AND coalesce(v.status, '{REGULAR}') != '{CANCELLED}'"
                    if "status" in self._columns(con, "bp_vouchers") else "")
            row = con.execute(
                "SELECT v.id FROM bp_vouchers v JOIN bp_voucher_lines l ON l.voucher_id = v.id "
                f"WHERE v.voucher_type = ? AND lower(trim(l.ledger)) = lower(?){live} "
                "ORDER BY v.voucher_date DESC, v.id DESC LIMIT 1", (voucher_type, party)).fetchone()
            if row is None:
                return None
            vid = row[0]
            lines = [{"side": s, "ledger": lg, "amount": from_paise(p)} for s, lg, p in con.execute(
                "SELECT side, ledger, amount_paise FROM bp_voucher_lines WHERE voucher_id = ? ORDER BY line_no", (vid,))]
            items = []
            if self._columns(con, "bp_voucher_items"):
                items = [{"item": it, "quantity": q, "rate": from_paise(r), "per": per, "amount": from_paise(a)}
                         for it, q, r, per, a in con.execute(
                             "SELECT item, quantity, rate_paise, per, amount_paise FROM bp_voucher_items "
                             "WHERE voucher_id = ? ORDER BY line_no", (vid,))]
            details = {}
            if self._columns(con, "bp_voucher_details"):
                details = dict(con.execute("SELECT field, value FROM bp_voucher_details WHERE voucher_id = ? "
                                           "ORDER BY rowid", (vid,)).fetchall())
            return {"lines": lines, "items": items, "details": details, "forex": self._forex_for(con, [vid]).get(vid)}
        finally:
            con.close()

    def _forex_for(self, con: sqlite3.Connection, ids: list[int]) -> dict[int, dict]:
        """voucher id -> {"currency", "rate", "amounts": [foreign amount per line]} (foreign vouchers only)."""
        out: dict[int, dict] = {}
        if not ids or not self._columns(con, "bp_voucher_forex"):
            return out
        marks = ",".join("?" * len(ids))
        for vid, _line, cur, rate, cents in con.execute(
                f"SELECT voucher_id, line_no, currency, rate, foreign_cents FROM bp_voucher_forex "
                f"WHERE voucher_id IN ({marks}) ORDER BY voucher_id, line_no", ids):
            fx = out.setdefault(vid, {"currency": cur, "rate": Decimal(rate), "amounts": []})
            fx["amounts"].append(from_paise(cents))
        return out

    def last_rate(self, currency: str) -> Decimal | None:
        """The rate used on the newest saved voucher in this currency (to offer it again)."""
        try:
            con = self._connect()
        except StoreError:
            return None
        try:
            if not self._columns(con, "bp_voucher_forex"):
                return None
            row = con.execute("SELECT f.rate FROM bp_voucher_forex f JOIN bp_vouchers v ON v.id = f.voucher_id "
                              "WHERE f.currency = ? ORDER BY v.voucher_date DESC, v.id DESC LIMIT 1",
                              (currency,)).fetchone()
            return Decimal(row[0]) if row else None
        finally:
            con.close()

    def load_all(self, limit: int = 5000) -> list[dict]:
        """Saved vouchers, oldest first, in the shape the Day Book uses."""
        con = self._connect()
        try:
            if not self._has_bp_tables(con):
                return []
            status = "status" if "status" in self._columns(con, "bp_vouchers") else "'Regular'"
            heads = con.execute(
                "SELECT id, voucher_type, voucher_no, voucher_date, narration, total_paise, invoice_no, entered_at, "
                f"{status} FROM bp_vouchers ORDER BY voucher_date DESC, id DESC LIMIT ?", (limit,)).fetchall()
            ids = [h[0] for h in heads]
            lines: dict[int, list[dict]] = {i: [] for i in ids}
            if ids:
                marks = ",".join("?" * len(ids))
                for vid, side, ledger, paise in con.execute(
                        f"SELECT voucher_id, side, ledger, amount_paise FROM bp_voucher_lines "
                        f"WHERE voucher_id IN ({marks}) ORDER BY voucher_id, line_no", ids):
                    lines[vid].append({"side": side, "ledger": ledger, "amount": from_paise(paise)})
            items: dict[int, list[dict]] = {i: [] for i in ids}
            if ids and self._columns(con, "bp_voucher_items"):
                for vid, it, q, r, per, a in con.execute(
                        f"SELECT voucher_id, item, quantity, rate_paise, per, amount_paise FROM bp_voucher_items "
                        f"WHERE voucher_id IN ({marks}) ORDER BY voucher_id, line_no", ids):
                    items[vid].append({"item": it, "quantity": q, "rate": from_paise(r), "per": per,
                                       "amount": from_paise(a)})
            details: dict[int, dict[str, str]] = {i: {} for i in ids}
            has_details = con.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND "
                                      "name='bp_voucher_details'").fetchone() is not None
            if ids and has_details:
                for vid, field, value in con.execute(
                        f"SELECT voucher_id, field, value FROM bp_voucher_details WHERE voucher_id IN ({marks}) "
                        "ORDER BY voucher_id, rowid", ids):
                    details[vid][field] = value
            forex = self._forex_for(con, ids)
            shares = cost_centres.read(con, ids)
            for vid, vlines in lines.items():
                for n, ln in enumerate(vlines, start=1):
                    if (vid, n) in shares:
                        ln["allocations"] = shares[(vid, n)]
            return [{
                "id": h[0], "type": h[1], "number": h[2],
                "date": date.fromisoformat(h[3]), "narration": h[4], "total": from_paise(h[5]),
                "invoice_no": h[6], "entered_at": datetime.fromisoformat(h[7]), "lines": lines[h[0]],
                "details": details[h[0]], "status": h[8] or REGULAR, "items": items[h[0]],
                "forex": forex.get(h[0]),
            } for h in reversed(heads)]
        except sqlite3.Error as exc:
            raise StoreError(f"Could not read vouchers: {exc}") from exc
        finally:
            con.close()

    # ---- write -------------------------------------------------------------------------
    def save(self, voucher: dict) -> SaveResult:
        """Writes the voucher and its side effects atomically. Raises StoreError on any problem."""
        status = voucher.get("status", REGULAR)
        vtype = voucher["type"]
        if status not in (REGULAR, OPTIONAL, POST_DATED):
            raise StoreError(f"Unknown voucher status '{status}'. Nothing was saved.")
        if status == POST_DATED and (vtype not in POST_DATED_TYPES or voucher["date"] <= date.today()):
            raise StoreError("A Post-Dated voucher must be a Payment, Receipt, Contra or Journal dated after today. "
                             "Nothing was saved.")
        live = status == REGULAR                     # only Regular vouchers change registers, balances, stock
        for ln in voucher["lines"]:
            problem = cost_centres.check(ln["amount"], ln.get("allocations") or [])
            if problem:
                raise StoreError(f"Cost centres for {ln['ledger']}: {problem}. Nothing was saved.")
        con = self._connect()
        try:
            has_summary = self._check_table(con, SUMMARY_TABLE, required=False)
            if vtype == "Sales" and live:
                self._check_table(con, SALES_TABLE, required=True)
            items = voucher.get("items") or []
            if items and live and not self._columns(con, STOCK_TABLE):
                raise StoreError(f"{STOCK_TABLE} is missing, so item quantities cannot be updated. Nothing was saved.")

            con.execute("BEGIN IMMEDIATE")      # one writer at a time; others wait up to 5 s
            # Statement by statement: executescript() would commit the open transaction.
            for stmt in filter(None, (s.strip() for s in DDL.split(";"))):
                con.execute(stmt)
            if "status" not in self._columns(con, "bp_vouchers"):      # databases from before statuses
                con.execute(f"ALTER TABLE bp_vouchers ADD COLUMN status TEXT NOT NULL DEFAULT '{REGULAR}'")
            audit.begin(con)
            before_bal = audit.snapshot(con, [voucher])

            number = (con.execute("SELECT max(voucher_no) FROM bp_vouchers WHERE voucher_type = ?",
                                  (vtype,)).fetchone()[0] or 0) + 1
            invoice_no = None
            if vtype == "Sales" and live:
                invoice_no = self._next_invoice_no(con, voucher["date"])
                if len(invoice_no) > INVOICE_MAX_LEN:
                    raise StoreError(f"Invoice number {invoice_no} is longer than {INVOICE_MAX_LEN} characters; "
                                     "shorten INVOICE_PREFIX in config/settings.py.")

            cur = con.execute(
                "INSERT INTO bp_vouchers (voucher_type, voucher_no, voucher_date, narration, total_paise, invoice_no, "
                "entered_at, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                (vtype, number, voucher["date"].isoformat(), voucher["narration"], to_paise(voucher["total"]),
                 invoice_no, voucher["entered_at"].isoformat(timespec="seconds"), status),
            )
            vid = cur.lastrowid
            con.executemany(
                "INSERT INTO bp_voucher_lines (voucher_id, line_no, side, ledger, amount_paise) VALUES (?, ?, ?, ?, ?)",
                [(vid, i + 1, ln["side"], ln["ledger"], to_paise(ln["amount"])) for i, ln in enumerate(voucher["lines"])],
            )

            details = [(vid, k, str(v)) for k, v in (voucher.get("details") or {}).items() if str(v).strip()]
            if details:
                con.executemany("INSERT INTO bp_voucher_details (voucher_id, field, value) VALUES (?, ?, ?)", details)
            write_forex(con, vid, voucher)
            cost_centres.write(con, vid, voucher["lines"])

            result = SaveResult(voucher_id=vid, number=number, invoice_no=invoice_no)

            if items:
                con.executemany(
                    "INSERT INTO bp_voucher_items (voucher_id, line_no, item, quantity, rate_paise, per, amount_paise) "
                    "VALUES (?, ?, ?, ?, ?, ?, ?)",
                    [(vid, i + 1, it["item"], int(it["quantity"]), to_paise(it["rate"]), it.get("per") or "Nos",
                      to_paise(it["amount"])) for i, it in enumerate(items)])
                if live:
                    result.stock_updates = self._apply_stock(con, voucher)

            if vtype == "Sales" and live:
                gst = voucher["gst"]
                # Rates, as in the existing columns: intra-state 9 + 9 + 0; inter-state 0 + 0 + 18.
                con.execute(
                    "INSERT INTO gst_sales_ledger (invoice_no, customer_name, customer_gstin, hsn_code, taxable_value, "
                    "cgst_rate, sgst_rate, igst_rate, place_of_supply) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                    (invoice_no, gst["customer"], gst["gstin"] or None, gst["hsn"], _real(gst["taxable"]),
                     float(gst["cgst_rate"]), float(gst["sgst_rate"]), float(gst["igst_rate"]),
                     gst["place_of_supply"]),
                )

            if has_summary and live:
                for name, delta in self._deltas(voucher).items():
                    rows = self._find_account(con, name)
                    if len(rows) != 1:
                        if vtype in ("Sales", "Receipt") and self._is_party_line(voucher, name):
                            result.unmatched_parties.append(name if not rows else f"{name} (matches {len(rows)} accounts)")
                        continue
                    acc_id, acc_name, balance, _ceiling = rows[0]
                    before = Decimal(str(balance or 0)).quantize(Decimal("0.01"))
                    after = before + delta
                    con.execute(f"UPDATE {SUMMARY_TABLE} SET outstanding_balance = ? WHERE account_id = ?",
                                (_real(after), acc_id))
                    result.account_updates.append(f"{acc_name}: {before:,.2f} -> {after:,.2f}")

            audit.record(con, "Create", vtype, invoice_no or number, vid, None, None,
                         audit.describe(dict(voucher, status=status)), voucher["total"],
                         audit.moved(before_bal, audit.snapshot(con, [voucher])))
            audit.end(con)
            con.execute("COMMIT")
            return result
        except StoreError:
            self._rollback(con)
            raise
        except sqlite3.IntegrityError as exc:
            self._rollback(con)
            raise StoreError(f"Not saved: {exc}. (Is that invoice number already in gst_sales_ledger?)") from exc
        except sqlite3.OperationalError as exc:
            self._rollback(con)
            if "locked" in str(exc).lower():
                raise StoreError("The database is busy (another program is writing to it). Nothing was saved; try again.") from exc
            raise StoreError(f"Not saved: {exc}") from exc
        except sqlite3.Error as exc:
            self._rollback(con)
            raise StoreError(f"Not saved: {exc}") from exc
        finally:
            con.close()

    # ---- helpers -----------------------------------------------------------------------
    @staticmethod
    def _rollback(con: sqlite3.Connection) -> None:
        try:
            if con.in_transaction:
                con.execute("ROLLBACK")
        except sqlite3.Error:
            pass

    @staticmethod
    def _deltas(voucher: dict) -> dict[str, Decimal]:
        """Net change per ledger name: + debit, - credit."""
        out: dict[str, Decimal] = {}
        for ln in voucher["lines"]:
            amt = ln["amount"] if ln["side"] == "Dr" else -ln["amount"]
            out[ln["ledger"]] = out.get(ln["ledger"], Decimal("0")) + amt
        return {k: v for k, v in out.items() if v}

    @staticmethod
    def _item_totals(voucher: dict) -> dict[str, int]:
        out: dict[str, int] = {}
        for it in voucher.get("items") or []:
            out[it["item"].strip()] = out.get(it["item"].strip(), 0) + int(it["quantity"])
        return out

    def _apply_stock(self, con: sqlite3.Connection, voucher: dict) -> list[str]:
        """qty_on_hand: Sales minus, Purchase plus. Inside the voucher's transaction."""
        sign = -1 if voucher["type"] == "Sales" else 1
        changes = []
        for name, qty in self._item_totals(voucher).items():
            row = con.execute(f"SELECT product_sku, qty_on_hand FROM {STOCK_TABLE} "
                              "WHERE lower(trim(product_sku)) = lower(trim(?))", (name,)).fetchall()
            if len(row) != 1:
                raise StoreError(f"Item '{name}' is not a product_sku in {STOCK_TABLE}"
                                 + (" (it matches more than one)" if row else "") + ". Nothing was saved.")
            sku, before = row[0][0], int(row[0][1] or 0)
            after = before + sign * qty
            con.execute(f"UPDATE {STOCK_TABLE} SET qty_on_hand = ? WHERE product_sku = ?", (after, sku))
            changes.append(f"{sku}: {before} -> {after}")
        return changes

    def realise_post_dated(self, today: date) -> list[str]:
        """Post-dated vouchers whose date has arrived: apply their balance changes and make them Regular.
        One transaction; returns a line per voucher for the status bar."""
        try:
            con = self._connect()
        except StoreError:
            return []
        try:
            if not self._has_bp_tables(con) or "status" not in self._columns(con, "bp_vouchers"):
                return []
            due = con.execute("SELECT id, voucher_type, voucher_no FROM bp_vouchers WHERE status = ? "
                              "AND voucher_date <= ? ORDER BY voucher_date, id", (POST_DATED, today.isoformat())).fetchall()
            if not due:
                return []
            has_summary = bool(self._columns(con, SUMMARY_TABLE))
            con.execute("BEGIN IMMEDIATE")
            audit.begin(con)
            messages = []
            for vid, vtype, vno in due:
                lines = [{"side": s, "ledger": lg, "amount": from_paise(p)} for s, lg, p in con.execute(
                    "SELECT side, ledger, amount_paise FROM bp_voucher_lines WHERE voucher_id = ?", (vid,))]
                before_bal = audit.snapshot(con, [{"lines": lines}])
                if has_summary:
                    for name, delta in self._deltas({"type": vtype, "lines": lines}).items():
                        rows = self._find_account(con, name)
                        if len(rows) == 1:
                            acc_id, _n, balance, _c = rows[0]
                            after = Decimal(str(balance or 0)).quantize(Decimal("0.01")) + delta
                            con.execute(f"UPDATE {SUMMARY_TABLE} SET outstanding_balance = ? WHERE account_id = ?",
                                        (_real(after), acc_id))
                con.execute("UPDATE bp_vouchers SET status = ? WHERE id = ?", (REGULAR, vid))
                total = sum((ln["amount"] for ln in lines if ln["side"] == "Dr"), Decimal("0"))
                audit.record(con, "Realise", vtype, vno, vid, f"Status: {POST_DATED}", total,
                             f"Status: {REGULAR} (date arrived; entered in the books)", total,
                             audit.moved(before_bal, audit.snapshot(con, [{"lines": lines}])))
                messages.append(f"Post-dated {vtype} No. {vno} is now due and has been entered in the books.")
            audit.end(con)
            con.execute("COMMIT")
            return messages
        except sqlite3.Error as exc:
            self._rollback(con)
            return [f"Post-dated vouchers not updated: {exc}"]
        finally:
            con.close()

    @staticmethod
    def _find_account(con: sqlite3.Connection, name: str) -> list[tuple]:
        return con.execute(
            f"SELECT account_id, account_name, outstanding_balance, credit_ceiling FROM {SUMMARY_TABLE} "
            "WHERE lower(trim(account_name)) = lower(trim(?))", (name,)).fetchall()

    @staticmethod
    def _is_party_line(voucher: dict, name: str) -> bool:
        """The customer line: Dr on a Sales voucher, Cr on a Receipt."""
        side = "Dr" if voucher["type"] == "Sales" else "Cr"
        first = next((ln for ln in voucher["lines"] if ln["side"] == side), None)
        return first is not None and first["ledger"] == name
