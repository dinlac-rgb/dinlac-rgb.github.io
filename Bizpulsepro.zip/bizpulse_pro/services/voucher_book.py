"""
Reading one voucher back, altering it, and the ledger statement that drill-down needs.

    VoucherBook(db_path, invoice_prefix)        everything VoucherStore does, plus:
        load_voucher(voucher_id)  -> dict       the voucher as the voucher screen fills it
        alter(voucher_id, voucher) -> SaveResult
        cancel(voucher_id) -> SaveResult         Alt+X: Cancelled, number kept, effects taken back
        ledger_statement(ledger, upto) -> dict   opening, rows (one per voucher), closing

Altering a saved voucher (Day Book / Ledger Statement / Trial Balance drill-down) is ONE
transaction:
    1. if the old voucher was Regular, its effects are taken back: corporate_ledger_summary
       balances, inventory_stock_registry quantities, and its gst_sales_ledger row
    2. its lines, items and details are replaced; type, number and invoice number stay
    3. if the new version is Regular, its effects are applied again (same rules as saving)
If any step fails, nothing changes. The type cannot change (enter a new voucher instead), and a
Sales invoice cannot move into another financial year (its invoice series would be wrong).

Cancelling (Alt+X) is also ONE transaction: the effects of a Regular voucher are taken back as in
step 1, the status becomes Cancelled and "Cancelled on" is recorded in bp_voucher_details. The
voucher number and the invoice number stay, so the series shows no unused number; the lines stay
on file for the audit trail but every report, register and balance leaves the voucher out. A
cancelled voucher cannot be altered (Alt+2 duplicates it as a new one instead).
"""
from __future__ import annotations

import sqlite3
from datetime import date, datetime
from decimal import Decimal

from services import audit, cost_centres
from services.gst import financial_year_label
from services.voucher_store import (CANCELLED, DDL, INVOICE_MAX_LEN, POST_DATED, POST_DATED_TYPES,
                                    REGULAR, SALES_TABLE, STOCK_TABLE, SUMMARY_TABLE, SaveResult, StoreError,
                                    VoucherStore, _real, from_paise, to_paise, write_forex)

ZERO = Decimal("0.00")


class VoucherBook(VoucherStore):
    # ---- read one voucher --------------------------------------------------------------
    def load_voucher(self, voucher_id: int) -> dict | None:
        con = self._connect()
        try:
            cols = self._columns(con, "bp_vouchers")
            if not cols:
                return None
            status = "status" if "status" in cols else "'Regular'"
            head = con.execute(f"SELECT id, voucher_type, voucher_no, voucher_date, narration, total_paise, invoice_no, "
                               f"{status} FROM bp_vouchers WHERE id = ?", (voucher_id,)).fetchone()
            if head is None:
                return None
            vid, vtype, vno, vdate, narration, total, invoice_no, vstatus = head
            lines = [{"side": s, "ledger": lg, "amount": from_paise(p)} for s, lg, p in con.execute(
                "SELECT side, ledger, amount_paise FROM bp_voucher_lines WHERE voucher_id = ? ORDER BY line_no", (vid,))]
            shares = cost_centres.read(con, [vid])
            for n, ln in enumerate(lines, start=1):
                if (vid, n) in shares:
                    ln["allocations"] = shares[(vid, n)]
            items = []
            if self._columns(con, "bp_voucher_items"):
                items = [{"item": it, "quantity": q, "rate": from_paise(r), "per": per, "amount": from_paise(a)}
                         for it, q, r, per, a in con.execute(
                             "SELECT item, quantity, rate_paise, per, amount_paise FROM bp_voucher_items "
                             "WHERE voucher_id = ? ORDER BY line_no", (vid,))]
            details = {}
            if self._columns(con, "bp_voucher_details"):
                details = dict(con.execute("SELECT field, value FROM bp_voucher_details WHERE voucher_id = ? "
                                           "ORDER BY rowid", (vid,)).fetchall())
            gst = None
            if invoice_no and self._columns(con, SALES_TABLE):
                row = con.execute(f"SELECT customer_gstin, hsn_code, taxable_value, cgst_rate, sgst_rate, igst_rate, "
                                  f"place_of_supply FROM {SALES_TABLE} WHERE invoice_no = ?", (invoice_no,)).fetchone()
                if row is not None:
                    gstin, hsn, taxable, cgst, sgst, igst, pos = row
                    rate = Decimal(str(igst or 0)) or Decimal(str(cgst or 0)) + Decimal(str(sgst or 0))
                    gst = {"gstin": gstin or "", "hsn": hsn or "", "taxable": Decimal(str(taxable or 0)).quantize(Decimal("0.01")),
                           "rate": f"{rate.normalize():f}", "place_of_supply": pos or ""}
            return {"id": vid, "type": vtype, "number": vno, "date": date.fromisoformat(vdate), "narration": narration,
                    "total": from_paise(total), "invoice_no": invoice_no, "status": vstatus or REGULAR,
                    "lines": lines, "items": items, "details": details, "gst": gst,
                    "forex": self._forex_for(con, [vid]).get(vid)}
        finally:
            con.close()

    # ---- alter -------------------------------------------------------------------------
    def alter(self, voucher_id: int, voucher: dict) -> SaveResult:
        status = voucher.get("status", REGULAR)
        if status == POST_DATED and (voucher["type"] not in POST_DATED_TYPES or voucher["date"] <= date.today()):
            raise StoreError("A Post-Dated voucher must be a Payment, Receipt, Contra or Journal dated after today. "
                             "Nothing was changed.")
        old = self.load_voucher(voucher_id)
        if old is None:
            raise StoreError("That voucher no longer exists. Nothing was changed.")
        if old["status"] == CANCELLED:
            raise StoreError(f"{old['type']} No. {old['invoice_no'] or old['number']} is cancelled and cannot be "
                             "altered. Alt+2 duplicates it as a new voucher.")
        if old["type"] != voucher["type"]:
            raise StoreError(f"A {old['type']} cannot be changed into a {voucher['type']}; enter a new voucher instead.")
        vtype = old["type"]
        for ln in voucher["lines"]:
            problem = cost_centres.check(ln["amount"], ln.get("allocations") or [])
            if problem:
                raise StoreError(f"Cost centres for {ln['ledger']}: {problem}. Nothing was changed.")
        old_live, live = old["status"] == REGULAR, status == REGULAR
        invoice_no = old["invoice_no"]
        if vtype == "Sales" and invoice_no and financial_year_label(old["date"]) != financial_year_label(voucher["date"]):
            raise StoreError(f"Invoice {invoice_no} belongs to {financial_year_label(old['date'])}; it cannot move to "
                             f"{financial_year_label(voucher['date'])}. Nothing was changed.")
        con = self._connect()
        try:
            has_summary = bool(self._columns(con, SUMMARY_TABLE))
            con.execute("BEGIN IMMEDIATE")
            for stmt in filter(None, (s.strip() for s in DDL.split(";"))):
                con.execute(stmt)
            if "status" not in self._columns(con, "bp_vouchers"):
                con.execute(f"ALTER TABLE bp_vouchers ADD COLUMN status TEXT NOT NULL DEFAULT '{REGULAR}'")
            audit.begin(con)
            before_bal = audit.snapshot(con, [old, voucher])
            result = SaveResult(voucher_id=voucher_id, number=old["number"], invoice_no=invoice_no)

            # 1. take back the old version's effects
            if old_live:
                if has_summary:
                    self._summary(con, old, sign=-1, result=None)
                if old["items"]:
                    self._apply_stock_signed(con, old, sign=-1)
                if vtype == "Sales" and invoice_no and self._columns(con, SALES_TABLE):
                    con.execute(f"DELETE FROM {SALES_TABLE} WHERE invoice_no = ?", (invoice_no,))

            # 2. replace the voucher's contents (number and invoice number stay)
            if vtype == "Sales" and live and not invoice_no:
                self._check_table(con, SALES_TABLE, required=True)
                invoice_no = self._next_invoice_no(con, voucher["date"])
                if len(invoice_no) > INVOICE_MAX_LEN:
                    raise StoreError(f"Invoice number {invoice_no} is too long; shorten INVOICE_PREFIX.")
                result.invoice_no = invoice_no
            con.execute(cost_centres.DDL)
            for table in ("bp_voucher_lines", "bp_voucher_items", "bp_voucher_details", "bp_voucher_forex",
                          "bp_cost_allocations"):
                con.execute(f"DELETE FROM {table} WHERE voucher_id = ?", (voucher_id,))
            con.execute("UPDATE bp_vouchers SET voucher_date = ?, narration = ?, total_paise = ?, invoice_no = ?, status = ? "
                        "WHERE id = ?", (voucher["date"].isoformat(), voucher["narration"], to_paise(voucher["total"]),
                                         invoice_no, status, voucher_id))
            con.executemany("INSERT INTO bp_voucher_lines (voucher_id, line_no, side, ledger, amount_paise) "
                            "VALUES (?, ?, ?, ?, ?)",
                            [(voucher_id, i + 1, ln["side"], ln["ledger"], to_paise(ln["amount"]))
                             for i, ln in enumerate(voucher["lines"])])
            items = voucher.get("items") or []
            con.executemany("INSERT INTO bp_voucher_items (voucher_id, line_no, item, quantity, rate_paise, per, "
                            "amount_paise) VALUES (?, ?, ?, ?, ?, ?, ?)",
                            [(voucher_id, i + 1, it["item"], int(it["quantity"]), to_paise(it["rate"]),
                              it.get("per") or "Nos", to_paise(it["amount"])) for i, it in enumerate(items)])
            con.executemany("INSERT INTO bp_voucher_details (voucher_id, field, value) VALUES (?, ?, ?)",
                            [(voucher_id, k, str(v)) for k, v in (voucher.get("details") or {}).items() if str(v).strip()])
            write_forex(con, voucher_id, voucher)
            cost_centres.write(con, voucher_id, voucher["lines"])

            # 3. apply the new version's effects
            if live:
                if items:
                    if not self._columns(con, STOCK_TABLE):
                        raise StoreError(f"{STOCK_TABLE} is missing. Nothing was changed.")
                    result.stock_updates = self._apply_stock_signed(con, voucher, sign=1)
                if vtype == "Sales":
                    gst = voucher["gst"]
                    con.execute(
                        f"INSERT INTO {SALES_TABLE} (invoice_no, customer_name, customer_gstin, hsn_code, taxable_value, "
                        "cgst_rate, sgst_rate, igst_rate, place_of_supply) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                        (invoice_no, gst["customer"], gst["gstin"] or None, gst["hsn"], _real(gst["taxable"]),
                         float(gst["cgst_rate"]), float(gst["sgst_rate"]), float(gst["igst_rate"]),
                         gst["place_of_supply"]))
                if has_summary:
                    self._summary(con, voucher, sign=1, result=result)
            audit.record(con, "Alter", vtype, invoice_no or old["number"], voucher_id, audit.describe(old), old["total"],
                         audit.describe(dict(voucher, status=status)), voucher["total"],
                         audit.moved(before_bal, audit.snapshot(con, [old, voucher])))
            audit.end(con)
            con.execute("COMMIT")
            return result
        except StoreError:
            self._rollback(con)
            raise
        except sqlite3.Error as exc:
            self._rollback(con)
            raise StoreError(f"Not changed: {exc}") from exc
        finally:
            con.close()

    # ---- cancel (Alt+X) ---------------------------------------------------------------------
    def cancel(self, voucher_id: int) -> SaveResult:
        """Marks the voucher Cancelled. Number and invoice number stay; its effects are taken back."""
        old = self.load_voucher(voucher_id)
        if old is None:
            raise StoreError("That voucher no longer exists. Nothing was changed.")
        label = f"{old['type']} No. {old['invoice_no'] or old['number']}"
        if old["status"] == CANCELLED:
            raise StoreError(f"{label} is already cancelled.")
        con = self._connect()
        try:
            con.execute("BEGIN IMMEDIATE")
            for stmt in filter(None, (s.strip() for s in DDL.split(";"))):
                con.execute(stmt)
            if "status" not in self._columns(con, "bp_vouchers"):
                con.execute(f"ALTER TABLE bp_vouchers ADD COLUMN status TEXT NOT NULL DEFAULT '{REGULAR}'")
            audit.begin(con)
            before_bal = audit.snapshot(con, [old])
            result = SaveResult(voucher_id=voucher_id, number=old["number"], invoice_no=old["invoice_no"])
            if old["status"] == REGULAR:          # Optional / Post-Dated ones never reached the books
                if self._columns(con, SUMMARY_TABLE):
                    self._summary(con, old, sign=-1, result=result)
                if old["items"]:
                    if not self._columns(con, STOCK_TABLE):
                        raise StoreError(f"{STOCK_TABLE} is missing, so the stock cannot be put back. Nothing was changed.")
                    result.stock_updates = self._apply_stock_signed(con, old, sign=-1)
                if old["type"] == "Sales" and old["invoice_no"] and self._columns(con, SALES_TABLE):
                    con.execute(f"DELETE FROM {SALES_TABLE} WHERE invoice_no = ?", (old["invoice_no"],))
            con.execute("UPDATE bp_vouchers SET status = ? WHERE id = ?", (CANCELLED, voucher_id))
            con.execute("INSERT OR REPLACE INTO bp_voucher_details (voucher_id, field, value) VALUES (?, ?, ?)",
                        (voucher_id, "Cancelled on", datetime.now().strftime("%d-%m-%Y %H:%M")))
            audit.record(con, "Cancel", old["type"], old["invoice_no"] or old["number"], voucher_id, audit.describe(old),
                         old["total"], f"Cancelled: number kept in the series; amounts out of the books (was {old['status']})",
                         Decimal("0"), audit.moved(before_bal, audit.snapshot(con, [old])))
            audit.end(con)
            con.execute("COMMIT")
            return result
        except StoreError:
            self._rollback(con)
            raise
        except sqlite3.Error as exc:
            self._rollback(con)
            if "locked" in str(exc).lower():
                raise StoreError("The database is busy (another program is writing to it). Nothing was changed.") from exc
            raise StoreError(f"Not cancelled: {exc}") from exc
        finally:
            con.close()

    def _summary(self, con: sqlite3.Connection, voucher: dict, sign: int, result: SaveResult | None) -> None:
        for name, delta in self._deltas(voucher).items():
            rows = self._find_account(con, name)
            if len(rows) != 1:
                continue
            acc_id, acc_name, balance, _c = rows[0]
            before = Decimal(str(balance or 0)).quantize(Decimal("0.01"))
            after = before + sign * delta
            con.execute(f"UPDATE {SUMMARY_TABLE} SET outstanding_balance = ? WHERE account_id = ?", (_real(after), acc_id))
            if result is not None:
                result.account_updates.append(f"{acc_name}: {before:,.2f} -> {after:,.2f}")

    def _apply_stock_signed(self, con: sqlite3.Connection, voucher: dict, sign: int) -> list[str]:
        """sign=1: as saving (Sales out, Purchase in); sign=-1: undo that."""
        direction = (-1 if voucher["type"] == "Sales" else 1) * sign
        changes = []
        for name, qty in self._item_totals(voucher).items():
            rows = con.execute(f"SELECT product_sku, qty_on_hand FROM {STOCK_TABLE} "
                               "WHERE lower(trim(product_sku)) = lower(trim(?))", (name,)).fetchall()
            if len(rows) != 1:
                raise StoreError(f"Item '{name}' is not a single product_sku in {STOCK_TABLE}. Nothing was changed.")
            sku, before = rows[0][0], int(rows[0][1] or 0)
            con.execute(f"UPDATE {STOCK_TABLE} SET qty_on_hand = ? WHERE product_sku = ?", (before + direction * qty, sku))
            changes.append(f"{sku}: {before} -> {before + direction * qty}")
        return changes

    # ---- ledger statement --------------------------------------------------------------
    def ledger_statement(self, ledger: str, upto: date, start: date | None = None) -> dict:
        """Opening (master opening + vouchers before `start`), one row per voucher, closing.
        Optional vouchers are left out, as in the reports. Amounts: Dr + / Cr -."""
        from services.reports import financial_year_start
        start = start or financial_year_start(upto)
        con = self._connect()
        try:
            opening = ZERO
            if self._columns(con, "bp_ledgers"):
                row = con.execute("SELECT opening_paise FROM bp_ledgers WHERE name = ?", (ledger.strip(),)).fetchone()
                opening = from_paise(row[0]) if row else ZERO
            rows: list[dict] = []
            if self._has_bp_tables(con):
                live = (" AND coalesce(v.status, 'Regular') NOT IN ('Optional', 'Cancelled')"
                        if "status" in self._columns(con, "bp_vouchers") else "")
                before = con.execute(
                    "SELECT coalesce(sum(CASE l.side WHEN 'Dr' THEN l.amount_paise ELSE -l.amount_paise END), 0) "
                    "FROM bp_voucher_lines l JOIN bp_vouchers v ON v.id = l.voucher_id "
                    f"WHERE lower(trim(l.ledger)) = lower(trim(?)) AND v.voucher_date < ?{live}",
                    (ledger, start.isoformat())).fetchone()[0]
                opening += from_paise(before)
                found = con.execute(
                    "SELECT v.id, v.voucher_date, v.voucher_type, v.voucher_no, v.invoice_no, v.narration, "
                    "sum(CASE l.side WHEN 'Dr' THEN l.amount_paise ELSE -l.amount_paise END) "
                    "FROM bp_voucher_lines l JOIN bp_vouchers v ON v.id = l.voucher_id "
                    f"WHERE lower(trim(l.ledger)) = lower(trim(?)) AND v.voucher_date BETWEEN ? AND ?{live} "
                    "GROUP BY v.id ORDER BY v.voucher_date, v.id", (ledger, start.isoformat(), upto.isoformat())).fetchall()
                for vid, vdate, vtype, vno, inv, narration, paise in found:
                    others = [r[0] for r in con.execute(
                        "SELECT ledger FROM bp_voucher_lines WHERE voucher_id = ? AND lower(trim(ledger)) != lower(trim(?)) "
                        "ORDER BY line_no", (vid, ledger))]
                    rows.append({"id": vid, "date": date.fromisoformat(vdate), "type": vtype, "number": inv or vno,
                                 "particulars": others[0] + (" (and others)" if len(others) > 1 else "") if others else "",
                                 "amount": from_paise(paise), "narration": narration})
            running = opening
            for r in rows:
                running += r["amount"]
                r["balance"] = running
            return {"ledger": ledger, "start": start, "end": upto, "opening": opening, "rows": rows, "closing": running}
        finally:
            con.close()
