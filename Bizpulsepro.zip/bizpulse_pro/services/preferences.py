"""
Saving the Settings screen's choices into config/settings.py, so they survive a restart.

    CHOICES                          key -> the values allowed, or a check (nothing else is ever written)
    read_preferences(path) -> dict   what the file says now
    save_preferences(values, path)   rewrites ONLY the lines between the two markers

    # >>> BIZPULSE PREFERENCES
    THEME = 'Pro Dark Blue'
    ...
    # <<< BIZPULSE PREFERENCES

Safety: every value must be one of CHOICES (no free text reaches the file); the new file is
checked by compiling it before anything is replaced; it is written to a temporary file beside
settings.py and swapped in with one rename (os.replace), so settings.py is never half-written;
the previous version is kept as settings.py.bak. If the markers are missing (an older or
hand-edited settings.py) nothing is written and the error says what to add.
"""
from __future__ import annotations

import ast
import os
import re
from pathlib import Path

SETTINGS_FILE = Path(__file__).resolve().parent.parent / "config" / "settings.py"
START, END = "# >>> BIZPULSE PREFERENCES", "# <<< BIZPULSE PREFERENCES"
_COMPANY_FILE = re.compile(r"^(companies/)?[a-z0-9_]{1,40}\.db$")


def _footer(value) -> bool:
    return isinstance(value, str) and len(value) <= 100 and value.isprintable()


# key -> the values allowed: a tuple of choices, or a check for free values (company file, footer)
CHOICES: dict[str, object] = {
    "THEME": ("Pro Dark Blue", "Lite Classic", "Slate Minimal"),
    "FONT_SCALE": (11, 12),
    "ROW_DENSITY": ("Compact", "Comfortable"),
    "KEYBOARD_LAYOUT": ("Standard Tally", "BizPulse Express"),
    "GRID_LINES": (True, False),
    "COMPANY_FILE": lambda v: isinstance(v, str) and (v == "bizpulse_local.db" or bool(_COMPANY_FILE.match(v))),
    "PRINT_PAPER": ("A4", "80 mm"),
    "PRINT_SHOW_HSN": (True, False),
    "PRINT_FOOTER": _footer,
}
DEFAULTS = {"THEME": "Pro Dark Blue", "FONT_SCALE": 11, "ROW_DENSITY": "Comfortable",
            "KEYBOARD_LAYOUT": "Standard Tally", "GRID_LINES": True, "COMPANY_FILE": "bizpulse_local.db",
            "PRINT_PAPER": "A4", "PRINT_SHOW_HSN": True, "PRINT_FOOTER": "This is a computer-generated invoice."}


def allowed(key: str, value) -> bool:
    rule = CHOICES.get(key)
    if rule is None or type(value) is not type(DEFAULTS[key]):
        return False
    return rule(value) if callable(rule) else value in rule
_BLOCK = re.compile(re.escape(START) + r"\n(.*?)" + re.escape(END), re.S)


class PreferencesError(Exception):
    """A message the user can act on; settings.py was not changed."""


def _block(text: str) -> re.Match:
    m = _BLOCK.search(text)
    if m is None:
        raise PreferencesError(f"config/settings.py has no preferences block. Add the lines '{START}' and "
                               f"'{END}' (see the copy of settings.py in the latest download); nothing was changed.")
    return m


def read_preferences(path: Path = SETTINGS_FILE) -> dict:
    """The values in the block (defaults for any that are missing or not allowed)."""
    values = dict(DEFAULTS)
    try:
        body = _block(Path(path).read_text(encoding="utf-8")).group(1)
    except (OSError, PreferencesError):
        return values
    for node in ast.parse(body).body:
        if isinstance(node, ast.Assign) and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name):
            key = node.targets[0].id
            try:
                value = ast.literal_eval(node.value)
            except ValueError:
                continue
            if allowed(key, value):
                values[key] = value
    return values


def save_preferences(values: dict, path: Path = SETTINGS_FILE) -> Path:
    """Writes the block: the keys given change, every other key keeps what the file holds.
    Raises PreferencesError (file unchanged) on any problem."""
    path = Path(path)
    clean = read_preferences(path)
    for key, value in values.items():
        if not allowed(key, value):
            raise PreferencesError(f"{key} = {value!r} is not one of the allowed settings; nothing was changed.")
        clean[key] = value
    try:
        text = path.read_text(encoding="utf-8")
    except OSError as exc:
        raise PreferencesError(f"Could not read {path.name}: {exc}") from exc
    m = _block(text)
    body = "".join(f"{key} = {clean[key]!r}\n" for key in CHOICES)
    new = text[:m.start(1)] + body + text[m.end(1):]
    try:
        compile(new, str(path), "exec")
    except SyntaxError as exc:                      # cannot happen with CHOICES, but never risk it
        raise PreferencesError(f"The new settings.py would not load ({exc}); nothing was changed.") from exc
    tmp = path.with_suffix(".py.tmp")
    try:
        tmp.write_text(new, encoding="utf-8")
        if path.exists():
            path.with_suffix(".py.bak").write_text(text, encoding="utf-8")
        os.replace(tmp, path)
    except OSError as exc:
        try:
            tmp.unlink()
        except OSError:
            pass
        raise PreferencesError(f"Could not write {path.name} ({exc}). Is the BizPulse folder read-only?") from exc
    return path
