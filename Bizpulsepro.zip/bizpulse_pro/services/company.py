"""
The company profile: name, GST state, GSTIN, PAN, CIN, address and invoice series, kept INSIDE
each company's database (bp_company), so every company file carries its own.

    read_profile(db_path) -> dict | None        what the database holds (None: not entered yet)
    current(db_path, settings) -> dict           the profile, or config/settings.py's values
    apply(settings, profile)                     puts it into config.settings for this run
    check(values) -> dict                        cleaned values; CompanyError says what is wrong
    save_profile(db_path, values)                one transaction, logged in the audit trail
    company_files(app_dir, main_file)            the company databases BizPulse can open
    new_file_name(app_dir, name)                 companies/<name>.db for Create Company

Rules (check): the name is required; the state code is a GST state; a GSTIN must be valid and
from that state; a PAN is AAAAA9999A; a CIN is the 21-character MCA form; the invoice prefix is
1–5 letters, digits or '-', so a number like SRJ/26-27/0001 fits the 16 characters GST allows.
"""
from __future__ import annotations

import re
import sqlite3
from datetime import datetime
from pathlib import Path

from services import audit
from services.gst import STATE_NAMES, check_gstin, check_state_code

FIELDS = ("name", "state_code", "gstin", "pan", "cin", "address", "invoice_prefix")
PAN_RE = re.compile(r"^[A-Z]{5}\d{4}[A-Z]$")
CIN_RE = re.compile(r"^[LU]\d{5}[A-Z]{2}\d{4}[A-Z]{3}\d{6}$")
PREFIX_RE = re.compile(r"^[A-Z0-9-]{1,5}$")
COMPANIES_DIR = "companies"


class CompanyError(Exception):
    """A message the user can act on; nothing was saved."""


def read_profile(db_path: Path) -> dict | None:
    db_path = Path(db_path)
    if not db_path.is_file():
        return None
    try:
        con = sqlite3.connect(db_path.resolve().as_uri() + "?mode=ro", uri=True, timeout=5)
    except sqlite3.Error:
        return None
    try:
        if not con.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='bp_company'").fetchone():
            return None
        row = con.execute(f"SELECT {', '.join(FIELDS)} FROM bp_company WHERE id = 1").fetchone()
        return dict(zip(FIELDS, row)) if row else None
    except sqlite3.Error:
        return None
    finally:
        con.close()


def current(db_path: Path, settings) -> dict:
    return read_profile(db_path) or {
        "name": settings.COMPANY_NAME, "state_code": settings.COMPANY_STATE_CODE, "gstin": settings.COMPANY_GSTIN,
        "pan": getattr(settings, "COMPANY_PAN", ""), "cin": getattr(settings, "COMPANY_CIN", ""),
        "address": getattr(settings, "COMPANY_ADDRESS", ""), "invoice_prefix": settings.INVOICE_PREFIX}


def apply(settings, profile: dict | None) -> None:
    if not profile:
        return
    settings.COMPANY_NAME = profile["name"]
    settings.COMPANY_STATE_CODE = profile["state_code"]
    settings.COMPANY_STATE_NAME = STATE_NAMES.get(profile["state_code"], profile["state_code"])
    settings.COMPANY_GSTIN = profile.get("gstin", "")
    settings.COMPANY_PAN = profile.get("pan", "")
    settings.COMPANY_CIN = profile.get("cin", "")
    settings.COMPANY_ADDRESS = profile.get("address", "")
    settings.INVOICE_PREFIX = profile["invoice_prefix"]


def check(values: dict) -> dict:
    v = {k: str(values.get(k, "") or "").strip() for k in FIELDS}
    if not v["name"]:
        raise CompanyError("Enter the company name.")
    if len(v["name"]) > 80:
        raise CompanyError("The company name can have at most 80 characters.")
    try:
        v["state_code"] = check_state_code(v["state_code"])
    except ValueError:
        raise CompanyError("The state code must be a GST state code: 01 to 38, or 97 (West Bengal is 19).") from None
    try:
        v["gstin"] = check_gstin(v["gstin"])
    except ValueError as exc:
        raise CompanyError(f"GSTIN: {exc}") from None
    if v["gstin"] and v["gstin"][:2] != v["state_code"]:
        raise CompanyError(f"The GSTIN is from state {v['gstin'][:2]}, but the state code is {v['state_code']}.")
    v["pan"] = v["pan"].upper()
    if v["pan"] and not PAN_RE.match(v["pan"]):
        raise CompanyError("PAN must look like AAAAA9999A.")
    if v["gstin"] and v["pan"] and v["gstin"][2:12] != v["pan"]:
        raise CompanyError("The PAN does not match the PAN inside the GSTIN (characters 3 to 12).")
    v["cin"] = v["cin"].upper()
    if v["cin"] and not CIN_RE.match(v["cin"]):
        raise CompanyError("CIN must be the 21-character form, e.g. U12345WB2020PTC123456.")
    v["invoice_prefix"] = v["invoice_prefix"].upper()
    if not PREFIX_RE.match(v["invoice_prefix"]):
        raise CompanyError("The invoice prefix must be 1 to 5 letters, digits or '-' (e.g. SRJ).")
    if len(v["address"]) > 300:
        raise CompanyError("The address can have at most 300 characters.")
    return v


def save_profile(db_path: Path, values: dict) -> dict:
    v = check(values)
    db_path = Path(db_path)
    if not db_path.is_file():
        raise CompanyError(f"{db_path.name} was not found. Nothing was saved.")
    from services.schema import COMPANY_DDL
    con = sqlite3.connect(str(db_path), timeout=5, isolation_level=None)
    try:
        con.execute("BEGIN IMMEDIATE")
        con.execute(COMPANY_DDL)
        audit.begin(con, source="BizPulse Company", mode="row")
        now = datetime.now().isoformat(timespec="seconds")
        con.execute(f"INSERT INTO bp_company (id, {', '.join(FIELDS)}, created_at, updated_at) "
                    f"VALUES (1, {', '.join('?' * len(FIELDS))}, ?, ?) ON CONFLICT(id) DO UPDATE SET "
                    + ", ".join(f"{f} = excluded.{f}" for f in FIELDS) + ", updated_at = excluded.updated_at",
                    tuple(v[f] for f in FIELDS) + (now, now))
        audit.end(con)
        con.execute("COMMIT")
    except sqlite3.Error as exc:
        if con.in_transaction:
            con.execute("ROLLBACK")
        raise CompanyError(f"Not saved: {exc}") from exc
    finally:
        con.close()
    return v


def company_files(app_dir: Path, main_file: str) -> list[tuple[str, str]]:
    """(file relative to the BizPulse folder, company name) for every company database."""
    app_dir = Path(app_dir)
    out = []
    candidates = [app_dir / main_file] + sorted((app_dir / COMPANIES_DIR).glob("*.db"))
    for path in candidates:
        if path.is_file():
            profile = read_profile(path)
            rel = path.relative_to(app_dir).as_posix()
            out.append((rel, profile["name"] if profile else f"{path.stem} (no company details yet)"))
    return out


def new_file_name(app_dir: Path, name: str) -> str:
    stem = re.sub(r"[^a-z0-9]+", "_", name.lower()).strip("_")[:40] or "company"
    rel, n = f"{COMPANIES_DIR}/{stem}.db", 2
    while (Path(app_dir) / rel).exists():
        rel, n = f"{COMPANIES_DIR}/{stem}_{n}.db", n + 1
    return rel
