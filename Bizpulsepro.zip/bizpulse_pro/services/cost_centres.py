"""
Cost centres: splitting a voucher line across departments, projects or branches.

    bp_cost_allocations(voucher_id, line_no, cost_centre, amount_paise, percent)
        one row per share of a bp_voucher_lines row; the shares add up to the line exactly

    cost_ledgers(db_path, groups)        ledgers whose group rolls up to COST_CENTRE_GROUPS
                                         (the lines that offer the allocation box)
    known_centres(db_path, configured)   COST_CENTRES plus every name used before
    check(amount, allocations)           None, or what is wrong
    share(amount, percent)               amount × percent / 100, to the paisa
    rescale(allocations, new_amount)     the same split on a converted amount (foreign currency)
    summary(db_path, start, end)         [(centre, ledger, amount)] for the Cost Centre Summary

Optional and Cancelled vouchers are left out of the summary, as everywhere else.
"""
from __future__ import annotations

import sqlite3
from dataclasses import dataclass
from datetime import date
from decimal import ROUND_HALF_UP, Decimal
from pathlib import Path

CENT = Decimal("0.01")
DDL = """
CREATE TABLE IF NOT EXISTS bp_cost_allocations (
    voucher_id    INTEGER NOT NULL REFERENCES bp_vouchers(id),
    line_no       INTEGER NOT NULL,             -- the bp_voucher_lines row it splits
    share_no      INTEGER NOT NULL,
    cost_centre   TEXT    NOT NULL,
    amount_paise  INTEGER NOT NULL CHECK (amount_paise > 0),
    percent       TEXT    NOT NULL DEFAULT '',  -- as typed ('' when an amount was typed)
    PRIMARY KEY (voucher_id, line_no, share_no)
)"""


def share(amount: Decimal, percent: Decimal) -> Decimal:
    return (amount * percent / 100).quantize(CENT, rounding=ROUND_HALF_UP)


def check(amount: Decimal, allocations: list[dict]) -> str | None:
    if not allocations:
        return None
    names = [a["cost_centre"].strip().lower() for a in allocations]
    if any(not n for n in names):
        return "every share needs a cost centre name"
    if len(set(names)) != len(names):
        return "a cost centre is used twice; put its amounts together"
    if any(a["amount"] <= 0 for a in allocations):
        return "every share needs an amount above 0"
    total = sum((a["amount"] for a in allocations), Decimal("0"))
    if total != amount:
        return f"the shares add up to {total:,.2f}, not {amount:,.2f}"
    return None


def rescale(allocations: list[dict], new_amount: Decimal) -> list[dict]:
    """Keeps the proportions; the last share takes the rounding paise."""
    if not allocations:
        return []
    old = sum((a["amount"] for a in allocations), Decimal("0"))
    out, used = [], Decimal("0")
    for i, a in enumerate(allocations):
        amt = new_amount - used if i == len(allocations) - 1 else (a["amount"] * new_amount / old).quantize(
            CENT, rounding=ROUND_HALF_UP)
        used += amt
        out.append(dict(a, amount=amt))
    return out


def write(con: sqlite3.Connection, voucher_id: int, lines: list[dict]) -> None:
    con.execute(DDL)
    rows = []
    for i, ln in enumerate(lines, start=1):
        for j, a in enumerate(ln.get("allocations") or [], start=1):
            rows.append((voucher_id, i, j, a["cost_centre"].strip(), int((a["amount"] * 100).to_integral_value()),
                         str(a.get("percent") or "")))
    if rows:
        con.executemany("INSERT INTO bp_cost_allocations (voucher_id, line_no, share_no, cost_centre, amount_paise, "
                        "percent) VALUES (?, ?, ?, ?, ?, ?)", rows)


def read(con: sqlite3.Connection, ids: list[int]) -> dict[tuple[int, int], list[dict]]:
    """(voucher id, line no) -> shares."""
    if not ids or not con.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='bp_cost_allocations'").fetchone():
        return {}
    out: dict[tuple[int, int], list[dict]] = {}
    marks = ",".join("?" * len(ids))
    for vid, line, centre, paise, pct in con.execute(
            f"SELECT voucher_id, line_no, cost_centre, amount_paise, percent FROM bp_cost_allocations "
            f"WHERE voucher_id IN ({marks}) ORDER BY voucher_id, line_no, share_no", ids):
        out.setdefault((vid, line), []).append({"cost_centre": centre, "amount": Decimal(paise) / 100,
                                                "percent": pct or ""})
    return out


def _ro(db_path: Path) -> sqlite3.Connection:
    return sqlite3.connect(Path(db_path).resolve().as_uri() + "?mode=ro", uri=True, timeout=5)


def cost_ledgers(db_path: Path, groups: tuple[str, ...]) -> set[str]:
    from services.reports import _group_lookup
    con = _ro(db_path)
    try:
        return {name for name, group in _group_lookup(con).items() if group in groups}
    finally:
        con.close()


def known_centres(db_path: Path, configured: list[str]) -> list[str]:
    names = list(configured)
    try:
        con = _ro(db_path)
    except sqlite3.Error:
        return names
    try:
        if con.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='bp_cost_allocations'").fetchone():
            for (n,) in con.execute("SELECT DISTINCT cost_centre FROM bp_cost_allocations ORDER BY cost_centre"):
                if n.lower() not in {x.lower() for x in names}:
                    names.append(n)
    finally:
        con.close()
    return names


@dataclass
class SummaryRow:
    centre: str
    ledger: str
    amount: Decimal


def summary(db_path: Path, start: date, end: date) -> list[SummaryRow]:
    from services.reports import live_filter
    con = _ro(db_path)
    try:
        if not con.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='bp_cost_allocations'").fetchone():
            return []
        rows = con.execute(
            "SELECT a.cost_centre, l.ledger, sum(CASE l.side WHEN 'Dr' THEN a.amount_paise ELSE -a.amount_paise END) "
            "FROM bp_cost_allocations a JOIN bp_voucher_lines l ON l.voucher_id = a.voucher_id AND l.line_no = a.line_no "
            "JOIN bp_vouchers v ON v.id = a.voucher_id "
            f"WHERE v.voucher_date BETWEEN ? AND ?{live_filter(con)} "
            "GROUP BY lower(a.cost_centre), l.ledger ORDER BY lower(a.cost_centre), l.ledger",
            (start.isoformat(), end.isoformat())).fetchall()
        return [SummaryRow(c, lg, Decimal(p) / 100) for c, lg, p in rows]
    finally:
        con.close()
