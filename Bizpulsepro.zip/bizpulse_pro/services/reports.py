"""
Balance Sheet and Profit & Loss A/c figures, worked out from the vouchers saved in
bizpulse_local.db (bp_vouchers / bp_voucher_lines).

Why vouchers, and not gst_sales_ledger / workforce_payroll directly:
    * Every voucher is balanced (debit = credit), so reports built from them always agree:
      the Balance Sheet totals match because the books do, not because a figure is forced.
    * gst_sales_ledger and workforce_payroll have no date column, so they cannot be cut to a
      period; and workforce_payroll is the salary register, not salary paid. Adding them on
      top of the vouchers would count Sales twice and salary that was never booked.
    Their totals are still shown on the P&L as a cross-check ("From your other tables").

Grouping: config/ledger_groups.py (plus customers in corporate_ledger_summary as Sundry
Debtors). A ledger with no group is shown as "Not grouped" on the side its balance falls.

Stock (config/stock_valuation.py):
    Opening Stock  = OPENING_STOCK entered for the financial year (value at cost on 1 April)
    Closing Stock  = Stock Summary value at cost (services/stock.py), today's quantities
    P&L A/c        gross profit = Sales + Direct Incomes − Opening Stock − Purchases
                                  − Direct Expenses + Closing Stock
    Balance Sheet  Current Assets › Stock-in-Hand › Closing Stock; the P&L A/c on the
                   liabilities side carries "Opening stock b/f" (last year's
                   closing stock, already in last year's profit) plus this period's profit.
    Closing stock is added once on each side, so the totals still agree by themselves.
    Stock valued at a selling price / MRP is kept out of the books (it would inflate gross
    profit); every such decision is listed in Reports.stock_notes for the screens to show.

Optional and Cancelled vouchers are left out everywhere (live_filter); Post-Dated ones count
from their date.

Read-only: the database is opened with mode=ro and never written here.
"""
from __future__ import annotations

import sqlite3
from dataclasses import dataclass, field
from datetime import date
from decimal import Decimal
from pathlib import Path

from config import stock_valuation as SV
from config.ledger_groups import LEDGER_GROUPS, RESERVED_GROUPS

ZERO = Decimal("0.00")

LIABILITY_GROUPS = ["Capital Account", "Loans (Liability)", "Current Liabilities"]
ASSET_GROUPS = ["Fixed Assets", "Investments", "Current Assets"]
# Reserved primary groups shown only when they hold something.
EXTRA_LIABILITY_GROUPS = ["Branch / Divisions", "Suspense A/c"]
EXTRA_ASSET_GROUPS = ["Misc. Expenses (ASSET)"]
OPENING_DIFFERENCE = "Difference in opening balances"
SUBGROUP_OF = {
    "Reserves & Surplus": "Capital Account",
    "Bank OD A/c": "Loans (Liability)", "Secured Loans": "Loans (Liability)", "Unsecured Loans": "Loans (Liability)",
    "Duties & Taxes": "Current Liabilities", "Provisions": "Current Liabilities", "Sundry Creditors": "Current Liabilities",
    "Bank Accounts": "Current Assets", "Cash-in-Hand": "Current Assets", "Deposits (Asset)": "Current Assets",
    "Loans & Advances (Asset)": "Current Assets", "Stock-in-Hand": "Current Assets", "Sundry Debtors": "Current Assets",
}
INCOME_GROUPS = ["Sales Accounts", "Direct Incomes", "Indirect Incomes"]
EXPENSE_GROUPS = ["Purchase Accounts", "Direct Expenses", "Indirect Expenses"]
PL_GROUPS = INCOME_GROUPS + EXPENSE_GROUPS
NOT_GROUPED = "Not grouped"


class ReportError(Exception):
    pass


@dataclass
class Node:
    """A report row: a group (with children) or a ledger (no children)."""
    name: str
    amount: Decimal = ZERO
    children: list["Node"] = field(default_factory=list)


@dataclass
class Reports:
    period_start: date
    period_end: date
    voucher_count: int
    liabilities: list[Node]
    assets: list[Node]
    liabilities_total: Decimal
    assets_total: Decimal
    pl: dict[str, Node]                    # group -> node (amounts on their natural side, positive)
    gross_profit: Decimal
    net_profit: Decimal                    # this period
    profit_before_period: Decimal          # earlier periods (carried into the P&L A/c on the Balance Sheet)
    not_grouped: list[tuple[str, Decimal]] = field(default_factory=list)   # (ledger, Dr+ / Cr- balance)
    reference: dict[str, str] = field(default_factory=dict)
    opening_stock: Decimal = ZERO
    closing_stock: Decimal = ZERO
    opening_difference: Decimal = ZERO     # ledger opening balances that do not agree (Dr + / Cr -)
    # Trial Balance: ledger -> closing balance (Dr +), Balance Sheet ledgers to date, P&L ledgers for the period
    tb_balances: dict[str, Decimal] = field(default_factory=dict)
    tb_groups: dict[str, str] = field(default_factory=dict)          # ledger -> group (None: not grouped)
    profit_before_vouchers: Decimal = ZERO                           # P&L A/c brought forward (vouchers)
    stock_notes: list[str] = field(default_factory=list)


def fy_label(start: date) -> str:
    return f"{start.year}-{(start.year + 1) % 100:02d}"


def _stock_in_books(db_path: Path, start: date, period_end: date,
                    stock_ledgers: list[str]) -> tuple[Decimal, Decimal, list[str]]:
    """(opening stock, closing stock, notes) for the period, per config/stock_valuation.py."""
    from services.stock import load_stock_summary          # here: services.stock imports this module

    notes: list[str] = []
    if stock_ledgers:
        notes.append(f"Ledger(s) grouped Stock-in-Hand on vouchers ({', '.join(stock_ledgers)}): stock is also "
                     "taken from the Stock Summary, so it may be counted twice.")
    if not SV.INCLUDE_STOCK_IN_BOOKS:
        notes.append("Stock is kept out of the books (INCLUDE_STOCK_IN_BOOKS is off in config/stock_valuation.py).")
        return ZERO, ZERO, notes

    fy = fy_label(start)
    opening, raw = ZERO, None
    if start == financial_year_start(start):
        raw = SV.OPENING_STOCK.get(fy)
        if raw is not None:
            try:
                opening = Decimal(str(raw).replace(",", "").strip()).quantize(Decimal("0.01"))
                if opening < 0:
                    raise ValueError
            except (ArithmeticError, ValueError):
                notes.append(f"OPENING_STOCK for {fy} is not a valid amount ('{raw}'); taken as nil.")
                opening = ZERO
    else:
        notes.append("The period does not start on 1 April, so no opening stock is applied.")

    closing = ZERO
    try:
        summary = load_stock_summary(db_path, SV.STOCK_RATE_COLUMN)
    except ReportError:
        summary = None
        notes.append("inventory_stock_registry was not found, so closing stock is nil.")
    if summary is not None and summary.lines:
        if not summary.at_cost:
            why = ("no rate column could be found in inventory_pricing_rules" if summary.rate_source == "none"
                   else f"it is valued at {summary.rate_source}, a selling price, which would overstate gross profit")
            notes.append(f"Stock (opening and closing) is left out of the books: {why}. Set STOCK_RATE_COLUMN "
                         "in config/stock_valuation.py to a cost column.")
            return ZERO, ZERO, notes        # both or neither, so gross profit is not tilted either way
        else:
            closing = summary.total_value
            if summary.unpriced:
                notes.append(f"{summary.unpriced} SKU(s) have no cost rate, so closing stock is understated by "
                             "their value.")
            if period_end < date.today():
                notes.append("Closing stock uses today's quantities (inventory_stock_registry keeps no history).")
    if closing and raw is None and start == financial_year_start(start):
        notes.append(f"Opening stock for {fy} is not entered in config/stock_valuation.py. If the business held "
                     f"stock on {start.strftime('%d-%m-%Y')}, gross profit is overstated by its value.")
    return opening, closing, notes


def financial_year_start(d: date) -> date:
    return date(d.year if d.month >= 4 else d.year - 1, 4, 1)


def _paise(x: int | None) -> Decimal:
    return (Decimal(x or 0) / 100).quantize(Decimal("0.01"))


def _connect_ro(db_path: Path) -> sqlite3.Connection:
    if not db_path.is_file():
        raise ReportError(f"{db_path.name} was not found in {db_path.parent}.")
    try:
        return sqlite3.connect(db_path.resolve().as_uri() + "?mode=ro", uri=True, timeout=5)
    except sqlite3.Error as exc:
        raise ReportError(f"Could not open {db_path.name}: {exc}") from exc


def _has_table(con: sqlite3.Connection, name: str) -> bool:
    return con.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", (name,)).fetchone() is not None


def _resolve(group: str, custom: dict[str, str]) -> str | None:
    """A new group (bp_groups) -> the reserved group it sits under; None if unknown."""
    seen = set()
    while group and group not in RESERVED_GROUPS:
        key = group.lower()
        if key in seen or key not in custom:
            return None
        seen.add(key)
        group = custom[key]
    return group or None


def _master_ledgers(con: sqlite3.Connection) -> tuple[dict[str, str], dict[str, tuple[str, Decimal]]]:
    """Ledgers created in Masters: (lower name -> reserved group, lower name -> (name, opening Dr+))."""
    if not _has_table(con, "bp_ledgers"):
        return {}, {}
    custom = {}
    if _has_table(con, "bp_groups"):
        custom = {n.lower(): u for n, u in con.execute("SELECT name, under_group FROM bp_groups")}
    groups, openings = {}, {}
    for name, under, paise in con.execute("SELECT name, under_group, opening_paise FROM bp_ledgers"):
        resolved = _resolve(under, custom)
        if resolved:
            groups[name.strip().lower()] = resolved
        if paise:
            openings[name.strip().lower()] = (name.strip(), _paise(paise))
    return groups, openings


def _books_opening_stock(con: sqlite3.Connection) -> Decimal:
    """OPENING_STOCK of the year the books begin (bp_company.books_from), when stock is in the books."""
    if not SV.INCLUDE_STOCK_IN_BOOKS or not _has_table(con, "bp_company"):
        return ZERO
    if "books_from" not in {r[1] for r in con.execute("PRAGMA table_info(bp_company)")}:
        return ZERO
    row = con.execute("SELECT books_from FROM bp_company WHERE id = 1").fetchone()
    if not row or not row[0]:
        return ZERO
    try:
        raw = SV.OPENING_STOCK.get(fy_label(financial_year_start(date.fromisoformat(row[0]))))
        value = Decimal(str(raw).replace(",", "").strip()).quantize(Decimal("0.01")) if raw is not None else ZERO
    except (ArithmeticError, ValueError):
        return ZERO
    return value if value > 0 else ZERO


def _group_lookup(con: sqlite3.Connection) -> dict[str, str]:
    groups = {k.strip().lower(): v for k, v in LEDGER_GROUPS.items()}
    if _has_table(con, "corporate_ledger_summary"):
        for (name,) in con.execute("SELECT account_name FROM corporate_ledger_summary WHERE account_name IS NOT NULL"):
            groups.setdefault(name.strip().lower(), "Sundry Debtors")
    groups.update(_master_ledgers(con)[0])          # ledgers created in Masters take precedence
    return groups


def live_filter(con: sqlite3.Connection, alias: str = "v") -> str:
    """SQL condition leaving out Optional and Cancelled vouchers (they never reach the reports).
    Empty on databases from before voucher statuses existed."""
    cols = {r[1] for r in con.execute("PRAGMA table_info(bp_vouchers)")}
    return f" AND coalesce({alias}.status, 'Regular') NOT IN ('Optional', 'Cancelled')" if "status" in cols else ""


def _balances(con: sqlite3.Connection, where: str, args: tuple) -> dict[str, Decimal]:
    """Ledger -> balance (debit positive) over the vouchers matching `where` (Optional ones left out)."""
    rows = con.execute(
        "SELECT l.ledger, sum(CASE l.side WHEN 'Dr' THEN l.amount_paise ELSE -l.amount_paise END) "
        "FROM bp_voucher_lines l JOIN bp_vouchers v ON v.id = l.voucher_id "
        f"WHERE {where}{live_filter(con)} GROUP BY l.ledger", args).fetchall()
    out: dict[str, Decimal] = {}
    for ledger, paise in rows:      # merge names that differ only by capitals / spaces
        key = ledger.strip()
        out[key] = out.get(key, ZERO) + _paise(paise)
    return out


def _tree(primary: str, items: list[tuple[str, str, Decimal]]) -> Node:
    """items: (subgroup or primary, ledger, amount) -> primary node with sub-group nodes."""
    node = Node(primary)
    subs: dict[str, Node] = {}
    for grp, ledger, amount in sorted(items, key=lambda t: (t[0] != primary, t[0], t[1].lower())):
        if not amount:
            continue
        if grp == primary:
            node.children.append(Node(ledger, amount))
        else:
            sub = subs.setdefault(grp, Node(grp))
            sub.children.append(Node(ledger, amount))
            sub.amount += amount
        node.amount += amount
    node.children.extend(subs.values())
    return node


def build_reports(db_path: Path, period_end: date, period_start: date | None = None,
                  stock_override: tuple[Decimal, Decimal, str] | None = None) -> Reports:
    """stock_override=(opening, closing, note): use these stock values instead of
    config/stock_valuation.py + the Stock Summary (comparative columns for past periods)."""
    start = period_start or financial_year_start(period_end)
    con = _connect_ro(db_path)
    try:
        if not _has_table(con, "bp_vouchers"):
            balances_all: dict[str, Decimal] = {}
            balances_period: dict[str, Decimal] = {}
            count = 0
        else:
            end_iso, start_iso = period_end.isoformat(), start.isoformat()
            balances_all = _balances(con, "v.voucher_date <= ?", (end_iso,))
            balances_period = _balances(con, "v.voucher_date BETWEEN ? AND ?", (start_iso, end_iso))
            count = con.execute("SELECT count(*) FROM bp_vouchers v WHERE voucher_date BETWEEN ? AND ?"
                                + live_filter(con), (start_iso, end_iso)).fetchone()[0]
        lookup = _group_lookup(con)
        openings = _master_ledgers(con)[1]
        books_stock = _books_opening_stock(con)
        reference = _reference_figures(con)
    except sqlite3.Error as exc:
        raise ReportError(f"Could not read {db_path.name}: {exc}") from exc
    finally:
        con.close()

    def group_of(ledger: str) -> str | None:
        return lookup.get(ledger.strip().lower())

    # Opening balances of ledgers created in Masters (Balance Sheet ledgers only).
    opening_total = ZERO
    by_lower = {k.lower(): k for k in balances_all}
    for low, (name, amount) in openings.items():
        key = by_lower.get(low, name)
        balances_all[key] = balances_all.get(key, ZERO) + amount
        opening_total += amount
    # The stock held when the books begin is part of the opening position (as in Tally's opening
    # trial balance), so the ledger openings are expected to fall short of it by exactly that much.
    opening_total += books_stock

    # ---- Profit & Loss: this period, and everything before it -----------------------------
    pl_items: dict[str, list[tuple[str, str, Decimal]]] = {g: [] for g in PL_GROUPS}
    for ledger, bal in balances_period.items():
        grp = group_of(ledger)
        if grp in PL_GROUPS:
            natural = -bal if grp in INCOME_GROUPS else bal      # incomes are credits
            pl_items[grp].append((grp, ledger, natural))
    pl = {g: _tree(g, items) for g, items in pl_items.items()}

    stock_ledgers = sorted(lg for lg, b in balances_all.items() if b and group_of(lg) == "Stock-in-Hand")
    if stock_override is not None:
        opening, closing, note = stock_override
        stock_notes = [note] if note else []
    else:
        opening, closing, stock_notes = _stock_in_books(db_path, start, period_end, stock_ledgers)
    pl["Opening Stock"] = Node("Opening Stock", opening, [Node(
        f"{SV.OPENING_STOCK_LEDGER} as on {start.strftime('%d-%m-%Y')}", opening)] if opening else [])
    pl["Closing Stock"] = Node("Closing Stock", closing, [Node(
        f"{SV.CLOSING_STOCK_LEDGER} (Stock Summary, at cost)", closing)] if closing else [])
    gross = (pl["Sales Accounts"].amount + pl["Direct Incomes"].amount
             - pl["Opening Stock"].amount - pl["Purchase Accounts"].amount - pl["Direct Expenses"].amount
             + pl["Closing Stock"].amount)
    net = gross + pl["Indirect Incomes"].amount - pl["Indirect Expenses"].amount

    profit_all = ZERO                                           # vouchers only, all dates
    for ledger, bal in balances_all.items():
        if group_of(ledger) in PL_GROUPS:
            profit_all -= bal                                   # credit balances are profit
    net_vouchers = net - closing + opening                      # this period's profit without stock
    before_vouchers = profit_all - net_vouchers
    before = before_vouchers + opening                          # last year's closing stock was in last year's profit

    # ---- Balance Sheet: everything up to the end date ------------------------------------
    liab_items: dict[str, list] = {g: [] for g in LIABILITY_GROUPS + EXTRA_LIABILITY_GROUPS}
    asset_items: dict[str, list] = {g: [] for g in ASSET_GROUPS + EXTRA_ASSET_GROUPS}
    not_grouped: list[tuple[str, Decimal]] = []
    asset_items["Current Assets"].append(("Stock-in-Hand", SV.CLOSING_STOCK_LEDGER, closing))
    for ledger, bal in balances_all.items():
        grp = group_of(ledger)
        if grp in PL_GROUPS:
            continue
        primary = SUBGROUP_OF.get(grp, grp) if grp else None
        if primary in liab_items:
            liab_items[primary].append((grp, ledger, -bal))      # liabilities are credits
        elif primary in asset_items:
            asset_items[primary].append((grp, ledger, bal))
        elif bal:
            not_grouped.append((ledger, bal))

    liabilities = [_tree(g, liab_items[g]) for g in LIABILITY_GROUPS]
    liabilities += [n for n in (_tree(g, liab_items[g]) for g in EXTRA_LIABILITY_GROUPS) if n.amount]
    pl_parts = [Node("Opening balance", before_vouchers)]
    if opening:
        pl_parts.append(Node("Opening stock b/f", opening))
    pl_parts.append(Node("Current period", net))
    liabilities.append(Node("Profit & Loss A/c", before + net, pl_parts))
    assets = [_tree(g, asset_items[g]) for g in ASSET_GROUPS]
    assets += [n for n in (_tree(g, asset_items[g]) for g in EXTRA_ASSET_GROUPS) if n.amount]
    if opening_total > 0:            # more Dr than Cr in the opening balances: shown as Tally does
        liabilities.append(Node(OPENING_DIFFERENCE, opening_total))
    elif opening_total < 0:
        assets.append(Node(OPENING_DIFFERENCE, -opening_total))
    ng_credit = [(lg, -b) for lg, b in not_grouped if b < 0]
    ng_debit = [(lg, b) for lg, b in not_grouped if b > 0]
    if ng_credit:
        liabilities.append(Node(NOT_GROUPED, sum((a for _l, a in ng_credit), ZERO), [Node(l, a) for l, a in ng_credit]))
    if ng_debit:
        assets.append(Node(NOT_GROUPED, sum((a for _l, a in ng_debit), ZERO), [Node(l, a) for l, a in ng_debit]))

    tb = {lg: b for lg, b in balances_all.items() if b and group_of(lg) not in PL_GROUPS}
    tb.update({lg: b for lg, b in balances_period.items() if b and group_of(lg) in PL_GROUPS})

    return Reports(
        tb_balances=tb, tb_groups={lg: group_of(lg) or NOT_GROUPED for lg in tb},
        profit_before_vouchers=before_vouchers,
        period_start=start, period_end=period_end, voucher_count=count,
        liabilities=liabilities, assets=assets,
        liabilities_total=sum((n.amount for n in liabilities), ZERO),
        assets_total=sum((n.amount for n in assets), ZERO),
        pl=pl, gross_profit=gross, net_profit=net, profit_before_period=before,
        not_grouped=sorted(not_grouped), reference=reference,
        opening_stock=opening, closing_stock=closing, stock_notes=stock_notes, opening_difference=opening_total,
    )


def _reference_figures(con: sqlite3.Connection) -> dict[str, str]:
    """Totals from your other tables, for cross-checking only (not used in the figures)."""
    ref: dict[str, str] = {}
    if _has_table(con, "gst_sales_ledger"):
        n, total = con.execute("SELECT count(*), coalesce(sum(taxable_value), 0) FROM gst_sales_ledger").fetchone()
        ref["gst_sales_ledger"] = f"{n} invoice(s), taxable value {Decimal(str(total)).quantize(Decimal('0.01')):,.2f} (all dates: the table has no date column)"
    if _has_table(con, "workforce_payroll"):
        n, gross = con.execute("SELECT count(*), coalesce(sum(gross_pay), 0) FROM workforce_payroll").fetchone()
        ref["workforce_payroll"] = (f"{n} employee(s), gross pay {Decimal(str(gross)).quantize(Decimal('0.01')):,.2f} "
                                    "per pay run (register only: book salary as a voucher to a 'Salaries' ledger)")
    if _has_table(con, "inventory_stock_registry"):
        n, qty = con.execute("SELECT count(*), coalesce(sum(qty_on_hand), 0) FROM inventory_stock_registry").fetchone()
        ref["inventory_stock_registry"] = f"{n} SKU(s), {qty} unit(s) on hand (valued in the Stock Summary; see Opening / Closing Stock)"
    return ref


def group_totals(r: Reports) -> dict[str, Decimal]:
    """Balance Sheet amounts by primary group and by sub-group (natural side, positive),
    e.g. {"Current Assets": …, "Sundry Debtors": …, "Profit & Loss A/c": …}. Used by Ratio Analysis."""
    totals: dict[str, Decimal] = {}
    for node in r.liabilities + r.assets:
        totals[node.name] = totals.get(node.name, ZERO) + node.amount
        if node.name in (NOT_GROUPED, "Profit & Loss A/c"):
            continue
        for child in node.children:
            if child.children:
                totals[child.name] = totals.get(child.name, ZERO) + child.amount
    return totals


# Shared with services/analytics.py and services/stock.py (read-only helpers).
connect_ro = _connect_ro
has_table = _has_table
group_lookup = _group_lookup
