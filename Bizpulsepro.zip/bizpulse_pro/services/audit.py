"""
The audit trail: bp_system_audit_logs, an append-only, hash-chained record of every change to
the books.

Two kinds of entry
    Voucher entries   written by BizPulse itself, inside the SAME transaction as the change
                      (services/voucher_store.py, voucher_book.py): Create, Alter, Cancel and
                      Realise (a post-dated voucher falling due). Each one keeps the voucher
                      type and number, the original voucher as text and its total, the new
                      voucher as text and its total, and the balances it moved
                      (corporate_ledger_summary, inventory_stock_registry) before -> after.
    Row entries       written by SQLite triggers on the audited tables (AUDITED, below) for any
                      insert / update / delete that is NOT part of a BizPulse voucher
                      transaction: master changes made in BizPulse (labelled "BizPulse Masters")
                      and anything written by another program or script (labelled "outside
                      BizPulse"). Each keeps the table, the changed columns before and after, and
                      the money column where the table has one.

Every entry has the time (YYYY-MM-DD HH:MM:SS, this computer's clock) and the login
(user@computer, plus a session tag for this run of BizPulse; "outside BizPulse" for other
programs, which the database cannot identify).

Unalterable, as far as a database file allows
    * Triggers refuse every DELETE and every UPDATE of bp_system_audit_logs, except the one
      allowed step that fills in the hash of a new entry ("sealing").
    * Each entry's row_hash = SHA-256 of the previous entry's hash and its own contents, so an
      edited or removed entry breaks the chain from that point; verify() reports where.
    * What a file cannot do: someone who can open bizpulse_local.db with other tools could drop
      the triggers and rewrite the whole log with fresh hashes, or cut entries off the end. Note
      the chain head (shown on the Audit Trail screen) at each period close: a later log that no
      longer contains that hash has been rewritten.

How the pieces meet
    begin(con, source, mode)   after BEGIN IMMEDIATE: puts this session's login in bp_audit_context
                               (mode "voucher" quiets the row triggers; the voucher entry says it all)
    record(con, ...)           one voucher entry
    end(con)                   seals new entries and clears bp_audit_context, before COMMIT
    install(db_path)           at start-up: tables, refreshed triggers, seals anything left unsealed
    verify(db_path), load(db_path, ...)   for the Audit Trail screen
"""
from __future__ import annotations

import getpass
import hashlib
import socket
import sqlite3
import uuid
from dataclasses import dataclass
from datetime import date, datetime
from decimal import Decimal
from pathlib import Path

LOG = "bp_system_audit_logs"
CONTEXT = "bp_audit_context"
SESSION = uuid.uuid4().hex[:6]                       # this run of BizPulse
OUTSIDE = "outside BizPulse"
AUDITED = ("bp_vouchers", "bp_voucher_lines", "bp_voucher_items", "bp_voucher_details", "bp_voucher_forex",
           "gst_sales_ledger", "corporate_ledger_summary", "inventory_stock_registry", "bp_ledgers", "bp_groups",
           "bp_gst_classifications", "bp_stock_groups", "bp_units", "bp_stock_items", "bp_cost_allocations",
           "bp_company", "bp_currencies", "bp_stock_categories", "bp_godowns")
# The money (or quantity) column a row entry shows as its value, per table.
VALUE = {"bp_vouchers": ("total_paise", "printf('%.2f', {X}.total_paise / 100.0)"),
         "bp_voucher_lines": ("amount_paise", "printf('%.2f', {X}.amount_paise / 100.0)"),
         "bp_voucher_items": ("amount_paise", "printf('%.2f', {X}.amount_paise / 100.0)"),
         "bp_voucher_forex": ("foreign_cents", "printf('%.2f', {X}.foreign_cents / 100.0)"),
         "gst_sales_ledger": ("taxable_value", "printf('%.2f', {X}.taxable_value)"),
         "corporate_ledger_summary": ("outstanding_balance", "printf('%.2f', {X}.outstanding_balance)"),
         "inventory_stock_registry": ("qty_on_hand", "CAST({X}.qty_on_hand AS TEXT)"),
         "bp_ledgers": ("opening_paise", "printf('%.2f', {X}.opening_paise / 100.0)"),
         "bp_cost_allocations": ("amount_paise", "printf('%.2f', {X}.amount_paise / 100.0)")}
FIELDS = ("logged_at", "user_id", "source", "action", "table_name", "voucher_type", "voucher_no", "voucher_id",
          "old_text", "old_amount", "new_text", "new_amount", "balances")

DDL = f"""
CREATE TABLE IF NOT EXISTS {LOG} (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    logged_at     TEXT    NOT NULL,           -- YYYY-MM-DD HH:MM:SS, local time
    user_id       TEXT    NOT NULL,           -- user@computer (session), or 'outside BizPulse'
    source        TEXT    NOT NULL,           -- BizPulse | BizPulse Masters | outside BizPulse
    action        TEXT    NOT NULL,           -- Create | Alter | Cancel | Realise | Insert | Update | Delete
    table_name    TEXT    NOT NULL,
    voucher_type  TEXT,
    voucher_no    TEXT,                       -- voucher number, or the invoice number for Sales
    voucher_id    INTEGER,
    old_text      TEXT,                       -- the original, as text
    old_amount    TEXT,                       -- the original total / balance (decimal text)
    new_text      TEXT,
    new_amount    TEXT,
    balances      TEXT,                       -- balances moved: 'Gupta Stores 40,000.00 -> 51,800.00; …'
    prev_hash     TEXT,
    row_hash      TEXT                        -- SHA-256 chain; NULL until sealed
);
CREATE INDEX IF NOT EXISTS {LOG}_by_time ON {LOG} (logged_at);
CREATE TABLE IF NOT EXISTS {CONTEXT} (        -- one row only inside a BizPulse write; empty otherwise
    user_id TEXT NOT NULL, source TEXT NOT NULL, mode TEXT NOT NULL
);
CREATE TRIGGER IF NOT EXISTS {LOG}_no_delete BEFORE DELETE ON {LOG}
BEGIN SELECT RAISE(ABORT, '{LOG} is append-only: entries cannot be deleted'); END;
CREATE TRIGGER IF NOT EXISTS {LOG}_no_update BEFORE UPDATE ON {LOG}
WHEN NOT (OLD.row_hash IS NULL AND NEW.row_hash IS NOT NULL AND NEW.id IS OLD.id
          {''.join(f' AND NEW.{f} IS OLD.{f}' for f in FIELDS)})
BEGIN SELECT RAISE(ABORT, '{LOG} is append-only: entries cannot be changed'); END
"""


class AuditError(Exception):
    pass


def session_user() -> str:
    try:
        user = getpass.getuser()
    except Exception:                                # no login name available (some services)
        user = "unknown"
    return f"{user}@{socket.gethostname()} (session {SESSION})"


def _now() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def _tables(con: sqlite3.Connection) -> set[str]:
    return {r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type = 'table'")}


def _create(con: sqlite3.Connection) -> None:
    for stmt in DDL.split(";\n"):
        if stmt.strip():
            con.execute(stmt)


# ---- row triggers ----------------------------------------------------------------------------
def _trigger_sql(con: sqlite3.Connection, table: str) -> list[str]:
    cols = [r[1] for r in con.execute(f"PRAGMA table_info({table})")]
    if not cols:
        return []
    names = set(cols)
    key = (cols[:3] if table == "bp_cost_allocations" else
           cols[:2] if table in ("bp_voucher_lines", "bp_voucher_items", "bp_voucher_forex") else cols[:1])

    def whole(x: str) -> str:
        return " || ', ' || ".join(f"'{c}=' || quote({x}.{c})" for c in cols)

    def changed(x: str) -> str:
        ident = " || ', ' || ".join(f"'{c}=' || quote({x}.{c})" for c in key)
        rest = " || ".join(f"CASE WHEN OLD.{c} IS NOT NEW.{c} THEN ', {c}=' || quote({x}.{c}) ELSE '' END"
                           for c in cols if c not in key)
        return f"{ident} || {rest}" if rest else ident

    def ident(x: str) -> tuple[str, str]:
        if table == "bp_vouchers":
            return f"{x}.voucher_type", f"coalesce({x}.invoice_no, CAST({x}.voucher_no AS TEXT))"
        if "voucher_id" in names:
            return (f"(SELECT voucher_type FROM bp_vouchers WHERE id = {x}.voucher_id)",
                    f"(SELECT coalesce(invoice_no, CAST(voucher_no AS TEXT)) FROM bp_vouchers WHERE id = {x}.voucher_id)")
        if table == "gst_sales_ledger":
            return "'Sales'", f"{x}.invoice_no"
        return "NULL", "NULL"

    def value(x: str) -> str:
        column, expr = VALUE.get(table, ("", ""))
        return expr.format(X=x) if column in names else "NULL"

    vid = lambda x: f"{x}.voucher_id" if "voucher_id" in names else (f"{x}.id" if table == "bp_vouchers" else "NULL")  # noqa: E731
    quiet = f"NOT EXISTS (SELECT 1 FROM {CONTEXT} WHERE mode = 'voucher')"
    who = f"coalesce((SELECT user_id FROM {CONTEXT} LIMIT 1), '{OUTSIDE}')"
    src = f"coalesce((SELECT source FROM {CONTEXT} LIMIT 1), '{OUTSIDE}')"
    now = "strftime('%Y-%m-%d %H:%M:%S', 'now', 'localtime')"
    head = (f"INSERT INTO {LOG} (logged_at, user_id, source, action, table_name, voucher_type, voucher_no, voucher_id, "
            "old_text, old_amount, new_text, new_amount)")
    any_change = " OR ".join(f"OLD.{c} IS NOT NEW.{c}" for c in cols)
    out = []
    for event, x, old, new, extra in (
            ("INSERT", "NEW", ("NULL", "NULL"), (whole("NEW"), value("NEW")), ""),
            ("UPDATE", "NEW", (changed("OLD"), value("OLD")), (changed("NEW"), value("NEW")), f" AND ({any_change})"),
            ("DELETE", "OLD", (whole("OLD"), value("OLD")), ("NULL", "NULL"), "")):
        vtype, vno = ident(x)
        out.append(f"CREATE TRIGGER bp_audit_{table}_{event.lower()} AFTER {event} ON {table} WHEN {quiet}{extra} "
                   f"BEGIN {head} VALUES ({now}, {who}, {src}, '{event.title()}', '{table}', {vtype}, {vno}, {vid(x)}, "
                   f"{old[0]}, {old[1]}, {new[0]}, {new[1]}); END")
    return out


def ensure(con: sqlite3.Connection, refresh: bool = False) -> None:
    """Log table, guards and row triggers (created where missing; refresh=True rebuilds the row
    triggers so new columns are covered). Runs inside the caller's transaction."""
    _create(con)
    present = _tables(con)
    triggers = {r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type = 'trigger'")}
    for table in AUDITED:
        if table not in present:
            continue
        names = [f"bp_audit_{table}_{e}" for e in ("insert", "update", "delete")]
        if not refresh and all(n in triggers for n in names):
            continue
        for n in names:
            con.execute(f"DROP TRIGGER IF EXISTS {n}")
        for sql in _trigger_sql(con, table):
            con.execute(sql)


# ---- writing entries -------------------------------------------------------------------------
def begin(con: sqlite3.Connection, source: str = "BizPulse", mode: str = "voucher") -> None:
    """Call right after BEGIN IMMEDIATE."""
    ensure(con)
    con.execute(f"DELETE FROM {CONTEXT}")
    con.execute(f"INSERT INTO {CONTEXT} (user_id, source, mode) VALUES (?, ?, ?)", (session_user(), source, mode))


def end(con: sqlite3.Connection) -> None:
    """Call right before COMMIT."""
    seal(con)
    con.execute(f"DELETE FROM {CONTEXT}")


def record(con: sqlite3.Connection, action: str, voucher_type: str, voucher_no, voucher_id: int | None,
           old_text: str | None, old_amount: Decimal | None, new_text: str | None, new_amount: Decimal | None,
           balances: str = "") -> None:
    con.execute(f"INSERT INTO {LOG} ({', '.join(FIELDS)}) VALUES ({', '.join('?' * len(FIELDS))})",
                (_now(), session_user(), "BizPulse", action, "bp_vouchers", voucher_type, str(voucher_no), voucher_id,
                 old_text, None if old_amount is None else f"{old_amount:.2f}", new_text,
                 None if new_amount is None else f"{new_amount:.2f}", balances or None))


def _digest(prev: str, row: tuple) -> str:
    text = prev + "|" + "|".join("" if v is None else str(v) for v in row)
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def seal(con: sqlite3.Connection) -> int:
    """Fills prev_hash / row_hash of new entries, oldest first. Returns how many."""
    rows = con.execute(f"SELECT id, {', '.join(FIELDS)} FROM {LOG} WHERE row_hash IS NULL ORDER BY id").fetchall()
    if not rows:
        return 0
    before = con.execute(f"SELECT row_hash FROM {LOG} WHERE id < ? ORDER BY id DESC LIMIT 1", (rows[0][0],)).fetchone()
    prev = (before[0] if before else "") or ""
    for rid, *fields in rows:
        h = _digest(prev, tuple(fields))
        con.execute(f"UPDATE {LOG} SET prev_hash = ?, row_hash = ? WHERE id = ?", (prev, h, rid))
        prev = h
    return len(rows)


def install(db_path: Path) -> str:
    """Start-up: create / refresh everything and seal entries other programs left. One line for the status bar."""
    con = sqlite3.connect(str(db_path), timeout=5, isolation_level=None)
    try:
        con.execute("BEGIN IMMEDIATE")
        ensure(con, refresh=True)
        con.execute(f"DELETE FROM {CONTEXT}")              # a crash mid-write cannot leave one behind
        sealed = seal(con)
        con.execute("COMMIT")
        total = con.execute(f"SELECT count(*) FROM {LOG}").fetchone()[0]
        extra = f"; {sealed} entr{'y' if sealed == 1 else 'ies'} from outside BizPulse sealed" if sealed else ""
        return f"Audit trail ready: {total} entr{'y' if total == 1 else 'ies'} in {LOG}{extra}."
    except sqlite3.Error as exc:
        if con.in_transaction:
            con.execute("ROLLBACK")
        return f"Audit trail NOT ready: {exc}"
    finally:
        con.close()


# ---- describing a voucher (the text kept in the log) --------------------------------------------
def _amt(v) -> str:
    q = Decimal(str(v)).quantize(Decimal("0.01"))
    sign, whole, frac = ("-" if q < 0 else ""), *f"{abs(q):.2f}".split(".")
    if len(whole) > 3:
        head, tail = whole[:-3], whole[-3:]
        groups = []
        while len(head) > 2:
            groups.insert(0, head[-2:])
            head = head[:-2]
        whole = ",".join(([head] if head else []) + groups + [tail])
    return f"{sign}{whole}.{frac}"


def describe(v: dict | None) -> str | None:
    """A voucher as one line of text: date, status, every line, items, GST, currency, details, narration."""
    if not v:
        return None
    parts = [v["date"].strftime("%d-%m-%Y") if isinstance(v.get("date"), date) else str(v.get("date", "")),
             v.get("status") or "Regular"]
    parts.append("; ".join(f"{ln['side']} {ln['ledger']} {_amt(ln['amount'])}"
                           + (" [" + ", ".join(f"{a['cost_centre']} {_amt(a['amount'])}" for a in ln["allocations"]) + "]"
                              if ln.get("allocations") else "")
                           for ln in v.get("lines") or []))
    items = v.get("items") or []
    if items:
        parts.append("Items: " + "; ".join(f"{it['item']} {it['quantity']} {it.get('per') or 'Nos'} @ {_amt(it['rate'])}"
                                           for it in items))
    gst = v.get("gst")
    if gst:
        parts.append(f"GST: GSTIN {gst.get('gstin') or 'unregistered'}, POS {gst.get('place_of_supply', '')}, "
                     f"HSN {gst.get('hsn', '')}, {gst.get('rate', '')}%, taxable {_amt(gst.get('taxable', 0))}")
    fx = v.get("forex")
    if fx:
        parts.append(f"{fx['currency']} at {fx['rate']}: " + "; ".join(_amt(a) for a in fx["amounts"]))
    details = v.get("details") or {}
    if details:
        parts.append("; ".join(f"{k}: {val}" for k, val in details.items()))
    if v.get("narration"):
        parts.append(f"Narration: {v['narration']}")
    return " | ".join(p for p in parts if p)


def snapshot(con: sqlite3.Connection, vouchers: list[dict | None]) -> dict[str, str]:
    """Balances a voucher can move, read now: corporate_ledger_summary by ledger name and
    inventory_stock_registry by item. Take one before and one after the change."""
    names = {ln["ledger"].strip().lower() for v in vouchers if v for ln in v.get("lines") or []}
    items = {str(it["item"]).strip().lower() for v in vouchers if v for it in v.get("items") or []}
    out: dict[str, str] = {}
    present = _tables(con)
    if names and "corporate_ledger_summary" in present:
        for name, bal in con.execute("SELECT account_name, outstanding_balance FROM corporate_ledger_summary"):
            if str(name).strip().lower() in names:
                out[str(name)] = _amt(bal or 0)
    if items and "inventory_stock_registry" in present:
        for sku, qty in con.execute("SELECT product_sku, qty_on_hand FROM inventory_stock_registry"):
            if str(sku).strip().lower() in items:
                out[f"{sku} (qty)"] = str(qty)
    return out


def moved(before: dict[str, str], after: dict[str, str]) -> str:
    return "; ".join(f"{k} {before.get(k, '')} -> {after[k]}" for k in after if before.get(k) != after[k])


# ---- reading (the Audit Trail screen) -----------------------------------------------------------
@dataclass
class Verify:
    entries: int
    ok: bool
    message: str
    head: str


def _connect_ro(db_path: Path) -> sqlite3.Connection:
    return sqlite3.connect(Path(db_path).resolve().as_uri() + "?mode=ro", uri=True, timeout=5)


def load(db_path: Path, start: date | None = None, end_: date | None = None, voucher_no: str = "",
         limit: int = 5000) -> list[dict]:
    """Entries in time order (oldest first); the newest `limit` that match."""
    con = _connect_ro(db_path)
    try:
        if LOG not in _tables(con):
            return []
        where, args = [], []
        if start:
            where.append("logged_at >= ?")
            args.append(start.isoformat())
        if end_:
            where.append("logged_at < ?")
            args.append(date.fromordinal(end_.toordinal() + 1).isoformat())
        if voucher_no.strip():
            where.append("(voucher_no LIKE ? OR CAST(voucher_id AS TEXT) = ?)")
            args += [f"%{voucher_no.strip()}%", voucher_no.strip()]
        sql = (f"SELECT id, {', '.join(FIELDS)}, row_hash FROM {LOG}"
               + (" WHERE " + " AND ".join(where) if where else "") + " ORDER BY id DESC LIMIT ?")
        rows = con.execute(sql, args + [limit]).fetchall()
        keys = ("id",) + FIELDS + ("row_hash",)
        return [dict(zip(keys, r)) for r in reversed(rows)]
    finally:
        con.close()


def verify(db_path: Path) -> Verify:
    """Recomputes the whole chain. A mismatch names the first entry that was changed or removed."""
    con = _connect_ro(db_path)
    try:
        if LOG not in _tables(con):
            return Verify(0, True, "No audit entries yet.", "")
        prev, count, last_id, unsealed = "", 0, 0, 0
        for rid, *fields, prev_hash, row_hash in con.execute(
                f"SELECT id, {', '.join(FIELDS)}, prev_hash, row_hash FROM {LOG} ORDER BY id"):
            count += 1
            if row_hash is None:
                unsealed += 1
                continue
            if unsealed:
                return Verify(count, False, f"Entry {rid} follows {unsealed} unsealed entr(ies): the order was "
                                            "tampered with.", prev)
            if last_id and rid != last_id + 1:
                return Verify(count, False, f"Entries {last_id + 1}–{rid - 1} are missing: they were deleted.", prev)
            if (prev_hash or "") != prev or _digest(prev, tuple(fields)) != row_hash:
                return Verify(count, False, f"Entry {rid} does not match its seal: it (or the one before it) was "
                                            "changed after it was written.", prev)
            prev, last_id = row_hash, rid
        note = f" {unsealed} new entr(ies) from outside BizPulse are sealed at the next save or start." if unsealed else ""
        return Verify(count, True, f"All {count - unsealed} sealed entries check out.{note}", prev)
    finally:
        con.close()
