"""
Display More Reports: HSN/SAC Summary, Movement Analysis and the GSTR-3B summary (read only).

    hsn_summary(db_path, start, end, company_state)  outward supplies by HSN/SAC and rate (Sales vouchers)
    movement(db_path, start, end)                    item quantities in (Purchase) and out (Sales) from
                                                     Item Invoices, with today's stock on hand
    gstr3b(db_path, year, month, company_state, input_ledgers) -> Gstr3b

Only Regular vouchers count (Optional, Cancelled and not-yet-due Post-Dated ones are left out).
Tax is worked out with services/gst.tax_for, exactly as on the vouchers and in GSTR-1.

GSTR-3B is a SUMMARY TO CHECK BEFORE FILING, not a return:
    3.1(a)  outward taxable supplies (rate above 0)          from gst_sales_ledger
    3.1(c)  nil-rated supplies (rate 0)                       from gst_sales_ledger
    3.2     inter-state supplies to unregistered persons, by place of supply
    4(A)(5) input tax credit: the debits on INPUT_TAX_LEDGERS in the month, less their credits.
            BizPulse has no purchase GST register, so ITC is only what you post to those ledgers;
            check it against GSTR-2B on the portal.
    Net     output tax less ITC per head, BEFORE the portal's set-off order (IGST credit first,
            then CGST / SGST) and before interest, late fee and cash ledger: the portal decides those.
"""
from __future__ import annotations

import sqlite3
from dataclasses import dataclass, field
from datetime import date
from decimal import Decimal
from pathlib import Path

from services.gst import STATE_NAMES, tax_for

ZERO = Decimal("0.00")


def _ro(db_path: Path) -> sqlite3.Connection:
    return sqlite3.connect(Path(db_path).resolve().as_uri() + "?mode=ro", uri=True, timeout=5)


def _tables(con: sqlite3.Connection) -> set[str]:
    return {r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type = 'table'")}


def _due(con: sqlite3.Connection) -> str:
    """Regular only: live_filter leaves out Optional and Cancelled; this also leaves out Post-Dated."""
    cols = {r[1] for r in con.execute("PRAGMA table_info(bp_vouchers)")}
    return " AND coalesce(v.status, 'Regular') = 'Regular'" if "status" in cols else ""


def _sales_rows(con: sqlite3.Connection, start: date, end: date) -> list[tuple]:
    if not {"gst_sales_ledger", "bp_vouchers"} <= _tables(con):
        return []
    cols = {r[1] for r in con.execute("PRAGMA table_info(gst_sales_ledger)")}
    igst = "coalesce(g.igst_rate, 0)" if "igst_rate" in cols else "0"
    pos = "coalesce(g.place_of_supply, '')" if "place_of_supply" in cols else "''"
    status = " AND coalesce(v.status, 'Regular') = 'Regular'" if "status" in {
        r[1] for r in con.execute("PRAGMA table_info(bp_vouchers)")} else ""
    return con.execute(
        f"SELECT g.hsn_code, g.taxable_value, coalesce(g.cgst_rate, 0), coalesce(g.sgst_rate, 0), {igst}, {pos}, "
        "coalesce(g.customer_gstin, '') FROM gst_sales_ledger g JOIN bp_vouchers v "
        "ON v.invoice_no = g.invoice_no AND v.voucher_type = 'Sales' "
        f"WHERE v.voucher_date BETWEEN ? AND ?{status}", (start.isoformat(), end.isoformat())).fetchall()


def _tax(taxable, cr, sr, ir, pos, company_state) -> tuple[Decimal, Decimal, dict]:
    t = Decimal(str(taxable or 0)).quantize(Decimal("0.01"))
    rate = Decimal(str(ir)) if ir else Decimal(str(cr)) + Decimal(str(sr))
    return t, rate, tax_for(t, rate, pos or company_state, company_state)


@dataclass
class HsnRow:
    hsn: str
    rate: Decimal
    invoices: int = 0
    taxable: Decimal = ZERO
    cgst: Decimal = ZERO
    sgst: Decimal = ZERO
    igst: Decimal = ZERO


def hsn_summary(db_path: Path, start: date, end: date, company_state: str) -> list[HsnRow]:
    con = _ro(db_path)
    try:
        rows = _sales_rows(con, start, end)
    finally:
        con.close()
    out: dict[tuple[str, Decimal], HsnRow] = {}
    for hsn, taxable, cr, sr, ir, pos, _gstin in rows:
        t, rate, tax = _tax(taxable, cr, sr, ir, pos, company_state)
        r = out.setdefault((hsn or "", rate), HsnRow(hsn or "(none)", rate))
        r.invoices += 1
        r.taxable += t
        r.cgst += tax["cgst"]
        r.sgst += tax["sgst"]
        r.igst += tax["igst"]
    return sorted(out.values(), key=lambda r: (r.hsn, r.rate))


@dataclass
class MovementRow:
    item: str
    qty_in: int = 0
    value_in: Decimal = ZERO
    qty_out: int = 0
    value_out: Decimal = ZERO
    on_hand: int | None = None


def movement(db_path: Path, start: date, end: date) -> list[MovementRow]:
    con = _ro(db_path)
    try:
        tables = _tables(con)
        out: dict[str, MovementRow] = {}
        if {"bp_voucher_items", "bp_vouchers"} <= tables:
            for item, vtype, qty, paise in con.execute(
                    "SELECT i.item, v.voucher_type, sum(i.quantity), sum(i.amount_paise) FROM bp_voucher_items i "
                    "JOIN bp_vouchers v ON v.id = i.voucher_id "
                    f"WHERE v.voucher_date BETWEEN ? AND ?{_due(con)} GROUP BY lower(trim(i.item)), v.voucher_type",
                    (start.isoformat(), end.isoformat())):
                r = out.setdefault(item.strip().lower(), MovementRow(item.strip()))
                if vtype == "Purchase":
                    r.qty_in += int(qty or 0)
                    r.value_in += Decimal(paise or 0) / 100
                elif vtype == "Sales":
                    r.qty_out += int(qty or 0)
                    r.value_out += Decimal(paise or 0) / 100
        if "inventory_stock_registry" in tables:
            for sku, qty in con.execute("SELECT product_sku, qty_on_hand FROM inventory_stock_registry"):
                r = out.setdefault(str(sku).strip().lower(), MovementRow(str(sku).strip()))
                r.on_hand = int(qty or 0)
        return sorted(out.values(), key=lambda r: r.item.lower())
    finally:
        con.close()


@dataclass
class Gstr3b:
    period: str
    outward: dict[str, Decimal] = field(default_factory=dict)        # taxable, igst, cgst, sgst (3.1 a)
    nil_rated: Decimal = ZERO                                         # 3.1 c
    unregistered_inter: dict[str, Decimal] = field(default_factory=dict)   # 3.2: state -> taxable
    unregistered_igst: dict[str, Decimal] = field(default_factory=dict)
    itc: dict[str, Decimal] = field(default_factory=dict)            # 4(A)(5): igst, cgst, sgst
    invoices: int = 0

    def net(self, head: str) -> Decimal:
        return self.outward.get(head, ZERO) - self.itc.get(head, ZERO)


def gstr3b(db_path: Path, year: int, month: int, company_state: str, input_ledgers: dict[str, str]) -> Gstr3b:
    start = date(year, month, 1)
    end = date.fromordinal(date(year + (month == 12), month % 12 + 1, 1).toordinal() - 1)
    result = Gstr3b(f"{month:02d}-{year}", {k: ZERO for k in ("taxable", "igst", "cgst", "sgst")},
                    itc={k: ZERO for k in ("igst", "cgst", "sgst")})
    con = _ro(db_path)
    try:
        for _hsn, taxable, cr, sr, ir, pos, gstin in _sales_rows(con, start, end):
            t, rate, tax = _tax(taxable, cr, sr, ir, pos, company_state)
            result.invoices += 1
            if rate == 0:
                result.nil_rated += t
                continue
            result.outward["taxable"] += t
            for head in ("igst", "cgst", "sgst"):
                result.outward[head] += tax[head]
            place = pos or company_state
            if not gstin and place != company_state:
                name = f"{place} {STATE_NAMES.get(place, '')}".strip()
                result.unregistered_inter[name] = result.unregistered_inter.get(name, ZERO) + t
                result.unregistered_igst[name] = result.unregistered_igst.get(name, ZERO) + tax["igst"]
        if "bp_voucher_lines" in _tables(con):
            for head, ledger in input_ledgers.items():
                paise = con.execute(
                    "SELECT coalesce(sum(CASE l.side WHEN 'Dr' THEN l.amount_paise ELSE -l.amount_paise END), 0) "
                    "FROM bp_voucher_lines l JOIN bp_vouchers v ON v.id = l.voucher_id "
                    f"WHERE lower(trim(l.ledger)) = lower(?) AND v.voucher_date BETWEEN ? AND ?{_due(con)}",
                    (ledger, start.isoformat(), end.isoformat())).fetchone()[0]
                result.itc[head] = Decimal(paise) / 100
    finally:
        con.close()
    return result
