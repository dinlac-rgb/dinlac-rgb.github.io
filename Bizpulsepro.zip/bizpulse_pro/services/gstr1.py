"""
GSTR-1 for one month, from gst_sales_ledger (joined to the Sales vouchers for dates and values).

    build_gstr1(db_path, year, month, gstin, company_state) -> Gstr1   (summary + JSON payload)
    write_gstr1(result, folder) -> Path                                (exports/GSTR1_<gstin>_<MMYYYY>.json)

Sections (GSTR-1 offline-tool JSON keys):
    b2b       invoices to registered buyers (customer GSTIN present), grouped by buyer GSTIN
    b2cl      inter-state invoices to unregistered buyers above B2CL_LIMIT, grouped by place of supply
    b2cs      every other unregistered invoice, summed by supply type (INTRA / INTER), place of supply, rate
    hsn       Table 12, split into hsn_b2b and hsn_b2c, summed by HSN/SAC and rate
    doc_issue invoice series used in the month: first and last number, total, cancelled, net issued
              (a voucher cancelled with Alt+X keeps its invoice number and counts as cancelled)

Tax amounts are worked out the same way as on the vouchers (services/gst.tax_for), so they
agree with the books. Only Regular Sales vouchers have invoice numbers, so Optional ones never
appear. A gst_sales_ledger row with no Sales voucher behind it has no date: it is left out and
counted in the warnings. Item quantities come from Item Invoices (unit code "NOS"); other
invoices report quantity 0 with unit code "NA".

Before uploading, import the file into the GST offline tool and let it validate: the portal's
JSON format changes from time to time (see GSTR1_JSON_VERSION and B2CL_LIMIT in config/settings.py).
"""
from __future__ import annotations

import json
import sqlite3
from dataclasses import dataclass, field
from datetime import date
from decimal import Decimal
from pathlib import Path

from services.gst import check_gstin, tax_for

CENT = Decimal("0.01")


class Gstr1Error(Exception):
    pass


@dataclass
class Gstr1:
    period: str                      # "102026"
    payload: dict
    summary: dict[str, dict]         # section -> {"count", "taxable", "tax"}
    warnings: list[str] = field(default_factory=list)


def _f(x: Decimal) -> float:
    return float(x.quantize(CENT))


def build_gstr1(db_path: Path, year: int, month: int, gstin: str, company_state: str = "19",
                b2cl_limit: Decimal = Decimal("100000"), version: str = "") -> Gstr1:
    try:
        gstin = check_gstin(gstin)
    except ValueError as exc:
        raise Gstr1Error(f"Company GSTIN: {exc}") from None
    if not gstin:
        raise Gstr1Error("Enter the company GSTIN first (COMPANY_GSTIN in config/settings.py): GSTR-1 is filed under it.")
    if gstin[:2] != company_state:
        raise Gstr1Error(f"COMPANY_GSTIN {gstin} is from state {gstin[:2]}, but COMPANY_STATE_CODE is {company_state}.")
    start = date(year, month, 1)
    end = date(year + (month == 12), month % 12 + 1, 1)
    period = f"{month:02d}{year}"

    con = sqlite3.connect(Path(db_path).resolve().as_uri() + "?mode=ro", uri=True, timeout=5)
    try:
        has = lambda t: con.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", (t,)).fetchone()  # noqa: E731
        if not has("gst_sales_ledger"):
            raise Gstr1Error("gst_sales_ledger was not found.")
        cancelled: list[str] = []
        if not has("bp_vouchers"):
            rows, orphans = [], con.execute("SELECT count(*) FROM gst_sales_ledger").fetchone()[0]
        else:
            has_status = any(r[1] == "status" for r in con.execute("PRAGMA table_info(bp_vouchers)"))
            live = " AND coalesce(v.status, 'Regular') = 'Regular'" if has_status else ""
            rows = con.execute(
                "SELECT g.invoice_no, g.customer_name, coalesce(g.customer_gstin, ''), g.hsn_code, g.taxable_value, "
                "coalesce(g.cgst_rate, 0), coalesce(g.sgst_rate, 0), coalesce(g.igst_rate, 0), "
                "coalesce(g.place_of_supply, ''), v.voucher_date, v.total_paise, v.id "
                "FROM gst_sales_ledger g JOIN bp_vouchers v ON v.invoice_no = g.invoice_no AND v.voucher_type = 'Sales' "
                f"WHERE v.voucher_date >= ? AND v.voucher_date < ?{live} ORDER BY v.voucher_date, g.invoice_no",
                (start.isoformat(), end.isoformat())).fetchall()
            orphans = con.execute("SELECT count(*) FROM gst_sales_ledger g WHERE NOT EXISTS (SELECT 1 FROM bp_vouchers v "
                                  "WHERE v.invoice_no = g.invoice_no AND v.voucher_type = 'Sales')").fetchone()[0]
            if has_status:
                cancelled = [r[0] for r in con.execute(
                    "SELECT invoice_no FROM bp_vouchers WHERE voucher_type = 'Sales' AND status = 'Cancelled' "
                    "AND invoice_no IS NOT NULL AND voucher_date >= ? AND voucher_date < ?",
                    (start.isoformat(), end.isoformat()))]
        qty: dict[int, int] = {}
        if has("bp_voucher_items"):
            for vid, q in con.execute("SELECT voucher_id, sum(quantity) FROM bp_voucher_items GROUP BY voucher_id"):
                qty[vid] = int(q or 0)
    finally:
        con.close()

    warnings = []
    if orphans:
        warnings.append(f"{orphans} gst_sales_ledger row(s) have no Sales voucher, so no invoice date: not included.")
    b2b: dict[str, list] = {}
    b2cl: dict[str, list] = {}
    b2cs: dict[tuple, dict] = {}
    hsn: dict[str, dict[tuple, dict]] = {"hsn_b2b": {}, "hsn_b2c": {}}
    summary = {k: {"count": 0, "taxable": Decimal("0"), "tax": Decimal("0")} for k in ("b2b", "b2cl", "b2cs")}
    numbers: list[str] = []

    for inv, _cust, ctin, hsn_code, taxable, cr, sr, ir, pos, vdate, total_paise, vid in rows:
        txval = Decimal(str(taxable or 0)).quantize(CENT)
        rate = Decimal(str(ir)) if ir else Decimal(str(cr)) + Decimal(str(sr))
        pos = pos or company_state
        tax = tax_for(txval, rate, pos, company_state)
        value = (Decimal(total_paise) / 100).quantize(CENT)
        idt = date.fromisoformat(vdate).strftime("%d-%m-%Y")
        rt = float(rate)
        det = {"txval": _f(txval), "rt": rt, "iamt": _f(tax["igst"]), "camt": _f(tax["cgst"]), "samt": _f(tax["sgst"]),
               "csamt": 0.0}
        tax_total = tax["igst"] + tax["cgst"] + tax["sgst"]
        numbers.append(inv)
        if ctin:
            b2b.setdefault(ctin.upper(), []).append({"inum": inv, "idt": idt, "val": _f(value), "pos": pos, "rchrg": "N",
                                                     "inv_typ": "R", "itms": [{"num": 1, "itm_det": det}]})
            section, hsn_key = "b2b", "hsn_b2b"
        elif pos != company_state and value > b2cl_limit:
            b2cl.setdefault(pos, []).append({"inum": inv, "idt": idt, "val": _f(value),
                                             "itms": [{"num": 1, "itm_det": {"rt": rt, "txval": _f(txval),
                                                                             "iamt": _f(tax["igst"]), "csamt": 0.0}}]})
            section, hsn_key = "b2cl", "hsn_b2c"
        else:
            sply = "INTRA" if pos == company_state else "INTER"
            agg = b2cs.setdefault((sply, pos, rt), {"sply_ty": sply, "pos": pos, "typ": "OE", "rt": rt, "txval": Decimal("0"),
                                                    "iamt": Decimal("0"), "camt": Decimal("0"), "samt": Decimal("0")})
            agg["txval"] += txval
            agg["iamt"] += tax["igst"]
            agg["camt"] += tax["cgst"]
            agg["samt"] += tax["sgst"]
            section, hsn_key = "b2cs", "hsn_b2c"
        summary[section]["count"] += 1
        summary[section]["taxable"] += txval
        summary[section]["tax"] += tax_total
        h = hsn[hsn_key].setdefault((hsn_code, rt), {"hsn_sc": hsn_code, "desc": "", "uqc": "NA", "qty": 0, "rt": rt,
                                                    "txval": Decimal("0"), "iamt": Decimal("0"), "camt": Decimal("0"),
                                                    "samt": Decimal("0")})
        if vid in qty:
            h["uqc"], h["qty"] = "NOS", h["qty"] + qty[vid]
        h["txval"] += txval
        h["iamt"] += tax["igst"]
        h["camt"] += tax["cgst"]
        h["samt"] += tax["sgst"]

    def money_fields(d: dict) -> dict:
        return {k: (_f(v) if isinstance(v, Decimal) else v) for k, v in d.items()}

    payload: dict = {"gstin": gstin, "fp": period}
    if version:
        payload["version"] = version
    payload["hash"] = "hash"
    if b2b:
        payload["b2b"] = [{"ctin": c, "inv": invs} for c, invs in sorted(b2b.items())]
    if b2cl:
        payload["b2cl"] = [{"pos": p, "inv": invs} for p, invs in sorted(b2cl.items())]
    if b2cs:
        payload["b2cs"] = [dict(money_fields(v), csamt=0.0) for _k, v in sorted(b2cs.items())]
    hsn_out = {}
    for key, groups in hsn.items():
        if groups:
            hsn_out[key] = [dict(money_fields(v), num=i + 1, csamt=0.0)
                            for i, (_k, v) in enumerate(sorted(groups.items(), key=lambda kv: (kv[0][0], kv[0][1])))]
    if hsn_out:
        payload["hsn"] = hsn_out
    docs = _doc_series(numbers, cancelled)
    if docs:
        payload["doc_issue"] = {"doc_det": [{"doc_num": 1, "docs": docs}]}
    summary["hsn"] = {"count": sum(len(g) for g in hsn.values()), "taxable": sum(summary[s]["taxable"] for s in ("b2b", "b2cl", "b2cs")),
                      "tax": sum(summary[s]["tax"] for s in ("b2b", "b2cl", "b2cs"))}
    summary["doc_issue"] = {"count": sum(d["net_issue"] for d in docs), "taxable": Decimal("0"), "tax": Decimal("0"),
                            "cancel": sum(d["cancel"] for d in docs),
                            "ranges": ", ".join(f"{d['from']} to {d['to']}" for d in docs)}
    if not rows:
        warnings.append(f"No Sales invoices dated {start.strftime('%m-%Y')}.")
    return Gstr1(period, payload, summary, warnings)


def _doc_series(numbers: list[str], cancelled: list[str] | None = None) -> list[dict]:
    """Group 'SRJ/26-27/0001'-style numbers by series (text before the last '/'). Cancelled
    numbers widen the range and count under cancel; numbers never used count there too."""
    series: dict[str, list[int]] = {}
    span: dict[str, list[int]] = {}
    for n, issued in [(n, True) for n in numbers] + [(n, False) for n in cancelled or []]:
        stem, _, seq = n.rpartition("/")
        if seq.isdigit():
            span.setdefault(stem, []).append(int(seq))
            if issued:
                series.setdefault(stem, []).append(int(seq))
            else:
                series.setdefault(stem, [])
    out = []
    for i, (stem, seqs) in enumerate(sorted(series.items()), start=1):
        lo, hi = min(span[stem]), max(span[stem])
        width = max(4, len(str(hi)))
        total = hi - lo + 1
        present = len(set(seqs))
        out.append({"num": i, "from": f"{stem}/{lo:0{width}d}", "to": f"{stem}/{hi:0{width}d}", "totnum": total,
                    "cancel": total - present, "net_issue": present})
    return out


def write_gstr1(result: Gstr1, folder: Path) -> Path:
    folder = Path(folder)
    folder.mkdir(parents=True, exist_ok=True)
    path = folder / f"GSTR1_{result.payload['gstin']}_{result.period}.json"
    tmp = path.with_suffix(".json.tmp")
    tmp.write_text(json.dumps(result.payload, separators=(",", ":")), encoding="utf-8")
    tmp.replace(path)                               # never leaves a half-written file
    return path
