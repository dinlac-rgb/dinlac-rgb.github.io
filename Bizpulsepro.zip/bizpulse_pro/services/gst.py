"""
GST helpers for Sales vouchers: GSTIN check, HSN/SAC check, tax split and invoice numbers.
Pure functions (no Tk, no database) so they are easy to test.
"""
from __future__ import annotations

import re
from datetime import date
from decimal import ROUND_HALF_UP, Decimal

CENT = Decimal("0.01")
GSTIN_RE = re.compile(r"^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z][1-9A-Z]Z[0-9A-Z]$")
GSTIN_CHARS = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"
HSN_RE = re.compile(r"^(?:\d{4}|\d{6}|\d{8})$")
# GST state codes: 01-38, and 97 (Other Territory).
VALID_STATE_CODES = {f"{n:02d}" for n in range(1, 39)} | {"97"}


def gstin_checksum_ok(gstin: str) -> bool:
    """The 15th character is a mod-36 check character over the first 14."""
    factor, total = 2, 0
    for ch in reversed(gstin[:14]):
        addend = factor * GSTIN_CHARS.index(ch)
        factor = 1 if factor == 2 else 2
        total += addend // 36 + addend % 36
    return GSTIN_CHARS[(36 - total % 36) % 36] == gstin[14]


def check_gstin(raw: str) -> str:
    """'' -> '' (unregistered customer). Otherwise the upper-cased GSTIN, or ValueError."""
    gstin = raw.strip().upper()
    if not gstin:
        return ""
    if not GSTIN_RE.match(gstin) or not gstin_checksum_ok(gstin):
        raise ValueError(f"'{raw.strip()}' is not a valid GSTIN (check the 15 characters).")
    return gstin


def check_hsn(raw: str) -> str:
    hsn = raw.strip().replace(" ", "")
    if not HSN_RE.match(hsn):
        raise ValueError("HSN/SAC must be 4, 6 or 8 digits.")
    return hsn


def money(value: Decimal) -> Decimal:
    return value.quantize(CENT, rounding=ROUND_HALF_UP)


def split_tax(taxable: Decimal, rate: Decimal) -> tuple[Decimal, Decimal]:
    """Intra-state supply: half the rate as CGST, half as SGST, each rounded to paise."""
    half = money(taxable * rate / Decimal(200))
    return half, half


def check_state_code(raw: str) -> str:
    code = raw.strip()
    if len(code) == 1 and code.isdigit():
        code = "0" + code
    if code not in VALID_STATE_CODES:
        raise ValueError("Place of supply must be a GST state code: 01 to 38, or 97.")
    return code


def tax_for(taxable: Decimal, rate: Decimal, place_of_supply: str, company_state: str) -> dict:
    """CGST + SGST when the place of supply is the company's own state, otherwise IGST."""
    if place_of_supply == company_state:
        cgst, sgst = split_tax(taxable, rate)
        return {"inter_state": False, "cgst": cgst, "sgst": sgst, "igst": Decimal("0.00"),
                "cgst_rate": rate / 2, "sgst_rate": rate / 2, "igst_rate": Decimal("0")}
    igst = money(taxable * rate / Decimal(100))
    return {"inter_state": True, "cgst": Decimal("0.00"), "sgst": Decimal("0.00"), "igst": igst,
            "cgst_rate": Decimal("0"), "sgst_rate": Decimal("0"), "igst_rate": rate}


def financial_year_label(d: date) -> str:
    """2026-10-09 -> '26-27' (April to March)."""
    start = d.year if d.month >= 4 else d.year - 1
    return f"{start % 100:02d}-{(start + 1) % 100:02d}"


def invoice_number(prefix: str, d: date, seq: int) -> str:
    """('SRJ', 2026-10-09, 7) -> 'SRJ/26-27/0007'."""
    return f"{prefix}/{financial_year_label(d)}/{seq:04d}"


# GST state codes and names (for ledger mailing details).
STATE_NAMES = {
    "01": "Jammu & Kashmir", "02": "Himachal Pradesh", "03": "Punjab", "04": "Chandigarh", "05": "Uttarakhand",
    "06": "Haryana", "07": "Delhi", "08": "Rajasthan", "09": "Uttar Pradesh", "10": "Bihar", "11": "Sikkim",
    "12": "Arunachal Pradesh", "13": "Nagaland", "14": "Manipur", "15": "Mizoram", "16": "Tripura",
    "17": "Meghalaya", "18": "Assam", "19": "West Bengal", "20": "Jharkhand", "21": "Odisha",
    "22": "Chhattisgarh", "23": "Madhya Pradesh", "24": "Gujarat",
    "26": "Dadra & Nagar Haveli and Daman & Diu", "27": "Maharashtra", "29": "Karnataka", "30": "Goa",
    "31": "Lakshadweep", "32": "Kerala", "33": "Tamil Nadu", "34": "Puducherry",
    "35": "Andaman & Nicobar Islands", "36": "Telangana", "37": "Andhra Pradesh", "38": "Ladakh",
    "97": "Other Territory",
}
STATE_CODE_OF = {name.lower(): code for code, name in STATE_NAMES.items()}
