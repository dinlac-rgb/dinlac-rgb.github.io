"""
Puts the 28 reserved groups (15 primary + 13 sub-groups) into the company database's
`account_groups` table, every time BizPulse Pro opens the database (start-up, background
thread), so other tools reading that table see the same chart of groups.

    seed_account_groups(db_path) -> str     one line for the status bar

    * No table yet: it is created —
        account_groups(name PRIMARY KEY, parent, nature, is_primary, reserved)
    * A table already there (for example made by your database_config.py): its own columns are
      used. The name column is the first of name / group_name / account_group; the parent column
      the first of parent / parent_group / under / under_group. Only groups that are missing are
      added (INSERT, never UPDATE or DELETE), so anything already in it stays as it is. If no
      name column can be found, the table is left alone and the status bar says why.
    * One transaction; parameters only.

database_config.py is your own script and is not part of this package. To seed from it too, add:
    from services.group_seeder import seed_account_groups
    seed_account_groups(path_to_bizpulse_local_db)
"""
from __future__ import annotations

import sqlite3
from pathlib import Path

from config.ledger_groups import RESERVED_GROUPS

NATURE = {
    "Assets": ("Current Assets", "Fixed Assets", "Investments", "Misc. Expenses (ASSET)"),
    "Liabilities": ("Capital Account", "Current Liabilities", "Loans (Liability)", "Branch / Divisions", "Suspense A/c"),
    "Income": ("Sales Accounts", "Direct Incomes", "Indirect Incomes"),
    "Expenses": ("Purchase Accounts", "Direct Expenses", "Indirect Expenses"),
}
NAME_COLUMNS = ("name", "group_name", "account_group")
PARENT_COLUMNS = ("parent", "parent_group", "under", "under_group")


def nature_of(group: str) -> str:
    primary = group
    while RESERVED_GROUPS.get(primary):
        primary = RESERVED_GROUPS[primary]
    return next(n for n, roots in NATURE.items() if primary in roots)


def seed_account_groups(db_path: Path) -> str:
    db_path = Path(db_path)
    if not db_path.is_file():
        return f"account_groups not checked: {db_path.name} was not found."
    con = sqlite3.connect(str(db_path), timeout=5, isolation_level=None)
    try:
        con.execute("BEGIN IMMEDIATE")
        cols = [r[1] for r in con.execute("PRAGMA table_info(account_groups)")]
        if not cols:
            con.execute("CREATE TABLE account_groups (name TEXT PRIMARY KEY COLLATE NOCASE, parent TEXT, "
                        "nature TEXT NOT NULL, is_primary INTEGER NOT NULL, reserved INTEGER NOT NULL DEFAULT 1)")
            cols = ["name", "parent", "nature", "is_primary", "reserved"]
        lower = {c.lower(): c for c in cols}
        name_col = next((lower[c] for c in NAME_COLUMNS if c in lower), None)
        if name_col is None:
            con.execute("ROLLBACK")
            return (f"account_groups has no name column ({', '.join(cols)}); the 28 reserved groups were not added. "
                    "BizPulse Pro uses its own list, so nothing else is affected.")
        parent_col = next((lower[c] for c in PARENT_COLUMNS if c in lower), None)
        have = {str(r[0]).strip().lower() for r in con.execute(f'SELECT "{name_col}" FROM account_groups')
                if r[0] is not None}
        added = 0
        for group, parent in RESERVED_GROUPS.items():
            if group.lower() in have:
                continue
            values = {name_col: group}
            if parent_col:
                values[parent_col] = parent
            for col, value in (("nature", nature_of(group)), ("is_primary", int(parent is None)), ("reserved", 1)):
                if col in lower:
                    values[lower[col]] = value
            names = ", ".join(f'"{c}"' for c in values)
            con.execute(f"INSERT INTO account_groups ({names}) VALUES ({', '.join('?' * len(values))})",
                        tuple(values.values()))
            added += 1
        con.execute("COMMIT")
        if not added:
            return "account_groups: the 28 reserved groups are all present."
        return f"account_groups: {added} of the 28 reserved groups added (15 primary, 13 sub-groups in all)."
    except sqlite3.Error as exc:
        if con.in_transaction:
            con.execute("ROLLBACK")
        return f"account_groups not updated: {exc}"
    finally:
        con.close()
