"""
Data, Export and Exchange tools that work on the whole company file.

    backup(db_path, folder, tag="") -> Path        Data › Backup: a consistent copy (SQLite backup API),
                                                   checked with PRAGMA integrity_check
    list_backups(folder, db_path) -> [dict]        Data › Restore: backups and pre-upgrade safety copies
    check(path) -> str                             "" if it is a usable BizPulse database, else why not
    restore(source, db_path, folder) -> Path       Data › Restore: safety copy of today's file first,
                                                   then the chosen copy replaces it; returns the safety copy
    ledger_balances_csv(db_path, folder, upto)     Export › Current Ledger: every ledger's closing balance
    final_accounts_html(db_path, company, upto)    Export › Final Accounts: P&L A/c and Balance Sheet
    client_pack(db_path, folder, company, upto)    Exchange › Client Share Pack: one ZIP for your CA

Nothing here edits a voucher. Restore replaces the database file's contents as a whole (the
audit trail with it: the restored file has the trail as it was then); the replaced file is kept
as a safety copy, so a restore can itself be undone with another restore.
"""
from __future__ import annotations

import csv
import io
import sqlite3
import zipfile
from datetime import date, datetime
from decimal import Decimal
from pathlib import Path

from services import printing as P
from services.reports import NOT_GROUPED, PL_GROUPS, build_reports


class DataError(Exception):
    """A message for the status line; nothing was changed."""


def _stamp() -> str:
    return datetime.now().strftime("%Y%m%d-%H%M%S")


def _integrity(path: Path) -> str:
    con = sqlite3.connect(Path(path).resolve().as_uri() + "?mode=ro", uri=True, timeout=5)
    try:
        result = con.execute("PRAGMA integrity_check").fetchone()[0]
        return "" if result == "ok" else f"integrity check: {result}"
    finally:
        con.close()


def backup(db_path: Path, folder: Path, tag: str = "") -> Path:
    db_path, folder = Path(db_path), Path(folder)
    if not db_path.is_file():
        raise DataError(f"{db_path.name} was not found; there is nothing to back up.")
    folder.mkdir(parents=True, exist_ok=True)
    target = folder / f"{db_path.stem}-{_stamp()}{'-' + tag if tag else ''}.db"
    partial = target.with_suffix(".db.part")
    src = sqlite3.connect(str(db_path), timeout=10)
    dst = sqlite3.connect(str(partial))
    try:
        src.backup(dst)                         # a consistent copy even while BizPulse is open
    except sqlite3.Error as exc:
        dst.close()
        partial.unlink(missing_ok=True)
        raise DataError(f"Backup failed: {exc}. Nothing was written.") from exc
    finally:
        src.close()
    dst.close()
    problem = _integrity(partial)
    if problem:
        partial.unlink(missing_ok=True)
        raise DataError(f"The copy did not pass its check ({problem}); it was discarded.")
    partial.replace(target)
    return target


def check(path: Path) -> str:
    try:
        problem = _integrity(path)
        if problem:
            return problem
        con = sqlite3.connect(Path(path).resolve().as_uri() + "?mode=ro", uri=True, timeout=5)
        try:
            tables = {r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type = 'table'")}
        finally:
            con.close()
    except sqlite3.Error as exc:
        return f"not a database ({exc})"
    if not tables & {"bp_vouchers", "gst_sales_ledger", "bp_company"}:
        return "not a BizPulse company file (no BizPulse tables)"
    return ""


def _describe(path: Path) -> dict:
    info = {"company": "", "vouchers": ""}
    try:
        con = sqlite3.connect(Path(path).resolve().as_uri() + "?mode=ro", uri=True, timeout=5)
        try:
            tables = {r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type = 'table'")}
            if "bp_company" in tables:
                row = con.execute("SELECT name FROM bp_company WHERE id = 1").fetchone()
                info["company"] = row[0] if row else ""
            if "bp_vouchers" in tables:
                info["vouchers"] = str(con.execute("SELECT count(*) FROM bp_vouchers").fetchone()[0])
        finally:
            con.close()
    except sqlite3.Error:
        info["company"] = "(cannot be read)"
    return info


def list_backups(folder: Path, db_path: Path) -> list[dict]:
    db_path = Path(db_path)
    found = list(Path(folder).glob("*.db")) if Path(folder).is_dir() else []
    found += list(db_path.parent.glob(f"{db_path.stem}.pre-upgrade-*.db"))
    rows = []
    for p in sorted(set(found), key=lambda x: x.stat().st_mtime, reverse=True):
        st = p.stat()
        rows.append({"file": p.name, "path": str(p), "kind": "safety copy" if ".pre-upgrade-" in p.name else "backup",
                     "saved": datetime.fromtimestamp(st.st_mtime).strftime("%d-%m-%Y %H:%M"),
                     "size": f"{max(1, st.st_size // 1024)} KB", **_describe(p)})
    return rows


def restore(source: Path, db_path: Path, folder: Path) -> Path:
    source, db_path = Path(source), Path(db_path)
    if source.resolve() == db_path.resolve():
        raise DataError("That is the open company file itself.")
    problem = check(source)
    if problem:
        raise DataError(f"{source.name} cannot be restored: {problem}. Nothing was changed.")
    safety = backup(db_path, folder, tag="before-restore") if db_path.is_file() else None
    src = sqlite3.connect(Path(source).resolve().as_uri() + "?mode=ro", uri=True, timeout=10)
    dst = sqlite3.connect(str(db_path), timeout=10)
    try:
        src.backup(dst)                         # replaces every page of the open file, under a lock
    except sqlite3.Error as exc:
        raise DataError(f"Restore failed: {exc}. The safety copy {safety.name if safety else ''} has your "
                        "file as it was.") from exc
    finally:
        src.close()
        dst.close()
    problem = _integrity(db_path)
    if problem:
        raise DataError(f"After the restore the file failed its check ({problem}); restore the safety copy "
                        f"{safety.name if safety else ''}.")
    return safety


# ---- exports ---------------------------------------------------------------------------------
def _tb_rows(r) -> list[list]:
    rows = []
    for ledger in sorted(r.tb_balances, key=lambda lg: (r.tb_groups.get(lg) or NOT_GROUPED, lg.lower())):
        bal = r.tb_balances[ledger]
        if not bal:
            continue
        rows.append([ledger, r.tb_groups.get(ledger) or NOT_GROUPED, f"{bal:.2f}" if bal > 0 else "",
                     f"{-bal:.2f}" if bal < 0 else ""])
    return rows


def ledger_balances_csv(db_path: Path, folder: Path, upto: date) -> Path:
    r = build_reports(Path(db_path), upto)
    out = io.StringIO()
    w = csv.writer(out)
    w.writerow(["Ledger", "Group", "Debit", "Credit"])
    rows = _tb_rows(r)
    w.writerows(rows)
    dr = sum((Decimal(x[2]) for x in rows if x[2]), Decimal("0"))
    cr = sum((Decimal(x[3]) for x in rows if x[3]), Decimal("0"))
    w.writerow(["Total", "", f"{dr:.2f}", f"{cr:.2f}"])
    folder = Path(folder)
    folder.mkdir(parents=True, exist_ok=True)
    path = folder / f"ledger_balances_{upto:%Y%m%d}.csv"
    tmp = path.with_suffix(".csv.tmp")
    tmp.write_text(out.getvalue(), encoding="utf-8-sig", newline="")    # utf-8-sig: Excel reads ₹ and names
    tmp.replace(path)
    return path


def final_accounts_html(db_path: Path, company: dict, upto: date) -> str:
    r = build_reports(Path(db_path), upto)
    period = f"{r.period_start:%d-%m-%Y} to {r.period_end:%d-%m-%Y}"

    def table(head: list[str], rows: list[list], totals: set[int]) -> str:
        th = "".join(f'<th class="{"n" if i else ""}">{P.e(h)}</th>' for i, h in enumerate(head))
        trs = "".join(f'<tr class="{"total" if n in totals else ""}">' + "".join(
            f'<td class="{"n" if i else ""}">{P.e(c)}</td>' for i, c in enumerate(row)) + "</tr>"
            for n, row in enumerate(rows))
        return f"<table><tr>{th}</tr>{trs}</table>"

    pl_rows = [[g, P.inr(r.pl[g].amount)] for g in PL_GROUPS if g in r.pl and r.pl[g].amount]
    if r.opening_stock or r.closing_stock:
        pl_rows += [["Opening Stock", P.inr(r.opening_stock)], ["Closing Stock", P.inr(r.closing_stock)]]
    pl_rows += [["Gross Profit / Loss", P.inr(r.gross_profit)], ["Net Profit / Loss", P.inr(r.net_profit)]]
    bs_rows: list[list] = [["LIABILITIES", ""]]
    bs_rows += [[n.name, P.inr(n.amount)] for n in r.liabilities]
    bs_rows += [["Total Liabilities", P.inr(r.liabilities_total)], ["ASSETS", ""]]
    bs_rows += [[n.name, P.inr(n.amount)] for n in r.assets]
    bs_rows.append(["Total Assets", P.inr(r.assets_total)])
    body = (f"<h1>Final Accounts · {P.e(company.get('name', ''))}</h1><p class='muted'>{P.e(period)}</p>"
            f"<h2>Profit &amp; Loss A/c</h2>{table(['Particulars', 'Amount'], pl_rows, {len(pl_rows) - 2, len(pl_rows) - 1})}"
            f"<h2>Balance Sheet as at {r.period_end:%d-%m-%Y}</h2>"
            f"{table(['Particulars', 'Amount'], bs_rows, {0, len(r.liabilities) + 1, len(r.liabilities) + 2, len(bs_rows) - 1})}")
    if r.opening_difference:
        body += f"<p style='color:#B02A37'>Difference in Opening Balances: {P.inr(abs(r.opening_difference))}</p>"
    return P.page(f"Final Accounts {company.get('name', '')}", body)


def client_pack(db_path: Path, folder: Path, company: dict, upto: date) -> Path:
    """One ZIP to send your CA: final accounts (HTML), ledger balances (CSV), day book (CSV)."""
    from services.voucher_store import VoucherStore
    folder = Path(folder)
    folder.mkdir(parents=True, exist_ok=True)
    balances = ledger_balances_csv(db_path, folder, upto)
    day = io.StringIO()
    w = csv.writer(day)
    w.writerow(["Date", "Type", "No.", "Status", "Side", "Ledger", "Amount", "Narration"])
    for v in VoucherStore(Path(db_path), "").load_all(limit=100000):
        for ln in v["lines"]:
            w.writerow([v["date"].strftime("%d-%m-%Y"), v["type"], v.get("invoice_no") or v["number"], v["status"],
                        ln["side"], ln["ledger"], f"{ln['amount']:.2f}", v["narration"]])
    safe = "".join(ch for ch in company.get("name", "company") if ch.isalnum() or ch in " -_").strip() or "company"
    path = folder / f"{safe.replace(' ', '_')}_client_pack_{upto:%Y%m%d}.zip"
    tmp = path.with_suffix(".zip.tmp")
    with zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("final_accounts.html", final_accounts_html(db_path, company, upto))
        z.write(balances, "ledger_balances.csv")
        z.writestr("day_book.csv", "﻿" + day.getvalue())
        z.writestr("README.txt", f"{company.get('name', '')}: books up to {upto:%d-%m-%Y}, prepared by BizPulse Pro.\n"
                                 "final_accounts.html opens in any browser (Ctrl+P prints it); the CSV files open in "
                                 "Excel. Optional and cancelled vouchers are left out of the final accounts and "
                                 "ledger balances; the day book lists every voucher with its status.\n")
    tmp.replace(path)
    return path
