"""
Printable documents: BizPulse writes a self-contained HTML page and opens it in the browser, where
Ctrl+P prints it (or saves a PDF) on any printer. Nothing here needs a printer driver.

    amount_in_words(Decimal("12345.50"))  -> "Rupees Twelve Thousand Three Hundred Forty-Five and Fifty Paise Only"
    invoice_html(voucher, company, paper, show_hsn, footer)      Print › Current Invoice
    payment_advice_html(voucher, company)                         Banking › Payment Advice
    deposit_slip_html(bank, on, rows, company)                    Banking › Deposit Slip
    cheque_html(payee, amount, on, layout)                        Banking › Cheque Printing
    table_html(title, subtitle, headers, rows)                    exports (Final Accounts, client pack)
    save(folder, name, html) -> Path;  open_in_browser(path)

Typography: Segoe UI 11 pt normal throughout; headings set apart with colour and rules, not size.
Paper: "A4" or "80 mm" (thermal roll; narrower layout, no HSN column).
"""
from __future__ import annotations

import html
import webbrowser
from datetime import date
from decimal import ROUND_HALF_UP, Decimal
from pathlib import Path

CENT = Decimal("0.01")
_ONES = ["", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten", "Eleven", "Twelve",
         "Thirteen", "Fourteen", "Fifteen", "Sixteen", "Seventeen", "Eighteen", "Nineteen"]
_TENS = ["", "", "Twenty", "Thirty", "Forty", "Fifty", "Sixty", "Seventy", "Eighty", "Ninety"]


def _two(n: int) -> str:
    if n < 20:
        return _ONES[n]
    return _TENS[n // 10] + (f"-{_ONES[n % 10]}" if n % 10 else "")


def _three(n: int) -> str:
    h, rest = divmod(n, 100)
    return " ".join(p for p in ((f"{_ONES[h]} Hundred" if h else ""), _two(rest)) if p)


def number_in_words(n: int) -> str:
    """Indian system: crore, lakh, thousand."""
    if n == 0:
        return "Zero"
    parts = []
    crore, n = divmod(n, 10_000_000)
    lakh, n = divmod(n, 100_000)
    thousand, n = divmod(n, 1000)
    if crore:
        parts.append(f"{number_in_words(crore)} Crore")
    if lakh:
        parts.append(f"{_two(lakh)} Lakh")
    if thousand:
        parts.append(f"{_two(thousand)} Thousand")
    if n:
        parts.append(_three(n))
    return " ".join(parts)


def amount_in_words(amount: Decimal) -> str:
    q = Decimal(amount).quantize(CENT, rounding=ROUND_HALF_UP)
    rupees, paise = divmod(int(q * 100), 100)
    text = f"Rupees {number_in_words(rupees)}"
    if paise:
        text += f" and {_two(paise)} Paise"
    return text + " Only"


def inr(v) -> str:
    q = Decimal(str(v)).quantize(CENT)
    whole, frac = f"{abs(q):.2f}".split(".")
    if len(whole) > 3:
        head, tail, groups = whole[:-3], whole[-3:], []
        while len(head) > 2:
            groups.insert(0, head[-2:])
            head = head[:-2]
        whole = ",".join(([head] if head else []) + groups + [tail])
    return ("-" if q < 0 else "") + whole + "." + frac


def e(text) -> str:
    return html.escape(str(text if text is not None else ""))


def page(title: str, body: str, paper: str = "A4") -> str:
    narrow = paper == "80 mm"
    size = "80mm auto" if narrow else "A4"
    width = "72mm" if narrow else "auto"
    return f"""<!doctype html>
<html lang="en"><head><meta charset="utf-8"><title>{e(title)}</title>
<style>
@page {{ size: {size}; margin: {"4mm" if narrow else "14mm"}; }}
body {{ font-family: "Segoe UI", Arial, sans-serif; font-size: 11pt; font-weight: normal; color: #1B2733;
        width: {width}; margin: 0 auto; }}
h1, h2, h3 {{ font-size: 11pt; font-weight: normal; color: #0D2C54; margin: 0 0 4pt; }}
h1 {{ border-bottom: 1.5pt solid #0D2C54; padding-bottom: 4pt; }}
table {{ width: 100%; border-collapse: collapse; margin: 6pt 0; }}
th {{ font-weight: normal; color: #FFFFFF; background: #0D2C54; text-align: left; padding: 3pt 5pt; }}
td {{ padding: 3pt 5pt; border-bottom: 0.5pt solid #D5DEE8; vertical-align: top; }}
td.n, th.n {{ text-align: right; white-space: nowrap; }}
tr.total td {{ background: #E6F0FA; color: #0D2C54; }}
.muted {{ color: #5A6772; }}
.grid {{ display: grid; grid-template-columns: {"1fr" if narrow else "1fr 1fr"}; gap: 6pt 18pt; margin: 6pt 0; }}
@media print {{ .noprint {{ display: none; }} }}
</style></head><body>
<p class="noprint muted">Print with Ctrl+P (choose "Save as PDF" for a file).</p>
{body}
</body></html>"""


def table_html(title: str, subtitle: str, headers: list[str], rows: list[list], numeric: set[int] | None = None,
               total_rows: set[int] | None = None) -> str:
    numeric, total_rows = numeric or set(), total_rows or set()
    head = "".join(f'<th class="{"n" if i in numeric else ""}">{e(h)}</th>' for i, h in enumerate(headers))
    body = "".join(
        f'<tr class="{"total" if r in total_rows else ""}">'
        + "".join(f'<td class="{"n" if i in numeric else ""}">{e(c)}</td>' for i, c in enumerate(row)) + "</tr>"
        for r, row in enumerate(rows))
    return page(title, f"<h1>{e(title)}</h1><p class='muted'>{e(subtitle)}</p><table><tr>{head}</tr>{body}</table>")


def _company_block(company: dict) -> str:
    lines = [e(company.get("name", ""))]
    if company.get("address"):
        lines.append(e(company["address"]))
    gst = [f"GSTIN {company['gstin']}" if company.get("gstin") else "GSTIN not entered",
           f"State code {company.get('state_code', '')}"]
    if company.get("pan"):
        gst.append(f"PAN {company['pan']}")
    lines.append(e(" · ".join(gst)))
    return "<br>".join(lines)


def invoice_html(v: dict, company: dict, paper: str = "A4", show_hsn: bool = True, footer: str = "") -> str:
    """A Sales voucher (as VoucherBook.load_voucher returns it) as a tax invoice."""
    narrow = paper == "80 mm"
    show_hsn = show_hsn and not narrow
    gst = v.get("gst") or {}
    details = v.get("details") or {}
    party = details.get("Party A/c") or next((ln["ledger"] for ln in v["lines"] if ln["side"] == "Dr"), "")
    tax_lines = [ln for ln in v["lines"] if ln["side"] == "Cr" and ln["ledger"].lower().startswith("output ")]
    round_off = [ln for ln in v["lines"] if ln["ledger"].lower() == "round off"]
    party_total = sum((ln["amount"] for ln in v["lines"] if ln["side"] == "Dr" and ln["ledger"] == party), Decimal("0"))
    hsn = gst.get("hsn", "")
    head = ["Item"] + (["HSN/SAC"] if show_hsn else []) + ["Qty", "Rate", "Amount"]
    rows = []
    if v.get("items"):
        for it in v["items"]:
            rows.append([it["item"]] + ([hsn] if show_hsn else []) + [f"{it['quantity']} {it.get('per', 'Nos')}",
                                                                     inr(it["rate"]), inr(it["amount"])])
    else:
        sales = sum((ln["amount"] for ln in v["lines"] if ln["side"] == "Cr" and ln not in tax_lines
                     and ln not in round_off), Decimal("0"))
        rows.append([v.get("narration") or "Sales"] + ([hsn] if show_hsn else []) + ["", "", inr(sales)])
    width = len(head)
    numeric = set(range(width - 3, width))
    body_rows = "".join("<tr>" + "".join(f'<td class="{"n" if i in numeric else ""}">{e(c)}</td>'
                                         for i, c in enumerate(r)) + "</tr>" for r in rows)
    extra = "".join(f'<tr><td colspan="{width - 1}" class="n">{e(ln["ledger"])}'
                    f'{" @ " + e(gst.get("rate", "")) + "%" if ln in tax_lines and gst.get("rate") else ""}</td>'
                    f'<td class="n">{"-" if ln["side"] == "Dr" else ""}{inr(ln["amount"])}</td></tr>'
                    for ln in tax_lines + round_off)
    total = f'<tr class="total"><td colspan="{width - 1}" class="n">Total</td><td class="n">{inr(party_total)}</td></tr>'
    th = "".join(f'<th class="{"n" if i in numeric else ""}">{e(h)}</th>' for i, h in enumerate(head))
    number = v.get("invoice_no") or v.get("number")
    buyer_gstin = gst.get("gstin") or "unregistered"
    body = f"""<h1>Tax Invoice</h1>
<div class="grid"><div>{_company_block(company)}</div>
<div>Invoice No. {e(number)}<br>Date {e(v['date'].strftime('%d-%m-%Y'))}<br>Place of supply {e(gst.get('place_of_supply', ''))}</div></div>
<h2>Bill to</h2><p>{e(details.get('Buyer') or gst.get('customer') or party)}<br>GSTIN {e(buyer_gstin)}</p>
<table><tr>{th}</tr>{body_rows}{extra}{total}</table>
<p>{e(amount_in_words(party_total))}</p>
<p class="muted">{e(footer)}</p>"""
    if v.get("status") == "Cancelled":
        body = "<h2 style='color:#B02A37'>CANCELLED</h2>" + body
    return page(f"Invoice {number}", body, paper)


def payment_advice_html(v: dict, company: dict) -> str:
    details = v.get("details") or {}
    paid = [ln for ln in v["lines"] if ln["side"] == "Dr"]
    bank = next((ln["ledger"] for ln in v["lines"] if ln["side"] == "Cr"), "")
    payee = paid[0]["ledger"] if paid else ""
    rows = "".join(f"<tr><td>{e(ln['ledger'])}</td><td class='n'>{inr(ln['amount'])}</td></tr>" for ln in paid)
    cheque = (f"<p>Cheque No. {e(details.get('Cheque · Cheque No.'))} dated {e(details.get('Cheque · Cheque Date', ''))} "
              f"drawn on {e(details.get('Cheque · Bank Name') or bank)}</p>" if details.get("Cheque · Cheque No.") else
              f"<p>Paid from {e(bank)}</p>")
    body = f"""<h1>Payment Advice</h1><div class="grid"><div>{_company_block(company)}</div>
<div>Payment No. {e(v['number'])}<br>Date {e(v['date'].strftime('%d-%m-%Y'))}</div></div>
<p>To {e(details.get('Cheque · Favouring') or payee)}</p>
<p>We have made the following payment to you:</p>
<table><tr><th>Particulars</th><th class="n">Amount</th></tr>{rows}
<tr class="total"><td>Total</td><td class="n">{inr(v['total'])}</td></tr></table>
<p>{e(amount_in_words(v['total']))}</p>{cheque}<p class="muted">{e(v.get('narration', ''))}</p>"""
    return page(f"Payment Advice {v['number']}", body)


def deposit_slip_html(bank: str, on: date, rows: list[dict], company: dict) -> str:
    total = sum((r["amount"] for r in rows), Decimal("0"))
    trs = "".join(f"<tr><td>{i}</td><td>{e(r['cheque_no'])}</td><td>{e(r['cheque_date'])}</td><td>{e(r['drawn_on'])}</td>"
                  f"<td>{e(r['from'])}</td><td class='n'>{inr(r['amount'])}</td></tr>" for i, r in enumerate(rows, 1))
    body = f"""<h1>Deposit Slip · {e(bank)}</h1><div class="grid"><div>{_company_block(company)}</div>
<div>Date {e(on.strftime('%d-%m-%Y'))}<br>{len(rows)} cheque(s)</div></div>
<table><tr><th>#</th><th>Cheque No.</th><th>Date</th><th>Drawn on</th><th>Received from</th><th class="n">Amount</th></tr>
{trs}<tr class="total"><td colspan="5">Total</td><td class="n">{inr(total)}</td></tr></table>
<p>{e(amount_in_words(total))}</p><p class="muted">Depositor's signature ____________________</p>"""
    return page(f"Deposit Slip {bank} {on:%d-%m-%Y}", body)


def cheque_html(payee: str, amount: Decimal, on: date, layout: dict) -> str:
    """Absolute positions in mm (CHEQUE_LAYOUT in config/settings.py): calibrate once per bank."""
    def at(key: str, text: str, extra: str = "") -> str:
        x, y = layout[key]
        return f'<div style="position:absolute;left:{x}mm;top:{y}mm;{extra}">{e(text)}</div>'
    digits = on.strftime("%d%m%Y")
    body = ('<div style="position:relative;width:{w}mm;height:{h}mm;border:0.3pt dashed #AEB7C2">'.format(
        w=layout["size"][0], h=layout["size"][1])
        + at("date", "  ".join(digits), "letter-spacing:1.2mm")
        + at("payee", payee) + at("words", amount_in_words(amount).replace("Rupees ", ""), f"width:{layout['words_width']}mm")
        + at("figures", f"{inr(amount)}/-") + "</div>")
    return page(f"Cheque {payee}", body)


def save(folder: Path, name: str, document: str) -> Path:
    folder = Path(folder)
    folder.mkdir(parents=True, exist_ok=True)
    path = folder / name
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(document, encoding="utf-8")
    tmp.replace(path)
    return path


def open_in_browser(path: Path) -> None:
    webbrowser.open(Path(path).resolve().as_uri())
