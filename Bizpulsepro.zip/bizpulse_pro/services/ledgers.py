"""
The ledger names offered in the voucher screen's "List of Ledger Accounts" panel.

    load_ledger_catalogue(db_path) -> [(category, [ledger, …]), …]

Sources (read-only, mode=ro; a missing database or table is simply skipped):
    config/ledger_groups.py             every ledger you have grouped, under its group
    bp_voucher_lines                    ledgers already used on saved vouchers, under their group
                                        ("Not grouped" when config/ledger_groups.py has none)
    corporate_ledger_summary            account_name    -> Sundry Debtors
    gst_sales_ledger                    customer_name   -> Sundry Debtors

Names are de-duplicated without regard to capitals or spaces at the ends; the first spelling
found is kept. Categories come in a fixed order (cash and bank first, then customers, then
the rest alphabetically, "Not grouped" last), names alphabetically within each.
"""
from __future__ import annotations

import sqlite3
from pathlib import Path

from config.ledger_groups import LEDGER_GROUPS

CASH_BANK = ("Cash-in-Hand", "Bank Accounts", "Bank OD A/c")
FIRST = CASH_BANK + ("Sundry Debtors", "Sundry Creditors")
NOT_GROUPED = "Not grouped"


def _rows(con: sqlite3.Connection, table: str, column: str) -> list[str]:
    if con.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", (table,)).fetchone() is None:
        return []
    cols = {r[1] for r in con.execute(f'PRAGMA table_info("{table}")')}
    if column not in cols:
        return []
    return [r[0] for r in con.execute(f'SELECT DISTINCT "{column}" FROM "{table}" WHERE "{column}" IS NOT NULL')]


def load_ledger_catalogue(db_path: Path | None) -> list[tuple[str, list[str]]]:
    groups = {k.strip().lower(): v for k, v in LEDGER_GROUPS.items()}
    seen: dict[str, tuple[str, str]] = {}            # key -> (category, spelling)

    def add(name: str, category: str) -> None:
        name = str(name).strip()
        if name and name.lower() not in seen:
            seen[name.lower()] = (category, name)

    for name, group in LEDGER_GROUPS.items():
        add(name, group)
    if db_path is not None and Path(db_path).is_file():
        try:
            con = sqlite3.connect(Path(db_path).resolve().as_uri() + "?mode=ro", uri=True, timeout=5)
        except sqlite3.Error:
            con = None
        if con is not None:
            try:
                for name in _rows(con, "corporate_ledger_summary", "account_name"):
                    add(name, groups.get(str(name).strip().lower(), "Sundry Debtors"))
                for name in _rows(con, "gst_sales_ledger", "customer_name"):
                    add(name, groups.get(str(name).strip().lower(), "Sundry Debtors"))
                if _rows(con, "bp_ledgers", "name"):          # ledgers created in Masters, under their group
                    for name, under in con.execute("SELECT name, under_group FROM bp_ledgers"):
                        seen[str(name).strip().lower()] = (under, str(name).strip())
                for name in _rows(con, "bp_voucher_lines", "ledger"):
                    add(name, groups.get(str(name).strip().lower(), NOT_GROUPED))
            except sqlite3.Error:
                pass
            finally:
                con.close()

    by_cat: dict[str, list[str]] = {}
    for category, name in seen.values():
        by_cat.setdefault(category, []).append(name)

    def order(cat: str) -> tuple:
        if cat in FIRST:
            return (0, FIRST.index(cat), "")
        return (2 if cat == NOT_GROUPED else 1, 0, cat.lower())

    return [(cat, sorted(by_cat[cat], key=str.lower)) for cat in sorted(by_cat, key=order)]


def load_item_catalogue(db_path: Path | None) -> list[tuple[str, list[str]]]:
    """Stock items for the Item Invoice: product_sku from inventory_stock_registry (read-only)."""
    if db_path is None or not Path(db_path).is_file():
        return []
    try:
        con = sqlite3.connect(Path(db_path).resolve().as_uri() + "?mode=ro", uri=True, timeout=5)
    except sqlite3.Error:
        return []
    try:
        names = sorted({str(n).strip() for n in _rows(con, "inventory_stock_registry", "product_sku") if str(n).strip()},
                       key=str.lower)
    except sqlite3.Error:
        names = []
    finally:
        con.close()
    return [("Stock Items", names)] if names else []
