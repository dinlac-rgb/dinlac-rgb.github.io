"""
[U] Upgrade (Alt+U): the statutory software-update check. BizPulse asks your update server's
feed what is newer than this copy; it shows no prices or plans (those live on the website).

    check(feed_url, installed) -> UpdateResult     one HTTPS request, in a background thread

The feed is a small JSON file you publish at UPDATE_FEED_URL (config/settings.py):

    {
      "published": "2026-10-10",
      "items": [
        {"kind": "app",        "version": "1.1.0",      "title": "BizPulse Pro 1.1.0",
         "notes": "…", "url": "https://…/download", "sha256": "…"},
        {"kind": "security",   "version": "2026.10.1",  "title": "Security patch", "url": "…"},
        {"kind": "tax_tables", "version": "2026.10",    "title": "GST rate / HSN table update", "url": "…"}
      ]
    }

An item is offered when its version is newer than the installed one of its kind
(INSTALLED_VERSIONS: app = APP_VERSION, security = SECURITY_PATCH_LEVEL, tax_tables =
TAX_TABLES_VERSION). Versions compare part by part as numbers: 1.10.0 > 1.9.2, 2026.10 > 2026.9.

What it does not do: download or install anything by itself. Each item's link opens in the
browser; install it as you install BizPulse, then raise the matching version in settings.py.
Only https:// feeds are accepted. With no feed set, it says so and claims nothing.
"""
from __future__ import annotations

import json
import re
import urllib.request
from dataclasses import dataclass, field

KINDS = {"app": "Version update", "security": "Security patch", "tax_tables": "Tax compliance tables"}
UP_TO_DATE = "Your BizPulse Pro System is Up to Date"
MAX_BYTES = 256 * 1024


class UpdateError(Exception):
    """A message for the screen; nothing was changed."""


@dataclass
class Update:
    kind: str
    version: str
    title: str
    notes: str = ""
    url: str = ""
    sha256: str = ""
    installed: str = ""


@dataclass
class UpdateResult:
    updates: list[Update] = field(default_factory=list)
    published: str = ""
    skipped: int = 0                       # items in the feed that could not be read

    @property
    def message(self) -> str:
        if not self.updates:
            return UP_TO_DATE
        n = len(self.updates)
        return f"{n} update{'s' if n != 1 else ''} available."


def version_key(text: str) -> tuple[int, ...]:
    parts = re.findall(r"\d+", str(text))
    if not parts:
        raise ValueError(f"'{text}' is not a version number")
    return tuple(int(p) for p in parts)


def newer(candidate: str, installed: str) -> bool:
    a, b = version_key(candidate), version_key(installed)
    width = max(len(a), len(b))
    return a + (0,) * (width - len(a)) > b + (0,) * (width - len(b))


def parse_feed(raw: bytes, installed: dict[str, str]) -> UpdateResult:
    try:
        data = json.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise UpdateError(f"The update feed is not valid JSON ({exc}).") from None
    if not isinstance(data, dict) or not isinstance(data.get("items", []), list):
        raise UpdateError("The update feed has no 'items' list.")
    result = UpdateResult(published=str(data.get("published", "")))
    for item in data.get("items", []):
        try:
            kind, version = str(item["kind"]), str(item["version"])
            if kind not in KINDS or kind not in installed:
                raise ValueError(kind)
            if newer(version, installed[kind]):
                url = str(item.get("url", ""))
                result.updates.append(Update(kind, version, str(item.get("title") or KINDS[kind]),
                                             str(item.get("notes", "")), url if url.startswith("https://") else "",
                                             str(item.get("sha256", "")), installed[kind]))
        except (KeyError, TypeError, ValueError):
            result.skipped += 1
    order = list(KINDS)
    result.updates.sort(key=lambda u: (order.index(u.kind), version_key(u.version)))
    return result


def check(feed_url: str, installed: dict[str, str], timeout: float = 8.0) -> UpdateResult:
    url = (feed_url or "").strip()
    if not url:
        raise UpdateError("No update feed is set (UPDATE_FEED_URL in config/settings.py), so nothing was "
                          "checked. Ask Srijee Creations for the feed address.")
    if not url.lower().startswith("https://"):
        raise UpdateError("UPDATE_FEED_URL must start with https:// (updates are never fetched over plain http).")
    request = urllib.request.Request(url, headers={"User-Agent": f"BizPulse-Pro/{installed.get('app', '?')}",
                                                   "Accept": "application/json"})
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:      # noqa: S310 (https only, above)
            raw = response.read(MAX_BYTES + 1)
    except OSError as exc:                       # URLError, timeouts, TLS and connection errors
        reason = getattr(exc, "reason", exc)
        raise UpdateError(f"Could not reach the update server ({reason}). Check the internet connection and "
                          "try again (R).") from None
    if len(raw) > MAX_BYTES:
        raise UpdateError("The update feed is larger than expected; it was not read.")
    return parse_feed(raw, installed)
