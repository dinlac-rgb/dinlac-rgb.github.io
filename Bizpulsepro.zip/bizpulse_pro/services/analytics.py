"""
Figures for the Dashboard and Ratio Analysis, worked out from the saved vouchers
(bp_vouchers / bp_voucher_lines) — the same source as the Balance Sheet and P&L, so all
four screens agree. Read-only: the database is opened with mode=ro.

    monthly_trends(db_path, upto)  -> Trends     sales, purchases, cash in / out per month (Apr–Mar)
    ratio_analysis(reports)        -> RatioAnalysis   principal groups and principal ratios

Definitions (stated on screen too):
    Sales / Purchases    ledgers grouped Sales Accounts / Purchase Accounts (config/ledger_groups.py)
    Cash in / out        per voucher, the net change of all Cash-in-Hand, Bank Accounts and
                         Bank OD A/c ledgers: up = in, down = out. A Contra (cash to bank)
                         nets to nil, so it is neither.
    Ratios               as in the RATIO_DEFINITIONS list below; a ratio whose divisor is nil
                         is shown as "—", never as 0.
"""
from __future__ import annotations

import sqlite3
from dataclasses import dataclass, field
from datetime import date
from decimal import Decimal
from pathlib import Path

from services.reports import (ZERO, ReportError, Reports, connect_ro, financial_year_start, group_lookup,
                              group_totals, has_table, live_filter)

MONTHS = ["Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec", "Jan", "Feb", "Mar"]
CASH_GROUPS = {"Cash-in-Hand", "Bank Accounts", "Bank OD A/c"}
HUNDRED = Decimal(100)


@dataclass
class Trends:
    fy_start: date
    upto: date
    sales: list[Decimal]
    purchases: list[Decimal]
    cash_in: list[Decimal]
    cash_out: list[Decimal]
    voucher_count: int

    @property
    def fy_label(self) -> str:
        return f"{self.fy_start.year}-{(self.fy_start.year + 1) % 100:02d}"

    def month_name(self, i: int) -> str:
        year = self.fy_start.year + (1 if i >= 9 else 0)
        return f"{MONTHS[i]} {year}"


def _month_index(iso: str) -> int:
    return (int(iso[5:7]) - 4) % 12


def monthly_trends(db_path: Path, upto: date) -> Trends:
    start = financial_year_start(upto)
    zeros = lambda: [ZERO] * 12  # noqa: E731
    sales, purchases, cash_in, cash_out = zeros(), zeros(), zeros(), zeros()
    con = connect_ro(db_path)
    try:
        lookup = group_lookup(con)
        if not has_table(con, "bp_vouchers"):
            return Trends(start, upto, sales, purchases, cash_in, cash_out, 0)
        rows = con.execute(
            "SELECT v.id, v.voucher_date, l.ledger, l.side, l.amount_paise "
            "FROM bp_voucher_lines l JOIN bp_vouchers v ON v.id = l.voucher_id "
            f"WHERE v.voucher_date BETWEEN ? AND ?{live_filter(con)} ORDER BY v.id",
            (start.isoformat(), upto.isoformat())).fetchall()
    except sqlite3.Error as exc:
        raise ReportError(f"Could not read {db_path.name}: {exc}") from exc
    finally:
        con.close()

    cash_net: dict[int, tuple[int, Decimal]] = {}       # voucher id -> (month, net change in paise)
    for vid, vdate, ledger, side, paise in rows:
        m = _month_index(vdate)
        amount = Decimal(paise) / 100
        dr = amount if side == "Dr" else -amount
        grp = lookup.get(ledger.strip().lower())
        if grp == "Sales Accounts":
            sales[m] -= dr
        elif grp == "Purchase Accounts":
            purchases[m] += dr
        elif grp in CASH_GROUPS:
            _m, net = cash_net.get(vid, (m, ZERO))
            cash_net[vid] = (m, net + dr)
    for m, net in cash_net.values():
        if net > 0:
            cash_in[m] += net
        elif net < 0:
            cash_out[m] -= net
    q = Decimal("0.01")
    fix = lambda xs: [x.quantize(q) for x in xs]  # noqa: E731
    return Trends(start, upto, fix(sales), fix(purchases), fix(cash_in), fix(cash_out),
                  len({r[0] for r in rows}))


# ---- Ratio Analysis ----------------------------------------------------------------------
@dataclass
class RatioRow:
    label: str
    value: Decimal | None          # None: cannot be worked out (see note)
    kind: str                      # money | ratio | percent | days | times
    formula: str
    note: str = ""


@dataclass
class RatioAnalysis:
    period_start: date
    period_end: date
    groups: list[RatioRow]
    ratios: list[RatioRow]
    notes: list[str] = field(default_factory=list)

    def ratio(self, label: str) -> RatioRow:
        return next(r for r in self.groups + self.ratios if r.label == label)


def _div(a: Decimal, b: Decimal, scale: Decimal = Decimal(1)) -> Decimal | None:
    return None if not b else (a * scale / b).quantize(Decimal("0.01"))


def ratio_analysis(r: Reports) -> RatioAnalysis:
    t = group_totals(r)
    g = lambda name: t.get(name, ZERO)  # noqa: E731
    pl = lambda name: r.pl[name].amount if name in r.pl else ZERO  # noqa: E731

    current_assets, current_liabilities = g("Current Assets"), g("Current Liabilities")
    stock = g("Stock-in-Hand")                    # closing stock on the Balance Sheet (already includes the
                                                  # Stock Summary value: services/reports.py)
    opening_stock = pl("Opening Stock")
    cogs = opening_stock + pl("Purchase Accounts") + pl("Direct Expenses") - pl("Closing Stock")
    average_stock = (opening_stock + stock) / 2 if opening_stock else stock
    working_capital = current_assets - current_liabilities
    sales = pl("Sales Accounts")
    expenses = (pl("Opening Stock") + pl("Purchase Accounts") + pl("Direct Expenses")
                + pl("Indirect Expenses") - pl("Closing Stock"))
    owners_funds = g("Capital Account") + g("Profit & Loss A/c")
    days = Decimal((r.period_end - r.period_start).days + 1)
    stock_note = "There is no closing stock in the books, so this is left out." if not stock else ""

    groups = [
        RatioRow("Working Capital", working_capital, "money", "Current Assets − Current Liabilities"),
        RatioRow("Cash-in-Hand", g("Cash-in-Hand"), "money", "Cash-in-Hand group"),
        RatioRow("Bank Accounts", g("Bank Accounts"), "money", "Bank Accounts group"),
        RatioRow("Bank OD A/c", g("Bank OD A/c"), "money", "Bank OD A/c group"),
        RatioRow("Sundry Debtors", g("Sundry Debtors"), "money", "Sundry Debtors group (customers)"),
        RatioRow("Sundry Creditors", g("Sundry Creditors"), "money", "Sundry Creditors group (suppliers)"),
        RatioRow("Sales Accounts", sales, "money", "Sales for the period"),
        RatioRow("Purchase Accounts", pl("Purchase Accounts"), "money", "Purchases for the period"),
        RatioRow("Stock-in-Hand", stock if stock else None, "money", "Closing stock value",
                 "" if stock else "Not in the books: see the notes below and the Stock Summary."),
        RatioRow("Nett Profit", r.net_profit, "money", "Net profit for the period (P&L A/c)"),
        RatioRow("Wkg. Capital Turnover", _div(sales, working_capital), "times", "Sales ÷ Working Capital"),
        RatioRow("Inventory Turnover", _div(cogs, average_stock), "times",
                 "Cost of goods sold ÷ average stock (opening + closing ÷ 2; closing alone if no opening "
                 "stock is entered)", stock_note),
    ]
    ratios = [
        RatioRow("Current Ratio", _div(current_assets, current_liabilities), "ratio",
                 "Current Assets : Current Liabilities"),
        RatioRow("Quick Ratio", _div(current_assets - stock, current_liabilities), "ratio",
                 "(Current Assets − Stock) : Current Liabilities"),
        RatioRow("Debt/Equity Ratio", _div(g("Loans (Liability)"), owners_funds), "ratio",
                 "Loans (Liability) : (Capital Account + P&L A/c)"),
        RatioRow("Gross Profit %", _div(r.gross_profit, sales, HUNDRED), "percent", "Gross Profit ÷ Sales × 100"),
        RatioRow("Nett Profit %", _div(r.net_profit, sales, HUNDRED), "percent", "Net Profit ÷ Sales × 100"),
        RatioRow("Operating Cost %", _div(expenses, sales, HUNDRED), "percent",
                 "(Opening Stock + Purchases + Direct and Indirect Expenses − Closing Stock) ÷ Sales × 100"),
        RatioRow("Recv. Turnover in Days", _div(g("Sundry Debtors") * days, sales), "days",
                 f"Sundry Debtors ÷ Sales × {days} days in the period"),
        RatioRow("Return on Investment %", _div(r.net_profit, owners_funds, HUNDRED), "percent",
                 "Net Profit ÷ (Capital Account + P&L A/c) × 100"),
        RatioRow("Return on Wkg. Capital %", _div(r.net_profit, working_capital, HUNDRED), "percent",
                 "Net Profit ÷ Working Capital × 100"),
    ]
    for row in ratios + groups:
        if row.value is None and not row.note:
            row.note = "Cannot be worked out: the divisor is nil."
    notes = []
    if r.not_grouped:
        notes.append(f"{len(r.not_grouped)} ledger(s) are not grouped and are left out of these figures: "
                     "add them to config/ledger_groups.py.")
    notes.extend(r.stock_notes)
    if not stock:
        notes.append("With no closing stock in the books, Quick Ratio equals Current Ratio and Inventory "
                     "Turnover is not shown.")
    return RatioAnalysis(r.period_start, r.period_end, groups, ratios, notes)
