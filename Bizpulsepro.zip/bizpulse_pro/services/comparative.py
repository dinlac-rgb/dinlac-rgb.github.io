"""
Comparative columns for the Profit & Loss A/c and the Balance Sheet (C on either screen).

    comparative(db_path, kind, mode, today) -> Comparison

    kind   "pl" (Profit & Loss A/c) or "bs" (Balance Sheet)
    mode   "year"      last financial year | this financial year to date
           "quarters"  Q1 | Q2 | Q3 | Q4 of this financial year (only quarters that have begun)

Each column is built by services/reports.py over its own dates (P&L: the column's period;
Balance Sheet: as at the column's last day), so the rows are the same groups in every column.

Stock, honestly:
    this year            as on the normal screens (config/stock_valuation.py + Stock Summary)
    last year            opening = OPENING_STOCK for last year, closing = OPENING_STOCK for this
                         year (last year's closing stock is this year's opening), at cost
    quarters             left out of every quarter column: there are no quarter-end stock values,
                         and today's quantities would be wrong for a past quarter
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date, timedelta
from decimal import Decimal
from pathlib import Path

from config import stock_valuation as SV
from services.reports import Node, Reports, build_reports, financial_year_start, fy_label

ZERO = Decimal("0.00")
MODES = ("year", "quarters")
PL_ROWS = [("Sales Accounts", "Sales Accounts"), ("Direct Incomes", "Direct Incomes"),
           ("Less: Opening Stock", "Opening Stock"), ("Less: Purchases", "Purchase Accounts"),
           ("Less: Direct Expenses", "Direct Expenses"), ("Add: Closing Stock", "Closing Stock"),
           ("Gross Profit / Loss", "_gross"), ("Add: Indirect Incomes", "Indirect Incomes"),
           ("Less: Indirect Expenses", "Indirect Expenses"), ("NET PROFIT / LOSS", "_net")]


@dataclass
class Column:
    label: str
    start: date
    end: date
    reports: Reports


@dataclass
class Comparison:
    kind: str
    mode: str
    columns: list[Column]
    rows: list[tuple[str, list[Decimal], str]]      # (label, one amount per column, style: group|total|net)
    notes: list[str] = field(default_factory=list)


def _stock_value(label: str) -> Decimal:
    raw = SV.OPENING_STOCK.get(label)
    try:
        return Decimal(str(raw).replace(",", "")).quantize(Decimal("0.01")) if raw is not None else ZERO
    except ArithmeticError:
        return ZERO


def _add_months(d: date, months: int) -> date:
    m = d.month - 1 + months
    return date(d.year + m // 12, m % 12 + 1, 1)


def periods(mode: str, today: date) -> list[tuple[str, date, date, tuple | None]]:
    """(label, start, end, stock_override) per column."""
    fy = financial_year_start(today)
    if mode == "year":
        last = date(fy.year - 1, 4, 1)
        last_label, this_label = fy_label(last), fy_label(fy)
        stock = (_stock_value(last_label), _stock_value(this_label),
                 f"{last_label}: stock from OPENING_STOCK for {last_label} and {this_label} (config/stock_valuation.py).")
        return [(f"FY {last_label}", last, fy - timedelta(days=1), stock),
                (f"FY {this_label} to date", fy, today, None)]
    out = []
    for q in range(4):
        start = _add_months(fy, 3 * q)
        if start > today:
            break
        end = min(_add_months(start, 3) - timedelta(days=1), today)
        out.append((f"Q{q + 1} {start.strftime('%b')}-{end.strftime('%b')}", start, end, (ZERO, ZERO, "")))
    return out


def comparative(db_path: Path, kind: str, mode: str, today: date | None = None) -> Comparison:
    today = today or date.today()
    columns = []
    for label, start, end, stock in periods(mode, today):
        r = build_reports(db_path, end, start if kind == "pl" else None, stock_override=stock)
        columns.append(Column(label, start, end, r))
    notes = []
    if mode == "quarters":
        notes.append("Quarter columns leave stock out: there are no quarter-end stock values.")
    else:
        notes.append(f"{columns[0].label}: stock taken from config/stock_valuation.py (OPENING_STOCK).")
    rows = _pl_rows(columns) if kind == "pl" else _bs_rows(columns)
    for c in columns:
        if c.reports.opening_difference and kind == "bs":
            notes.append(f"{c.label}: Difference in Opening Balances ₹{abs(c.reports.opening_difference):,.2f}.")
    return Comparison(kind, mode, columns, rows, notes)


def _pl_rows(columns: list[Column]) -> list[tuple[str, list[Decimal], str]]:
    rows = []
    for label, key in PL_ROWS:
        if key == "_gross":
            rows.append((label, [c.reports.gross_profit for c in columns], "total"))
        elif key == "_net":
            rows.append((label, [c.reports.net_profit for c in columns], "net"))
        else:
            rows.append((label, [c.reports.pl.get(key, Node(key)).amount for c in columns], "group"))
    return rows


def _bs_rows(columns: list[Column]) -> list[tuple[str, list[Decimal], str]]:
    def side(attr: str) -> list[str]:
        names: list[str] = []
        for c in columns:
            for n in getattr(c.reports, attr):
                if n.name not in names:
                    names.append(n.name)
        return names

    def amount(c: Column, attr: str, name: str) -> Decimal:
        return next((n.amount for n in getattr(c.reports, attr) if n.name == name), ZERO)

    rows = [("LIABILITIES", [ZERO] * len(columns), "heading")]
    rows += [(name, [amount(c, "liabilities", name) for c in columns], "group") for name in side("liabilities")]
    rows.append(("Total Liabilities", [c.reports.liabilities_total for c in columns], "total"))
    rows.append(("ASSETS", [ZERO] * len(columns), "heading"))
    rows += [(name, [amount(c, "assets", name) for c in columns], "group") for name in side("assets")]
    rows.append(("Total Assets", [c.reports.assets_total for c in columns], "total"))
    return rows
