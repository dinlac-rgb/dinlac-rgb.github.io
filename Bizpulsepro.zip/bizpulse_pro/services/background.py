"""
Run slow work off the UI thread and get the result back on it.

    run_in_background(widget, work, on_done, on_error)

`work()` runs in a daemon thread. Its result (or exception) is handed back through a queue
that the UI thread polls with widget.after(), so on_done / on_error always run on the UI
thread and may touch widgets. If the widget is destroyed first (screen closed), nothing runs.
"""
from __future__ import annotations

import queue
import threading
import tkinter as tk
from typing import Any, Callable

POLL_MS = 40


def run_in_background(widget: tk.Misc, work: Callable[[], Any],
                      on_done: Callable[[Any], None], on_error: Callable[[Exception], None]) -> None:
    box: "queue.Queue[tuple[bool, Any]]" = queue.Queue(maxsize=1)

    def worker() -> None:
        try:
            box.put((True, work()))
        except Exception as exc:   # handed to on_error on the UI thread
            box.put((False, exc))

    def poll() -> None:
        if not widget.winfo_exists():
            return
        try:
            ok, value = box.get_nowait()
        except queue.Empty:
            widget.after(POLL_MS, poll)
            return
        (on_done if ok else on_error)(value)

    threading.Thread(target=worker, daemon=True).start()
    widget.after(POLL_MS, poll)
