"""
Every table BizPulse Pro uses, created in one place.

    ensure_schema(db_path) -> str        at every start: BizPulse's own bp_* tables, created only where
                                         missing (CREATE TABLE IF NOT EXISTS), never altered or emptied
    create_company_file(path, profile)   a NEW company database: the core tables, every bp_* table,
                                         the company profile, the 28 groups and the audit trail

Two families of tables
    core tables      gst_sales_ledger, inventory_stock_registry, corporate_ledger_summary. In an
                     existing database they belong to you (your database_config.py made them) and
                     are never created or changed here, so nothing can collide with them. A new
                     company made by Company › Create Company gets them, with the columns BizPulse
                     reads and writes.
    bp_* tables      BizPulse's own: vouchers and their lines, items, details, foreign amounts,
                     cost centres, masters, company profile, bank reconciliation, audit trail.

Everything for one database runs in one transaction: all of it is created, or none of it.
"""
from __future__ import annotations

import sqlite3
from datetime import datetime
from pathlib import Path

from services import audit, bank_reco, cost_centres
from services.inventory_masters import INVENTORY_DDL
from services.masters import DDL as MASTER_DDL
from services.voucher_store import DDL as VOUCHER_DDL

CORE_DDL = """
CREATE TABLE IF NOT EXISTS gst_sales_ledger (
    invoice_no TEXT PRIMARY KEY, customer_name TEXT, customer_gstin TEXT, hsn_code TEXT, taxable_value REAL,
    cgst_rate REAL, sgst_rate REAL, igst_rate REAL, place_of_supply TEXT);
CREATE TABLE IF NOT EXISTS inventory_stock_registry (
    product_sku TEXT PRIMARY KEY, qty_on_hand INTEGER NOT NULL DEFAULT 0, min_safety_floor INTEGER NOT NULL DEFAULT 0,
    last_audit_date TEXT);
CREATE TABLE IF NOT EXISTS corporate_ledger_summary (
    account_id TEXT PRIMARY KEY, account_name TEXT, outstanding_balance REAL NOT NULL DEFAULT 0,
    credit_ceiling REAL NOT NULL DEFAULT 0)
"""
COMPANY_DDL = """
CREATE TABLE IF NOT EXISTS bp_company (
    id             INTEGER PRIMARY KEY CHECK (id = 1),      -- one company per database
    name           TEXT NOT NULL,
    state_code     TEXT NOT NULL,
    gstin          TEXT NOT NULL DEFAULT '',
    pan            TEXT NOT NULL DEFAULT '',
    cin            TEXT NOT NULL DEFAULT '',
    address        TEXT NOT NULL DEFAULT '',
    invoice_prefix TEXT NOT NULL,
    books_from     TEXT NOT NULL DEFAULT '',                -- YYYY-MM-DD the books begin (opening balances date)
    created_at     TEXT NOT NULL,
    updated_at     TEXT NOT NULL
)"""
EXTRA_DDL = """
CREATE TABLE IF NOT EXISTS bp_currencies (
    code TEXT PRIMARY KEY COLLATE NOCASE, name TEXT NOT NULL, symbol TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL, updated_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS bp_stock_categories (
    name TEXT PRIMARY KEY COLLATE NOCASE, under_category TEXT NOT NULL DEFAULT 'Primary',
    created_at TEXT NOT NULL, updated_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS bp_godowns (
    name TEXT PRIMARY KEY COLLATE NOCASE, under_godown TEXT NOT NULL DEFAULT 'Primary', address TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL, updated_at TEXT NOT NULL)
"""


def _statements(*blocks: str) -> list[str]:
    return [s.strip() for block in blocks for s in block.split(";") if s.strip()]


def bp_statements() -> list[str]:
    return _statements(VOUCHER_DDL, cost_centres.DDL, MASTER_DDL, INVENTORY_DDL, bank_reco.DDL, COMPANY_DDL, EXTRA_DDL)


def _tables(con: sqlite3.Connection) -> set[str]:
    return {r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type = 'table'")}


def _apply(con: sqlite3.Connection, statements: list[str]) -> int:
    before = _tables(con)
    for stmt in statements:
        con.execute(stmt)
    if "status" not in {r[1] for r in con.execute("PRAGMA table_info(bp_vouchers)")}:
        con.execute("ALTER TABLE bp_vouchers ADD COLUMN status TEXT NOT NULL DEFAULT 'Regular'")
    return len(_tables(con) - before)


def ensure_schema(db_path: Path) -> str:
    """BizPulse's own tables, where missing. One line for the status bar."""
    db_path = Path(db_path)
    if not db_path.is_file():
        return f"Tables not checked: {db_path.name} was not found."
    con = sqlite3.connect(str(db_path), timeout=5, isolation_level=None)
    try:
        con.execute("BEGIN IMMEDIATE")
        created = _apply(con, bp_statements())
        con.execute("COMMIT")
        missing = [t for t in ("gst_sales_ledger", "inventory_stock_registry") if t not in _tables(con)]
        note = (f" Not found (your own tables, never created here): {', '.join(missing)}; Sales and Item "
                "Invoices need them." if missing else "")
        return (f"BizPulse tables ready ({created} created)." if created else "BizPulse tables ready.") + note
    except sqlite3.Error as exc:
        if con.in_transaction:
            con.execute("ROLLBACK")
        return f"BizPulse tables NOT checked: {exc}"
    finally:
        con.close()


def create_company_file(path: Path, profile: dict) -> Path:
    """A new, complete company database. Refuses to touch a file that already exists."""
    from services.group_seeder import seed_account_groups
    path = Path(path)
    if path.exists():
        raise FileExistsError(f"{path.name} already exists; choose another company name.")
    path.parent.mkdir(parents=True, exist_ok=True)
    con = sqlite3.connect(str(path), timeout=5, isolation_level=None)
    try:
        con.execute("BEGIN IMMEDIATE")
        _apply(con, _statements(CORE_DDL) + bp_statements())
        now = datetime.now().isoformat(timespec="seconds")
        from services.reports import financial_year_start
        books_from = profile.get("books_from") or financial_year_start(datetime.now().date()).isoformat()
        con.execute("INSERT INTO bp_company (id, name, state_code, gstin, pan, cin, address, invoice_prefix, books_from, "
                    "created_at, updated_at) VALUES (1, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                    (profile["name"], profile["state_code"], profile.get("gstin", ""), profile.get("pan", ""),
                     profile.get("cin", ""), profile.get("address", ""), profile["invoice_prefix"], books_from, now, now))
        con.execute("COMMIT")
    except BaseException:
        if con.in_transaction:
            con.execute("ROLLBACK")
        con.close()
        path.unlink(missing_ok=True)
        raise
    con.close()
    seed_account_groups(path)
    audit.install(path)
    return path
