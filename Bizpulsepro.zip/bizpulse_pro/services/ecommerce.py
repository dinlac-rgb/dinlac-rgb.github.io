"""
E-commerce Orders (O: Import › E-commerce Orders): marketplace / web-shop order CSVs into Sales
vouchers, in two steps so nothing is written until you have seen it.

    plan = read_orders(csv_path, db_path, ...)     READ ONLY: parse, match SKUs, work out GST
    result = post(plan, store)                     WRITES: one Sales voucher per invoice, in order

The file: comma, semicolon or tab separated, a header row in the first 20 lines. Headings are
recognised in any capitals (see the *_HEADS lists): order id, order date, SKU, quantity, and
either a line amount or a unit price; optional ship-to state, GST rate, HSN, buyer name,
buyer GSTIN and marketplace / channel.

Rules, row by row
    SKU            must match a product_sku in inventory_stock_registry (capitals and spaces
                   ignored). No match: the row is an error and is not posted.
    GST rate, HSN  from the row; else from the Stock Item whose name or alias is the SKU, through
                   its GST Classification. Neither: error (no rate is ever assumed).
    State          ship-to state (a 2-digit code or a state name) is the place of supply. Equal to
                   COMPANY_STATE_CODE (19, West Bengal): CGST + SGST; any other state: IGST.
                   Missing or unknown: error.
    Price          ECOM_PRICES_INCLUDE_GST: taxable = amount × 100 / (100 + rate), else the
                   amount is the taxable value. Paise left over go to ECOM_ROUND_OFF_LEDGER.

Orders and invoices: rows with the same order id make one order. An order whose rows have
different rates, HSN codes or ship-to states becomes one invoice per combination (the GST
register keeps one rate and HSN per invoice). Each invoice is an Item Invoice Sales voucher:

    Dr ECOM_PARTY_LEDGER      amount the marketplace collected
    Cr Sales                  taxable value          items: SKU, quantity, rate
    Cr Output CGST / SGST / IGST
    Dr/Cr Round Off           (only when paise are left)
    details: Party A/c, Marketplace Order, Import File, Buyer      status: Regular

Held back, with the reason shown: orders already imported (the same Marketplace Order on a
voucher that is not cancelled), and orders that would take a SKU's stock below zero
(ECOM_ALLOW_NEGATIVE_STOCK = False). Posting saves each invoice through VoucherStore.save, so
the invoice number, gst_sales_ledger row, stock change, balances and audit-trail entry happen
exactly as for a voucher typed by hand, each in its own transaction. Run it again after a
failure: what was posted is recognised and skipped.
"""
from __future__ import annotations

import csv
import io
import re
import sqlite3
from dataclasses import dataclass, field
from datetime import date, datetime
from decimal import ROUND_HALF_UP, Decimal, InvalidOperation
from pathlib import Path

from services.gst import STATE_CODE_OF, STATE_NAMES, check_gstin, check_hsn, tax_for

CENT = Decimal("0.01")
ORDER_FIELD = "Marketplace Order"
ORDER_HEADS = ("order id", "order no", "order number", "orderid", "order_id", "invoice no", "invoice number")
DATE_HEADS = ("order date", "invoice date", "date", "purchase date", "order_date", "created at")
SKU_HEADS = ("sku", "seller sku", "product sku", "item sku", "sku code", "msku", "sku id")
QTY_HEADS = ("quantity", "qty", "item quantity", "units")
AMOUNT_HEADS = ("item total", "line total", "total", "amount", "invoice amount", "item amount", "order total")
UNIT_HEADS = ("unit price", "item price", "selling price", "price", "rate")
STATE_HEADS = ("ship to state", "shipping state", "ship state", "delivery state", "state", "place of supply",
               "customer state", "buyer state")
RATE_HEADS = ("gst rate", "tax rate", "gst %", "gst", "tax %")
HSN_HEADS = ("hsn", "hsn code", "hsn/sac", "hsn sac", "sac")
NAME_HEADS = ("buyer name", "customer name", "customer", "ship to name", "name")
GSTIN_HEADS = ("buyer gstin", "customer gstin", "gstin")
CHANNEL_HEADS = ("marketplace", "channel", "platform", "sales channel")
DATE_FORMATS = ("%d-%m-%Y", "%d/%m/%Y", "%Y-%m-%d", "%d-%b-%Y", "%d %b %Y", "%d/%m/%y", "%d-%m-%y", "%d.%m.%Y",
                "%b %d, %Y")


class EcomError(Exception):
    """A message about the whole file; nothing was read or written."""


@dataclass
class OrderLine:
    row: int
    sku: str
    qty: int
    amount: Decimal               # as in the file (GST-inclusive or not, per the setting)
    taxable: Decimal = CENT * 0


@dataclass
class Invoice:
    order_id: str
    date: date
    pos: str
    rate: Decimal
    hsn: str
    buyer: str
    gstin: str
    channel: str
    lines: list[OrderLine] = field(default_factory=list)
    status: str = "Ready"          # Ready | Already imported | Short stock | Posted | Failed
    note: str = ""
    voucher: dict | None = None

    @property
    def taxable(self) -> Decimal:
        return sum((ln.taxable for ln in self.lines), Decimal("0.00"))

    @property
    def collected(self) -> Decimal:
        return sum((ln.amount for ln in self.lines), Decimal("0.00"))


@dataclass
class ImportPlan:
    file: str
    invoices: list[Invoice]
    errors: list[str]                 # rows that cannot be posted, with the reason
    rows: int
    inclusive: bool = True            # file amounts include GST

    @property
    def ready(self) -> list[Invoice]:
        return [i for i in self.invoices if i.status == "Ready"]


@dataclass
class PostResult:
    posted: list[tuple[Invoice, str]] = field(default_factory=list)       # (invoice, invoice number)
    failed: list[tuple[Invoice, str]] = field(default_factory=list)


# ---- reading the file -----------------------------------------------------------------------
def _norm(text: str) -> str:
    return re.sub(r"\s+", " ", re.sub(r"[_\-]+", " ", str(text or ""))).strip().lower()


def _find(header: list[str], heads: tuple[str, ...]) -> int | None:
    names = [_norm(h) for h in header]
    for h in heads:
        if h in names:
            return names.index(h)
    return None


def _money(text: str) -> Decimal:
    raw = re.sub(r"(?i)rs\.?|inr|₹|,|\s", "", str(text or ""))
    try:
        value = Decimal(raw)
    except InvalidOperation:
        raise ValueError(f"'{text}' is not an amount") from None
    if not value.is_finite() or value < 0:
        raise ValueError(f"'{text}' is not an amount")
    return value.quantize(CENT, rounding=ROUND_HALF_UP)


def _date(text: str) -> date:
    raw = str(text or "").strip()
    if re.match(r"^\d{4}-\d\d-\d\d[ T]", raw):
        raw = raw[:10]
    for fmt in DATE_FORMATS:
        try:
            return datetime.strptime(raw, fmt).date()
        except ValueError:
            continue
    raise ValueError(f"'{text}' is not a date")


def _state(text: str) -> str:
    raw = str(text or "").strip()
    if raw.isdigit() and raw.zfill(2) in STATE_NAMES:
        return raw.zfill(2)
    code = STATE_CODE_OF.get(_norm(raw).replace(" and ", " & "))
    if code is None:
        raise ValueError(f"ship-to state '{text}' is not a GST state code or name" if raw else "no ship-to state")
    return code


def _rate(text: str, allowed: tuple[str, ...]) -> Decimal:
    raw = str(text or "").replace("%", "").strip()
    value = Decimal(raw) if re.fullmatch(r"\d+(\.\d+)?", raw) else None
    if value is None or f"{value.normalize():f}" not in allowed:
        raise ValueError(f"GST rate '{text}' is not one of {', '.join(allowed)}")
    return value


def _rows(path: Path) -> list[list[str]]:
    raw = Path(path).read_bytes()
    for enc in ("utf-8-sig", "cp1252"):
        try:
            text = raw.decode(enc)
            break
        except UnicodeDecodeError:
            continue
    else:
        raise EcomError("The file is not a text (CSV) file.")
    sample = text[:4096]
    try:
        dialect = csv.Sniffer().sniff(sample, delimiters=",;\t")
    except csv.Error:
        dialect = csv.excel
    return [r for r in csv.reader(io.StringIO(text), dialect)]


def _registry(con: sqlite3.Connection) -> dict[str, tuple[str, int]]:
    try:
        return {str(s).strip().lower(): (str(s), int(q or 0))
                for s, q in con.execute("SELECT product_sku, qty_on_hand FROM inventory_stock_registry")}
    except sqlite3.Error:
        raise EcomError("inventory_stock_registry was not found: SKUs cannot be matched.") from None


def _item_tax(con: sqlite3.Connection) -> dict[str, tuple[str, str]]:
    """Stock Item name / alias (lower) -> (GST rate text, HSN) from its GST Classification."""
    tables = {r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type = 'table'")}
    if not {"bp_stock_items", "bp_gst_classifications"} <= tables:
        return {}
    out = {}
    for name, alias, rate, hsn in con.execute(
            "SELECT i.name, i.alias, c.gst_rate, c.hsn_sac FROM bp_stock_items i JOIN bp_gst_classifications c "
            "ON lower(c.name) = lower(i.gst_classification) WHERE i.gst_applicable = 'Yes'"):
        for key in (name, alias):
            if key:
                out[str(key).strip().lower()] = (str(rate), str(hsn))
    return out


def _imported(con: sqlite3.Connection) -> set[str]:
    tables = {r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type = 'table'")}
    if not {"bp_voucher_details", "bp_vouchers"} <= tables:
        return set()
    status = any(r[1] == "status" for r in con.execute("PRAGMA table_info(bp_vouchers)"))
    live = " AND coalesce(v.status, 'Regular') != 'Cancelled'" if status else ""
    return {str(v) for (v,) in con.execute(
        "SELECT d.value FROM bp_voucher_details d JOIN bp_vouchers v ON v.id = d.voucher_id "
        f"WHERE d.field = ?{live}", (ORDER_FIELD,))}


def read_orders(path: Path, db_path: Path, *, company_state: str, gst_rates: tuple[str, ...],
                prices_include_gst: bool = True, allow_negative_stock: bool = False) -> ImportPlan:
    rows = _rows(Path(path))
    header_at = next((i for i, r in enumerate(rows[:20]) if _find(r, SKU_HEADS) is not None
                      and _find(r, ORDER_HEADS) is not None), None)
    if header_at is None:
        raise EcomError("No header row with an order id and a SKU column was found in the first 20 lines.")
    header = rows[header_at]
    col = {k: _find(header, heads) for k, heads in (
        ("order", ORDER_HEADS), ("date", DATE_HEADS), ("sku", SKU_HEADS), ("qty", QTY_HEADS),
        ("amount", AMOUNT_HEADS), ("unit", UNIT_HEADS), ("state", STATE_HEADS), ("rate", RATE_HEADS),
        ("hsn", HSN_HEADS), ("name", NAME_HEADS), ("gstin", GSTIN_HEADS), ("channel", CHANNEL_HEADS))}
    missing = [n for n, k in (("order date", "date"), ("quantity", "qty")) if col[k] is None]
    if col["amount"] is None and col["unit"] is None:
        missing.append("amount or unit price")
    if missing:
        raise EcomError(f"The file has no {', '.join(missing)} column.")

    con = sqlite3.connect(Path(db_path).resolve().as_uri() + "?mode=ro", uri=True, timeout=5)
    try:
        registry, item_tax, done = _registry(con), _item_tax(con), _imported(con)
    finally:
        con.close()

    errors: list[str] = []
    groups: dict[tuple, Invoice] = {}
    count = 0
    for n, r in enumerate(rows[header_at + 1:], start=header_at + 2):
        if not any(c.strip() for c in r):
            continue
        count += 1
        cell = lambda k: (r[col[k]].strip() if col[k] is not None and col[k] < len(r) else "")  # noqa: E731
        try:
            order_id = cell("order")
            if not order_id:
                raise ValueError("no order id")
            sku_text = cell("sku")
            match = registry.get(sku_text.lower())
            if match is None:
                raise ValueError(f"SKU '{sku_text}' is not a product_sku in inventory_stock_registry")
            qty_text = cell("qty").replace(",", "")
            if not qty_text.isdigit() or int(qty_text) <= 0:
                raise ValueError(f"quantity '{cell('qty')}' is not a whole number above 0")
            qty = int(qty_text)
            amount = _money(cell("amount")) if col["amount"] is not None else (_money(cell("unit")) * qty).quantize(CENT)
            if not amount:
                raise ValueError("amount is 0")
            master = item_tax.get(sku_text.lower(), ("", ""))
            if not (cell("rate") or master[0]):
                raise ValueError("no GST rate (in the file or on the Stock Item's GST Classification)")
            rate = _rate(cell("rate") or master[0], gst_rates)
            hsn_text = cell("hsn") or master[1]
            if not hsn_text:
                raise ValueError("no HSN code (in the file or on the Stock Item's GST Classification)")
            hsn = check_hsn(hsn_text)
            pos = _state(cell("state"))
            gstin = check_gstin(cell("gstin"))
            d = _date(cell("date"))
        except ValueError as exc:
            errors.append(f"Row {n}: {str(exc).rstrip('.')}.")
            continue
        taxable = (amount * 100 / (100 + rate)).quantize(CENT, rounding=ROUND_HALF_UP) if prices_include_gst else amount
        key = (order_id, rate, hsn, pos)
        inv = groups.get(key)
        if inv is None:
            inv = groups[key] = Invoice(order_id, d, pos, rate, hsn, cell("name"), gstin, cell("channel"))
        inv.date = min(inv.date, d)
        inv.lines.append(OrderLine(n, match[0], qty, amount, taxable))

    invoices = sorted(groups.values(), key=lambda i: (i.date, i.order_id, str(i.rate), i.hsn))
    stock = {k: q for k, (_s, q) in registry.items()}
    for inv in invoices:
        if inv.order_id in done:
            inv.status, inv.note = "Already imported", f"order {inv.order_id} is already on a voucher"
            continue
        need: dict[str, int] = {}
        for ln in inv.lines:
            need[ln.sku.lower()] = need.get(ln.sku.lower(), 0) + ln.qty
        short = [f"{sku}: {stock[sku]} on hand, {q} needed" for sku, q in need.items() if stock[sku] - q < 0]
        if short and not allow_negative_stock:
            inv.status, inv.note = "Short stock", "; ".join(short)
            continue
        for sku, q in need.items():
            stock[sku] -= q
    return ImportPlan(Path(path).name, invoices, errors, count, prices_include_gst)


# ---- building and posting the vouchers ---------------------------------------------------------
def build_voucher(inv: Invoice, *, file: str, company_state: str, party_ledger: str, sales_ledger: str,
                  tax_ledgers: dict[str, str], round_off_ledger: str, round_off_limit: Decimal,
                  inclusive: bool = True) -> dict:
    taxable = inv.taxable
    tax = tax_for(taxable, inv.rate, inv.pos, company_state)
    value = taxable + tax["cgst"] + tax["sgst"] + tax["igst"]
    collected = inv.collected if inclusive else value        # what the marketplace collects from the buyer
    diff = collected - value                         # + : Cr Round Off, - : Dr Round Off
    if abs(diff) > round_off_limit:
        raise ValueError(f"amounts differ from taxable + GST by {diff} (more than the round-off limit)")
    lines = [{"side": "Dr", "ledger": party_ledger, "amount": collected},
             {"side": "Cr", "ledger": sales_ledger, "amount": taxable}]
    lines += [{"side": "Cr", "ledger": tax_ledgers[k], "amount": tax[k]} for k in ("cgst", "sgst", "igst") if tax[k]]
    if diff:
        lines.append({"side": "Cr" if diff > 0 else "Dr", "ledger": round_off_ledger, "amount": abs(diff)})
    items = [{"item": ln.sku, "quantity": ln.qty, "rate": (ln.taxable / ln.qty).quantize(CENT, rounding=ROUND_HALF_UP),
              "per": "Nos", "amount": ln.taxable} for ln in inv.lines]
    details = {"Party A/c": party_ledger, ORDER_FIELD: inv.order_id, "Import File": file}
    if inv.buyer:
        details["Buyer"] = inv.buyer
    channel = f"{inv.channel} " if inv.channel else ""
    return {"type": "Sales", "date": inv.date, "lines": lines, "items": items, "details": details, "status": "Regular",
            "narration": f"{channel}order {inv.order_id} (imported from {file})",
            "total": sum((ln["amount"] for ln in lines if ln["side"] == "Dr"), Decimal("0")),
            "entered_at": datetime.now(),
            "gst": {"customer": inv.buyer or party_ledger, "gstin": inv.gstin, "place_of_supply": inv.pos,
                    "hsn": inv.hsn, "rate": inv.rate, "taxable": taxable, **tax, "invoice_value": value}}


def post(plan: ImportPlan, store, **build) -> PostResult:
    """Background thread: saves each Ready invoice in date order through store.save (one
    transaction each). A failure is noted and the rest carry on."""
    from services.voucher_store import StoreError
    result = PostResult()
    for inv in plan.ready:
        try:
            inv.voucher = build_voucher(inv, file=plan.file, inclusive=plan.inclusive, **build)
            saved = store.save(inv.voucher)
        except (StoreError, ValueError) as exc:
            inv.status, inv.note = "Failed", str(exc)
            result.failed.append((inv, str(exc)))
            continue
        inv.status, inv.note = "Posted", saved.invoice_no or str(saved.number)
        result.posted.append((inv, saved.invoice_no or str(saved.number)))
    return result
