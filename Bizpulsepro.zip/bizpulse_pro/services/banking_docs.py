"""
The Banking menu's lists, read from the saved vouchers (read only).

    activities(db_path)          Banking Activities: each bank ledger's entries to today, money in / out,
                                 balance, and how many are matched to a statement
    bank_payments(db_path)       Payments out of a bank ledger (Cheque Printing, Payment Advice)
    cheque_register(db_path)     Payments and Receipts that carry Cheque Details (Ctrl+I › Q)
    deposit_batches(db_path)     Receipts into a bank by cheque, grouped by bank and date (Deposit Slip)
    post_dated(db_path)          vouchers marked Post-Dated and not yet due

Cheque numbers, dates, drawee bank and "favouring" come from the voucher's Cheque Details card
(stored as details "Cheque · Cheque No." etc.). A voucher without that card is not a cheque as
far as BizPulse knows: it is left out of the register and the deposit slip, and a printed cheque
for it uses the payee ledger's name.
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import date
from decimal import Decimal
from pathlib import Path

from services.bank_reco import BANK_GROUPS, bank_book, bank_ledgers
from services.voucher_store import VoucherStore

CHQ = "Cheque · "


@dataclass
class Activity:
    ledger: str
    entries: int
    money_in: Decimal
    money_out: Decimal
    balance: Decimal
    matched: int


def _live(db_path: Path) -> list[dict]:
    return [v for v in VoucherStore(Path(db_path), "").load_all(limit=100000) if v["status"] not in ("Optional", "Cancelled")]


def _banks(db_path: Path) -> set[str]:
    return {b.strip().lower() for b in bank_ledgers(db_path)}


def activities(db_path: Path) -> list[Activity]:
    out = []
    for ledger in bank_ledgers(db_path):
        book = [e for e in bank_book(db_path, ledger) if e.date <= date.today()]   # post-dated: not yet in the bank
        out.append(Activity(ledger, len(book), sum((e.amount for e in book if e.amount > 0), Decimal("0")),
                            -sum((e.amount for e in book if e.amount < 0), Decimal("0")),
                            sum((e.amount for e in book), Decimal("0")), sum(1 for e in book if e.matched)))
    return out


def _cheque(v: dict) -> dict:
    d = v.get("details") or {}
    return {"no": d.get(CHQ + "Cheque No.", ""), "date": d.get(CHQ + "Cheque Date", ""),
            "bank": d.get(CHQ + "Bank Name", ""), "favouring": d.get(CHQ + "Favouring", "")}


def bank_payments(db_path: Path) -> list[dict]:
    banks = _banks(db_path)
    rows = []
    for v in _live(db_path):
        if v["type"] != "Payment":
            continue
        bank = next((ln["ledger"] for ln in v["lines"] if ln["side"] == "Cr" and ln["ledger"].strip().lower() in banks), None)
        if bank is None:
            continue
        payee = next((ln["ledger"] for ln in v["lines"] if ln["side"] == "Dr"), "")
        chq = _cheque(v)
        rows.append({"id": v["id"], "date": v["date"], "number": v["number"], "bank": bank,
                     "payee": chq["favouring"] or payee, "amount": v["total"], "cheque": chq, "voucher": v})
    return rows


def cheque_register(db_path: Path) -> list[dict]:
    rows = []
    for v in _live(db_path):
        chq = _cheque(v)
        if v["type"] not in ("Payment", "Receipt") or not chq["no"]:
            continue
        other = next((ln["ledger"] for ln in v["lines"] if ln["side"] == ("Dr" if v["type"] == "Payment" else "Cr")), "")
        rows.append({"id": v["id"], "date": v["date"], "type": v["type"], "number": v["number"], "cheque_no": chq["no"],
                     "cheque_date": chq["date"], "bank": chq["bank"], "party": chq["favouring"] or other,
                     "amount": v["total"], "status": v["status"]})
    return rows


def deposit_batches(db_path: Path) -> list[dict]:
    """One row per (bank, date) of Receipts by cheque into that bank."""
    banks = _banks(db_path)
    batches: dict[tuple[str, date], dict] = {}
    for v in _live(db_path):
        chq = _cheque(v)
        if v["type"] != "Receipt" or not chq["no"]:
            continue
        bank = next((ln["ledger"] for ln in v["lines"] if ln["side"] == "Dr" and ln["ledger"].strip().lower() in banks), None)
        if bank is None:
            continue
        frm = next((ln["ledger"] for ln in v["lines"] if ln["side"] == "Cr"), "")
        b = batches.setdefault((bank, v["date"]), {"bank": bank, "date": v["date"], "rows": []})
        b["rows"].append({"cheque_no": chq["no"], "cheque_date": chq["date"], "drawn_on": chq["bank"], "from": frm,
                          "amount": v["total"]})
    return sorted(batches.values(), key=lambda b: (b["date"], b["bank"]), reverse=True)


def post_dated(db_path: Path) -> list[dict]:
    rows = []
    for v in VoucherStore(Path(db_path), "").load_all(limit=100000):
        if v["status"] != "Post-Dated":
            continue
        first = v["lines"][0] if v["lines"] else {"ledger": ""}
        rows.append({"id": v["id"], "date": v["date"], "type": v["type"], "number": v["number"],
                     "party": first["ledger"], "amount": v["total"], "cheque_no": _cheque(v)["no"],
                     "days": (v["date"] - date.today()).days})
    return sorted(rows, key=lambda r: r["date"])


__all__ = ["BANK_GROUPS", "Activity", "activities", "bank_payments", "cheque_register", "deposit_batches", "post_dated"]
