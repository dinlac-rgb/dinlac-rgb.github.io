"""
Foreign-currency vouchers: the rules, kept apart from the screen so they can be tested.

A voucher has ONE currency. Its lines are typed in that currency; on Accept every line is
converted to rupees at the voucher's rate (₹ per 1 unit) and the RUPEE amounts are what
bp_voucher_lines holds, so every report, the GST registers and the balances stay in INR.
The foreign amounts and the rate are kept beside them in bp_voucher_forex (one row per line),
so the voucher reopens exactly as typed.

    split_designator("USD 1,200") -> ("USD", "1,200")      "$1200" -> ("USD", "1200")
    parse_rate("83.25")           -> Decimal("83.25")       (ValueError if not a usable rate)
    to_base(Decimal("10.01"), Decimal("83.25")) -> Decimal("833.33")
    convert_lines(lines, rate)    -> (rupee lines, foreign amounts, note)

Rounding: each line is rounded to paise (half up). If that leaves the rupee debits and credits
a few paise apart, the difference goes on the largest line of the short side and the note says
so; nothing is ever saved unbalanced.
"""
from __future__ import annotations

import re
from decimal import ROUND_HALF_UP, Decimal, InvalidOperation

BASE = "INR"
CENT = Decimal("0.01")
MAX_RATE = Decimal("100000")
RATE_PLACES = 6
SYMBOLS = {"$": "USD", "€": "EUR", "£": "GBP", "¥": "JPY", "₹": BASE}
_CODE = re.compile(r"[A-Za-z]{3}")


def normal_code(text: str) -> str:
    """'usd' -> 'USD', '$' -> 'USD', '' -> 'INR'. ValueError for anything else."""
    raw = text.strip()
    if not raw:
        return BASE
    if raw in SYMBOLS:
        return SYMBOLS[raw]
    if _CODE.fullmatch(raw):
        return raw.upper()
    raise ValueError(f"'{raw}' is not a currency code (three letters, e.g. USD, EUR)")


def split_designator(text: str) -> tuple[str | None, str]:
    """A currency in front of or after an amount: 'USD 1,200', '1200 eur', '$1,200'.
    Returns (code or None, the amount text without it)."""
    raw = text.strip()
    if raw[:1] in SYMBOLS:
        return SYMBOLS[raw[:1]], raw[1:].strip()
    m = re.fullmatch(r"([A-Za-z]{3})\s*([0-9.,]+)", raw) or re.fullmatch(r"([0-9.,]+)\s*([A-Za-z]{3})", raw)
    if not m:
        return None, raw
    code, amount = (m.group(1), m.group(2)) if m.group(1)[0].isalpha() else (m.group(2), m.group(1))
    return code.upper(), amount


def parse_rate(text: str) -> Decimal:
    raw = text.replace(",", "").replace("₹", "").strip()
    try:
        rate = Decimal(raw)
    except InvalidOperation:
        raise ValueError(f"'{text}' is not a rate") from None
    if not rate.is_finite() or rate <= 0 or rate >= MAX_RATE:
        raise ValueError("The rate must be above 0 (rupees for 1 unit of the currency)")
    if rate != rate.quantize(Decimal(1).scaleb(-RATE_PLACES)):
        raise ValueError(f"The rate can have at most {RATE_PLACES} decimal places")
    return rate


def rate_text(rate: Decimal) -> str:
    """Decimal('83.250000') -> '83.25'; Decimal('83') -> '83.00'."""
    s = f"{rate.normalize():f}"
    whole, _, frac = s.partition(".")
    return f"{whole}.{(frac or '').ljust(2, '0')}"


def to_base(amount: Decimal, rate: Decimal) -> Decimal:
    return (amount * rate).quantize(CENT, rounding=ROUND_HALF_UP)


def convert_lines(lines: list[dict], rate: Decimal) -> tuple[list[dict], list[Decimal], str]:
    """Lines in the foreign currency (balanced) -> the same lines in rupees (balanced)."""
    foreign = [ln["amount"] for ln in lines]
    out = [dict(ln, amount=to_base(ln["amount"], rate)) for ln in lines]
    debit = sum((ln["amount"] for ln in out if ln["side"] == "Dr"), Decimal("0"))
    credit = sum((ln["amount"] for ln in out if ln["side"] == "Cr"), Decimal("0"))
    note = ""
    if debit != credit:
        short = "Cr" if debit > credit else "Dr"
        idx = max((i for i, ln in enumerate(out) if ln["side"] == short), key=lambda i: out[i]["amount"])
        diff = abs(debit - credit)
        out[idx] = dict(out[idx], amount=out[idx]["amount"] + diff)
        note = f"Rounding ₹{diff} added to {out[idx]['ledger']} so the rupee debits and credits agree."
    return out, foreign, note
