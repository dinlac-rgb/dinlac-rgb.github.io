# BizPulse Pro

Desktop GST accounting for Indian businesses, by Srijee Creations. One window: a white working
canvas, the **CORRIDOR TO BIZPULSE** menu in its centre, Tally-style keys throughout, Segoe UI
11 pt normal with bold shortcut letters.

## Run it

1. Python 3.12 or newer, with Tkinter (the python.org Windows installer includes it). Tested on 3.12.
   Nothing else to install: see `requirements.txt`.
2. Put the `bizpulse_pro` folder anywhere you can write to (BizPulse keeps its database, backups,
   exports and prints inside it).
3. Start it: `python main.py`, or double-click `start_bizpulse.bat` on Windows.

The first start with no company file opens **Company › Create Company**: name, GST state code
(19 = West Bengal), GSTIN, invoice prefix (SRJ → SRJ/26-27/0001). BizPulse then creates
`bizpulse_local.db` with every table it uses. An existing `bizpulse_local.db` (with your
`gst_sales_ledger`, `inventory_stock_registry` and `corporate_ledger_summary`) is used as it is:
BizPulse adds only its own `bp_*` tables, never changes yours, and makes a safety copy before
its one-time upgrade of `gst_sales_ledger`.

## Folder map

```
bizpulse_pro/
├── main.py                      the window: layout, menus, key routing (run this)
├── README.md                    this file
├── requirements.txt             nothing to install: Python's standard library only
├── start_bizpulse.bat           Windows: double-click to start without a console window
├── config/                      settings, colours and fonts, ledger groups, stock valuation
│   ├── ledger_groups.py         Which group each ledger belongs to — this is what puts a ledger on the Balance Sheet …
│   ├── settings.py              BizPulse Pro — application settings: menus, script mappings, file names, timeouts
│   ├── stock_valuation.py       Stock in the books — opening stock per financial year, and how closing stock is valued
│   └── theme.py                 BizPulse Pro — colours, fonts and ttk styles
├── components/                  widgets shared by many screens
│   ├── allocation_box.py        Cost Centre Allocation — the inline box that slides out under an expense or purchase …
│   ├── banking_view.py          Banking - List of Actions (N - Banking, under Utilities on the gateway)
│   ├── column_chart.py          Small column chart drawn on a Tk Canvas (no extra libraries), used by the Dashboard
│   ├── currency_box.py          The inline exchange-rate box of the voucher screen. It opens just under the Currency …
│   ├── details_card.py          A centred white details card on the voucher screen — Dispatch Details, Order Details
│   ├── display_more_reports.py  Display More Reports (M, under Reports on the Corridor) — centred light-blue box
│   ├── gateway_menu.py          CORRIDOR TO BIZPULSE — the light-blue gateway box, sitting in the middle of the …
│   ├── header_menus.py          Header bar with Tally-style dropdown menus (K: Company, Y: Data, Z: Exchange, O: Import
│   ├── ledger_list.py           "List of Ledger Accounts" — the white panel on the right of the voucher screen
│   ├── macro_bar.py             Right-hand action bar — the thin light-blue strip down the far right edge of the window
│   ├── pointer_guard.py         The mouse-highlight guard shared by every menu box (Corridor, List of Masters, …
│   ├── subsystem_monitor.py     Subsystem Monitor — now a one-line status bar along the bottom of the window, plus …
│   └── voucher_drawer.py        Voucher Entry Utilities — the drawer that slides out over the left of the voucher screen
├── services/                    data and rules: no Tk here, everything testable
│   ├── analytics.py             Figures for the Dashboard and Ratio Analysis, worked out from the saved vouchers
│   ├── audit.py                 The audit trail: bp_system_audit_logs, an append-only, hash-chained record of every …
│   ├── background.py            Run slow work off the UI thread and get the result back on it
│   ├── bank_reco.py             Bank reconciliation helper: your bank book (vouchers on a bank ledger) against a …
│   ├── banking_docs.py          The Banking menu's lists, read from the saved vouchers (read only)
│   ├── company.py               The company profile: name, GST state, GSTIN, PAN, CIN, address and invoice series, …
│   ├── comparative.py           Comparative columns for the Profit & Loss A/c and the Balance Sheet (C on either screen)
│   ├── cost_centres.py          Cost centres: splitting a voucher line across departments, projects or branches
│   ├── csv_import.py            Import › Masters and Import › Vouchers CSV: read a CSV, show what will happen, then post
│   ├── data_tools.py            Data, Export and Exchange tools that work on the whole company file
│   ├── ecommerce.py             E-commerce Orders (O: Import › E-commerce Orders): marketplace / web-shop order CSVs …
│   ├── extra_reports.py         Display More Reports: HSN/SAC Summary, Movement Analysis and the GSTR-3B summary …
│   ├── forex.py                 Foreign-currency vouchers: the rules, kept apart from the screen so they can be tested
│   ├── group_seeder.py          Puts the 28 reserved groups (15 primary + 13 sub-groups) into the company database's
│   ├── gst.py                   GST helpers for Sales vouchers: GSTIN check, HSN/SAC check, tax split and invoice …
│   ├── gst_check.py             Offline structure checks for a GSTIN and an HSN/SAC code — what can be known WITHOUT the
│   ├── gstr1.py                 GSTR-1 for one month, from gst_sales_ledger (joined to the Sales vouchers for dates …
│   ├── inventory_masters.py     Inventory masters (Masters › Create / Alter): Stock Groups, Units of Measure, Stock …
│   ├── ledgers.py               The ledger names offered in the voucher screen's "List of Ledger Accounts" panel
│   ├── masters.py               Masters created in BizPulse Pro (Masters › Create / Alter): Groups, Ledgers, GST …
│   ├── migrations.py            One-time database upgrades for bizpulse_local.db, run in a background thread at start-up
│   ├── preferences.py           Saving the Settings screen's choices into config/settings.py, so they survive a restart
│   ├── printing.py              Printable documents: BizPulse writes a self-contained HTML page and opens it in the …
│   ├── reports.py               Balance Sheet and Profit & Loss A/c figures, worked out from the vouchers saved in
│   ├── runner.py                Background script runner and the read-only database check
│   ├── schema.py                Every table BizPulse Pro uses, created in one place
│   ├── stock.py                 Stock Summary figures: quantities from inventory_stock_registry, rates from
│   ├── updates.py               [U] Upgrade (Alt+U): the statutory software-update check. BizPulse asks your update …
│   ├── voucher_book.py          Reading one voucher back, altering it, and the ledger statement that drill-down needs
│   └── voucher_store.py         Saving accepted vouchers into bizpulse_local.db
├── views/                       the screens drawn on the white canvas
│   ├── activity_log_view.py     Session Messages (Help › Session Messages, F1 then M) — every status message of this …
│   ├── audit_trail_view.py      Audit Trail (Help › Activity Log, F1 then G; or L on the Corridor) — the compliance …
│   ├── balance_sheet_view.py    Balance Sheet (B, under Reports) — full-width, split down the middle
│   ├── bank_reco_view.py        Banking › Imported Bank Data — the bank reconciliation helper, side by side on the …
│   ├── company_view.py          Company › Create Company / Alter Company (also Masters › GST Registration, Company …
│   ├── comparative_view.py      Comparative Profit & Loss A/c / Balance Sheet — the same group rows, one column per …
│   ├── cost_centre_view.py      Cost Centre Summary (Display More Reports › C) — what each department, project or …
│   ├── dashboard_grid_view.py   Dashboard (Alt+D, or [D] Dashboard in the header) — analytics board filling the …
│   ├── daybook_view.py          Day Book — full-width transaction table drawn over the workspace
│   ├── ecommerce_view.py        O: Import › E-commerce Orders — preview a marketplace order file, then post it
│   ├── gstr1_view.py            GSTR-1 (Display More Reports › GSTR-1, or Export › GST Returns JSON)
│   ├── ledger_statement_view.py Ledger Statement (Tally's Ledger Vouchers) — one ledger's vouchers for the financial …
│   ├── list_screen.py           A full-canvas list screen many BizPulse screens share: title bar, a line under it, a …
│   ├── master_form.py           Master creation / alteration forms on the white canvas (Masters › Create / Alter)
│   ├── masters_overlay.py       List of Masters — the light-blue box drawn over the workspace for Create, Alter and
│   ├── print_setup_view.py      Print › Configuration Setup — how printed invoices look (Print › Current Invoice)
│   ├── profit_loss_view.py      Profit & Loss A/c (P, under Reports) — full-width, one row per heading
│   ├── ratio_analysis_view.py   Ratio Analysis (R, under Reports) — two columns on the white canvas
│   ├── report_common.py         Shared pieces for the report screens (Balance Sheet, Profit & Loss A/c)
│   ├── settings_view.py         [S] Settings (Alt+S) — the preferences grid on the white canvas
│   ├── stock_summary_view.py    Stock Summary (S, under Reports) — full-width table on the white canvas
│   ├── tool_screens.py          The list screens behind the Data, Import, Banking, Display More Reports and Masters …
│   ├── trial_balance_view.py    Trial Balance — every ledger's closing balance, Debit | Credit, grouped by primary group
│   ├── tutorial_content.py      The text of [T] Tutorial (views/tutorial_view.py), kept apart so it is easy to correct
│   ├── tutorial_view.py         [T] Tutorial (Alt+T) — the step-by-step operating guide, a vertical scrolling board …
│   ├── update_view.py           [U] Upgrade (Alt+U) — Software Update on the white canvas
│   └── vouchers_view.py         Accounting Voucher Creation — full-width entry screen on the white canvas, in two modes
└── tests/                       16 test files (unittest; GUI tests need a display)
```

Created while BizPulse runs (not shipped): `bizpulse_local.db` (and other company files under
`companies/`), `backups/` (Data › Backup), `exports/` (GSTR-1 JSON, ledger CSV, final accounts,
client packs), `prints/` (invoices, cheques, payment advices, deposit slips: HTML, print with
Ctrl+P), and `*.pre-upgrade-*.db` safety copies.

## Where things are

| Menu | What it does |
|---|---|
| Corridor | Masters (Create, Alter, Chart of Accounts), Vouchers, Day Book, Banking, Audit Trail, Balance Sheet, P&L, Stock Summary, Ratio Analysis, Display More Reports |
| Alt+K Company | Create, Alter, Select (one database file per company), Shut |
| Alt+Y Data | Backup (checked copy), Restore (safety copy first), Split Company Data (guide) |
| Alt+Z Exchange | Client Share Pack (ZIP for your CA), Synchronize (guide) |
| Alt+O Import | Masters (ledger CSV), Vouchers CSV, Bank Statement, E-commerce Orders |
| Alt+E Export | Current Ledger (CSV), Final Accounts (HTML), GST Returns JSON (GSTR-1) |
| Alt+P Print | Current Invoice, Configuration Setup (paper, HSN column, footer) |
| F1 Help | About, Licence, Troubleshooting, Activity Log (audit trail), Session Messages |
| Alt+S / T / U / D | Settings, Tutorial, Software Update, Dashboard |
| F3 / F4 (Corridor) | Select Company, Go To (every screen by name) |
| F12 (any screen) | The right-hand action bar takes the keyboard: Up / Down move, Enter runs the button, Esc / F12 go back to your field |
| Esc | Leaves the open screen (in master forms from any field, asking once if something is typed); in vouchers it steps back one field |

Data, Export and Print options that name one of your own scripts (`backup_engine.py`,
`db_migration_utility.py`, `csv_balance_exporter.py`, `profit_loss_statement.py`,
`thermal_invoice_formatter.py`) run that script when it is beside `main.py`; otherwise
BizPulse's built-in version runs, so no option points at a missing file.

## Configuration

`config/settings.py`. The block between `# >>> BIZPULSE PREFERENCES` and
`# <<< BIZPULSE PREFERENCES` is written by Settings (Alt+S) and Print › Configuration Setup;
edit the rest by hand. To fill in before going live:

- `UPDATE_FEED_URL`: the https address of your update feed (Alt+U). Blank means no check is made,
  and the screen says so.
- `B2CL_LIMIT`, `GSTR1_JSON_VERSION`: check against the current GST offline tool.
- `INPUT_TAX_LEDGERS`: the ledgers GSTR-3B reads input tax credit from.
- `CHEQUE_LAYOUT`: millimetre positions for your bank's cheque leaf.
- `COST_CENTRES`, `ECOM_*`: cost centres offered, and e-commerce import rules.

## Tests

```
cd bizpulse_pro
python -m unittest discover -s tests -v
```

GUI tests need a display; on a server use `xvfb-run -a python -m unittest discover -s tests`.

## Honest limits

- GSTR-1 JSON and the GSTR-3B summary are for checking before filing: validate the JSON in the
  GST offline tool, and file 3B on the portal (it applies the set-off order). Input tax credit
  is only what you post to the Input tax ledgers.
- The audit trail is append-only and hash-chained. Someone with direct access to the database file
  could still rewrite it: note the chain head (Audit Trail › V) at each period close.
- The licence number shown is a placeholder; no licence is verified.
- Synchronize and Split Company Data are guides, not automatic actions (they need a server, and
  a reviewed year-end plan, respectively). F2 Period explains how each report's period works.
