"""
BizPulse Pro — main window. Run:  python main.py

Window geometry (Tally profile):

    +------------------------------------------------------------------------------------+
    | BIZPULSE PRO  K Y Z O E P F1 …        [S] Settings | [D] Dashboard | [T] … | [U] … |  header #0D2C54
    +-------------------------------------------------------------------+----------------+
    |                     A Srijee Creations' Creation                  |  F2: Period    |
    |                                                                   |  F3: Company   |
    |   white canvas (#FFFFFF): blank on the        +---------------+   |  F4: Go To     |
    |   Corridor; screens open here                 | CORRIDOR TO   |   |  (changes with |
    |                                               |  BIZPULSE     |   |   the screen)  |
    |                                               |  light blue   |   |                |
    |                                               +---------------+   |  licence       |
    |                                                                   |  internet      |
    +-------------------------------------------------------------------+----------------+
    | status: latest message                               F1 › M Session Messages        |
    +------------------------------------------------------------------------------------+

    The folder map, how to run it, what each file does and the data files BizPulse writes are in
    README.md beside this file (config/ settings, components/ widgets, services/ data and rules,
    views/ screens, tests/ the test suite).

    Put bizpulse_local.db, customer_credit_guard.py and the other scripts in this folder.

Who gets the keyboard (one dispatcher, _on_key):
    1. an open header dropdown        letters, arrows, Enter; Esc closes it
    2. the action bar                 its F-keys (they change with the screen)
    3. an open screen                 Esc goes straight back to the Corridor
    4. an open box (List of …)        Esc closes it and returns to the Corridor
    5. the Corridor                   letters, arrows, Enter; Esc asks "Quit?"
                                      (V opens the inline Vouchers submenu: its own letters,
                                      Enter opens that voucher type, Esc closes the submenu)
    Alt+K Y Z O E P open the header dropdowns, F1 opens Help, Alt+D opens the Dashboard.
    Alt+S Settings, Alt+T Tutorial, Alt+U software-update check (Upgrade Tier).
"""
from __future__ import annotations

import socket
from datetime import date
import sys
import threading
import tkinter as tk
from pathlib import Path
from tkinter import messagebox

# Make the package folders importable however the app is started (double-click, IDE, shell).
sys.path.insert(0, str(Path(__file__).resolve().parent))

from components.banking_view import banking_menu  # noqa: E402
from components.display_more_reports import more_reports_menu  # noqa: E402
from components.gateway_menu import GatewayMenu  # noqa: E402
from components.macro_bar import Macro, MacroBar  # noqa: E402
from components.header_menus import HeaderBar  # noqa: E402
from components.subsystem_monitor import SubsystemMonitor  # noqa: E402
from config import settings as S  # noqa: E402
from config import theme as T  # noqa: E402
from services import audit, company, cost_centres, data_tools, printing, schema  # noqa: E402
from services.preferences import PreferencesError, save_preferences  # noqa: E402
from services.background import run_in_background  # noqa: E402
from services.ledgers import load_item_catalogue, load_ledger_catalogue  # noqa: E402
from services.group_seeder import seed_account_groups  # noqa: E402
from services.inventory_masters import InventoryStore  # noqa: E402
from services.migrations import upgrade_database  # noqa: E402
from services.runner import ScriptRunner  # noqa: E402
from services.voucher_book import VoucherBook  # noqa: E402
from services.voucher_store import StoreError  # noqa: E402
from views.activity_log_view import ActivityLogView  # noqa: E402
from views.balance_sheet_view import BalanceSheetView  # noqa: E402
from views.company_view import CompanyFormView, select_company_screen  # noqa: E402
from views.cost_centre_view import CostCentreView  # noqa: E402
from views.ecommerce_view import EcommerceView  # noqa: E402
from views.update_view import UpdateView  # noqa: E402
from views.print_setup_view import PrintSetupView  # noqa: E402
from views import tool_screens as TS  # noqa: E402
from views.comparative_view import ComparativeView  # noqa: E402
from views.audit_trail_view import AuditTrailView  # noqa: E402
from views.bank_reco_view import BankRecoView  # noqa: E402
from views.dashboard_grid_view import DashboardGridView  # noqa: E402
from views.daybook_view import DaybookView  # noqa: E402
from views.gstr1_view import Gstr1View  # noqa: E402
from views.master_form import MasterFormView  # noqa: E402
from views.masters_overlay import MastersOverlay  # noqa: E402
from views.profit_loss_view import ProfitLossView  # noqa: E402
from views.ledger_statement_view import LedgerStatementView  # noqa: E402
from views.ratio_analysis_view import RatioAnalysisView  # noqa: E402
from views.trial_balance_view import TrialBalanceView  # noqa: E402
from views.stock_summary_view import StockSummaryView  # noqa: E402
from views.settings_view import SettingsView  # noqa: E402
from views.tutorial_view import TutorialView  # noqa: E402
from views.vouchers_view import VoucherView, fmt_inr  # noqa: E402


VOUCHER_TYPE_NAMES = {name for _k, name in S.VOUCHER_SUBMENU}


# Header options mapped to your own scripts. When the script is not beside main.py, BizPulse's
# own version of the job runs instead, so no menu option ever points at a missing file.
SCRIPT_BUILTINS = {"backup_engine.py": "backup_now", "db_migration_utility.py": "import_masters",
                   "csv_balance_exporter.py": "export_ledgers", "profit_loss_statement.py": "export_final_accounts",
                   "thermal_invoice_formatter.py": "print_invoice"}


class BizPulseApp(tk.Tk):
    def __init__(self) -> None:
        super().__init__()
        self.title(S.APP_TITLE)
        self.geometry(S.WINDOW_GEOMETRY)
        self.minsize(*S.MIN_SIZE)
        self.configure(bg=T.WHITE)
        T.apply_ttk_styles(self)

        self.overlay: MastersOverlay | None = None
        self.view: tk.Frame | None = None            # the screen open on the canvas, if any
        self._view_factory = None                    # rebuilds it (F5 Refresh); None = not refreshable
        self.voucher_mode = S.DEFAULT_VOUCHER_MODE   # Single / Double Entry, kept between voucher screens
        self.invoice_mode = S.DEFAULT_INVOICE_MODE   # Sales / Purchase: Item / Accounting Invoice / As Voucher
        self.db_path = S.APP_DIR / S.LOCAL_DB
        company.apply(S, company.read_profile(self.db_path))   # this company's name, GST state, invoice series
        self.store = VoucherBook(self.db_path, S.INVOICE_PREFIX)      # saves, alters, ledger statements
        self._stack: list = []                       # drill-down: screens to go back to (factories)
        self._current_factory = None
        self.masters = InventoryStore(self.db_path)      # Group, Ledger, GST Classification + inventory masters

        self._build_header()
        self.monitor = SubsystemMonitor(self)        # status line along the bottom
        self.monitor.pack(side="bottom", fill="x")
        self._build_workspace()

        self.runner = ScriptRunner(self.monitor.post, S.APP_DIR)
        self.monitor.on("done", self.runner.mark_done)
        self.monitor.on("net", self._show_net)
        self.monitor.start()

        self._bind_keys()
        self.protocol("WM_DELETE_WINDOW", self.confirm_quit)

        self.monitor.log("BizPulse Pro gateway ready.")
        self.monitor.log(self.runner.describe_local_database())
        # One-time upgrade (gst_sales_ledger: igst_rate, place_of_supply; safety copy first).
        threading.Thread(target=self._upgrade_worker, daemon=True).start()
        self._run_credit_guard()
        self._schedule_net_check()
        self._refresh_macros()
        self.after(300, self._first_boot_check)
        self.after(100, self.focus_gateway)

    # ------------------------------------------------------------------------------------
    # Header bar (45 px) and tagline
    # ------------------------------------------------------------------------------------
    def _build_header(self) -> None:
        self.header = HeaderBar(self, left=S.HEADER_LEFT, right=S.HEADER_RIGHT, menus=S.HEADER_MENUS,
                                on_choose=self.run_header_action, on_plain=self.header_action,
                                on_closed=self._after_dropdown)
        self.header.pack(side="top", fill="x")

    def _after_dropdown(self, previous_focus: tk.Widget | None) -> None:
        """A dropdown closed: back to the gateway, or to the screen that was open underneath."""
        if self.view is None and self.overlay is None:
            self.focus_gateway()
        elif previous_focus is not None and previous_focus.winfo_exists():
            previous_focus.focus_set()

    # ------------------------------------------------------------------------------------
    # Workspace: white canvas (left, fills) | action bar (far right)
    # ------------------------------------------------------------------------------------
    def _build_workspace(self) -> None:
        body = tk.Frame(self, bg=T.WHITE)
        body.pack(side="top", fill="both", expand=True)

        self.macro_bar = MacroBar(body)
        self.macro_bar.pack(side="right", fill="y")
        self.macro_bar.status_block("License Verification Number", S.LICENCE_DISPLAY)
        self._net_value = self.macro_bar.status_block("Internet", "CHECKING…")

        # The canvas: blank white; screens are placed over all of it.
        self.canvas = tk.Frame(body, bg=T.WHITE)
        self.canvas.pack(side="left", fill="both", expand=True)

        # Corridor layer: maker's line at the top (Corridor only) and the gateway box.
        tag = tk.Frame(self.canvas, bg=T.WHITE)
        tk.Label(tag, text="A Srijee Creations' Creation", bg=T.WHITE, fg=T.SLATE, font=T.F_TAG_UP).pack()
        tk.Label(tag, text="Fitness, Accuracy, Trust and Low Pricing", bg=T.WHITE, fg=T.SLATE_LIGHT,
                 font=T.F_TAG_LOW).pack()
        tag.place(in_=self.canvas, relx=GatewayMenu.CENTRE_X, y=10, anchor="n")
        self.gateway = GatewayMenu(self.canvas, S.GATEWAY_SECTIONS, on_select=self.on_gateway_select,
                                   submenus=S.GATEWAY_SUBMENUS, on_change=self._refresh_macros)
        self.gateway.show()

    # ---- the action bar follows whatever is on screen ----------------------------------
    def _refresh_macros(self) -> None:
        active = None
        if self.view is not None:
            macros = list(self.view.macros()) if hasattr(self.view, "macros") else []
            if self._view_factory is not None:
                macros.append(Macro.fkey("F5", "Refresh", self._refresh_view))
            macros.append(Macro("Esc", "Back", self._back_from_view))
            active = self.view.active_macro() if hasattr(self.view, "active_macro") else None
        elif self.overlay is not None:
            macros = [Macro("Esc", "Close", self.close_overlay)]
        elif self.gateway.expanded == "Vouchers":
            # The Vouchers submenu is open: every voucher key, Credit and Debit Note included, opens
            # that voucher straight away.
            macros = [Macro.fkey(key, name, lambda n=name: self.open_vouchers(n))
                      for key, name in S.VOUCHER_TYPES + S.NOTE_VOUCHER_TYPES]
            macros.append(Macro("Esc", "Close list", self.gateway.collapse))
        else:
            macros = [Macro.fkey(key, label, lambda l=label: self.macro_action(l)) for key, label in S.GATEWAY_MACROS]
            macros.append(Macro("Alt+D", "Dashboard", self.open_dashboard))
        self.macro_bar.set(macros, active)

    # ------------------------------------------------------------------------------------
    # Keyboard routing
    # ------------------------------------------------------------------------------------
    def _bind_keys(self) -> None:
        self.bind("<KeyPress>", self._on_key)
        # Header dropdowns on Alt+letter (Tally convention), so they never clash with menu letters.
        for key, label in S.HEADER_LEFT + S.HEADER_RIGHT:
            if not key.startswith("F"):
                for k in (key.lower(), key.upper()):
                    self.bind(f"<Alt-KeyPress-{k}>", lambda _e, l=label: self._alt_header(l))
        # A click anywhere outside an open dropdown closes it (runs after the clicked widget's own handler).
        self.bind("<Button-1>", self._click_away, add="+")

    def _alt_header(self, label: str) -> str:
        if self.header.has_menu(label):
            self.header.toggle_menu(label)
        else:
            self.header_action(label)
        return "break"

    def _click_away(self, event: tk.Event) -> None:
        if self.header.is_open and not self.header.contains(event.widget):
            self.header.close_menu()

    def _on_key(self, event: tk.Event) -> str | None:
        if self.header.is_open:
            if self.macro_bar.keyboard:
                self._leave_action_bar(restore=False)
            return self.header.handle_key(event)
        plain = not event.state & (T.MOD_CTRL | T.MOD_ALT)
        if self.macro_bar.keyboard:                      # F12: the action bar has the keys
            return self._action_bar_key(event)
        if event.keysym == "F12" and plain:
            self.open_action_bar()
            return "break"
        if event.keysym == "F1" and not event.state & (T.MOD_CTRL | T.MOD_ALT):
            self.header.open_menu("Help")
            return "break"
        if self.macro_bar.handle_key(event):             # F-keys of the current screen
            return "break"
        if self.view is not None:
            return self.view.handle_key(event)          # type: ignore[attr-defined]
        if self.overlay is not None:
            return self.overlay.handle_key(event)
        if event.state & (T.MOD_CTRL | T.MOD_ALT):
            return None
        if event.keysym == "Escape" and not self.gateway.expanded:
            self.confirm_quit()                          # Esc in the Vouchers submenu only closes it
            return "break"
        return self.gateway.handle_key(event)

    # ---- the action bar from the keyboard (F12) ------------------------------------------------
    def open_action_bar(self) -> None:
        """F12: Up / Down move through the right-hand buttons, Enter runs one, Esc / F12 come back."""
        self._bar_return = self.focus_get()
        if self.macro_bar.enter_keyboard():
            self.monitor.log("[Action bar] Up / Down choose a button, Enter runs it, Esc or F12 goes back.")

    def _leave_action_bar(self, restore: bool = True) -> None:
        self.macro_bar.leave_keyboard()
        back = getattr(self, "_bar_return", None)
        self._bar_return = None
        if not restore:
            return
        if back is not None and back.winfo_exists() and back.winfo_ismapped():
            back.focus_set()
        elif self.view is not None:
            self.view.focus_first()                      # type: ignore[attr-defined]
        else:
            self._refocus()

    def _action_bar_key(self, event: tk.Event) -> str:
        key = event.keysym
        if key in ("Up", "Down"):
            self.macro_bar.move(-1 if key == "Up" else 1)
        elif key in ("Return", "KP_Enter", "space"):
            macro = self.macro_bar.current()
            self._leave_action_bar(restore=True)         # the cursor goes back first, then the button runs
            if macro is not None:
                macro.command()
        elif key in ("Escape", "F12", "Tab", "ISO_Left_Tab"):
            self._leave_action_bar(restore=True)
        elif key.startswith("F") and key[1:].isdigit() or event.state & T.MOD_CTRL:
            self._leave_action_bar(restore=True)         # a button's own key (F5, Ctrl+F8 …) still works
            self.macro_bar.handle_key(event)
        return "break"                                   # nothing else reaches the fields meanwhile

    def focus_gateway(self) -> None:
        self.gateway.set_hover_enabled(True)
        self.gateway.focus_menu()

    # ------------------------------------------------------------------------------------
    # Gateway actions
    # ------------------------------------------------------------------------------------
    def on_gateway_select(self, label: str) -> None:
        self.close_overlay(refocus=False)
        if label == "Quit":
            self.confirm_quit()
        elif label in S.MASTER_MENU_ITEMS:
            self.open_overlay(label)
        elif label in VOUCHER_TYPE_NAMES:               # from the Vouchers submenu
            self.open_vouchers(label)
        elif label == "Vouchers":
            self.open_vouchers()
        elif label == "Banking":
            self.open_banking()
        elif label == "Display More Reports":
            self.open_more_reports()
        elif label in self._screens():
            self._screens()[label]()
        elif label in S.GATEWAY_SCRIPTS:
            self.run_gateway_script(label, S.GATEWAY_SCRIPTS[label])
        else:
            self.monitor.log(f"[{label}] nothing is assigned yet.")
        if self.view is None and self.overlay is None:
            self.focus_gateway()

    def _screens(self) -> dict:
        """Screens that open on the canvas, by the name used on the menus."""
        return {
            "Day Book": self.open_daybook,
            "Trial Balance": self.open_trial_balance,
            "Ledger Statement": self.open_ledger_statement,
            "Balance Sheet": lambda: self._show_view(lambda: BalanceSheetView(
                self.canvas, db_path=self.db_path, company=S.COMPANY_NAME, on_close=self.close_view,
                on_compare=lambda: self.open_comparative("bs"))),
            "Profit & Loss A/c": lambda: self._show_view(lambda: ProfitLossView(
                self.canvas, db_path=self.db_path, company=S.COMPANY_NAME, on_close=self.close_view,
                on_compare=lambda: self.open_comparative("pl"))),
            "GSTR-1": self.open_gstr1,
            "Stock Summary": lambda: self._show_view(lambda: StockSummaryView(
                self.canvas, db_path=self.db_path, company=S.COMPANY_NAME, on_close=self.close_view,
                rate_column=S.STOCK_RATE_COLUMN)),
            "Ratio Analysis": lambda: self._show_view(lambda: RatioAnalysisView(
                self.canvas, db_path=self.db_path, company=S.COMPANY_NAME, on_close=self.close_view)),
            "Dashboard": self.open_dashboard,
            "Cost Centre Summary": lambda: self._show_view(lambda: CostCentreView(
                self.canvas, db_path=self.db_path, company=S.COMPANY_NAME, on_close=self.close_view)),
            "HSN/SAC Summary": lambda: self._show_view(lambda: TS.hsn_screen(
                self.canvas, db_path=self.db_path, company_state=S.COMPANY_STATE_CODE, on_close=self.close_view)),
            "Movement Analysis": lambda: self._show_view(lambda: TS.movement_screen(
                self.canvas, db_path=self.db_path, on_close=self.close_view)),
            "GSTR-3B Return": lambda: self._show_view(lambda: TS.gstr3b_screen(
                self.canvas, db_path=self.db_path, company_state=S.COMPANY_STATE_CODE,
                input_ledgers=S.INPUT_TAX_LEDGERS, on_close=self.close_view)),
            "Audit Trail": self.open_audit_trail,
            "Settings": self.open_settings,
            "Tutorial": self.open_tutorial,
            "Software Update": self.open_update,
            "Vouchers": self.open_vouchers,
            "Banking": self.open_banking,
        }

    def open_dashboard(self) -> None:
        self._show_view(lambda: DashboardGridView(self.canvas, db_path=self.db_path, company=S.COMPANY_NAME,
                                                  on_close=self.close_view))

    def open_comparative(self, kind: str) -> None:
        """C on the Balance Sheet / P&L: the same rows, one column per period. Esc comes back."""
        self._show_view(lambda: ComparativeView(self.canvas, db_path=self.db_path, kind=kind,
                                                company=S.COMPANY_NAME, on_close=self.close_view),
                        refreshable=False, push=True)

    def open_gstr1(self, _title: str = "") -> None:
        """Export › GST Returns JSON: build GSTR-1 for a month and write the JSON file."""
        self.close_overlay(refocus=False)
        self._show_view(lambda: Gstr1View(self.canvas, db_path=self.db_path, export_dir=S.EXPORT_DIR,
                                          gstin=S.COMPANY_GSTIN, company_state=S.COMPANY_STATE_CODE,
                                          b2cl_limit=S.B2CL_LIMIT, version=S.GSTR1_JSON_VERSION,
                                          on_close=self.close_view, on_note=self.monitor.log),
                        refreshable=False)

    # ---- [U] software update, e-commerce import, cost centres -------------------------------
    def open_update(self) -> None:
        """Alt+U: ask the update server what is newer than this copy. Esc returns to the Corridor."""
        self._show_view(lambda: UpdateView(self.canvas, feed_url=S.UPDATE_FEED_URL, installed=S.INSTALLED_VERSIONS,
                                           on_close=self.close_view, on_note=self.monitor.log), refreshable=False)

    def open_ecommerce(self, _title: str = "") -> None:
        """O: Import › E-commerce Orders."""
        self._show_view(lambda: EcommerceView(self.canvas, db_path=self.db_path, store=self.store, settings=S,
                                              on_close=self.close_view, on_note=self.monitor.log), refreshable=False)

    def _cost_ledgers(self) -> set[str]:
        """Background thread (voucher screen): ledgers that offer the Cost Centre Allocation box."""
        if not self.db_path.is_file():
            return set()
        return cost_centres.cost_ledgers(self.db_path, S.COST_CENTRE_GROUPS)

    def _centre_names(self) -> list[str]:
        return cost_centres.known_centres(self.db_path, S.COST_CENTRES) if self.db_path.is_file() else list(S.COST_CENTRES)

    # ---- Company: create, alter, select ------------------------------------------------------
    def _first_boot_check(self) -> None:
        """No company database yet: open Company Creation for it straight away."""
        if not self.db_path.is_file() and self.view is None:
            self.monitor.log(f"No company yet: {self.db_path.name} was not found. Create the company to begin.")
            self.create_company(first=True)

    def create_company(self, _title: str = "", first: bool | None = None) -> None:
        first = (not self.db_path.is_file()) if first is None else first
        target = self.db_path if first else S.APP_DIR / company.new_file_name(S.APP_DIR, "company")
        note = (f"Welcome. There is no company yet, so BizPulse will create {self.db_path.name} with every table it "
                "needs. Enter your company's details." if first else
                "A new company gets its own database file in the companies folder; your current company is not "
                "touched.")
        defaults = {"state_code": S.COMPANY_STATE_CODE, "invoice_prefix": S.INVOICE_PREFIX} if first else \
            {"state_code": S.COMPANY_STATE_CODE, "invoice_prefix": "INV"}

        def save(values, done, failed):
            path = target if first else S.APP_DIR / company.new_file_name(S.APP_DIR, values["name"])
            run_in_background(self, lambda: schema.create_company_file(path, values),
                              lambda p: self._company_created(p, values, first, done),
                              lambda exc: failed(f"Not created: {exc}"))

        self._show_view(lambda: CompanyFormView(self.canvas, mode="create", values=defaults, on_close=self.close_view,
                                                on_save=save, note=note), refreshable=False)

    def _company_created(self, path: Path, values: dict, first: bool, done) -> None:
        self.monitor.log(f"[Company] '{values['name']}' created in {path.relative_to(S.APP_DIR).as_posix()}.")
        if first:
            company.apply(S, values)
            self.store.invoice_prefix = values["invoice_prefix"]
            done(f"Created. {values['name']} is open: press Esc for the Corridor.")
            threading.Thread(target=self._upgrade_worker, daemon=True).start()
            return
        done(f"Created in {path.relative_to(S.APP_DIR).as_posix()}.")
        if messagebox.askyesno("Open the new company?", f"Open '{values['name']}' now? BizPulse restarts with it.",
                               parent=self):
            self._switch_company(path.relative_to(S.APP_DIR).as_posix())

    def alter_company(self, _title: str = "", focus: str = "name") -> None:
        if not self.db_path.is_file():
            self.create_company(first=True)
            return

        def save(values, done, failed):
            run_in_background(self, lambda: company.save_profile(self.db_path, values),
                              lambda v: self._company_altered(v, done), lambda exc: failed(str(exc)))

        values = company.current(self.db_path, S)
        note = ("Saved inside this company's database. A new state code changes the GST split (CGST + SGST or "
                "IGST) of vouchers entered from now on; a new prefix starts a new invoice series.")
        self._show_view(lambda: CompanyFormView(self.canvas, mode="alter", values=values, on_close=self.close_view,
                                                on_save=save, note=note, focus=focus), refreshable=False)

    def _company_altered(self, values: dict, done) -> None:
        company.apply(S, values)
        self.store.invoice_prefix = values["invoice_prefix"]
        done("Saved. The new details are in use now.")
        self.monitor.log(f"[Company] Details of '{values['name']}' saved (state {values['state_code']}, "
                         f"GSTIN {values['gstin'] or 'not entered'}, invoice prefix {values['invoice_prefix']}).")

    def select_company(self, _title: str = "") -> None:
        self._show_view(lambda: select_company_screen(self.canvas, app_dir=S.APP_DIR, main_file=S.MAIN_DB,
                                                      active=S.LOCAL_DB, on_choose=self._company_chosen,
                                                      on_close=self.close_view), refreshable=False)

    def _company_chosen(self, rel: str) -> None:
        if rel == S.LOCAL_DB:
            self.monitor.log("[Company] That company is already open.")
            return
        if messagebox.askyesno("Open company?", f"Open {rel}? BizPulse restarts with it.", parent=self):
            self._switch_company(rel)

    def _switch_company(self, rel: str) -> None:
        try:
            save_preferences({"COMPANY_FILE": rel})
        except PreferencesError as exc:
            self.monitor.log(f"[Company] {exc}")
            return
        self.restart_app(confirm=False)

    def open_audit_trail(self, _title: str = "") -> None:
        """Help › Activity Log (F1, G) or L on the Corridor: the audit trail sheet. Esc returns to the Corridor."""
        self._show_view(lambda: AuditTrailView(self.canvas, db_path=self.db_path, on_close=self.close_view))

    def open_activity_log(self, _title: str = "") -> None:
        self._show_view(lambda: ActivityLogView(self.canvas, monitor=self.monitor, on_close=self.close_view),
                        refreshable=False)

    # ---- header dropdown options ---------------------------------------------------------
    def run_header_action(self, menu: str, option: str, action: tuple[str, str]) -> None:
        """An option was chosen in a header dropdown. Slow work goes to background threads."""
        kind, arg = action
        title = f"{menu} › {option}"
        if kind == "script":
            builtin = SCRIPT_BUILTINS.get(arg)
            if builtin and not (S.APP_DIR / arg).is_file():
                getattr(self, builtin)(title)               # no broken link: BizPulse's own version runs
            else:
                self.run_gateway_script(title, arg)
        elif kind == "todo":
            self.monitor.log(f"[{title}] {arg}")
        elif kind == "app":
            handler = {
                "about": self._about,
                "licence": self._licence_info,
                "troubleshoot": self._troubleshoot,
                "shut_company": self._shut_company,
                "activity_log": self.open_activity_log,
                "audit_trail": self.open_audit_trail,
                "ecommerce": self.open_ecommerce,
                "create_company": self.create_company,
                "alter_company": self.alter_company,
                "select_company": self.select_company,
                "gstr1": self.open_gstr1,
                "restore": self.open_restore,
                "client_pack": self.client_pack,
                "import_vouchers": self.import_vouchers,
                "bank_statement": self.open_bank_statement,
                "print_setup": self.print_setup,
            }.get(arg)
            if handler is None:
                self.monitor.log(f"[{title}] nothing is assigned yet.")
            else:
                handler(title)

    def _about(self, title: str) -> None:
        messagebox.showinfo(
            "About BizPulse Pro",
            f"{S.APP_TITLE} {S.APP_VERSION}\nA Srijee Creations' Creation\n\n"
            f"Licence number shown: {S.LICENCE_DISPLAY}\n"
            f"Database: {S.APP_DIR / S.LOCAL_DB}\n\nSupport: {S.SUPPORT_CONTACT}",
            parent=self,
        )
        self._refocus()

    def _licence_info(self, title: str) -> None:
        # Honest status: this desktop app has no licence check yet, so nothing is "verified".
        self.monitor.log(f"[{title}] {S.LICENCE_DISPLAY} is a display placeholder. BizPulse Pro does not "
                         "verify licences yet, so no signature was checked.")
        messagebox.showinfo(
            "Licence Activation",
            f"Licence shown: {S.LICENCE_DISPLAY}\n\nThis version does not verify licences yet: the number "
            "above is shown for reference only and no signature was checked.",
            parent=self,
        )
        self._refocus()

    def _troubleshoot(self, title: str) -> None:
        """Database and internet checks, both in background threads; results arrive in the monitor."""
        self.monitor.log(f"[{title}] {self.runner.describe_local_database()}")
        self.runner.check_database(title)
        self.monitor.log(f"[{title}] checking the internet connection …")
        threading.Thread(target=self._net_worker, args=(title,), daemon=True).start()

    def _shut_company(self, title: str) -> None:
        """BizPulse holds no database connection open between saves, so 'shutting' means: close the
        open screen, and make sure no script is still writing."""
        if self.runner.running:
            self.monitor.log(f"[{title}] wait: still running {', '.join(sorted(self.runner.running))}.")
            return
        if self.view is not None:
            self.view.request_close() if hasattr(self.view, "request_close") else self.close_view()  # type: ignore[attr-defined]
            if self.view is not None:          # the user chose to keep an unsaved voucher
                self.monitor.log(f"[{title}] cancelled: the open voucher was kept.")
                return
        self.close_overlay()
        self.monitor.log(f"[{title}] no screen or script is using {S.LOCAL_DB}; it is safe to copy or back up.")

    def _refocus(self) -> None:
        if self.view is None and self.overlay is None:
            self.focus_gateway()

    def run_gateway_script(self, label: str, script: str) -> None:
        warning = S.CONFIRM_BEFORE_RUN.get(script)
        if warning and (S.APP_DIR / script).is_file() and script not in self.runner.running:
            ok = messagebox.askyesno(label, f"{warning}\n\nRun {script} now?", default="no", parent=self)
            self._refocus()
            if not ok:
                self.monitor.log(f"[{label}] cancelled.")
                return
        self.runner.run_script(script, title=label)

    # ---- List of Masters box -----------------------------------------------------------
    def open_overlay(self, mode: str) -> None:
        self.close_overlay(refocus=False)
        self.gateway.set_hover_enabled(False)
        self.overlay = MastersOverlay(self.canvas, mode, on_choose=self._on_master_chosen,
                                      on_close=self.close_overlay)
        self._show_overlay()
        self.monitor.log(f"[{mode}] {'Chart of Accounts' if mode == 'Chart of Accounts' else 'List of Masters'} opened.")

    def open_banking(self) -> None:
        self.close_overlay(refocus=False)
        self.gateway.set_hover_enabled(False)
        self.overlay = banking_menu(self.canvas, on_choose=self._on_banking_chosen, on_close=self.close_overlay)
        self._show_overlay()
        self.monitor.log("[Banking] List of Actions opened.")

    def open_more_reports(self) -> None:
        self.close_overlay(refocus=False)
        self.gateway.set_hover_enabled(False)
        self.overlay = more_reports_menu(self.canvas, on_choose=self._on_report_chosen, on_close=self.close_overlay)
        self._show_overlay()

    def _on_report_chosen(self, _mode: str, report: str) -> None:
        self.close_overlay()
        if report in S.MORE_REPORTS_NOT_BUILT:
            self.monitor.log(f"[Display More Reports › {report}] {S.MORE_REPORTS_NOT_BUILT[report]}")
        elif report in self._screens():
            self._screens()[report]()
        else:
            self.monitor.log(f"[Display More Reports › {report}] nothing is assigned yet.")

    def _on_banking_chosen(self, _mode: str, action: str) -> None:
        if action == "Imported Bank Data":
            self.close_overlay(refocus=False)
            self._show_view(lambda: BankRecoView(self.canvas, db_path=self.db_path, on_close=self.close_view,
                                                 on_note=self.monitor.log), refreshable=False)
            return
        routes = {
            "Banking Activities": lambda: TS.bank_activities_screen(
                self.canvas, db_path=self.db_path, on_close=self.close_view,
                on_open_ledger=lambda name: self.open_ledger_statement(name, push=True)),
            "Cheque Printing": lambda: TS.bank_payments_screen(
                self.canvas, db_path=self.db_path, title="Cheque Printing", action="Print cheque",
                on_close=self.close_view, on_print=self._print_cheque),
            "Payment Advice": lambda: TS.bank_payments_screen(
                self.canvas, db_path=self.db_path, title="Payment Advice", action="Print advice",
                on_close=self.close_view, on_print=self._print_advice),
            "Cheque Register": lambda: TS.cheque_register_screen(self.canvas, db_path=self.db_path,
                                                                 on_close=self.close_view),
            "Deposit Slip": lambda: TS.deposit_slip_screen(self.canvas, db_path=self.db_path, on_close=self.close_view,
                                                           on_print=self._print_deposit_slip),
            "Post-dated Summary": lambda: TS.post_dated_screen(self.canvas, db_path=self.db_path,
                                                               on_close=self.close_view,
                                                               on_open=self.open_voucher_alteration),
        }
        if action in routes:
            self.close_overlay(refocus=False)
            self._show_view(routes[action])
            return
        self.close_overlay()
        self.monitor.log(f"[Banking › {action}] {S.BANKING_NOT_BUILT.get(action, 'nothing is assigned yet.')}")

    def _show_overlay(self) -> None:
        """A centred pop-up box takes the Corridor's place until Esc (the Corridor box is hidden
        meanwhile, so the two boxes never overlap)."""
        self.gateway.place_forget()
        self.overlay.show()                              # type: ignore[union-attr]
        self._refresh_macros()

    def close_overlay(self, refocus: bool = True) -> None:
        if self.overlay is not None:
            self.overlay.destroy()
            self.overlay = None
            self.gateway.show()
            self._refresh_macros()
        if refocus:
            self.focus_gateway()

    def _on_master_chosen(self, mode: str, master: str) -> None:
        """Masters with a form open it on the canvas (Chart of Accounts opens the Alter form);
        Voucher Type lists the fixed types; GST Registration, Company GST Details and PAN/CIN open
        Company › Alter at that field."""
        self.close_overlay(refocus=False)
        title = f"{mode} › {master}"
        if master in S.MASTER_FORMS:
            alter = mode != "Create"
            self._show_view(lambda: MasterFormView(self.canvas, kind=master, alter=alter, store=self.masters,
                                                   on_close=self.close_view, on_saved=self._master_saved,
                                                   on_note=self.monitor.log),
                            refreshable=False)
            return
        if master == "Voucher Type":
            self._show_view(lambda: TS.voucher_types_screen(self.canvas, voucher_keys=S.VOUCHER_TYPES + S.NOTE_VOUCHER_TYPES,
                                                            on_close=self.close_view), refreshable=False)
            return
        company_field = {"GST Registration": "gstin", "Company GST Details": "gstin", "PAN/CIN Details": "pan"}
        if master in company_field:                      # the company's own details live in Company › Alter
            self.alter_company(title, focus=company_field[master])
            return
        self.monitor.log(f"[{title}] {S.MASTER_NOT_BUILT.get(master, 'screen not built yet.')}")
        self.focus_gateway()

    def _master_saved(self, message: str) -> None:
        self.monitor.log(f"[Masters] {message}")

    # ---- full-width screens ------------------------------------------------------------
    def _show_view(self, factory, refreshable: bool = True, push: bool = False) -> bool:
        """Open a screen over the whole canvas. factory() builds it (and rebuilds it for F5).
        An open voucher with typed entries asks first; False = the user kept it.
        push=True (drill-down): the screen underneath is remembered, and Esc / close returns to
        it, rebuilt so it shows any change just made."""
        if self.view is not None and hasattr(self.view, "can_close") and not self.view.can_close():
            return False
        if push and self.view is not None and self._current_factory is not None:
            self._stack.append(self._current_factory)
        elif not push:
            self._stack.clear()
        self.close_view(refocus=False)
        self.close_overlay(refocus=False)
        if self.header.is_open:
            self.header.close_menu(restore_focus=False)
        self.gateway.set_hover_enabled(False)
        view = factory()
        self.view = view
        self._current_factory = factory
        self._view_factory = factory if refreshable else None
        if hasattr(view, "on_macros_changed"):
            view.on_macros_changed = self._refresh_macros
        view.place(in_=self.canvas, relx=0, rely=0, relwidth=1, relheight=1)
        view.lift()
        self._refresh_macros()
        view.focus_first()                               # type: ignore[attr-defined]
        return True

    def _refresh_view(self) -> None:
        """F5: rebuild the screen in place (the drill-down path behind it is kept)."""
        if self._view_factory is not None and self.view is not None:
            factory = self._view_factory
            self.view.destroy()
            self.view = None
            self._reopen(factory)

    def _back_from_view(self) -> None:
        if self.view is not None and hasattr(self.view, "request_close"):
            self.view.request_close()                    # asks first if a voucher has typed entries
        else:
            self.close_view()

    def close_view(self, refocus: bool = True) -> None:
        """Esc from any screen: back to the screen it was opened from (drill-down), otherwise
        clear the canvas and give the Corridor the keyboard."""
        if refocus and self._stack and self.view is not None:
            previous = self._stack.pop()
            self.view.destroy()
            self.view = None
            self._current_factory = None
            self._reopen(previous)
            return
        if self.view is not None:
            if isinstance(self.view, VoucherView) and self.view.existing is None:
                self.voucher_mode = self.view.mode
                self.invoice_mode = self.view.invoice_mode
            self.view.destroy()
            self.view = None
            self._view_factory = None
            self._current_factory = None
            self._refresh_macros()
        if refocus:
            self._stack.clear()
            self.focus_gateway()

    def _reopen(self, factory) -> None:
        """Rebuild a screen from the drill-down stack without disturbing the rest of the stack."""
        view = factory()
        self.view = view
        self._current_factory = factory
        self._view_factory = factory
        if hasattr(view, "on_macros_changed"):
            view.on_macros_changed = self._refresh_macros
        view.place(in_=self.canvas, relx=0, rely=0, relwidth=1, relheight=1)
        view.lift()
        self._refresh_macros()
        view.focus_first()

    # ---- drill-down: Trial Balance -> Ledger Statement -> voucher --------------------------------
    def open_trial_balance(self) -> None:
        self._show_view(lambda: TrialBalanceView(self.canvas, db_path=self.db_path, company=S.COMPANY_NAME,
                                                 on_close=self.close_view,
                                                 on_open_ledger=lambda name: self.open_ledger_statement(name, True)))

    def open_ledger_statement(self, ledger: str = "", push: bool = False) -> None:
        self._show_view(lambda: LedgerStatementView(
            self.canvas, statement_source=lambda name: self.store.ledger_statement(name, date.today()),
            on_close=self.close_view, on_open_voucher=self.open_voucher_alteration, ledger=ledger,
            ledger_source=lambda: load_ledger_catalogue(self.db_path), on_duplicate=self.duplicate_voucher,
            on_cancel=self.cancel_voucher), push=push)

    def open_voucher_alteration(self, voucher_id: int) -> None:
        """Enter / double-click on a voucher in a report: it opens in Accounting Voucher Alteration
        (read in the background); Esc goes back to the report."""
        def opened(data) -> None:
            if data is None:
                self.monitor.log("[Drill-down] that voucher no longer exists.")
                return
            self._show_view(lambda: VoucherView(
                self.canvas, voucher_type=data["type"], number_for=self.store.next_number,
                on_accept=lambda v, done: self._on_voucher_altered(voucher_id, v, done), on_close=self.close_view,
                invoice_for=self._safe_invoice_no, ledger_source=lambda: load_ledger_catalogue(self.db_path),
                item_source=lambda: load_item_catalogue(self.db_path), autofill_source=self.store.last_voucher_for,
                unused_source=self.store.unused_numbers, existing=data, rate_source=self.store.last_rate,
                cost_source=self._cost_ledgers, centre_source=self._centre_names,
                currency_source=self.masters.currency_list,
                on_duplicate=lambda: self.duplicate_voucher(voucher_id),
                on_cancel_voucher=lambda: self.cancel_voucher(voucher_id)), refreshable=False, push=True)

        run_in_background(self, lambda: self.store.load_voucher(voucher_id), opened,
                          lambda exc: self.monitor.log(f"[Drill-down] could not open the voucher: {exc}"))

    def _on_voucher_altered(self, voucher_id: int, voucher: dict, done) -> None:
        title = f"[Vouchers] {voucher['type']}"
        self.monitor.log(f"{title} saving the alteration …")

        def saved(result) -> None:
            self.monitor.log(f"{title} No. {result.invoice_no or result.number} altered: ₹{fmt_inr(voucher['total'])}.")
            for change in result.account_updates + result.stock_updates:
                self.monitor.log(f"{title} No. {result.number} {change}")
            done(True)
            self.close_view()                            # back to the report, refreshed

        run_in_background(self, lambda: self.store.alter(voucher_id, voucher), saved,
                          lambda exc: self._voucher_failed(title, exc, done))

    def open_vouchers(self, voucher_type: str = S.DEFAULT_VOUCHER_TYPE) -> None:
        self._show_view(lambda: VoucherView(self.canvas, voucher_type=voucher_type, number_for=self.store.next_number,
                                            on_accept=self._on_voucher_accepted, on_close=self.close_view,
                                            invoice_for=self._safe_invoice_no, mode=self.voucher_mode,
                                            invoice_mode=self.invoice_mode,
                                            ledger_source=lambda: load_ledger_catalogue(self.db_path),
                                            item_source=lambda: load_item_catalogue(self.db_path),
                                            autofill_source=self.store.last_voucher_for,
                                            unused_source=self.store.unused_numbers,
                                            rate_source=self.store.last_rate,
                cost_source=self._cost_ledgers, centre_source=self._centre_names,
                currency_source=self.masters.currency_list),
                        refreshable=False)

    def open_daybook(self) -> None:
        def build() -> DaybookView:
            try:
                vouchers = self.store.load_all()
            except StoreError as exc:
                self.monitor.log(f"[Day Book] {exc}")
                vouchers = []
            return DaybookView(self.canvas, vouchers, on_close=self.close_view, on_open=self.open_voucher_alteration,
                               on_duplicate=self.duplicate_voucher, on_cancel=self.cancel_voucher)
        self._show_view(build)

    # ---- Alt+2 duplicate, Alt+X cancel (Day Book, Ledger Statement, Voucher Alteration) -------
    def duplicate_voucher(self, voucher_id: int) -> None:
        """Alt+2: a new voucher pre-filled from a saved one, under the next number. Esc (or saving
        it) comes back to the list it was started from."""
        def opened(data) -> None:
            if data is None:
                self.monitor.log("[Duplicate] that voucher no longer exists.")
                return
            factory = lambda: VoucherView(  # noqa: E731
                self.canvas, voucher_type=data["type"], number_for=self.store.next_number,
                on_accept=self._on_voucher_accepted, on_close=self.close_view, invoice_for=self._safe_invoice_no,
                ledger_source=lambda: load_ledger_catalogue(self.db_path),
                item_source=lambda: load_item_catalogue(self.db_path), autofill_source=self.store.last_voucher_for,
                unused_source=self.store.unused_numbers, rate_source=self.store.last_rate,
                cost_source=self._cost_ledgers, centre_source=self._centre_names,
                currency_source=self.masters.currency_list, template=data)
            altering = isinstance(self.view, VoucherView) and self.view.existing is not None
            kept = self._current_factory
            if altering:
                self._current_factory = None     # the duplicate takes the alteration's place in the path
            if not self._show_view(factory, refreshable=False, push=True) and altering:
                self._current_factory = kept
                return
            self.monitor.log(f"[Duplicate] {data['type']} No. {data['invoice_no'] or data['number']} copied as "
                             f"new {data['type']} No. {self.store.next_number(data['type'])}: Ctrl+A saves it.")

        run_in_background(self, lambda: self.store.load_voucher(voucher_id), opened,
                          lambda exc: self.monitor.log(f"[Duplicate] could not read the voucher: {exc}"))

    def cancel_voucher(self, voucher_id: int) -> None:
        """Alt+X: asks, then marks the voucher Cancelled (number kept, amounts out of the books)."""
        def opened(data) -> None:
            if data is None:
                self.monitor.log("[Cancel] that voucher no longer exists.")
                return
            label = f"{data['type']} No. {data['invoice_no'] or data['number']}"
            if data["status"] == "Cancelled":
                self.monitor.log(f"[Cancel] {label} is already cancelled.")
                return
            if not messagebox.askyesno(
                    "Cancel voucher?",
                    f"Cancel {label} of {data['date'].strftime('%d-%m-%Y')} for ₹{fmt_inr(data['total'])}?\n\n"
                    "The number stays in the series (no unused number). Its amounts leave the books, the reports "
                    "and the GST registers; balances and stock it changed are put back.\n\nThis cannot be undone.",
                    default="no", icon="warning", parent=self):
                self.monitor.log(f"[Cancel] {label} kept.")
                return
            run_in_background(self, lambda: self.store.cancel(voucher_id), lambda r: cancelled(label, r),
                              lambda exc: self.monitor.log(f"[Cancel] {label} NOT cancelled: {exc}"))

        def cancelled(label: str, result) -> None:
            self.monitor.log(f"[Cancel] {label} cancelled: number kept in the series, amounts out of the books.")
            for change in result.account_updates + result.stock_updates:
                self.monitor.log(f"[Cancel] {label} {change}")
            if isinstance(self.view, VoucherView) and self.view.existing is not None \
                    and self.view.existing.get("id") == voucher_id:
                self.view._snapshot = self.view._state()   # nothing to keep: the voucher is cancelled
                self.close_view()                          # back to the report, rebuilt
            elif self.view is not None and self._current_factory is not None:
                factory = self._current_factory
                self.view.destroy()
                self.view = None
                self._reopen(factory)
                if hasattr(self.view, "select_voucher"):
                    self.view.select_voucher(voucher_id)

        run_in_background(self, lambda: self.store.load_voucher(voucher_id), opened,
                          lambda exc: self.monitor.log(f"[Cancel] could not read the voucher: {exc}"))

    def _safe_invoice_no(self, d) -> str:
        try:
            return self.store.next_invoice_no(d)
        except StoreError as exc:
            return str(exc)

    def _on_voucher_accepted(self, voucher: dict, done) -> None:
        """Saves an accepted voucher into bizpulse_local.db in a BACKGROUND THREAD, so the window
        never freezes while the database is written. done(True) clears the voucher screen;
        done(False) keeps everything that was typed.

        Every voucher -> bp_vouchers + bp_voucher_lines (+ bp_voucher_items, bp_voucher_details);
        Regular ones also -> gst_sales_ledger (Sales), corporate_ledger_summary balances and
        inventory_stock_registry quantities (Item Invoice). One transaction.
        The two questions (credit ceiling, stock below zero) are quick reads asked first, here.
        """
        title = f"[Vouchers] {voucher['type']}"
        regular = voucher.get("status", "Regular") == "Regular"
        warnings = self.store.credit_warnings(voucher) if regular else []
        if warnings:
            text = "\n".join(f"{w.account}: balance would be ₹{fmt_inr(w.after)}, ceiling ₹{fmt_inr(w.ceiling)}"
                             for w in warnings)
            if not messagebox.askyesno("Credit ceiling", f"This voucher takes these accounts over their credit ceiling:\n\n"
                                       f"{text}\n\nSave anyway?", default="no", icon="warning", parent=self):
                self.monitor.log(f"{title} not saved: over credit ceiling ({', '.join(w.account for w in warnings)}).")
                done(False)
                return
        short = self.store.stock_shortfalls(voucher)
        if short:
            text = "\n".join(f"{s.item}: {s.on_hand} on hand, {s.wanted} on this invoice" for s in short)
            if not messagebox.askyesno("Stock", f"These items would go below zero in inventory_stock_registry:\n\n"
                                       f"{text}\n\nSave anyway?", default="no", icon="warning", parent=self):
                self.monitor.log(f"{title} not saved: not enough stock ({', '.join(s.item for s in short)}).")
                done(False)
                return
        self.monitor.log(f"{title} saving …")
        run_in_background(self, lambda: self.store.save(voucher),
                          lambda result: self._voucher_saved(title, voucher, result, done),
                          lambda exc: self._voucher_failed(title, exc, done))

    def _voucher_saved(self, title: str, voucher: dict, result, done) -> None:
        status = voucher.get("status", "Regular")
        invoice = f", invoice {result.invoice_no} added to gst_sales_ledger" if result.invoice_no else ""
        kept = "" if status == "Regular" else f" as {status}"
        self.monitor.log(f"{title} No. {result.number} saved{kept}: ₹{fmt_inr(voucher['total'])}{invoice}.")
        fx = voucher.get("forex")
        if fx:
            self.monitor.log(f"{title} No. {result.number} entered in {fx['currency']} at ₹{fx['rate']} per "
                             f"{fx['currency']}; saved in rupees (₹{fmt_inr(voucher['total'])}).")
            if fx.get("note"):
                self.monitor.log(f"{title} No. {result.number}: {fx['note']}")
        for change in result.account_updates:
            self.monitor.log(f"{title} No. {result.number} customer balance {change}")
        for change in result.stock_updates:
            self.monitor.log(f"{title} No. {result.number} stock {change}")
        for party in result.unmatched_parties:
            self.monitor.log(f"{title} No. {result.number}: '{party}' is not in corporate_ledger_summary; "
                             "its balance was not updated.")
        done(True)

    def _voucher_failed(self, title: str, exc: Exception, done) -> None:
        msg = str(exc) if isinstance(exc, StoreError) else f"Not saved: {exc}"
        self.monitor.log(f"{title} NOT saved: {msg}")
        messagebox.showerror("Voucher not saved", msg, parent=self)
        done(False)

    # ------------------------------------------------------------------------------------
    # Start-up credit guard and the internet indicator
    # ------------------------------------------------------------------------------------
    def _upgrade_worker(self) -> None:
        """Background thread: one-time upgrades, then post-dated vouchers that have fallen due."""
        for line in upgrade_database(S.APP_DIR / S.LOCAL_DB, S.COMPANY_STATE_CODE):
            self.monitor.post("log", line)
        if self.db_path.is_file():
            self.monitor.post("log", schema.ensure_schema(self.db_path))  # BizPulse's own tables, where missing
        self.monitor.post("log", seed_account_groups(self.db_path))     # the 28 reserved groups
        if self.db_path.is_file():
            self.monitor.post("log", audit.install(self.db_path))       # audit trail tables, triggers, seals
        from datetime import date as _date
        for line in self.store.realise_post_dated(_date.today()):
            self.monitor.post("log", line)

    def _run_credit_guard(self) -> None:
        if (S.APP_DIR / S.CREDIT_GUARD).is_file():
            self.monitor.log("Customer credit guard found: collecting the live risk summary …")
            self.runner.run_script(S.CREDIT_GUARD, title="Credit Guard", keywords=S.CREDIT_KEYWORDS)
        else:
            self.monitor.log(f"{S.CREDIT_GUARD} not found beside the app; risk summary skipped.")

    def _schedule_net_check(self) -> None:
        threading.Thread(target=self._net_worker, daemon=True).start()
        self.after(S.NET_CHECK_EVERY_MS, self._schedule_net_check)

    def _net_worker(self, report_to: str | None = None) -> None:
        """Background thread. report_to: also write the result in the monitor under this title."""
        online = False
        for host, port in S.NET_PROBES:
            try:
                with socket.create_connection((host, port), timeout=3):
                    online = True
                    break
            except OSError:
                continue
        self.monitor.post("net", "ONLINE / CONNECTED" if online else "OFFLINE / NO NETWORK")
        if report_to:
            self.monitor.post("log", f"[{report_to}] internet: " +
                              ("connected." if online else "no connection (checked 1.1.1.1 and 8.8.8.8)."))

    def _show_net(self, text: str) -> None:
        self._net_value.configure(text=text, fg=T.OK_GREEN if text.startswith("ONLINE") else T.BAD_RED)

    # ------------------------------------------------------------------------------------
    # Placeholders and quit
    # ------------------------------------------------------------------------------------
    def header_action(self, label: str) -> None:
        """Right-hand header links: [S] Settings | [D] Dashboard | [T] Tutorial | [U] Upgrade Tier."""
        if self.header.is_open:
            self.header.close_menu(restore_focus=False)
        if label == "Dashboard":
            self.open_dashboard()
            return
        if label == "Settings":
            self.open_settings()
            return
        if label == "Tutorial":
            self.open_tutorial()
            return
        if label == "Upgrade Tier":
            self.open_update()
            return
        self.monitor.log(f"[{label}] {S.HEADER_NOT_BUILT.get(label, 'screen not built yet.')}")
        self._refocus()

    # ---- [S] Settings and [T] Tutorial ---------------------------------------------------------
    def open_settings(self) -> None:
        """Alt+S: the preferences grid. Esc clears the canvas and returns to the Corridor."""
        self._show_view(lambda: SettingsView(self.canvas, on_close=self.close_view, on_note=self.monitor.log,
                                             on_restart=self.restart_app), refreshable=False)

    def open_tutorial(self) -> None:
        """Alt+T: the operating guide. Esc clears the canvas and returns to the Corridor."""
        self._show_view(lambda: TutorialView(self.canvas, on_close=self.close_view), refreshable=False)

    def restart_app(self, confirm: bool = True) -> None:
        """Start a fresh BizPulse (it reads the saved preferences and company) and close this one."""
        if self.runner.running:
            self.monitor.log(f"[Restart] Not restarting: still running {', '.join(sorted(self.runner.running))}.")
            return
        if confirm and not messagebox.askyesno("Restart BizPulse?", "Close BizPulse Pro and start it again with the "
                                               "saved settings?", parent=self):
            return
        import subprocess
        command = [sys.executable] if getattr(sys, "frozen", False) else [sys.executable, str(Path(__file__).resolve())]
        try:
            subprocess.Popen(command, cwd=str(S.APP_DIR))
        except OSError as exc:
            self.monitor.log(f"[Settings] Could not start a new BizPulse ({exc}); close it and open it again.")
            return
        self.destroy()

    def macro_action(self, label: str) -> None:
        if label == "Company":
            self.select_company()
        elif label == "Go To":
            self.open_goto()
        else:
            self.monitor.log(f"[{label}] {S.MACRO_NOT_BUILT.get(label, 'not built yet.')}")

    def open_goto(self) -> None:
        """F4 on the Corridor: every screen by name."""
        screens = self._screens()
        where = {"Balance Sheet": "Corridor B", "Profit & Loss A/c": "Corridor P", "Stock Summary": "Corridor S",
                 "Ratio Analysis": "Corridor R", "Day Book": "Corridor D", "Vouchers": "Corridor V",
                 "Banking": "Corridor N", "Audit Trail": "Corridor L, F1 › G", "Settings": "Alt+S",
                 "Tutorial": "Alt+T", "Software Update": "Alt+U", "Dashboard": "Alt+D", "GSTR-1": "Alt+E › G"}
        extra = [("Create Company", "Alt+K › C", lambda: self.create_company()),
                 ("Alter Company", "Alt+K › A", lambda: self.alter_company()),
                 ("Select Company", "Alt+K › S, F3", lambda: self.select_company()),
                 ("Backup", "Alt+Y › B", lambda: self.backup_now()),
                 ("Restore", "Alt+Y › R", lambda: self.open_restore()),
                 ("E-commerce Orders", "Alt+O › E", lambda: self.open_ecommerce()),
                 ("Import Masters", "Alt+O › M", lambda: self.import_masters()),
                 ("Import Vouchers CSV", "Alt+O › V", lambda: self.import_vouchers()),
                 ("Print Configuration", "Alt+P › C", lambda: self.print_setup())]
        def go(fn):
            def run() -> None:                    # Go To steps aside first: a box (Banking) or an action
                self.close_view(refocus=False)    # without a screen (Backup) must not sit under it
                fn()
                if self.view is None and self.overlay is None:
                    self.focus_gateway()
            return run
        dest = sorted([(n, where.get(n, "Display More Reports"), go(fn)) for n, fn in screens.items()]
                      + [(n, w, go(fn)) for n, w, fn in extra], key=lambda d: d[0].lower())
        self._show_view(lambda: TS.goto_screen(self.canvas, destinations=dest, on_close=self.close_view),
                        refreshable=False)

    # ---- Data, Export, Exchange, Import, Print (built in) ------------------------------------
    def _has_company(self, title: str) -> bool:
        if self.db_path.is_file():
            return True
        self.monitor.log(f"[{title}] No company file yet: Company › Create Company makes one.")
        return False

    def _rel(self, path: Path) -> str:
        try:
            return Path(path).relative_to(S.APP_DIR).as_posix()
        except ValueError:
            return str(path)

    def _background(self, title: str, work, done_text, open_after: bool = False) -> None:
        """Runs work() in a thread; logs done_text(result) (and opens an HTML result in the browser)."""
        def done(result) -> None:
            self.monitor.log(f"[{title}] {done_text(result)}")
            if open_after:
                printing.open_in_browser(result)

        def failed(exc) -> None:
            self.monitor.log(f"[{title}] {exc}")
        run_in_background(self, work, done, failed)

    def backup_now(self, title: str = "Data › Backup") -> None:
        if self._has_company(title):
            self.monitor.log(f"[{title}] backing up {self.db_path.name} …")
            self._background(title, lambda: data_tools.backup(self.db_path, S.BACKUP_DIR),
                             lambda p: f"Backup written and checked: {self._rel(p)}.")

    def open_restore(self, title: str = "Data › Restore") -> None:
        self._show_view(lambda: TS.restore_screen(self.canvas, db_path=self.db_path, backup_dir=S.BACKUP_DIR,
                                                  on_close=self.close_view, on_restore=self._restore_chosen))

    def _restore_chosen(self, row: dict) -> None:
        title = "Data › Restore"
        if self.runner.running:
            self.monitor.log(f"[{title}] Not now: {', '.join(sorted(self.runner.running))} is still running.")
            return
        if not messagebox.askyesno("Restore?", f"Put {row['file']} ({row['company'] or 'company'}, saved {row['saved']}) "
                                   f"in place of {self.db_path.name}?\n\nToday's file is saved first as a safety copy, "
                                   "so this can be undone with another restore.", default="no", icon="warning",
                                   parent=self):
            return

        def done(safety) -> None:
            company.apply(S, company.read_profile(self.db_path))
            self.store.invoice_prefix = S.INVOICE_PREFIX
            self.monitor.log(f"[{title}] {row['file']} restored. Safety copy of the replaced file: "
                             f"{self._rel(safety) if safety else 'none'}.")
            self.monitor.post("log", audit.install(self.db_path))
            self._refresh_view()

        self.monitor.log(f"[{title}] restoring {row['file']} …")
        run_in_background(self, lambda: data_tools.restore(Path(row["path"]), self.db_path, S.BACKUP_DIR), done,
                          lambda exc: self.monitor.log(f"[{title}] {exc}"))

    def export_ledgers(self, title: str = "Export › Current Ledger") -> None:
        if self._has_company(title):
            self._background(title, lambda: data_tools.ledger_balances_csv(self.db_path, S.EXPORT_DIR, date.today()),
                             lambda p: f"Ledger balances written to {self._rel(p)} (opens in Excel).")

    def export_final_accounts(self, title: str = "Export › Final Accounts") -> None:
        if self._has_company(title):
            info = company.current(self.db_path, S)
            self._background(title, lambda: printing.save(S.EXPORT_DIR, f"final_accounts_{date.today():%Y%m%d}.html",
                                                          data_tools.final_accounts_html(self.db_path, info, date.today())),
                             lambda p: f"Final accounts written to {self._rel(p)}; opened in the browser (Ctrl+P prints).",
                             open_after=True)

    def client_pack(self, title: str = "Exchange › Client Share Pack") -> None:
        if self._has_company(title):
            info = company.current(self.db_path, S)
            self._background(title, lambda: data_tools.client_pack(self.db_path, S.EXPORT_DIR, info, date.today()),
                             lambda p: f"Client pack written to {self._rel(p)}: final accounts, ledger balances and "
                                       "day book in one ZIP to send to your CA.")

    def import_masters(self, title: str = "Import › Masters") -> None:
        self._show_view(lambda: TS.ledger_import_screen(self.canvas, store=self.masters, on_close=self.close_view,
                                                        on_note=self.monitor.log), refreshable=False)

    def import_vouchers(self, title: str = "Import › Vouchers CSV") -> None:
        self._show_view(lambda: TS.voucher_import_screen(self.canvas, db_path=self.db_path, store=self.store,
                                                         on_close=self.close_view, on_note=self.monitor.log),
                        refreshable=False)

    def open_bank_statement(self, title: str = "Import › Bank Statement") -> None:
        self._show_view(lambda: BankRecoView(self.canvas, db_path=self.db_path, on_close=self.close_view,
                                             on_note=self.monitor.log), refreshable=False)

    def print_setup(self, title: str = "Print › Configuration Setup") -> None:
        self._show_view(lambda: PrintSetupView(self.canvas, on_close=self.close_view, on_note=self.monitor.log),
                        refreshable=False)

    def _print(self, title: str, name: str, make_html) -> None:
        safe = "".join(ch if ch.isalnum() or ch in "-_" else "-" for ch in name)
        self._background(title, lambda: printing.save(S.PRINT_DIR, f"{safe}.html", make_html()),
                         lambda p: f"{self._rel(p)} opened in the browser: Ctrl+P prints it (or saves a PDF).",
                         open_after=True)

    def print_invoice(self, title: str = "Print › Current Invoice") -> None:
        """The Sales voucher open on screen; otherwise the latest saved one."""
        if not self._has_company(title):
            return
        open_id = None
        if isinstance(self.view, VoucherView) and self.view.existing and self.view.existing.get("type") == "Sales":
            open_id = self.view.existing["id"]
        info = company.current(self.db_path, S)

        def make() -> str:
            vid = open_id
            if vid is None:
                latest = [v for v in self.store.load_all() if v["type"] == "Sales" and v["status"] != "Optional"]
                if not latest:
                    raise data_tools.DataError("There is no Sales invoice to print yet.")
                vid = latest[-1]["id"]
            v = self.store.load_voucher(vid)
            return printing.invoice_html(v, info, S.PRINT_PAPER, S.PRINT_SHOW_HSN, S.PRINT_FOOTER)
        self._print(title, f"invoice-{open_id or 'latest'}-{date.today():%Y%m%d}", make)

    def _print_cheque(self, p: dict) -> None:
        self._print("Banking › Cheque Printing", f"cheque-{p['number']}",
                    lambda: printing.cheque_html(p["payee"], p["amount"], p["date"], S.CHEQUE_LAYOUT))

    def _print_advice(self, p: dict) -> None:
        info = company.current(self.db_path, S)
        self._print("Banking › Payment Advice", f"payment-advice-{p['number']}",
                    lambda: printing.payment_advice_html(p["voucher"], info))

    def _print_deposit_slip(self, b: dict) -> None:
        info = company.current(self.db_path, S)
        self._print("Banking › Deposit Slip", f"deposit-slip-{b['bank']}-{b['date']:%Y%m%d}",
                    lambda: printing.deposit_slip_html(b["bank"], b["date"], b["rows"], info))

    def confirm_quit(self) -> None:
        """Safe termination: never close silently while a script may be writing to the database."""
        notes = []
        if self.runner.running:
            notes.append(f"Still running: {', '.join(sorted(self.runner.running))}. "
                         "Quitting now can interrupt it in the middle of writing.")
        if notes:
            ok = messagebox.askyesno("Quit", "\n\n".join(notes) + "\n\nQuit anyway?",
                                     default="no", icon="warning", parent=self)
        else:
            ok = messagebox.askyesno("Quit", "Quit BizPulse Pro?", parent=self)
        if ok:
            self.destroy()
        elif self.view is None and self.overlay is None:
            self.focus_gateway()


if __name__ == "__main__":
    BizPulseApp().mainloop()
