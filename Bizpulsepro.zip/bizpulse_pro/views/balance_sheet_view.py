"""
Balance Sheet (B, under Reports) — full-width, split down the middle.

    +--------------------------------------------------------------------------+
    | Balance Sheet - SRIJEE CREATIONS                 as at 09-10-2026  Esc   |
    +-------------------------------------+------------------------------------+
    | Liabilities                         | Assets                             |
    |  Capital Account          xx        |  Fixed Assets              xx      |
    |  Loans (Liability)        xx        |  Investments               xx      |
    |  Current Liabilities      xx        |  Current Assets            xx      |
    |  Profit & Loss A/c        xx        |                                    |
    +-------------------------------------+------------------------------------+
    | Total                    xx         | Total                     xx       |
    +--------------------------------------------------------------------------+

Figures come from services/reports.py (vouchers saved in bizpulse_local.db, grouped by
config/ledger_groups.py; stock from config/stock_valuation.py and the Stock Summary), loaded in a
background thread. The two totals agree because every
voucher is balanced; nothing is adjusted to make them agree. If they ever differ, or a ledger
has no group, the screen says so in red.

Keys: Up / Down move, Left / Right expand or collapse a group, Tab switches side, Esc back.
"""
from __future__ import annotations

import tkinter as tk
from datetime import date
from pathlib import Path
from tkinter import ttk
from typing import Callable

from config import theme as T
from services.background import run_in_background
from services.reports import NOT_GROUPED, ReportError, Reports, build_reports
from views.report_common import insert_node, money, report_tree, title_bar
from views.vouchers_view import DATE_FMT, fmt_inr


class BalanceSheetView(tk.Frame):
    def __init__(self, parent: tk.Widget, *, db_path: Path, company: str, on_close: Callable[[], None],
                 on_compare: Callable[[], None] | None = None,
                 as_at: date | None = None) -> None:
        super().__init__(parent, bg=T.WHITE)
        self._on_close = on_close
        self._on_compare = on_compare          # C: comparative columns
        self._as_at = as_at or date.today()
        title_bar(self, f"Balance Sheet - {company.upper()}", "C Compare    Tab other side    Esc Back")

        self._subtitle = tk.Label(self, text="Loading…", bg=T.WHITE, fg=T.MUTED, font=T.F_LABEL, anchor="w")
        self._subtitle.pack(side="top", fill="x", padx=14, pady=(8, 4))

        body = tk.Frame(self, bg=T.WHITE)
        body.pack(side="top", fill="both", expand=True, padx=14)
        body.columnconfigure(0, weight=1, uniform="half")
        body.columnconfigure(1, weight=1, uniform="half")
        body.rowconfigure(1, weight=1)
        self._trees = []
        for col, title in enumerate(("Liabilities", "Assets")):
            tk.Label(body, text=title, bg=T.WHITE, fg=T.NAVY, font=T.F_VIEW_TITLE, anchor="w").grid(
                row=0, column=col, sticky="ew", padx=(0 if col == 0 else 6, 6 if col == 0 else 0), pady=(0, 4))
            box = tk.Frame(body, bg=T.WHITE, highlightthickness=1, highlightbackground=T.BORDER)
            box.grid(row=1, column=col, sticky="nsew", padx=(0 if col == 0 else 6, 6 if col == 0 else 0))
            tree = report_tree(box, "Particulars")
            # Each half is about 440 px wide beside the action bar: keep both amount columns in view.
            tree.column("#0", width=170, minwidth=140, stretch=True)
            tree.column("sub", width=112, minwidth=104, stretch=False)
            tree.column("amount", width=122, minwidth=112, stretch=False)
            sb = ttk.Scrollbar(box, orient="vertical", command=tree.yview)
            tree.configure(yscrollcommand=sb.set)
            sb.pack(side="right", fill="y")
            tree.pack(side="left", fill="both", expand=True)
            self._trees.append(tree)

        # Total row stretching across both halves
        totals = tk.Frame(body, bg=T.LIGHT_BLUE, highlightthickness=1, highlightbackground=T.NAVY)
        totals.grid(row=2, column=0, columnspan=2, sticky="ew", pady=(6, 0))
        totals.columnconfigure(0, weight=1, uniform="half")
        totals.columnconfigure(1, weight=1, uniform="half")
        self._total_labels = []
        for col in (0, 1):
            cell = tk.Frame(totals, bg=T.LIGHT_BLUE)
            cell.grid(row=0, column=col, sticky="ew", padx=10, pady=6)
            tk.Label(cell, text="Total", bg=T.LIGHT_BLUE, fg=T.NAVY, font=T.F_LABEL_BOLD).pack(side="left")
            amt = tk.Label(cell, text="", bg=T.LIGHT_BLUE, fg=T.NAVY, font=T.F_TOTAL)
            amt.pack(side="right", padx=(0, 18))
            self._total_labels.append(amt)

        self._notice = tk.Label(self, bg=T.WHITE, fg=T.BAD_RED, font=T.F_LABEL, anchor="w", justify="left",
                                wraplength=900)
        self._notice.pack(side="top", fill="x", padx=14, pady=(6, 10))

        run_in_background(self, lambda: build_reports(db_path, self._as_at), self._show, self._failed)

    # ---- data --------------------------------------------------------------------------
    def _show(self, r: Reports) -> None:
        self._subtitle.configure(
            text=f"as at {r.period_end.strftime(DATE_FMT)} · profit for {r.period_start.strftime(DATE_FMT)} to "
                 f"{r.period_end.strftime(DATE_FMT)} · {r.voucher_count} voucher(s) in the period")
        for tree, nodes in zip(self._trees, (r.liabilities, r.assets)):
            for node in nodes:
                insert_node(tree, node, tag="warn" if node.name == NOT_GROUPED else "group")
        self._total_labels[0].configure(text=money(r.liabilities_total))
        self._total_labels[1].configure(text=money(r.assets_total))

        notes = []
        if r.liabilities_total != r.assets_total:
            notes.append(f"The totals differ by {money(r.liabilities_total - r.assets_total)}. Please report this: "
                         "saved vouchers should always balance.")
        if r.not_grouped:
            names = ", ".join(name for name, _b in r.not_grouped[:8]) + (" …" if len(r.not_grouped) > 8 else "")
            notes.append(f"Not grouped: {names}. Add them to config/ledger_groups.py so they show under "
                         "the right heading.")
        notes += r.stock_notes
        if r.opening_difference:
            notes.insert(0, f"Difference in Opening Balances: ₹{fmt_inr(abs(r.opening_difference))} "
                            f"({'Dr' if r.opening_difference > 0 else 'Cr'} more than "
                            f"{'Cr' if r.opening_difference > 0 else 'Dr'}). Check the openings in Masters › Alter › Ledger.")
        if not r.voucher_count and not any(n.amount for n in r.liabilities + r.assets):
            notes.append("No vouchers are saved yet, so every figure is 0.")
        warn = (r.not_grouped or r.liabilities_total != r.assets_total or r.opening_difference
                or any(w in n for n in r.stock_notes for w in ("overstated", "understated", "left out", "twice")))
        self._notice.configure(text="\n".join(notes), fg=T.BAD_RED if warn else T.MUTED)
        self.focus_first()

    def _failed(self, exc: Exception) -> None:
        msg = str(exc) if isinstance(exc, ReportError) else f"Could not build the Balance Sheet: {exc}"
        self._subtitle.configure(text="")
        self._notice.configure(text=msg, fg=T.BAD_RED)

    # ---- keys --------------------------------------------------------------------------
    def focus_first(self) -> None:
        tree = self._trees[0]
        tree.focus_set()
        first = tree.get_children()
        if first:
            tree.selection_set(first[0])
            tree.focus(first[0])

    def handle_key(self, event: tk.Event) -> str | None:
        if event.keysym == "Escape":
            self._on_close()
            return "break"
        if event.keysym.lower() == "c" and not event.state & (T.MOD_CTRL | T.MOD_ALT) and self._on_compare:
            self._on_compare()
            return "break"
        if event.keysym == "Tab":
            other = self._trees[1] if self.focus_get() is self._trees[0] else self._trees[0]
            other.focus_set()
            kids = other.get_children()
            if kids and not other.selection():
                other.selection_set(kids[0])
                other.focus(kids[0])
            return "break"
        return None   # arrows: the table moves and opens / closes groups itself
