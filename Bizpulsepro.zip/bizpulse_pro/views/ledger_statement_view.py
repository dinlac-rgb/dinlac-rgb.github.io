"""
Ledger Statement (Tally's Ledger Vouchers) — one ledger's vouchers for the financial year,
with the opening balance, a running balance and the closing balance.

    Date | Particulars | Vch Type | Vch No. | Debit | Credit | Balance

Opened from the Trial Balance (Enter on a ledger) or from Display More Reports (choose the
ledger at the top; the list on the right helps). Enter or a double-click on a voucher opens it
in Accounting Voucher Alteration; Esc there comes back here, refreshed with the change.
Loaded in a background thread (services/voucher_book.py); Optional and Cancelled vouchers are
left out. Alt+2 on a row duplicates that voucher as a new one; Alt+X cancels it (asks first).
"""
from __future__ import annotations

import tkinter as tk
from datetime import date
from decimal import Decimal
from tkinter import ttk
from typing import Callable

from components.ledger_list import LedgerListPanel
from components.macro_bar import Macro
from config import theme as T
from services.background import run_in_background
from views.report_common import title_bar
from views.vouchers_view import DATE_FMT, fmt_inr

COLUMNS = (("date", "Date", 100, "w"), ("particulars", "Particulars", 260, "w"), ("type", "Vch Type", 110, "w"),
           ("number", "Vch No.", 120, "e"), ("dr", "Debit", 130, "e"), ("cr", "Credit", 130, "e"),
           ("balance", "Balance", 150, "e"))


def balance_text(v: Decimal) -> str:
    return f"{fmt_inr(abs(v))} {'Dr' if v >= 0 else 'Cr'}" if v else "0.00"


class LedgerStatementView(tk.Frame):
    def __init__(self, parent: tk.Widget, *, statement_source: Callable[[str], dict], on_close: Callable[[], None],
                 on_open_voucher: Callable[[int], None] | None = None, ledger: str = "",
                 ledger_source: Callable[[], list] | None = None,
                 on_duplicate: Callable[[int], None] | None = None,
                 on_cancel: Callable[[int], None] | None = None) -> None:
        super().__init__(parent, bg=T.WHITE)
        self._source, self._on_close, self._on_open = statement_source, on_close, on_open_voucher
        self._on_duplicate, self._on_cancel = on_duplicate, on_cancel      # Alt+2 / Alt+X on a row
        title_bar(self, "Ledger Statement", "Enter open    Alt+2 Duplicate    Alt+X Cancel    Esc Back")
        top = tk.Frame(self, bg=T.WHITE)
        top.pack(side="top", fill="x", padx=14, pady=(8, 4))
        tk.Label(top, text="Ledger", bg=T.WHITE, fg=T.TEXT, font=T.F_TEXT).pack(side="left")
        self._ledger = tk.Entry(top, width=34, font=T.F_TEXT, relief="flat", bd=0, highlightthickness=1,
                                highlightbackground=T.LINE, highlightcolor=T.ORANGE)
        self._ledger.pack(side="left", padx=8, ipady=3)
        self._subtitle = tk.Label(top, bg=T.WHITE, fg=T.MUTED, font=T.F_TEXT, anchor="w")
        self._subtitle.pack(side="left", padx=8)

        body = tk.Frame(self, bg=T.WHITE)
        body.pack(side="top", fill="both", expand=True)
        box = tk.Frame(body, bg=T.WHITE, highlightthickness=1, highlightbackground=T.BORDER)
        box.pack(side="left", fill="both", expand=True, padx=14, pady=(0, 10))
        self._list = LedgerListPanel(body, on_pick=self._picked)
        self._list.pack_before = box
        self._tree = ttk.Treeview(box, columns=[c[0] for c in COLUMNS], show="headings", style="BizPulse.Treeview",
                                  selectmode="browse")
        for key, head, width, anchor in COLUMNS:
            self._tree.heading(key, text=head, anchor=anchor)
            self._tree.column(key, width=width, minwidth=60, anchor=anchor, stretch=key == "particulars")
        self._tree.tag_configure("edge", foreground=T.NAVY, background=T.LIGHT_BLUE)
        sb = ttk.Scrollbar(box, orient="vertical", command=self._tree.yview)
        self._tree.configure(yscrollcommand=sb.set)
        sb.pack(side="right", fill="y")
        self._tree.pack(side="left", fill="both", expand=True)
        self._tree.bind("<Double-Button-1>", lambda e: self.open_row(self._tree.identify_row(e.y)))
        self._rows: dict[str, int] = {}                  # tree iid -> voucher id

        self._ledger.bind("<FocusIn>", lambda _e: self._list.show(text=self._ledger.get()), add="+")
        self._ledger.bind("<KeyRelease>", lambda e: self._list.filter(self._ledger.get())
                          if e.keysym not in ("Up", "Down", "Return", "Escape") else None, add="+")
        if ledger_source is not None:
            run_in_background(self, ledger_source, self._list.set_catalogue, lambda _e: None)
        if ledger:
            self._ledger.insert(0, ledger)
            self.load(ledger)

    # ---- data --------------------------------------------------------------------------
    def load(self, ledger: str) -> None:
        self._list.hide()
        self._subtitle.configure(text="Loading…", fg=T.MUTED)
        run_in_background(self, lambda: self._source(ledger), self._show,
                          lambda exc: self._subtitle.configure(text=f"Could not load: {exc}", fg=T.BAD_RED))

    def _show(self, st: dict) -> None:
        self._tree.delete(*self._tree.get_children())
        self._rows.clear()
        self._subtitle.configure(text=f"{st['start'].strftime(DATE_FMT)} to {st['end'].strftime(DATE_FMT)} · "
                                      f"{len(st['rows'])} voucher(s)", fg=T.MUTED)
        self._tree.insert("", "end", values=("", "Opening Balance", "", "", "", "", balance_text(st["opening"])),
                          tags=("edge",))
        dr = cr = Decimal("0")
        for r in st["rows"]:
            a = r["amount"]
            dr += max(a, Decimal("0"))
            cr += max(-a, Decimal("0"))
            iid = self._tree.insert("", "end", values=(
                r["date"].strftime(DATE_FMT), r["particulars"], r["type"], r["number"],
                fmt_inr(a) if a > 0 else "", fmt_inr(-a) if a < 0 else "", balance_text(r["balance"])))
            self._rows[iid] = r["id"]
        self._tree.insert("", "end", values=("", "Closing Balance", "", "", fmt_inr(dr), fmt_inr(cr),
                                             balance_text(st["closing"])), tags=("edge",))
        self.focus_first()

    def _picked(self, name: str) -> None:
        self._ledger.delete(0, "end")
        self._ledger.insert(0, name)
        self.load(name)

    def open_row(self, iid: str) -> None:
        if iid in self._rows and self._on_open is not None:
            self._on_open(self._rows[iid])

    def _row_action(self, action: Callable[[int], None] | None) -> None:
        sel = self._tree.selection()
        if action is not None and sel and sel[0] in self._rows:
            action(self._rows[sel[0]])

    def macros(self) -> list[Macro]:
        out = []
        if self._on_duplicate is not None:
            out.append(Macro("Alt+2", "Duplicate", lambda: self._row_action(self._on_duplicate)))
        if self._on_cancel is not None:
            out.append(Macro("Alt+X", "Cancel Vch", lambda: self._row_action(self._on_cancel)))
        return out

    # ---- keys --------------------------------------------------------------------------
    def focus_first(self) -> None:
        if not self._ledger.get().strip():
            self._ledger.focus_set()
            return
        self._tree.focus_set()
        ids = list(self._rows)
        if ids:
            self._tree.selection_set(ids[-1])
            self._tree.focus(ids[-1])
            self._tree.see(ids[-1])

    def handle_key(self, event: tk.Event) -> str | None:
        if event.keysym == "Escape":
            self._on_close()
            return "break"
        if event.state & T.MOD_ALT and not event.state & T.MOD_CTRL and event.widget is not self._ledger:
            if event.keysym == "2":
                self._row_action(self._on_duplicate)
                return "break"
            if event.keysym.lower() == "x":
                self._row_action(self._on_cancel)
                return "break"
            return None
        if event.keysym in ("Up", "Down") and event.widget is self._ledger and self._list.visible:
            self._list.move(-1 if event.keysym == "Up" else 1)
            return "break"
        if event.keysym in ("Return", "KP_Enter"):
            if event.widget is self._ledger:
                name = self._list.choice(self._ledger.get()) or self._ledger.get().strip()
                if name:
                    self._picked(name)
            else:
                sel = self._tree.selection()
                if sel:
                    self.open_row(sel[0])
            return "break"
        return None
