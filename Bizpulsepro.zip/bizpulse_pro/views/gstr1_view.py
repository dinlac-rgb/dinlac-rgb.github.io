"""
GSTR-1 (Display More Reports › GSTR-1, or Export › GST Returns JSON).

    Return period [10-2026]                                     E Export JSON
    Section                       Invoices / rows     Taxable value        Tax
    B2B  registered buyers                      3        1,20,000.00   21,600.00
    B2CL inter-state, unregistered, large       0               0.00        0.00
    B2CS other unregistered                     5          45,000.00    8,100.00
    HSN/SAC summary                             4        1,65,000.00   29,700.00
    Documents issued  SRJ/26-27/0001 to SRJ/26-27/0008     8                  0 missing

Keys: type the month as MM-YYYY and Enter; E writes the JSON to the exports folder beside
main.py (exports/GSTR1_<GSTIN>_<MMYYYY>.json) and logs it in the status bar; Esc goes back.
Building and writing run in a background thread (services/gstr1.py). Import the file into the
GST offline tool to validate it before uploading.
"""
from __future__ import annotations

import tkinter as tk
from datetime import date, datetime
from pathlib import Path
from tkinter import ttk
from typing import Callable

from config import theme as T
from services.background import run_in_background
from services.gstr1 import Gstr1, Gstr1Error, build_gstr1, write_gstr1
from views.masters_overlay import hotkey_labels
from views.report_common import title_bar
from views.vouchers_view import fmt_inr

SECTIONS = (("b2b", "B2B  registered buyers"), ("b2cl", "B2CL inter-state, unregistered, large"),
            ("b2cs", "B2CS other unregistered"), ("hsn", "HSN/SAC summary"), ("doc_issue", "Documents issued"))


class Gstr1View(tk.Frame):
    def __init__(self, parent: tk.Widget, *, db_path: Path, export_dir: Path, gstin: str, company_state: str,
                 b2cl_limit, version: str, on_close: Callable[[], None], on_note: Callable[[str], None]) -> None:
        super().__init__(parent, bg=T.WHITE)
        self._args = (db_path, gstin, company_state, b2cl_limit, version)
        self._export_dir, self._on_close, self._on_note = export_dir, on_close, on_note
        self._result: Gstr1 | None = None
        title_bar(self, "GSTR-1", "Enter load    E Export JSON    Esc Back")
        top = tk.Frame(self, bg=T.WHITE)
        top.pack(side="top", fill="x", padx=14, pady=(10, 6))
        tk.Label(top, text="Return period (MM-YYYY)", bg=T.WHITE, fg=T.TEXT, font=T.F_TEXT).pack(side="left")
        self._period = tk.Entry(top, width=9, font=T.F_TEXT, justify="center", relief="flat", bd=0,
                                highlightthickness=1, highlightbackground=T.LINE, highlightcolor=T.ORANGE)
        self._period.pack(side="left", padx=8, ipady=3)
        self._period.insert(0, date.today().strftime("%m-%Y"))
        link = tk.Frame(top, bg=T.LIGHT_BLUE, cursor="hand2", highlightthickness=1, highlightbackground=T.LINE)
        link.pack(side="right")
        for w in (link, *hotkey_labels(link, "Export JSON", "E", T.LIGHT_BLUE, T.NAVY, first_padx=8)):
            w.bind("<Button-1>", lambda _e: self.export())
        tk.Frame(link, bg=T.LIGHT_BLUE, width=8).pack(side="left")

        box = tk.Frame(self, bg=T.WHITE, highlightthickness=1, highlightbackground=T.BORDER)
        box.pack(side="top", fill="x", padx=14)
        self._tree = ttk.Treeview(box, columns=("count", "taxable", "tax"), show="tree headings", height=6,
                                  style="BizPulse.Treeview", selectmode="none")
        self._tree.heading("#0", text="Section", anchor="w")
        self._tree.column("#0", width=320, stretch=True)
        for col, head, w in (("count", "Invoices / rows", 130), ("taxable", "Taxable value", 160), ("tax", "Tax", 140)):
            self._tree.heading(col, text=head, anchor="e")
            self._tree.column(col, width=w, anchor="e", stretch=False)
        self._tree.pack(fill="x")
        self._notes = tk.Label(self, bg=T.WHITE, fg=T.MUTED, font=T.F_TEXT, anchor="w", justify="left", wraplength=880)
        self._notes.pack(side="top", fill="x", padx=14, pady=(8, 10))
        self.load()

    def _month(self) -> tuple[int, int] | None:
        try:
            d = datetime.strptime(self._period.get().strip(), "%m-%Y")
        except ValueError:
            self._say("Type the return period as MM-YYYY, e.g. 10-2026.", True)
            return None
        return d.year, d.month

    def load(self) -> None:
        ym = self._month()
        if ym is None:
            return
        db, gstin, state, limit, version = self._args
        self._say("Building…")
        run_in_background(self, lambda: build_gstr1(db, ym[0], ym[1], gstin, state, limit, version), self._show,
                          lambda exc: self._say(str(exc) if isinstance(exc, Gstr1Error) else f"Could not build: {exc}", True))

    def _show(self, r: Gstr1) -> None:
        self._result = r
        self._tree.delete(*self._tree.get_children())
        for key, label in SECTIONS:
            s = r.summary[key]
            if key == "doc_issue":
                label = f"{label}  {s['ranges']}" if s["ranges"] else label
                values = (s["count"], "", f"{s['cancel']} missing")
            else:
                values = (s["count"], fmt_inr(s["taxable"]), fmt_inr(s["tax"]))
            self._tree.insert("", "end", text=label, values=values)
        self._say("\n".join(r.warnings) or "Ready: E writes the JSON file.", bool(r.warnings))

    def export(self) -> None:
        if self._result is None:
            self._say("Load a return period first (Enter).", True)
            return
        result, folder = self._result, self._export_dir
        run_in_background(self, lambda: write_gstr1(result, folder), self._written,
                          lambda exc: self._say(f"Not written: {exc}", True))

    def _written(self, path: Path) -> None:
        msg = f"GSTR-1 for {self._result.period[:2]}-{self._result.period[2:]} written to {path}"
        self._say(msg + ". Validate it in the GST offline tool before uploading.")
        self._on_note(f"[GSTR-1] {msg}.")

    def _say(self, text: str, warn: bool = False) -> None:
        self._notes.configure(text=text, fg=T.BAD_RED if warn else T.MUTED)

    def focus_first(self) -> None:
        self._period.focus_set()

    def handle_key(self, event: tk.Event) -> str | None:
        if event.state & (T.MOD_CTRL | T.MOD_ALT):
            return None
        if event.keysym == "Escape":
            self._on_close()
            return "break"
        if event.keysym in ("Return", "KP_Enter"):
            self.load()
            return "break"
        if event.keysym.lower() == "e" and event.widget is not self._period:
            self.export()
            return "break"
        return None
