"""
O: Import › E-commerce Orders — preview a marketplace order file, then post it.

    E-commerce Orders - Import                              O Open file   P Post orders   Esc Corridor
    File: amazon_oct.csv · 42 rows · 18 invoices ready · 2 already imported · 3 row errors
    Order | Status | Date | Ship-to | GST % | HSN | Items | Taxable | GST | Collected
    Rows not imported:  Row 7: SKU 'XYZ' is not a product_sku in inventory_stock_registry. …

Keys: O opens the order file (CSV); P posts every invoice marked Ready, after one Yes / No
question; Esc clears the canvas and gives the keyboard back to the Corridor. Reading and posting
both run in a background thread (services/ecommerce.py); nothing is written until P and Yes.
"""
from __future__ import annotations

import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox, ttk
from typing import Callable

from config import theme as T
from services.background import run_in_background
from services.ecommerce import EcomError, ImportPlan, PostResult, post, read_orders
from services.gst import tax_for
from views.masters_overlay import hotkey_labels
from views.report_common import title_bar
from views.vouchers_view import DATE_FMT, fmt_inr

COLUMNS = (("order", "Order", 110, "w"), ("status", "Status", 230, "w"), ("date", "Date", 92, "w"),
           ("pos", "Ship-to", 64, "center"), ("rate", "GST %", 56, "e"), ("hsn", "HSN", 70, "w"),
           ("items", "Items", 150, "w"), ("taxable", "Taxable", 100, "e"), ("gst", "GST", 90, "e"),
           ("collected", "Collected", 100, "e"))


class EcommerceView(tk.Frame):
    def __init__(self, parent: tk.Widget, *, db_path: Path, store, settings, on_close: Callable[[], None],
                 on_note: Callable[[str], None] | None = None) -> None:
        super().__init__(parent, bg=T.WHITE, takefocus=1)
        self._db, self._store, self._S, self._on_close = db_path, store, settings, on_close
        self._on_note = on_note or (lambda _m: None)
        self._plan: ImportPlan | None = None
        self._busy = False
        title_bar(self, "E-commerce Orders - Import", "O Open file    P Post orders    Esc Corridor")
        top = tk.Frame(self, bg=T.WHITE)
        top.pack(side="top", fill="x", padx=14, pady=(8, 4))
        self._file = tk.Label(top, text="No file opened. O opens a marketplace order CSV.", bg=T.WHITE, fg=T.MUTED,
                              font=T.F_TEXT, anchor="w")
        self._file.pack(side="left")
        for label, key, command in (("Post orders", "P", self.post), ("Open file", "O", self.open_file)):
            link = tk.Frame(top, bg=T.LIGHT_BLUE, cursor="hand2", highlightthickness=1, highlightbackground=T.LINE)
            link.pack(side="right", padx=(6, 0))
            for w in (link, *hotkey_labels(link, label, key, T.LIGHT_BLUE, T.NAVY, first_padx=8)):
                w.bind("<Button-1>", lambda _e, c=command: c())
            tk.Frame(link, bg=T.LIGHT_BLUE, width=8).pack(side="left")
        rules = (f"Ship-to state {settings.COMPANY_STATE_CODE} ({settings.COMPANY_STATE_NAME}): CGST + SGST; other states: "
                 f"IGST. Prices {'include' if settings.ECOM_PRICES_INCLUDE_GST else 'exclude'} GST. "
                 f"Dr {settings.ECOM_PARTY_LEDGER}, Cr Sales and Output GST; stock leaves inventory_stock_registry.")
        tk.Label(self, text=rules, bg=T.WHITE, fg=T.MUTED, font=T.F_TEXT, anchor="w", justify="left",
                 wraplength=880).pack(side="top", fill="x", padx=14)
        self.summary = tk.Label(self, bg=T.WHITE, fg=T.MUTED, font=T.F_TEXT, anchor="w", justify="left", wraplength=880)
        self.summary.pack(side="top", fill="x", padx=14, pady=(4, 4))

        box = tk.Frame(self, bg=T.WHITE, highlightthickness=1, highlightbackground=T.BORDER)
        box.pack(side="top", fill="both", expand=True, padx=14)
        self.tree = ttk.Treeview(box, columns=[c[0] for c in COLUMNS], show="headings", style="BizPulse.Treeview",
                                 selectmode="browse")
        for key, head, width, anchor in COLUMNS:
            self.tree.heading(key, text=head, anchor=anchor)
            self.tree.column(key, width=width, minwidth=50, anchor=anchor, stretch=key in ("items", "status"))
        for tag, colour in (("Ready", T.TEXT), ("Posted", T.OK_GREEN), ("Failed", T.BAD_RED),
                            ("Short stock", T.BAD_RED), ("Already imported", T.MUTED)):
            self.tree.tag_configure(tag, foreground=colour)
        vbar = ttk.Scrollbar(box, orient="vertical", command=self.tree.yview)
        hbar = ttk.Scrollbar(box, orient="horizontal", command=self.tree.xview)
        self.tree.configure(yscrollcommand=vbar.set, xscrollcommand=hbar.set)
        self.tree.grid(row=0, column=0, sticky="nsew")
        vbar.grid(row=0, column=1, sticky="ns")
        hbar.grid(row=1, column=0, sticky="ew")
        box.rowconfigure(0, weight=1)
        box.columnconfigure(0, weight=1)
        self.errors = tk.Label(self, bg=T.WHITE, fg=T.BAD_RED, font=T.F_TEXT, anchor="w", justify="left",
                               wraplength=880)
        self.errors.pack(side="top", fill="x", padx=14, pady=(6, 10))

    # ---- reading -------------------------------------------------------------------------
    def open_file(self, path: str | None = None) -> None:
        if self._busy:
            return
        if path is None:
            path = filedialog.askopenfilename(parent=self, title="Marketplace orders (CSV)",
                                              filetypes=[("Order files", "*.csv *.txt"), ("All files", "*.*")])
        if not path:
            return
        S = self._S
        self._busy = True
        self.summary.configure(text=f"Reading {Path(path).name} and matching SKUs…", fg=T.MUTED)
        run_in_background(self, lambda: read_orders(
            Path(path), self._db, company_state=S.COMPANY_STATE_CODE, gst_rates=tuple(S.GST_RATES),
            prices_include_gst=S.ECOM_PRICES_INCLUDE_GST, allow_negative_stock=S.ECOM_ALLOW_NEGATIVE_STOCK),
            self._read, self._failed)

    def _read(self, plan: ImportPlan) -> None:
        self._busy = False
        self._plan = plan
        self._file.configure(text=f"File: {plan.file} · {plan.rows} order row(s)", fg=T.TEXT)
        self._draw()
        if plan.errors:
            shown = plan.errors[:12]
            more = f" … and {len(plan.errors) - 12} more." if len(plan.errors) > 12 else ""
            self.errors.configure(text="Rows not imported (fix them in the file and open it again):  "
                                       + "  ".join(shown) + more)
        else:
            self.errors.configure(text="")

    def _failed(self, exc: Exception) -> None:
        self._busy = False
        msg = str(exc) if isinstance(exc, EcomError) else f"Could not read the file: {exc}"
        self.summary.configure(text=msg, fg=T.BAD_RED)

    def _draw(self) -> None:
        plan, S = self._plan, self._S
        self.tree.delete(*self.tree.get_children())
        counts: dict[str, int] = {}
        for i, inv in enumerate(plan.invoices):
            counts[inv.status] = counts.get(inv.status, 0) + 1
            tax = tax_for(inv.taxable, inv.rate, inv.pos, S.COMPANY_STATE_CODE)
            gst = tax["cgst"] + tax["sgst"] + tax["igst"]
            items = ", ".join(f"{ln.sku} × {ln.qty}" for ln in inv.lines)
            collected = inv.collected if plan.inclusive else inv.taxable + gst
            status = inv.status + (f": {inv.note}" if inv.note else "")
            self.tree.insert("", "end", iid=str(i), tags=(inv.status,), values=(
                inv.order_id, status, inv.date.strftime(DATE_FMT), inv.pos, f"{inv.rate.normalize():f}", inv.hsn,
                items, fmt_inr(inv.taxable), fmt_inr(gst), fmt_inr(collected)))
        parts = [f"{n} {k.lower()}" for k, n in counts.items()]
        if plan.errors:
            parts.append(f"{len(plan.errors)} row error(s)")
        ready = counts.get("Ready", 0)
        hint = " P posts the ready ones." if ready else ""
        self.summary.configure(text=f"{len(plan.invoices)} invoice(s): " + (", ".join(parts) or "none") + "." + hint,
                               fg=T.MUTED)

    # ---- posting -------------------------------------------------------------------------
    def post(self) -> None:
        if self._busy or self._plan is None:
            if self._plan is None:
                self.summary.configure(text="Open an order file first (O).", fg=T.BAD_RED)
            return
        ready = self._plan.ready
        if not ready:
            self.summary.configure(text="Nothing is Ready to post.", fg=T.BAD_RED)
            return
        if not messagebox.askyesno("Post e-commerce orders?",
                                   f"Post {len(ready)} Sales invoice(s) from {self._plan.file}?\n\nEach gets the next "
                                   "invoice number, a gst_sales_ledger row, a stock change and an audit-trail entry.",
                                   parent=self):
            return
        S, plan, store = self._S, self._plan, self._store
        build = dict(company_state=S.COMPANY_STATE_CODE, party_ledger=S.ECOM_PARTY_LEDGER,
                     sales_ledger=S.ITEM_INVOICE_LEDGER["Sales"], tax_ledgers=S.OUTPUT_TAX_LEDGERS,
                     round_off_ledger=S.ECOM_ROUND_OFF_LEDGER, round_off_limit=S.ROUND_OFF_LIMIT)
        self._busy = True
        self.summary.configure(text=f"Posting {len(ready)} invoice(s)…", fg=T.MUTED)
        run_in_background(self, lambda: post(plan, store, **build), self._posted, self._post_failed)

    def _posted(self, result: PostResult) -> None:
        self._busy = False
        for inv, number in result.posted:
            self._on_note(f"[E-commerce] Order {inv.order_id} posted as Sales invoice {number}: "
                          f"₹{fmt_inr(inv.voucher['lines'][0]['amount'])} due from {inv.voucher['lines'][0]['ledger']}.")
        for inv, why in result.failed:
            self._on_note(f"[E-commerce] Order {inv.order_id} NOT posted: {why}")
        self._draw()
        text = f"Posted {len(result.posted)} invoice(s)"
        text += f"; {len(result.failed)} failed (see Status)." if result.failed else "."
        self.summary.configure(text=text, fg=T.BAD_RED if result.failed else T.OK_GREEN)
        self._on_note(f"[E-commerce] {self._plan.file}: {text}")

    def _post_failed(self, exc: Exception) -> None:
        self._busy = False
        self.summary.configure(text=f"Posting stopped: {exc}", fg=T.BAD_RED)

    # ---- keys ----------------------------------------------------------------------------
    def focus_first(self) -> None:
        self.tree.focus_set()

    def handle_key(self, event: tk.Event) -> str | None:
        if event.keysym == "Escape":
            if self._busy:
                self.summary.configure(text="Still working; Esc goes back when it has finished.", fg=T.BAD_RED)
                return "break"
            self._on_close()
            return "break"
        if event.state & (T.MOD_CTRL | T.MOD_ALT):
            return None
        key = event.keysym.lower()
        if key == "o":
            self.open_file()
            return "break"
        if key == "p":
            self.post()
            return "break"
        return None
