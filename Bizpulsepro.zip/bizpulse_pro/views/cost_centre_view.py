"""
Cost Centre Summary (Display More Reports › C) — what each department, project or branch was
charged this financial year, ledger by ledger.

    Cost Centre / Ledger                  Amount
    ▾ Marketing                        15,000.00
        Office Rent                    15,000.00
    ▾ Operations                       10,000.00
    Total allocated                    25,000.00

Only lines split in the Cost Centre Allocation box appear. Optional and Cancelled vouchers are
left out. Esc goes back. Figures: services/cost_centres.summary, in a background thread.
"""
from __future__ import annotations

import tkinter as tk
from datetime import date
from decimal import Decimal
from pathlib import Path
from tkinter import ttk
from typing import Callable

from config import theme as T
from services.background import run_in_background
from services.cost_centres import summary
from services.reports import financial_year_start
from views.report_common import title_bar
from views.vouchers_view import DATE_FMT, fmt_inr


class CostCentreView(tk.Frame):
    def __init__(self, parent: tk.Widget, *, db_path: Path, company: str, on_close: Callable[[], None],
                 today: date | None = None) -> None:
        super().__init__(parent, bg=T.WHITE)
        self._on_close = on_close
        end = today or date.today()
        start = financial_year_start(end)
        title_bar(self, f"Cost Centre Summary - {company.upper()}", "Esc Back")
        self._sub = tk.Label(self, text=f"{start.strftime(DATE_FMT)} to {end.strftime(DATE_FMT)} · loading…",
                             bg=T.WHITE, fg=T.MUTED, font=T.F_TEXT, anchor="w")
        self._sub.pack(side="top", fill="x", padx=14, pady=(8, 4))
        box = tk.Frame(self, bg=T.WHITE, highlightthickness=1, highlightbackground=T.BORDER)
        box.pack(side="top", fill="both", expand=True, padx=14, pady=(0, 10))
        self.tree = ttk.Treeview(box, columns=("amount",), show="tree headings", style="BizPulse.Treeview")
        self.tree.heading("#0", text="Cost Centre / Ledger", anchor="w")
        self.tree.heading("amount", text="Amount", anchor="e")
        self.tree.column("#0", width=420, stretch=True)
        self.tree.column("amount", width=160, anchor="e", stretch=False)
        self.tree.tag_configure("centre", foreground=T.NAVY)
        self.tree.tag_configure("total", foreground=T.NAVY, background=T.LIGHT_BLUE)
        self.tree.pack(fill="both", expand=True)
        run_in_background(self, lambda: summary(db_path, start, end), self._show,
                          lambda exc: self._sub.configure(text=f"Could not build it: {exc}", fg=T.BAD_RED))
        self._period = f"{start.strftime(DATE_FMT)} to {end.strftime(DATE_FMT)}"

    def _show(self, rows) -> None:
        totals: dict[str, Decimal] = {}
        names: dict[str, str] = {}
        for r in rows:
            key = r.centre.lower()
            names.setdefault(key, r.centre)
            totals[key] = totals.get(key, Decimal("0")) + r.amount
        parents = {key: self.tree.insert("", "end", text=names[key], values=(fmt_inr(totals[key]),),
                                         open=True, tags=("centre",)) for key in totals}
        for r in rows:
            self.tree.insert(parents[r.centre.lower()], "end", text=r.ledger, values=(fmt_inr(r.amount),))
        if rows:
            self.tree.insert("", "end", text="Total allocated", values=(fmt_inr(sum(totals.values())),), tags=("total",))
            self._sub.configure(text=f"{self._period} · {len(totals)} cost centre(s)")
        else:
            self._sub.configure(text=f"{self._period} · nothing allocated yet. Split an expense or purchase line "
                                     "with Enter on its amount.")

    def focus_first(self) -> None:
        self.tree.focus_set()

    def handle_key(self, event: tk.Event) -> str | None:
        if event.keysym == "Escape":
            self._on_close()
            return "break"
        return None
