"""
Master creation / alteration forms on the white canvas (Masters › Create / Alter):

    Stock Group         Name, Under (Primary or a stock group), Should quantities of items be ADDED?
    Unit                Type (Simple / Compound), Symbol, Formal Name, Number of decimal places;
                        Compound also: First unit, Conversion, Second unit
    Stock Item          Name, Alias, Under, Units, GST Applicable, GST Classification,
                        Opening Quantity, Rate per unit, Value (worked out)

    Group               Group Name, Under (one of the 28 reserved groups or a group you made)
    Ledger              Name, Under, Mailing Details (Name, Address, State),
                        Tax Information (PAN/IT No., GSTIN/UIN), Opening Balance + Dr/Cr
    GST Classification  Classification Name, HSN/SAC, GST Rate, Cess Type

Keyboard (Tally style; Tab does the same as Enter):
    Enter        checks the field and moves to the next one; on the last field it saves
    Esc          from ANY field (focus inside an entry box included): closes the form, clears the
                 canvas and gives the keyboard back to the Corridor. If something is typed and not
                 saved it asks once first (Yes closes, No stays).
    Shift+Tab    one field back (fast corrections)
    Up / Down    in a field with a list (Under, State, GST Rate, Cess Type, Dr/Cr): choose
    Typing       filters the list on the right; Enter takes the highlighted or the only match

Saving runs in a background thread (services/masters.py checks everything again and writes
in one transaction), so the window never freezes. After a save the form clears for the next
master (Create) or goes back to the name (Alter). Alter: the first field lists the masters of
that kind; Enter loads the chosen one (its name is fixed; everything else can change).
"""
from __future__ import annotations

import tkinter as tk
from dataclasses import dataclass, replace
from tkinter import messagebox
from typing import Callable

from components.ledger_list import LedgerListPanel
from config import theme as T
from config.settings import GST_RATES
from services.background import run_in_background
from services.gst import STATE_NAMES
from services.inventory_masters import PRIMARY, UNIT_TYPES
from services.masters import CESS_TYPES, MasterError, MasterStore
from views.report_common import title_bar


@dataclass
class Field:
    key: str
    label: str
    kind: str = "text"            # text | choice | amount | side | yesno | int | computed
    width: int = 34
    section: str = ""             # heading shown above this field
    choices: str = ""             # catalogue name for choice fields
    required: bool = False
    default: str = ""
    skip: Callable[[dict], bool] | None = None    # True: Enter / Esc pass over this field


FORMS: dict[str, list[Field]] = {
    "Group": [
        Field("name", "Group Name", required=True),
        Field("under", "Under", kind="choice", choices="groups", required=True),
    ],
    "Ledger": [
        Field("name", "Ledger Name", required=True),
        Field("under", "Under", kind="choice", choices="groups", required=True),
        Field("mailing_name", "Name", section="Mailing Details"),
        Field("address", "Address", width=46),
        Field("state", "State", kind="choice", choices="states", default="West Bengal"),
        Field("pan", "PAN/IT No.", width=14, section="Tax Information"),
        Field("gstin", "GSTIN/UIN", width=18),
        Field("opening", "Opening Balance", kind="amount", width=16, section="Opening Balance"),
        Field("drcr", "Dr / Cr", kind="side", width=5, default="Dr"),
    ],
    "GST Classification": [
        Field("name", "Classification Name", required=True),
        Field("hsn", "HSN/SAC Code", width=12, required=True),
        Field("rate", "GST Rate (%)", kind="choice", choices="rates", width=8, required=True),
        Field("cess", "Cess Type", kind="choice", choices="cess", width=28, default="None"),
    ],
}
FORMS["Stock Group"] = [
    Field("name", "Stock Group Name", required=True),
    Field("under", "Under", kind="choice", choices="stock_groups", default=PRIMARY, required=True),
    Field("add", "Should quantities of items be ADDED?", kind="yesno", width=5, default="Yes"),
]
_simple = lambda v: v.get("type", "Simple").lower() != "compound"      # noqa: E731
FORMS["Unit"] = [
    Field("type", "Type", kind="choice", choices="unit_types", width=12, default="Simple", required=True),
    Field("symbol", "Symbol", width=14),
    Field("formal", "Formal Name"),
    Field("decimals", "Number of decimal places (0 to 4)", kind="int", width=4, default="0",
          skip=lambda v: not _simple(v)),
    Field("first", "First unit", kind="choice", choices="simple_units", width=14, section="Compound unit",
          skip=_simple),
    Field("conversion", "Conversion (Second units in one First)", kind="amount", width=10, skip=_simple),
    Field("second", "Second unit", kind="choice", choices="simple_units", width=14, skip=_simple),
]
FORMS["Stock Item"] = [
    Field("name", "Stock Item Name", required=True),
    Field("alias", "Alias"),
    Field("under", "Under", kind="choice", choices="stock_groups", default=PRIMARY, required=True),
    Field("unit", "Units", kind="choice", choices="units", width=16, required=True),
    Field("gst", "GST Applicable", kind="yesno", width=5, default="Yes", section="Statutory Details"),
    Field("classification", "GST Classification", kind="choice", choices="classifications",
          skip=lambda v: v.get("gst", "Yes") == "No"),
    Field("qty", "Opening Quantity", kind="int", width=12, section="Opening Balance"),
    Field("rate", "Rate per unit (INR)", kind="amount", width=14),
    Field("value", "Value (INR)", kind="computed", width=16),
]
FORMS["Currency"] = [
    Field("code", "Currency Code (USD, EUR …)", width=6, required=True),
    Field("name", "Formal Name", required=True),
    Field("symbol", "Symbol", width=6),
]
FORMS["Stock Category"] = [
    Field("name", "Stock Category Name", required=True),
    Field("under", "Under", kind="choice", choices="stock_categories", default=PRIMARY, required=True),
]
FORMS["Godown"] = [
    Field("name", "Godown Name", required=True),
    Field("under", "Under", kind="choice", choices="godowns", default=PRIMARY, required=True),
    Field("address", "Address", width=46),
]
SAVERS = {"Group": "save_group", "Ledger": "save_ledger", "GST Classification": "save_classification",
          "Stock Group": "save_stock_group", "Unit": "save_unit", "Stock Item": "save_stock_item",
          "Currency": "save_currency", "Stock Category": "save_stock_category", "Godown": "save_godown"}
EXISTING = {"Group": "custom_groups", "Ledger": "ledger_names", "GST Classification": "classification_names",
            "Stock Group": "stock_group_names", "Unit": "unit_names", "Stock Item": "item_names",
            "Currency": "currency_names", "Stock Category": "stock_category_names", "Godown": "godown_names"}
NAME_KEY = {"Unit": "symbol"}          # the field that names the master (picked first in Alter)
# Lists filled from the database in the background: catalogue name -> store method.
LOADERS = {"groups": "group_catalogue", "stock_groups": "stock_group_catalogue",
           "stock_categories": "stock_category_catalogue", "godowns": "godown_catalogue",
           "units": "unit_names", "simple_units": "simple_units", "classifications": "classification_names"}
TITLES = {"groups": "List of Groups", "states": "List of States", "rates": "GST Rates", "cess": "Cess Types",
          "stock_groups": "List of Stock Groups", "units": "List of Units", "simple_units": "Simple Units",
          "classifications": "GST Classifications", "unit_types": "Types of Unit",
          "stock_categories": "List of Stock Categories", "godowns": "List of Godowns"}


class MasterFormView(tk.Frame):
    def __init__(self, parent: tk.Widget, *, kind: str, alter: bool, store: MasterStore,
                 on_close: Callable[[], None], on_saved: Callable[[str], None] | None = None,
                 on_note: Callable[[str], None] | None = None) -> None:
        super().__init__(parent, bg=T.WHITE)
        self.kind, self.alter, self._store = kind, alter, store
        self._on_close = on_close
        self._on_saved = on_saved or (lambda _m: None)
        self._on_note = on_note or (lambda _m: None)      # the window's status bar
        self._fields = [replace(f) for f in FORMS[kind]]     # copies: Alter changes the first one
        if alter and kind in NAME_KEY:                         # Alter starts on the master's name
            named = next(f for f in self._fields if f.key == NAME_KEY[kind])
            self._fields.remove(named)
            self._fields.insert(0, named)
            named.section = ""
        self._entries: dict[str, tk.Entry] = {}
        self._catalogues: dict[str, list] = {
            "states": [("States and union territories", list(STATE_NAMES.values()))],
            "rates": [("GST rates (%)", list(GST_RATES))],
            "cess": [("Cess Type", list(CESS_TYPES))],
            "unit_types": [("Type", list(UNIT_TYPES))],
            "groups": [], "existing": [], "stock_groups": [("Primary", [PRIMARY])], "units": [],
            "simple_units": [], "classifications": [],
        }
        self._saving = False
        self._loaded = not alter                 # Alter: nothing to save until a master is loaded

        title_bar(self, f"{kind} {'Alteration' if alter else 'Creation'}", "Enter next    Esc back one field")
        body = tk.Frame(self, bg=T.WHITE)
        body.pack(side="top", fill="both", expand=True)
        form = tk.Frame(body, bg=T.WHITE)
        form.pack(side="left", fill="both", expand=True, padx=24, pady=16)
        self._list = LedgerListPanel(body, on_pick=self._pick)
        self._list.pack_before = form

        grid = tk.Frame(form, bg=T.WHITE)
        grid.pack(side="top", anchor="nw")
        row = 0
        for f in self._fields:
            if f.section:
                tk.Label(grid, text=f.section.upper(), bg=T.WHITE, fg=T.MUTED, font=T.F_HINT, anchor="w").grid(
                    row=row, column=0, columnspan=2, sticky="w", pady=(14, 2))
                row += 1
            tk.Label(grid, text=f.label, bg=T.WHITE, fg=T.TEXT, font=T.F_LABEL, anchor="w").grid(
                row=row, column=0, sticky="w", pady=3, padx=(0, 14))
            e = tk.Entry(grid, width=f.width, font=T.F_GRID, relief="flat", bd=0, highlightthickness=1,
                         highlightbackground=T.LINE, highlightcolor=T.ORANGE, readonlybackground=T.ROW_ALT,
                         justify="right" if f.kind in ("amount", "int", "computed")
                         else "center" if f.kind in ("side", "yesno") else "left")
            e.grid(row=row, column=1, sticky="w", pady=3, ipady=3)
            e.insert(0, f.default)
            e.bind("<FocusIn>", lambda _e, fl=f: self._focused(fl), add="+")
            e.bind("<KeyRelease>", lambda ev, fl=f: self._typed(fl, ev), add="+")
            if f.kind in ("side", "yesno"):
                e.bind("<KeyPress>", self._side_key)
            if f.kind == "computed":
                e.configure(state="readonly", takefocus=0)
            if f.key in ("gstin", "hsn"):                 # structure check when the cursor leaves
                e.bind("<FocusOut>", lambda _e, k=f.key: self._structure_check(k), add="+")
            self._entries[f.key] = e
            row += 1
        if alter:
            self._fields[0].kind = "choice"     # Alter: the name is picked from the masters of this kind
            self._fields[0].choices = "existing"

        self._badge = tk.Label(form, bg=T.WHITE, fg=T.WHITE, font=T.F_LABEL, anchor="w", padx=8)
        self._badge_detail = tk.Label(form, bg=T.WHITE, fg=T.TEXT, font=T.F_HINT, anchor="w", justify="left",
                                      wraplength=560)
        self._status = tk.Label(form, bg=T.WHITE, fg=T.BAD_RED, font=T.F_LABEL, anchor="w", justify="left",
                                wraplength=560)
        self._status.pack(side="top", fill="x", pady=(16, 0))
        tk.Label(form, text="Enter on the last field saves.", bg=T.WHITE, fg=T.MUTED, font=T.F_HINT,
                 anchor="w").pack(side="top", fill="x", pady=(4, 0))
        self._load_catalogues()

    # ---- data --------------------------------------------------------------------------
    def _load_catalogues(self) -> None:
        wanted = {f.choices for f in self._fields if f.choices in LOADERS}

        def work():
            out = {}
            for name in wanted:
                if hasattr(self._store, LOADERS[name]):
                    got = getattr(self._store, LOADERS[name])()
                    out[name] = got if (got and isinstance(got[0], tuple)) else (
                        [(TITLES[name].replace("List of ", ""), list(got))] if got else [])
            existing = getattr(self._store, EXISTING[self.kind])()
            names = sorted(existing, key=str.lower)
            plural = self.kind[:-1] + "ies" if self.kind.endswith("y") else self.kind + "s"
            out["existing"] = [(plural, names)] if names else []
            return out

        def done(result) -> None:
            if "stock_groups" in result and not result["stock_groups"]:
                result["stock_groups"] = [("Primary", [PRIMARY])]
            self._catalogues.update(result)
            f = self._field_of(self.focus_get())
            if f is not None and f.kind == "choice":
                self._focused(f)

        run_in_background(self, work, done, lambda exc: self._say(f"Lists not loaded: {exc}"))

    def values(self) -> dict[str, str]:
        return {k: e.get().strip() for k, e in self._entries.items()}

    # ---- public (window) ---------------------------------------------------------------
    def focus_first(self) -> None:
        self._entries[self._fields[0].key].focus_set()

    def can_close(self) -> bool:
        typed = any(v and v != f.default for f, v in zip(self._fields, self.values().values()))
        return not typed or messagebox.askyesno("Quit?", f"The {self.kind} typed here is not saved.\n\nClose anyway?",
                                                default="no", parent=self)

    def request_close(self) -> None:
        if self.can_close():
            self._on_close()

    def handle_key(self, event: tk.Event) -> str | None:
        keysym = event.keysym
        if event.state & (T.MOD_CTRL | T.MOD_ALT):
            return None
        f = self._field_of(event.widget)
        if keysym == "Escape":                   # from any field: leave the form (no field-by-field trap)
            self.exit_to_corridor()
            return "break"
        if keysym == "ISO_Left_Tab" or (keysym == "Tab" and event.state & 0x0001):
            self.back(f)                         # Shift+Tab = one field back
            return "break"
        if keysym in ("Return", "KP_Enter", "Tab"):
            if f is not None:
                self.advance(f)
            return "break"
        if keysym in ("Up", "Down") and f is not None and f.kind == "choice" and self._list.visible:
            self._list.move(-1 if keysym == "Up" else 1)
            return "break"
        if keysym in ("Up", "Down") and f is not None and f.kind in ("side", "yesno"):
            self._toggle_side(event.widget)
            return "break"
        return None

    # ---- moving --------------------------------------------------------------------------
    def _field_of(self, widget) -> Field | None:
        return next((f for f in self._fields if self._entries[f.key] is widget), None)

    def _index(self, f: Field) -> int:
        return self._fields.index(f)

    def advance(self, f: Field) -> None:
        """Enter: check this field, then the next one (or save on the last)."""
        if self._saving:
            return
        message = self._check(f)
        if message:
            self._say(message)
            return
        self._say("")
        if self.alter and self._index(f) == 0 and not self._loaded:
            self._load_existing()
            return
        nxt = self._neighbour(f, +1)
        if nxt is not None:
            self._entries[nxt.key].focus_set()
        else:
            self.save()

    def _active(self, f: Field) -> bool:
        """Fields Enter / Esc stop at: not worked-out ones, not ones this master does not need."""
        return f.kind != "computed" and not (f.skip and f.skip(self.values()))

    def _neighbour(self, f: Field, step: int) -> Field | None:
        i = self._index(f) + step
        while 0 <= i < len(self._fields):
            if self._active(self._fields[i]):
                return self._fields[i]
            i += step
        return None

    def exit_to_corridor(self) -> None:
        """Esc: close the form from wherever the cursor is. The window then destroys this screen and
        focuses the Corridor (close_view). Typed, unsaved values: ask once first."""
        self._list.hide()
        self.request_close()

    def back(self, f: Field | None) -> None:
        """Shift+Tab: one field back; on the first field, close the form (back to the Corridor)."""
        prev = None if f is None else self._neighbour(f, -1)
        if prev is None:
            self._list.hide()
            self.request_close()
            return
        self._entries[prev.key].focus_set()

    # ---- checking each field -------------------------------------------------------------
    def _check(self, f: Field) -> str:
        e = self._entries[f.key]
        text = e.get().strip()
        if f.kind == "choice":
            catalogue = self._catalogues.get(f.choices, [])
            names = [n for _c, ns in catalogue for n in ns]
            exact = next((n for n in names if n.lower() == text.lower()), None)
            if exact is None and self._list.visible:
                exact = self._list.choice(text)
            if exact is None and text and f.choices == "rates":
                exact = next((n for n in names if n == text.rstrip("%").strip()), None)
            if exact is not None:
                self._set(e, exact)
                text = exact
            elif text:
                return f"'{text}' is not in the list for {f.label}: choose from the list on the right."
        if not self._active(f):
            return ""
        if f.required and not text:
            return f"Enter the {f.label}."
        if f.kind == "yesno":
            if text.title() not in ("Yes", "No", "Y", "N"):
                return f"{f.label}: Yes or No."
            self._set(e, "Yes" if text.title() in ("Yes", "Y") else "No")
        if f.kind == "int" and text:
            raw = text.replace(",", "")
            if not raw.isdigit():
                return f"{f.label} must be a whole number."
            if f.key == "decimals" and int(raw) > 4:
                return "Number of decimal places must be from 0 to 4."
            self._set(e, str(int(raw)))
        if f.kind == "amount" and text:
            try:
                from services.masters import parse_opening
                value = parse_opening(text)
                self._set(e, f"{value:,.2f}")
            except MasterError as exc:
                return str(exc)
        if f.key in ("pan", "gstin") and text:
            self._set(e, text.upper().replace(" ", ""))
        return ""

    @staticmethod
    def _set(e: tk.Entry, text: str) -> None:
        state = e.cget("state")
        e.configure(state="normal")
        e.delete(0, "end")
        e.insert(0, text)
        e.configure(state=state)

    # ---- lists ---------------------------------------------------------------------------
    def _focused(self, f: Field) -> None:
        if f.kind == "choice":
            title = f"List of {self.kind}s" if f.choices == "existing" else TITLES.get(f.choices, "List")
            self._list.set_title(title)
            self._list.set_catalogue(self._catalogues.get(f.choices, []))
            self._list_field = f
            fixed = f.choices in ("rates", "cess", "unit_types", "stock_groups") and \
                self._entries[f.key].get() == f.default
            self._list.show(text="" if fixed else self._entries[f.key].get())
        else:
            self._list.hide()

    def _typed(self, f: Field, event: tk.Event) -> None:
        if f.kind == "choice" and event.keysym not in ("Up", "Down", "Return", "KP_Enter", "Escape", "Tab"):
            self._list.filter(self._entries[f.key].get())
        if f.key in ("qty", "rate") and "value" in self._entries:
            self._refresh_value()

    def _refresh_value(self) -> None:
        """Value = Opening Quantity x Rate, shown as it is typed (not editable)."""
        from decimal import Decimal, InvalidOperation
        try:
            qty = int(self._entries["qty"].get().replace(",", "").strip() or "0")
            rate = Decimal(self._entries["rate"].get().replace(",", "").strip() or "0")
            text = f"{(rate * qty).quantize(Decimal('0.01')):,.2f}" if qty and rate else ""
        except (ValueError, InvalidOperation):
            text = ""
        self._set(self._entries["value"], text)

    def _pick(self, name: str) -> None:
        f = getattr(self, "_list_field", None)
        if f is not None:
            self._set(self._entries[f.key], name)
            self._entries[f.key].focus_set()

    def _side_key(self, event: tk.Event) -> str | None:
        ch = event.keysym.lower()
        f = self._field_of(event.widget)
        if f is not None and f.kind == "yesno":
            if ch in ("y", "n"):
                self._set(event.widget, "Yes" if ch == "y" else "No")
                return "break"
            if ch == "space":
                self._toggle_side(event.widget)
                return "break"
            return "break" if len(event.keysym) == 1 else None
        if ch in ("d", "c"):
            self._set(event.widget, "Dr" if ch == "d" else "Cr")
            return "break"
        if ch == "space":
            self._toggle_side(event.widget)
            return "break"
        if len(event.keysym) == 1:
            return "break"                       # only Dr / Cr can be typed here
        return None

    def _toggle_side(self, e: tk.Entry) -> None:
        flips = {"Dr": "Cr", "Cr": "Dr", "Yes": "No", "No": "Yes"}
        self._set(e, flips.get(e.get().strip(), "Dr"))

    # ---- Alter: load ---------------------------------------------------------------------
    def _load_existing(self) -> None:
        name = self._entries[self._fields[0].key].get().strip()
        self._say("Loading…", T.MUTED)
        run_in_background(self, lambda: self._store.load(self.kind, name), self._loaded_values,
                          lambda exc: self._say(f"Could not load {name}: {exc}"))

    def _loaded_values(self, values: dict | None) -> None:
        if not values:
            self._say(f"No {self.kind} with that name.")
            return
        for f in self._fields:
            self._set(self._entries[f.key], values.get(f.key, "") or f.default)
        self._entries[self._fields[0].key].configure(state="readonly")    # names are not changed here
        self._loaded = True
        self._say("")
        if "value" in self._entries:
            self._refresh_value()
        nxt = self._neighbour(self._fields[0], +1)
        if nxt is not None:
            self._entries[nxt.key].focus_set()

    # ---- saving --------------------------------------------------------------------------
    def save(self) -> None:
        for f in self._fields:                                   # every field, not only the last
            message = self._check(f)
            if message:
                self._say(message)
                self._entries[f.key].focus_set()
                return
        if not self._loaded:
            self._say(f"Choose the {self.kind} to alter first.")
            return
        values = self.values()
        saver = getattr(self._store, SAVERS[self.kind])
        self._saving = True
        self._say("Saving…", T.MUTED)
        run_in_background(self, lambda: saver(values, alter=self.alter), self._saved, self._failed)

    def _saved(self, message: str) -> None:
        self._saving = False
        self._on_saved(message)
        for f in self._fields:
            e = self._entries[f.key]
            e.configure(state="normal")
            self._set(e, f.default)
            if f.kind == "computed":
                e.configure(state="readonly")
        self._loaded = not self.alter
        self._say(message + ("  Next one:" if not self.alter else ""), T.OK_GREEN)
        self._load_catalogues()
        self.focus_first()

    # ---- GSTIN / HSN structure check (background; no portal call) ----------------------------
    def _structure_check(self, key: str) -> None:
        from services.gst_check import check_gstin_structure, check_hsn_structure
        text = self._entries[key].get()
        if not text.strip():
            self._badge.pack_forget()
            self._badge_detail.pack_forget()
            return
        work = (lambda: check_gstin_structure(text)) if key == "gstin" else (lambda: check_hsn_structure(text))
        run_in_background(self, work, self._show_check, lambda exc: None)

    def _show_check(self, result) -> None:
        if not result.badge:
            return
        colour = T.OK_GREEN if result.ok else T.BAD_RED
        mark = "✓ " if result.ok else "✗ "
        self._badge.configure(text=mark + result.badge, bg=colour)
        self._badge_detail.configure(text=result.detail)
        self._badge.pack(side="top", anchor="w", pady=(12, 0), before=self._status)
        self._badge_detail.pack(side="top", fill="x", pady=(2, 0), before=self._status)
        self._on_note(f"[{self.kind}] {mark}{result.badge}: {result.detail}")

    def _failed(self, exc: Exception) -> None:
        self._saving = False
        self._say(str(exc) if isinstance(exc, MasterError) else f"Not saved: {exc}")

    def _say(self, text: str, colour: str = T.BAD_RED) -> None:
        self._status.configure(text=text, fg=colour)
