"""
Accounting Voucher Creation — full-width entry screen on the white canvas, in two modes
(Ctrl+H, or "Ctrl+H: Change Mode" on the action bar, opens the Change Voucher Mode box).

Single Entry (Payment, Receipt, Contra; the default)
    +--------------------------------------------------------+----------------------+
    | [Payment]  No. 3   Single Entry     Date 09-10-2026 Fri | List of Ledger       |
    | Account: [ HDFC Bank                            ]       | Accounts             |
    |          credited with the total (money goes out)       |  CASH-IN-HAND        |
    | Particulars                              | Amount       |    Cash              |
    | Office Rent                              | 25,000.00    |  BANK ACCOUNTS       |
    | Electricity                              |  3,200.00    |    HDFC Bank         |
    |                                    Total | 28,200.00    |  SUNDRY DEBTORS …    |
    | Narration: ...                                          |                      |
    +--------------------------------------------------------+----------------------+
    Saved as Dr Office Rent 25,000, Dr Electricity 3,200, Cr HDFC Bank 28,200
    (the Account's side per type: config/settings.py, SINGLE_ENTRY_ACCOUNT_SIDE).

Double Entry (every type; Journal, Sales, Purchase and the notes always use it)
    | Dr/Cr | Particulars                    | Debit     | Credit    |
    |  Dr   | Office Rent                    | 25,000.00 |           |
    |  Cr   | HDFC Bank                      |           | 25,000.00 |
    On the Dr/Cr cell: D or B (By) = Dr, C or T (To) = Cr, Space toggles.

The List of Ledger Accounts panel opens whenever the cursor is in a ledger field and lists
the ledgers from config/ledger_groups.py, saved vouchers, corporate_ledger_summary and
gst_sales_ledger (services/ledgers.py, read in a background thread). Typing filters it,
Up / Down pick a name, Enter uses it. A new name can still be typed.

Keys
    F4 – F9      voucher type; Ctrl+F8 Credit Note, Ctrl+F9 Debit Note — on the action bar
                 (the Corridor's Vouchers submenu opens any type directly)
    Ctrl+H       Change Voucher Mode box: Up / Down, Enter (or the bold letter), Esc closes
    Enter        next field; after the last line a new line opens (Double Entry: with the
                 balancing side and amount); an empty Particulars on a complete voucher moves
                 to Narration
    Ctrl+A       accept (also Enter on Narration)
    F12          the right-hand action bar takes the keyboard: Up / Down move through Contra …
                 Purchase, Credit / Debit Note, Change Mode, More Details, Accept; Enter runs the
                 highlighted one; Esc / F12 return to the field you were in
    Esc          closes an open box / card / drawer first; otherwise goes back ONE field (fast
                 corrections, the screen stays open). On the first field (the date) it leaves the
                 voucher, asking first if anything is typed. Tab = Enter, Shift+Tab = Esc.
    Enter        also checks the field (date, amount, quantity, GST fields): a wrong value keeps
                 the cursor where it is, with the reason underneath.

Per type:
    Journal      Double Entry, with the side cell reading By (= Dr) / To (= Cr)
    Sales        Party A/c name (the customer debited; GST is recorded for it) and Name of Item
    Purchase     Supplier Invoice No. and Date (kept with the voucher, shown in the Day Book)
    Credit Note  soft pink background; Debit Note soft yellow (config/settings.py, VOUCHER_TINTS)

Foreign currency (Single Entry, Double Entry and Accounting Invoice; config FOREX_ENABLED)
    | Currency [USD]   1 USD = ₹83.25   Amounts below are in USD · ₹ total 99,900.00 |
    The Currency field follows the date (and the Party / supplier fields). INR or blank = rupees,
    Enter moves on. Any other code opens the inline Exchange Rate box (components/currency_box.py):
    Up / Down picks the currency, type the rate (₹ for 1 unit; the last rate used is offered),
    Enter accepts, Esc closes it and changes nothing. An amount typed as "USD 1,200" or "$1,200"
    does the same. Lines are typed in the currency; a "₹ Value" column shows each line in rupees.
    On Accept every line is converted (services/forex.py) and the RUPEE amounts are saved in
    bp_voucher_lines, so the books, reports and GST registers stay in INR; the foreign amounts
    and the rate go to bp_voucher_forex. The Sales GST panel is always in rupees.

Cost centres (config COST_CENTRE_GROUPS, COST_CENTRES)
    Enter on the amount of a DEBIT line whose ledger is an expense or purchase ledger (Direct /
    Indirect Expenses, Purchase Accounts) slides out the Cost Centre Allocation box under the line
    (components/allocation_box.py): split the amount across departments, projects or branches by %
    or by amount. An empty Cost Centre finishes (with nothing typed the line stays unsplit); Esc
    closes the box and the line keeps the split it had. Single Entry, Double Entry and Accounting
    Invoice lines; saved to bp_cost_allocations; Cost Centre Summary in Display More Reports.

Saved vouchers (Day Book / Ledger Statement drill-down opens them here for alteration)
    Alt+2        duplicate: a new voucher of the same type with the same ledgers, amounts, GST
                 and details, under the next voucher number (Day Book rows too)
    Alt+X        cancel: asks first; the voucher becomes Cancelled, keeps its number (no unused
                 number in the series) and leaves the books, reports and GST registers

Sales vouchers also show a GST panel (customer GSTIN, place of supply, HSN/SAC, GST rate,
taxable value) for the gst_sales_ledger row. The customer is the first Dr line. The place of
supply (filled in from the GSTIN, or West Bengal 19 for an unregistered customer) decides the
tax: 19 -> CGST + SGST, any other state -> IGST. The invoice value must match the voucher total
within the round-off limit.

Amounts use Decimal (never float) and are shown with Indian digit grouping. Both modes hand
the same voucher (Dr / Cr lines) to `on_accept(voucher)`, which saves it and returns True; the
screen clears only after a successful save, so nothing typed is lost if saving fails.
"""
from __future__ import annotations

import tkinter as tk
from datetime import date, datetime
from decimal import Decimal, InvalidOperation
from tkinter import messagebox
from typing import Callable

from components.allocation_box import AllocationBox
from components.currency_box import CurrencyBox
from components.details_card import DetailsCard
from components.ledger_list import LedgerListPanel
from components.voucher_drawer import UtilitiesDrawer
from components.macro_bar import Macro
from config import theme as T
from config import settings as S
from config.settings import (COST_CENTRES, CURRENCIES,
                             DEFAULT_INVOICE_MODE,
                             DEFAULT_UNIT, DEFAULT_VOUCHER_MODE, DETAIL_FORMS, FOREX_ENABLED, GST_RATES, INVOICE_MODES,
                             INVOICE_TYPES, ITEM_INVOICE_LEDGER, NOTE_VOUCHER_TYPES, OUTPUT_TAX_LEDGERS,
                             PARTY_SIDE, ROUND_OFF_LIMIT, SIDE_WORDS, SINGLE_ENTRY_ACCOUNT_SIDE,
                             SINGLE_ENTRY_TYPES, VOUCHER_MODES, VOUCHER_TINTS, VOUCHER_TYPES)
from services.background import run_in_background
from services.cost_centres import check as check_allocations
from services.cost_centres import rescale
from services.forex import BASE, convert_lines, normal_code, rate_text, split_designator, to_base
from services.gst import check_gstin, check_hsn, check_state_code, tax_for

CENT = Decimal("0.01")
MAX_AMOUNT = Decimal("999999999999.99")
DATE_FMT = "%d-%m-%Y"
START_ROWS = 2
SINGLE, DOUBLE = "Single Entry", "Double Entry"
ITEM_INV, ACC_INV, AS_VOUCHER = "Item Invoice", "Accounting Invoice", "As Voucher"
REGULAR, OPTIONAL, POST_DATED, CANCELLED = "Regular", "Optional", "Post-Dated", "Cancelled"
POST_DATED_TYPES = ("Payment", "Receipt", "Contra", "Journal")
CASH_BANK = ("Cash-in-Hand", "Bank Accounts", "Bank OD A/c")
TINTABLE = {T.WHITE} | set(VOUCHER_TINTS.values())      # backgrounds that follow the voucher tint

# Side of the first line for each voucher type (later lines default to the balancing side).
FIRST_SIDE = {
    "Contra": "Cr", "Payment": "Dr", "Receipt": "Cr", "Journal": "Dr",
    "Sales": "Dr", "Purchase": "Cr", "Credit Note": "Dr", "Debit Note": "Cr",
}


def parse_amount(text: str) -> Decimal | None:
    """'' -> None; '1,25,000.5' -> Decimal('125000.50'). Raises ValueError if not a valid amount."""
    raw = text.replace(",", "").replace("₹", "").strip()
    if not raw:
        return None
    try:
        value = Decimal(raw)
    except InvalidOperation:
        raise ValueError(f"'{text}' is not an amount") from None
    if not value.is_finite() or value < 0 or value > MAX_AMOUNT:
        raise ValueError(f"'{text}' is not an amount")
    if value != value.quantize(CENT):
        raise ValueError(f"'{text}' has more than 2 decimal places")
    return value.quantize(CENT)


def fmt_inr(value: Decimal) -> str:
    """Decimal('1234567.5') -> '12,34,567.50' (Indian grouping)."""
    q = value.quantize(CENT)
    sign = "-" if q < 0 else ""
    whole, frac = f"{abs(q):.2f}".split(".")
    if len(whole) > 3:
        head, tail = whole[:-3], whole[-3:]
        groups = []
        while len(head) > 2:
            groups.insert(0, head[-2:])
            head = head[:-2]
        if head:
            groups.insert(0, head)
        whole = ",".join(groups + [tail])
    return f"{sign}{whole}.{frac}"


class _FieldError(Exception):
    def __init__(self, message: str, widget: tk.Widget) -> None:
        super().__init__(message)
        self.message = message
        self.widget = widget


class _Line:
    """One Dr/Cr line of the grid."""

    def __init__(self, view: "VoucherView", parent: tk.Frame, row: int, side: str) -> None:
        self.side = tk.StringVar(value=side)             # always "Dr" / "Cr" inside the program
        self.side_text = tk.StringVar()                  # what the cell shows: Dr / Cr, or By / To
        self.side.trace_add("write", lambda *_a: self.side_text.set(view.side_word(self.side.get())))
        self.side_text.set(view.side_word(side))
        cell = dict(relief="flat", bd=0, highlightthickness=1, highlightbackground=T.CELL_LINE,
                    highlightcolor=T.ORANGE, font=T.F_GRID, bg=T.WHITE, fg=T.TEXT,
                    disabledbackground=T.ROW_ALT, readonlybackground=T.WHITE)
        self.side_entry = tk.Entry(parent, textvariable=self.side_text, width=4, justify="center",
                                   state="readonly", cursor="hand2", **cell)
        self.ledger = tk.Entry(parent, **cell)
        amount = dict(cell, font=T.F_AMOUNT, justify="right", width=16)
        self.debit = tk.Entry(parent, **amount)
        self.credit = tk.Entry(parent, **amount)

        for col, w in enumerate((self.side_entry, self.ledger, self.debit, self.credit)):
            w.grid(row=row, column=col, sticky="ew", padx=1, pady=1, ipady=T.CELL_PAD_Y)
            w.bind("<FocusIn>", lambda _e, wid=w: view._on_focus(self, wid), add="+")
            view._guard(w)
        self.allocations: list[dict] = []                 # cost centre shares of this line
        self.inr = tk.Label(parent, bg=T.WHITE, fg=T.MUTED, font=T.F_AMOUNT, anchor="e", width=14, padx=6)
        self.inr.grid(row=row, column=4, sticky="ew", padx=1, pady=1)
        if not view.is_forex:
            self.inr.grid_remove()
        self.ledger.bind("<KeyRelease>", lambda e: view._ledger_typed(e), add="+")
        self.side_entry.bind("<KeyPress>", lambda e: view._on_side_key(self, e))
        self.side_entry.bind("<Button-1>", lambda _e: view._toggle_side(self))
        for w in (self.debit, self.credit):
            w.bind("<KeyRelease>", lambda _e: view._refresh_totals(), add="+")
            w.bind("<FocusOut>", lambda _e, wid=w: view._tidy_amount(wid), add="+")
        self.apply_side()

    @property
    def widgets(self) -> tuple[tk.Entry, ...]:
        return (self.side_entry, self.ledger, self.debit, self.credit)

    @property
    def amount_entry(self) -> tk.Entry:
        return self.debit if self.side.get() == "Dr" else self.credit

    def apply_side(self) -> None:
        """Only the amount column of the chosen side can be typed into."""
        keep, other = (self.debit, self.credit) if self.side.get() == "Dr" else (self.credit, self.debit)
        moved = other.get() if other.cget("state") == "normal" else ""
        keep.configure(state="normal")
        if moved and not keep.get():
            keep.insert(0, moved)
        other.configure(state="normal")
        other.delete(0, "end")
        other.configure(state="disabled")

    def amount(self) -> Decimal | None:
        """Raises ValueError for an invalid amount."""
        return parse_amount(self.amount_entry.get())

    def used(self) -> bool:
        return bool(self.ledger.get().strip() or self.amount_entry.get().strip())

    def clear(self, side: str) -> None:
        self.allocations = []
        self.ledger.delete(0, "end")
        for w in (self.debit, self.credit):
            w.configure(state="normal")
            w.delete(0, "end")
        self.side.set(side)
        self.apply_side()

    def destroy(self) -> None:
        for w in self.widgets:
            w.destroy()
        self.inr.destroy()


class _SingleLine:
    """One Particulars | Amount line of the Single Entry grid."""

    def __init__(self, view: "VoucherView", parent: tk.Frame, row: int) -> None:
        cell = dict(relief="flat", bd=0, highlightthickness=1, highlightbackground=T.CELL_LINE,
                    highlightcolor=T.ORANGE, font=T.F_GRID, bg=T.WHITE, fg=T.TEXT)
        self.ledger = tk.Entry(parent, **cell)
        self.amount_entry = tk.Entry(parent, **dict(cell, font=T.F_AMOUNT, justify="right", width=18))
        self.ledger.grid(row=row, column=0, sticky="ew", padx=1, pady=1, ipady=T.CELL_PAD_Y)
        self.amount_entry.grid(row=row, column=1, sticky="ew", padx=1, pady=1, ipady=T.CELL_PAD_Y)
        self.allocations: list[dict] = []                 # cost centre shares of this line
        self.inr = tk.Label(parent, bg=T.WHITE, fg=T.MUTED, font=T.F_AMOUNT, anchor="e", width=14, padx=6)
        self.inr.grid(row=row, column=2, sticky="ew", padx=1, pady=1)
        if not view.is_forex:
            self.inr.grid_remove()
        for w in self.widgets:
            w.bind("<FocusIn>", lambda _e, wid=w: view._on_single_focus(wid), add="+")
            view._guard(w)
        self.ledger.bind("<KeyRelease>", lambda e: view._ledger_typed(e), add="+")
        self.amount_entry.bind("<KeyRelease>", lambda _e: view._refresh_single_total(), add="+")
        self.amount_entry.bind("<FocusOut>", lambda _e: view._tidy_amount(self.amount_entry), add="+")

    @property
    def widgets(self) -> tuple[tk.Entry, ...]:
        return (self.ledger, self.amount_entry)

    def amount(self) -> Decimal | None:
        return parse_amount(self.amount_entry.get())

    def used(self) -> bool:
        return bool(self.ledger.get().strip() or self.amount_entry.get().strip())

    def destroy(self) -> None:
        for w in self.widgets:
            w.destroy()
        self.inr.destroy()


class _ItemLine:
    """One Name of Item | Quantity | Rate | per | Amount line of the Item Invoice grid."""

    def __init__(self, view: "VoucherView", parent: tk.Frame, row: int) -> None:
        cell = dict(relief="flat", bd=0, highlightthickness=1, highlightbackground=T.CELL_LINE,
                    highlightcolor=T.ORANGE, font=T.F_GRID, bg=T.WHITE, fg=T.TEXT, readonlybackground=T.ROW_ALT)
        self.item = tk.Entry(parent, **cell)
        self.qty = tk.Entry(parent, **dict(cell, justify="right", width=9))
        self.rate = tk.Entry(parent, **dict(cell, justify="right", width=12))
        self.per = tk.Entry(parent, **dict(cell, justify="center", width=6))
        self.amount = tk.Entry(parent, **dict(cell, justify="right", width=15), state="readonly")
        for col, w in enumerate(self.widgets):
            w.grid(row=row, column=col, sticky="ew", padx=1, pady=1, ipady=T.CELL_PAD_Y)
            w.bind("<FocusIn>", lambda _e, wid=w: view._on_item_focus(wid), add="+")
            view._guard(w)
        self.item.bind("<KeyRelease>", lambda e: view._ledger_typed(e), add="+")
        for w in (self.qty, self.rate):
            w.bind("<KeyRelease>", lambda _e: view._refresh_items(), add="+")
        self.rate.bind("<FocusOut>", lambda _e: view._tidy_amount(self.rate), add="+")

    @property
    def widgets(self) -> tuple[tk.Entry, ...]:
        return (self.item, self.qty, self.rate, self.per, self.amount)

    def used(self) -> bool:
        return any(w.get().strip() for w in (self.item, self.qty, self.rate))

    def values(self) -> tuple[str, int, Decimal, str, Decimal]:
        """(item, quantity, rate, per, amount). Raises ValueError with a message."""
        name = self.item.get().strip()
        raw_q = self.qty.get().replace(",", "").strip()
        if not raw_q.isdigit() or int(raw_q) <= 0:
            raise ValueError("Quantity must be a whole number above 0 (qty_on_hand counts whole units)")
        rate = parse_amount(self.rate.get())
        if rate is None:
            raise ValueError("Enter the rate")
        qty = int(raw_q)
        return name, qty, rate, self.per.get().strip() or DEFAULT_UNIT, (rate * qty).quantize(CENT)

    def show_amount(self) -> Decimal | None:
        try:
            _n, _q, _r, _p, amount = self.values()
        except ValueError:
            amount = None
        self.amount.configure(state="normal")
        self.amount.delete(0, "end")
        if amount is not None:
            self.amount.insert(0, fmt_inr(amount))
        self.amount.configure(state="readonly")
        return amount

    def fill(self, item: str, qty, rate: Decimal, per: str) -> None:
        for w, v in ((self.item, item), (self.qty, str(qty)), (self.rate, fmt_inr(rate)), (self.per, per)):
            w.delete(0, "end")
            w.insert(0, v)
        self.show_amount()

    def destroy(self) -> None:
        for w in self.widgets:
            w.destroy()


class VoucherView(tk.Frame):
    def __init__(self, parent: tk.Widget, *, voucher_type: str,
                 number_for: Callable[[str], int],
                 on_accept: Callable[[dict, Callable[[bool], None]], None],
                 on_close: Callable[[], None],
                 invoice_for: Callable[[date], str] | None = None,
                 ledger_source: Callable[[], list] | None = None,
                 mode: str = DEFAULT_VOUCHER_MODE,
                 invoice_mode: str = DEFAULT_INVOICE_MODE,
                 item_source: Callable[[], list] | None = None,
                 autofill_source: Callable[[str, str], dict | None] | None = None,
                 unused_source: Callable[[str], list[int]] | None = None,
                 existing: dict | None = None,
                 template: dict | None = None,
                 rate_source: Callable[[str], Decimal | None] | None = None,
                 on_duplicate: Callable[[], None] | None = None,
                 on_cancel_voucher: Callable[[], None] | None = None,
                 cost_source: Callable[[], set] | None = None,
                 centre_source: Callable[[], list] | None = None,
                 currency_source: Callable[[], list] | None = None) -> None:
        super().__init__(parent, bg=T.WHITE)
        self._currency_source = currency_source
        self._currencies: list[tuple[str, str]] = list(CURRENCIES)      # + the Currency masters
        self._cost_source, self._centre_source = cost_source, centre_source
        self._cost_ledgers: set[str] = set()                   # expense / purchase ledgers (lower case)
        self._centres: list[str] = list(COST_CENTRES)
        self._alloc_box: AllocationBox | None = None
        self._type = voucher_type
        self._currency, self._fx_rate = BASE, Decimal("1")      # the voucher's currency and ₹ per unit
        self._fx_box: CurrencyBox | None = None
        self._fx_return: tk.Widget | None = None                # where the cursor goes after the box
        self._rate_source = rate_source
        self._template = template                                # Alt+2: a saved voucher to copy
        self._on_duplicate = on_duplicate
        self._on_cancel_voucher = on_cancel_voucher
        self._mode = mode if mode in (SINGLE, DOUBLE) else DOUBLE     # chosen with Ctrl+H
        self._invoice_mode = invoice_mode if invoice_mode in (ITEM_INV, ACC_INV, AS_VOUCHER) else ITEM_INV
        self._item_lines: list[_ItemLine] = []
        self._item_source = item_source
        self._autofill_source = autofill_source
        self._unused_source = unused_source
        self._ledger_cat: list = []
        self._item_cat: list = []
        self._voucher_status = REGULAR
        self._forms: dict[str, dict[str, str]] = {}        # Dispatch / Order / Consignee Details
        self._dispatch_offered = False
        self._card: DetailsCard | None = None
        self._drawer: UtilitiesDrawer | None = None
        self._saving = False
        self._layout = ""                                             # mode actually on screen
        self._single_lines: list[_SingleLine] = []
        self._mode_box = None                                         # Change Voucher Mode box
        self._ledger_source = ledger_source
        self._list_target: tk.Entry | None = None                     # field the ledger list fills
        self._number_for = number_for
        self._invoice_for = invoice_for
        self._on_accept = on_accept
        self._on_close = on_close
        self._lines: list[_Line] = []
        self.on_macros_changed: Callable[[], None] | None = None   # set by the window
        self.existing = existing              # a saved voucher being altered (drill-down), else None
        self._snapshot: tuple | None = None

        self._build_title_bar()
        self._build_form()
        self._reset(keep_date=False)
        self.load_ledgers()
        if existing is not None:
            self._load_existing(existing)
        elif template is not None:
            self._load_template(template)

    # ---- layout ------------------------------------------------------------------------
    def _build_title_bar(self) -> None:
        bar = tk.Frame(self, bg=T.NAVY, height=34)
        bar.pack(side="top", fill="x")
        bar.pack_propagate(False)
        tk.Label(bar, text="Accounting Voucher Alteration" if self.existing else "Accounting Voucher Creation",
                 bg=T.NAVY, fg=T.WHITE,
                 font=T.F_VIEW_TITLE).pack(side="left", padx=12)
        tk.Label(bar, text="Ctrl+H Mode    Ctrl+I More    Ctrl+A Accept    F12 Bar    Esc Back", bg=T.NAVY, fg=T.HOVER_TEXT,
                 font=T.F_HEADER).pack(side="right", padx=12)

    def _build_form(self) -> None:
        form = tk.Frame(self, bg=T.WHITE)
        form.pack(side="left", fill="both", expand=True, padx=14, pady=10)
        self._ledger_list = LedgerListPanel(self, on_pick=self._pick_ledger)
        self._ledger_list.pack_before = form

        # Voucher type, number, date
        head = tk.Frame(form, bg=T.WHITE)
        head.pack(side="top", fill="x")
        self._type_label = tk.Label(head, bg=T.LIGHT_BLUE, fg=T.NAVY, font=T.F_VIEW_TITLE, padx=12, pady=3,
                                    highlightthickness=1, highlightbackground=T.BORDER)
        self._type_label.pack(side="left")
        self._number_label = tk.Label(head, bg=T.WHITE, fg=T.TEXT, font=T.F_LABEL_BOLD, padx=12)
        self._number_label.pack(side="left")
        self._mode_label = tk.Label(head, bg=T.WHITE, fg=T.MUTED, font=T.F_LABEL, padx=6)
        self._mode_label.pack(side="left")
        self._status_badge = tk.Label(head, bg=T.ORANGE, fg=T.TEXT_DARK, font=T.F_LABEL, padx=8)
        self._weekday = tk.Label(head, bg=T.WHITE, fg=T.MUTED, font=T.F_LABEL, width=10, anchor="w")
        self._weekday.pack(side="right")
        self._date = tk.Entry(head, width=11, font=T.F_LABEL_BOLD, justify="center", relief="flat", bd=0,
                              highlightthickness=1, highlightbackground=T.LINE, highlightcolor=T.ORANGE)
        self._date.pack(side="right", ipady=3)
        self._date.bind("<KeyRelease>", lambda _e: (self._show_weekday(), self._refresh_gst()))
        tk.Label(head, text="Date", bg=T.WHITE, fg=T.MUTED, font=T.F_LABEL, padx=6).pack(side="right")

        # Sales: Party A/c name, Name of Item.  Purchase: Supplier Invoice No., Date.
        self._build_type_fields(form)
        self._build_currency_row(form)

        # The two layouts share this slot; _apply_layout shows one of them.
        self._body = tk.Frame(form, bg=T.WHITE)
        self._body.pack(side="top", fill="both", expand=True)
        self._double_box = tk.Frame(self._body, bg=T.WHITE)
        self._single_box = tk.Frame(self._body, bg=T.WHITE)
        self._item_box = tk.Frame(self._body, bg=T.WHITE)
        self._build_single(self._single_box)
        self._build_items(self._item_box)

        # Double Entry: grid of Dr / Cr lines (scrolls when it grows)
        self._canvas, self._grid = self._scroll_grid(self._double_box)
        self._grid.columnconfigure(1, weight=1)
        heads = []
        for col, (text, anchor) in enumerate((("Dr/Cr", "center"), ("Particulars", "w"),
                                              ("Debit", "e"), ("Credit", "e"), ("₹ Value", "e"))):
            lbl = tk.Label(self._grid, text=text, bg=T.NAVY, fg=T.WHITE, font=T.F_GRID_HEAD, anchor=anchor,
                           padx=8, pady=5)
            lbl.grid(row=0, column=col, sticky="ew", padx=1, pady=(0, 2))
            heads.append(lbl)
        self._side_head = heads[0]
        self._amount_heads = heads[2:4]
        self._fx_heads = [heads[4]]
        heads[4].grid_remove()

        # Totals
        totals = tk.Frame(self._double_box, bg=T.WHITE)
        totals.pack(side="top", fill="x", pady=(6, 0))
        self._credit_total = tk.Label(totals, bg=T.LIGHT_BLUE, fg=T.NAVY, font=T.F_TOTAL, width=16, anchor="e", padx=6, pady=3)
        self._credit_total.pack(side="right", padx=(2, 18))
        self._debit_total = tk.Label(totals, bg=T.LIGHT_BLUE, fg=T.NAVY, font=T.F_TOTAL, width=16, anchor="e", padx=6, pady=3)
        self._debit_total.pack(side="right", padx=2)
        tk.Label(totals, text="Total", bg=T.WHITE, fg=T.NAVY, font=T.F_LABEL_BOLD, padx=8).pack(side="right")
        self._difference = tk.Label(totals, bg=T.WHITE, font=T.F_LABEL, anchor="w")
        self._difference.pack(side="left")

        self._build_gst_panel(form)

        # Narration and status
        narr = tk.Frame(form, bg=T.WHITE)
        self._narr_row = narr
        narr.pack(side="top", fill="x", pady=(10, 0))
        tk.Label(narr, text="Narration:", bg=T.WHITE, fg=T.MUTED, font=T.F_LABEL).pack(side="left")
        self._narration = tk.Entry(narr, font=T.F_GRID, relief="flat", bd=0, highlightthickness=1,
                                   highlightbackground=T.LINE, highlightcolor=T.ORANGE)
        self._narration.pack(side="left", fill="x", expand=True, padx=(8, 0), ipady=4)
        for w in (self._date, self._narration):
            self._guard(w)
            w.bind("<FocusIn>", lambda _e: self._ledger_list.hide(), add="+")
        self._status = tk.Label(form, bg=T.WHITE, fg=T.BAD_RED, font=T.F_LABEL, anchor="w")
        self._status.pack(side="top", fill="x", pady=(6, 0))

    def _build_gst_panel(self, form: tk.Widget) -> None:
        """Sales only: the fields gst_sales_ledger needs. Shown / hidden by set_type."""
        panel = tk.Frame(form, bg=T.LIGHT_BLUE, highlightthickness=1, highlightbackground=T.BORDER)
        self._gst_panel = panel
        row = tk.Frame(panel, bg=T.LIGHT_BLUE)
        row.pack(side="top", fill="x", padx=10, pady=(8, 2))

        def field(label: str, width: int) -> tk.Entry:
            box = tk.Frame(row, bg=T.LIGHT_BLUE)
            box.pack(side="left", padx=(0, 14))
            self._taxable_label = tk.Label(box, text=label, bg=T.LIGHT_BLUE, fg=T.MUTED, font=T.F_HINT, anchor="w")
            self._taxable_label.pack(fill="x")      # the last one made is the Taxable value's
            e = tk.Entry(box, width=width, font=T.F_LABEL_BOLD, relief="flat", bd=0, highlightthickness=1,
                         highlightbackground=T.LINE, highlightcolor=T.ORANGE)
            e.pack(ipady=3)
            e.bind("<KeyRelease>", lambda _e: self._refresh_gst(), add="+")
            e.bind("<FocusIn>", lambda _e: self._ledger_list.hide(), add="+")
            self._guard(e)
            return e

        self._gstin = field("Customer GSTIN (blank = unregistered)", 20)
        self._pos = field("Place of supply", 5)
        self._pos.configure(justify="center")
        self._gstin.bind("<KeyRelease>", lambda _e: self._pos_from_gstin(), add="+")
        self._hsn = field("HSN / SAC", 10)
        self._rate = field(f"GST rate % ({', '.join(GST_RATES)})", 8)
        self._taxable = field("Taxable value", 16)
        self._taxable.configure(font=T.F_AMOUNT, justify="right")
        self._gst_fields = (self._gstin, self._pos, self._hsn, self._rate, self._taxable)
        self._gst_info = tk.Label(panel, bg=T.LIGHT_BLUE, fg=T.NAVY, font=T.F_LABEL, anchor="w")
        self._gst_info.pack(side="top", fill="x", padx=10, pady=(0, 8))

    def _gst_values(self) -> dict:
        """Reads and checks the GST panel. Raises ValueError (with the field) on a problem."""
        try:
            gstin = check_gstin(self._gstin.get())
        except ValueError as exc:
            raise _FieldError(str(exc), self._gstin) from None
        try:
            pos = check_state_code(self._pos.get())
        except ValueError as exc:
            raise _FieldError(str(exc), self._pos) from None
        try:
            hsn = check_hsn(self._hsn.get())
        except ValueError as exc:
            raise _FieldError(str(exc), self._hsn) from None
        rate_txt = self._rate.get().strip().rstrip("%").strip()
        if rate_txt not in GST_RATES:
            raise _FieldError(f"GST rate must be one of {', '.join(GST_RATES)}.", self._rate)
        try:
            taxable = parse_amount(self._taxable.get())
        except ValueError as exc:
            raise _FieldError(str(exc).capitalize() + ".", self._taxable) from None
        if not taxable:
            raise _FieldError("Enter the taxable value.", self._taxable)
        rate = Decimal(rate_txt)
        tax = tax_for(taxable, rate, pos, S.COMPANY_STATE_CODE)
        return {"gstin": gstin, "place_of_supply": pos, "hsn": hsn, "rate": rate, "taxable": taxable, **tax,
                "invoice_value": taxable + tax["cgst"] + tax["sgst"] + tax["igst"]}

    def _pos_from_gstin(self) -> None:
        """A complete, valid GSTIN fills the place of supply with its state code (still editable)."""
        try:
            gstin = check_gstin(self._gstin.get())
        except ValueError:
            return
        if gstin:
            self._pos.delete(0, "end")
            self._pos.insert(0, gstin[:2])
            self._refresh_gst()

    def _refresh_gst(self) -> None:
        if self._type != "Sales":
            return
        try:
            g = self._gst_values()
        except _FieldError:
            g = None
        parts = []
        if self._invoice_for is not None:
            try:
                d = datetime.strptime(self._date.get().strip(), DATE_FMT).date()
                parts.append(f"Invoice No. {self._invoice_for(d)} (next free)")
            except ValueError:
                pass
        if g:
            if g["inter_state"]:
                parts.append(f"Inter-state: IGST {fmt_inr(g['igst'])} = invoice value {fmt_inr(g['invoice_value'])}")
            else:
                parts.append(f"CGST {fmt_inr(g['cgst'])} + SGST {fmt_inr(g['sgst'])} = invoice value {fmt_inr(g['invoice_value'])}")
            if g["gstin"] and g["gstin"][:2] != g["place_of_supply"]:
                parts.append(f"(GSTIN is from state {g['gstin'][:2]})")
        self._gst_info.configure(text="    ".join(parts))

    # ---- public ------------------------------------------------------------------------
    @property
    def voucher_type(self) -> str:
        return self._type

    def focus_first(self) -> None:
        first = self._first_type_field()
        if first is not None:
            first.focus_set()
        else:
            self._focus_after_header()

    def _focus_body(self) -> None:
        """The first field of the lines area for the layout on screen."""
        if self._layout == SINGLE:
            self._account.focus_set()
        elif self._layout == ACC_INV and self._single_lines:
            self._single_lines[0].ledger.focus_set()
        elif self._layout == ITEM_INV and self._item_lines:
            self._item_lines[0].item.focus_set()
        elif self._lines:
            self._lines[0].side_entry.focus_set()

    # ---- right-hand action bar ---------------------------------------------------------
    def macros(self) -> list[Macro]:
        if self.existing is not None:            # altering: the type is fixed, so no type keys
            extra = []
            if self._on_duplicate is not None:
                extra.append(Macro("Alt+2", "Duplicate", self._on_duplicate))
            if self._on_cancel_voucher is not None:
                extra.append(Macro("Alt+X", "Cancel Vch", self._on_cancel_voucher))
            return extra + [Macro("Ctrl+I", "More Details", self.open_drawer), Macro("Ctrl+A", "Accept", self.accept)]
        return ([Macro.fkey(key, name, lambda n=name: self.set_type(n)) for key, name in VOUCHER_TYPES]
                + [Macro.fkey(key, name, lambda n=name: self.set_type(n)) for key, name in NOTE_VOUCHER_TYPES]
                + [Macro("Ctrl+H", "Change Mode", self.open_mode_box),
                   Macro("Ctrl+I", "More Details", self.open_drawer),
                   Macro("Ctrl+A", "Accept", self.accept)])

    def active_macro(self) -> str:
        return next((k for k, n in VOUCHER_TYPES + NOTE_VOUCHER_TYPES if n == self._type), "")

    def side_word(self, side: str) -> str:
        """'Dr' -> 'By' on a Journal (Tally's words), else unchanged."""
        words = self._side_words()
        return words[0] if side == "Dr" else words[1]

    def _side_words(self) -> tuple[str, str]:
        """By / To on a Journal and on Sales / Purchase 'As Voucher'; Dr / Cr elsewhere."""
        vtype = getattr(self, "_type", "")
        if vtype in SIDE_WORDS:
            return SIDE_WORDS[vtype]
        if vtype in INVOICE_TYPES and getattr(self, "_invoice_mode", "") == AS_VOUCHER:
            return ("By", "To")
        return ("Dr", "Cr")

    def _refresh_side_words(self) -> None:
        words = self._side_words()
        self._side_head.configure(text=f"{words[0]}/{words[1]}")
        for line in self._lines:
            line.side_text.set(self.side_word(line.side.get()))

    def set_type(self, name: str) -> None:
        if not self._may_switch_layout(self._layout_for(name)):
            return
        if self._voucher_status == POST_DATED and name not in POST_DATED_TYPES:
            self.set_status(REGULAR)
        self._type = name
        self._type_label.configure(text=name)
        self._number_label.configure(text=f"No.  {self._number_for(name)}")
        if name == "Sales":
            self._gst_panel.pack(side="top", fill="x", pady=(10, 0), before=self._narr_row)
            self._refresh_gst()
        else:
            self._gst_panel.pack_forget()
        self._apply_layout()
        self._show_type_fields()
        self._refresh_side_words()
        self._apply_tint(VOUCHER_TINTS.get(name, T.WHITE))
        if self.on_macros_changed is not None:
            self.on_macros_changed()
        if not any(line.used() for line in self._lines):
            # Nothing typed yet: first line takes the type's usual side, the rest the opposite.
            first = FIRST_SIDE.get(name, "Dr")
            for i, line in enumerate(self._lines):
                line.clear(first if i == 0 else ("Cr" if first == "Dr" else "Dr"))
            self._refresh_totals()
            if self.winfo_ismapped():
                self.after_idle(self.focus_first)      # e.g. Sales starts on Party A/c name

    def handle_key(self, event: tk.Event) -> str | None:
        """Called by the window's key dispatcher while this screen is open."""
        keysym = event.keysym
        ctrl = bool(event.state & T.MOD_CTRL)
        if self._card is not None:                      # Dispatch / Order / … card has the keys
            return self._card.handle_key(event)
        if self._alloc_box is not None:                 # Cost Centre Allocation box has the keys
            return self._alloc_box.handle_key(event)
        if self._fx_box is not None:                    # Exchange Rate box: typing goes to its rate field
            return self._fx_box.handle_key(event)
        if self._mode_box is not None:                  # the Change Voucher Mode box has the keys
            return self._mode_box.handle_key(event) or "break"
        if self._drawer is not None:                    # Voucher Entry Utilities drawer
            if keysym == "Escape":
                self.close_drawer()
                return "break"
            return self._drawer.handle_key(event) or "break"
        shift = bool(event.state & 0x0001)
        if keysym == "ISO_Left_Tab" or (keysym == "Tab" and shift):
            keysym = "Escape"                           # Shift+Tab = one field back, like Esc
        elif keysym == "Tab":
            keysym = "Return"                           # Tab = Enter: no jumping to stray widgets
        if keysym == "Escape":
            # Tally rule: Esc goes back one field for a quick correction; only on the very first
            # field (the date) does it leave the voucher (asking first if anything is typed).
            if self._step_back(event.widget):
                return "break"
            if self._ledger_list.visible and event.widget is not self._date:
                self._ledger_list.hide()
                return "break"
            self._ledger_list.hide()
            self.request_close()
            return "break"
        if ctrl and keysym.lower() == "a":
            self.accept()
            return "break"
        if ctrl and keysym.lower() == "h":
            if self.existing is None:
                self.open_mode_box()
            return "break"
        if ctrl and keysym.lower() == "i":
            self.open_drawer()
            return "break"
        if event.state & T.MOD_ALT and not ctrl:
            if keysym == "2" and self._on_duplicate is not None:        # Alt+2: duplicate this saved voucher
                self._on_duplicate()
                return "break"
            if keysym.lower() == "x" and self._on_cancel_voucher is not None:   # Alt+X: cancel it
                self._on_cancel_voucher()
                return "break"
        if event.state & (T.MOD_CTRL | T.MOD_ALT):
            return None
        if keysym in ("Up", "Down") and self._ledger_list.visible and event.widget is self._list_target:
            self._ledger_list.move(-1 if keysym == "Up" else 1)
            return "break"
        # F4 – F9 and Ctrl+F8 / Ctrl+F9 are answered by the action bar (macros()) before this.
        if keysym in ("Return", "KP_Enter"):
            if self._valid_here(event.widget):          # Enter checks the field before moving on
                self._advance(event.widget)
            return "break"
        return None

    # ---- field order (Enter forward, Esc back) ---------------------------------------------
    def _field_order(self) -> list[tk.Widget]:
        """Every field in the order Enter visits them, for the layout on screen."""
        order: list[tk.Widget] = [self._date]
        if self._type in INVOICE_TYPES:
            order.append(self._party)
            if self._type == "Purchase":
                order += [self._supplier_inv, self._supplier_date]
        if self._fx_shown():
            order.append(self._currency_entry)
        if self._layout == SINGLE:
            order.append(self._account)
        if self._layout in (SINGLE, ACC_INV):
            for ln in self._single_lines:
                order += [ln.ledger, ln.amount_entry]
        elif self._layout == ITEM_INV:
            order.append(self._item_ledger)
            for ln in self._item_lines:
                order += [ln.item, ln.qty, ln.rate, ln.per]
        else:
            for ln in self._lines:
                order += [ln.side_entry, ln.ledger, ln.amount_entry]
        if self._type == "Sales":
            order += [w for w in self._gst_fields if str(w.cget("state")) == "normal"]
        order.append(self._narration)
        return [w for w in order if w.winfo_exists() and str(w.cget("state")) != "disabled"]

    def _step_back(self, widget) -> bool:
        order = self._field_order()
        if widget in order and order.index(widget) > 0:
            order[order.index(widget) - 1].focus_set()
            return True
        return False

    def _valid_here(self, widget) -> bool:
        """Enter on a field checks just that field; a wrong value keeps the cursor there."""
        if any(widget is ln.amount_entry for ln in self._lines + self._single_lines) \
                and not self._take_designator(widget):
            return False
        text = widget.get().strip() if isinstance(widget, tk.Entry) else ""
        problem = ""
        try:
            if widget is self._date or widget is self._supplier_date:
                if text or widget is self._date:
                    datetime.strptime(text, DATE_FMT)
            elif widget is self._pos and text:
                check_state_code(text)
            elif widget is self._gstin and text:
                check_gstin(text)
            elif widget is self._hsn and text:
                check_hsn(text)
            elif widget is self._rate and text and text.rstrip("%").strip() not in GST_RATES:
                problem = f"GST rate must be one of {', '.join(GST_RATES)}."
            elif widget is self._taxable or any(widget is ln.amount_entry for ln in self._lines + self._single_lines) \
                    or any(widget is ln.rate for ln in self._item_lines):
                parse_amount(text)
            elif any(widget is ln.qty for ln in self._item_lines) and text and \
                    (not text.replace(",", "").isdigit() or int(text.replace(",", "")) <= 0):
                problem = "Quantity must be a whole number above 0."
        except ValueError as exc:
            problem = str(exc)
            if widget is self._date or widget is self._supplier_date:
                problem = "Enter the date as DD-MM-YYYY."
        if problem:
            self._status.configure(text=problem[0].upper() + problem[1:].rstrip(".") + ".", fg=T.BAD_RED)
            return False
        if self._status.cget("fg") == T.BAD_RED:
            self._status.configure(text="")
        return True

    def can_close(self) -> bool:
        """True when nothing is typed, or the user agrees to lose it."""
        return not self._dirty() or messagebox.askyesno(
            "Quit voucher?", "The entries on this voucher will be lost.\n\nGo back anyway?",
            default="no", parent=self,
        )

    def request_close(self) -> None:
        if self.can_close():
            self._on_close()

    def accept(self) -> None:
        """Checks the voucher and hands it to on_accept(voucher, done). The window saves it in a
        background thread and calls done(True) when it is in the database; only then does the
        screen clear. Accept is ignored while a save is still running."""
        if self._saving:
            return
        voucher = self._validate()
        if voucher is None:
            return
        self._saving = True
        self._status.configure(text="Saving…", fg=T.MUTED)
        self._on_accept(voucher, self._accepted)

    def _accepted(self, ok: bool) -> None:
        if not self.winfo_exists():
            return
        self._saving = False
        if self._status.cget("text") == "Saving…":
            self._status.configure(text="")
        self._status.configure(fg=T.BAD_RED)
        if ok and self._template is not None:    # a duplicate (Alt+2): back to the Day Book, refreshed
            self._on_close()
            return
        if ok and self.existing is None:         # altering: the window goes back to the report
            self._reset(keep_date=True)
            self.load_ledgers()                          # names and items used here join the lists

    # ---- validation and reset ----------------------------------------------------------
    def _validate(self) -> dict | None:
        self._status.configure(text="")
        try:
            vdate = datetime.strptime(self._date.get().strip(), DATE_FMT).date()
        except ValueError:
            return self._fail("Enter the date as DD-MM-YYYY.", self._date)

        status = self._voucher_status
        if status == POST_DATED:
            if self._type not in POST_DATED_TYPES:
                return self._fail(f"A {self._type} cannot be Post-Dated (Payment, Receipt, Contra, Journal only).", None)
            if vdate <= date.today():
                return self._fail("A Post-Dated voucher needs a date after today.", self._date)

        items: list[dict] = []
        if self._layout == ITEM_INV:
            built = self._item_invoice_lines()
            if built is None:
                return None
            lines, items = built
        elif self._layout in (SINGLE, ACC_INV):
            lines = self._single_entry_lines()
            if lines is None:
                return None
        else:
            lines = self._double_entry_lines()
            if lines is None:
                return None
        forex = None
        if self.is_forex and self._layout != ITEM_INV:
            lines, amounts, note = convert_lines(lines, self._fx_rate)
            lines = [dict(ln, allocations=rescale(ln["allocations"], ln["amount"])) if ln.get("allocations") else ln
                     for ln in lines]
            forex = {"currency": self._currency, "rate": self._fx_rate, "amounts": amounts, "note": note}
        debit = sum((ln["amount"] for ln in lines if ln["side"] == "Dr"), Decimal("0"))
        details = self._type_details(lines)
        if details is None:
            return None

        gst = None
        if self._type == "Sales":
            try:
                gst = self._gst_values()
            except _FieldError as exc:
                return self._fail(exc.message, exc.widget)
            party = details.get("Party A/c", "")
            customer = next((ln["ledger"] for ln in lines if ln["side"] == "Dr" and ln["ledger"].lower() == party.lower()),
                            next(ln["ledger"] for ln in lines if ln["side"] == "Dr"))
            customer_total = sum((ln["amount"] for ln in lines if ln["side"] == "Dr" and ln["ledger"] == customer), Decimal("0"))
            if abs(customer_total - gst["invoice_value"]) > ROUND_OFF_LIMIT:
                return self._fail(
                    f"{customer} is debited {fmt_inr(customer_total)}, but taxable value + GST comes to "
                    f"{fmt_inr(gst['invoice_value'])}. Check the taxable value or the GST rate.", self._taxable)
            gst["customer"] = customer

        return {
            "type": self._type,
            "date": vdate,
            "lines": lines,
            "narration": self._narration.get().strip(),
            "total": debit,
            "entered_at": datetime.now(),
            "gst": gst,
            "details": details,
            "items": items,
            "status": status,
            "forex": forex,
        }

    def _double_entry_lines(self) -> list[dict] | None:
        lines = []
        for line in self._lines:
            if not line.used():
                continue
            ledger = line.ledger.get().strip()
            if not ledger:
                return self._fail("Every line needs a ledger name under Particulars.", line.ledger)
            try:
                amount = line.amount()
            except ValueError as exc:
                return self._fail(str(exc).capitalize() + ".", line.amount_entry)
            if not amount:
                return self._fail(f"Enter the amount for {ledger}.", line.amount_entry)
            entry = {"side": line.side.get(), "ledger": ledger, "amount": amount}
            if not self._allocations_into(entry, line):
                return None
            lines.append(entry)

        if len(lines) < 2:
            return self._fail("A voucher needs at least one debit and one credit line.", self._first_empty_ledger())
        debit = sum((ln["amount"] for ln in lines if ln["side"] == "Dr"), Decimal("0"))
        credit = sum((ln["amount"] for ln in lines if ln["side"] == "Cr"), Decimal("0"))
        if not debit or not credit:
            return self._fail("A voucher needs at least one debit and one credit line.", self._first_empty_ledger())
        if debit != credit:
            return self._fail(f"Debit {fmt_inr(debit)} and credit {fmt_inr(credit)} do not match.", None)
        return lines

    def _fail(self, message: str, widget: tk.Widget | None) -> None:
        self._status.configure(text=message)
        if widget is not None:
            widget.focus_set()
        return None

    def _first_empty_ledger(self) -> tk.Widget | None:
        line = next((ln for ln in self._lines if not ln.used()), None)
        return (line or self._add_line()).side_entry

    def _reset(self, keep_date: bool) -> None:
        for line in self._lines:
            line.destroy()
        self._lines = []
        first = FIRST_SIDE.get(self._type, "Dr")
        for i in range(START_ROWS):
            self._add_line(first if i == 0 else ("Cr" if first == "Dr" else "Dr"))
        self._clear_single()
        self._clear_items()
        for e in self._type_fields:
            e.delete(0, "end")
        self._item_ledger.delete(0, "end")
        self._forms = {}
        self._dispatch_offered = False
        self.set_status(REGULAR)
        self._close_currency_box()
        self._close_allocation()
        self._currency, self._fx_rate = BASE, Decimal("1")
        self._currency_entry.delete(0, "end")
        self._currency_entry.insert(0, BASE)
        self._narration.delete(0, "end")
        self._taxable.configure(state="normal")
        for e in self._gst_fields:
            e.delete(0, "end")
        self._pos.insert(0, S.COMPANY_STATE_CODE)     # unregistered customers: West Bengal unless changed
        if not keep_date or not self._date.get().strip():
            self._date.delete(0, "end")
            self._date.insert(0, date.today().strftime(DATE_FMT))
        self._show_weekday()
        self.set_type(self._type)
        self._refresh_totals()
        self._status.configure(text="")
        self.after_idle(self.focus_first)

    def _dirty(self) -> bool:
        if self._snapshot is not None:           # altering: only changes since it was loaded count
            return self._state() != self._snapshot
        return (self._lines_dirty() or bool(self._narration.get().strip()) or self.is_forex
                or any(e.get().strip() for e in self._type_fields)
                or any(v for form in self._forms.values() for v in form.values())
                or any(e.get().strip() for e in self._gst_fields if e is not self._pos)
                or self._pos.get().strip() != S.COMPANY_STATE_CODE)

    def _after_lines(self) -> tk.Widget:
        """Where Enter goes once the lines balance: the GST panel on Sales, else Narration."""
        return self._gstin if self._type == "Sales" else self._narration

    # ---- grid behaviour ----------------------------------------------------------------
    def _add_line(self, side: str | None = None) -> _Line:
        if side is None:
            debit, credit = self._totals()
            side = "Cr" if debit > credit else "Dr"
        line = _Line(self, self._grid, row=len(self._lines) + 1, side=side)
        self._lines.append(line)
        return line

    def _totals(self) -> tuple[Decimal, Decimal]:
        debit = credit = Decimal("0")
        for line in self._lines:
            try:
                amt = line.amount() or Decimal("0")
            except ValueError:
                continue
            if line.side.get() == "Dr":
                debit += amt
            else:
                credit += amt
        return debit, credit

    def _refresh_totals(self) -> None:
        self._refresh_fx()
        debit, credit = self._totals()
        self._debit_total.configure(text=fmt_inr(debit))
        self._credit_total.configure(text=fmt_inr(credit))
        diff = debit - credit
        if not diff:
            self._difference.configure(text="Balanced" if debit else "", fg=T.OK_GREEN)
        else:
            side = "Dr" if diff > 0 else "Cr"
            self._difference.configure(text=f"Difference: {fmt_inr(abs(diff))} {side}", fg=T.BAD_RED)

    def _on_side_key(self, line: _Line, event: tk.Event) -> str | None:
        ch = event.keysym.lower()
        if ch in ("d", "c"):
            line.side.set("Dr" if ch == "d" else "Cr")
        elif ch in ("b", "t"):                          # By = Dr, To = Cr (Tally's words)
            line.side.set("Dr" if ch == "b" else "Cr")
        elif ch == "space":
            line.side.set("Cr" if line.side.get() == "Dr" else "Dr")
        else:
            return None
        line.apply_side()
        self._refresh_totals()
        return "break"

    def _toggle_side(self, line: _Line) -> None:
        line.side.set("Cr" if line.side.get() == "Dr" else "Dr")
        line.apply_side()
        self._refresh_totals()

    def _tidy_amount(self, entry: tk.Entry) -> None:
        """On leaving an amount: show it grouped (25000 -> 25,000.00), or flag it if invalid."""
        if entry.cget("state") != "normal":
            return
        try:
            value = parse_amount(entry.get())
        except ValueError as exc:
            entry.configure(bg="#FDECEC")
            self._status.configure(text=str(exc).capitalize() + ".")
            return
        entry.configure(bg=T.WHITE)
        if value is not None:
            entry.delete(0, "end")
            entry.insert(0, fmt_inr(value))
        self._refresh_totals()

    def _on_focus(self, line: _Line, widget: tk.Widget) -> None:
        self._ensure_visible(widget)
        if widget is line.ledger:
            self._show_ledger_list(widget)
        else:
            self._ledger_list.hide()
        # Entering the amount of a new line: offer the amount that balances the voucher.
        if widget is line.amount_entry and not widget.get().strip():
            debit, credit = self._totals()
            short_side = "Dr" if credit > debit else "Cr"
            if line.side.get() == short_side and debit != credit:
                widget.insert(0, fmt_inr(abs(debit - credit)))
                widget.select_range(0, "end")

    def _ensure_visible(self, widget: tk.Widget, canvas: tk.Canvas | None = None,
                        grid: tk.Frame | None = None) -> None:
        canvas, grid = canvas or self._canvas, grid or self._grid
        canvas.update_idletasks()
        total = max(grid.winfo_height(), 1)
        top = widget.winfo_y()
        view_top, view_bottom = (f * total for f in canvas.yview())
        if top < view_top or top + widget.winfo_height() > view_bottom:
            canvas.yview_moveto(max(0, top - 40) / total)

    def _advance(self, widget: tk.Widget, allocated: bool = False) -> None:
        """Enter: move forward like Tally."""
        if not allocated and self._offer_allocation(widget):
            return
        if widget is self._date:
            self.focus_first()
            return
        if widget in self._type_fields:
            self._advance_type_field(widget)
            return
        if widget is self._currency_entry:
            self._currency_entered()
            return
        if self._layout in (SINGLE, ACC_INV) and self._advance_single(widget):
            return
        if self._layout == ITEM_INV and self._advance_item(widget):
            return
        if widget in self._gst_fields:
            i = self._gst_fields.index(widget)
            if widget is self._taxable:
                self._tidy_amount(widget)
            (self._gst_fields[i + 1] if i + 1 < len(self._gst_fields) else self._narration).focus_set()
            return
        if widget is self._narration:
            if messagebox.askyesno("Accept?", "Accept this voucher?", parent=self):
                self.accept()
            else:
                self._narration.focus_set()
            return
        line = next((ln for ln in self._lines if widget in ln.widgets), None)
        if line is None:
            return
        idx = self._lines.index(line)
        if widget is line.side_entry:
            line.ledger.focus_set()
        elif widget is line.ledger:
            self._complete_ledger(widget)
            if not line.ledger.get().strip():
                # An empty Particulars on a balanced voucher ends the lines (Tally style).
                debit, credit = self._totals()
                if debit and debit == credit and idx >= 2:
                    self._after_lines().focus_set()
                return
            line.amount_entry.focus_set()
        elif widget is line.amount_entry:
            self._tidy_amount(widget)
            debit, credit = self._totals()
            if debit and debit == credit and idx >= 1 and all(
                ln.used() for ln in self._lines[: idx + 1]
            ):
                self._after_lines().focus_set()
                return
            nxt = self._lines[idx + 1] if idx + 1 < len(self._lines) else self._add_line()
            if not nxt.used():
                nxt.clear("Cr" if debit > credit else "Dr")
            nxt.side_entry.focus_set()

    def _show_weekday(self) -> None:
        try:
            d = datetime.strptime(self._date.get().strip(), DATE_FMT)
            self._weekday.configure(text=d.strftime("%A"), fg=T.MUTED)
        except ValueError:
            self._weekday.configure(text="DD-MM-YYYY", fg=T.BAD_RED)

    # ---- shared layout helpers ---------------------------------------------------------
    def _scroll_grid(self, parent: tk.Widget) -> tuple[tk.Canvas, tk.Frame]:
        """A bordered, vertically scrolling frame for grid lines."""
        box = tk.Frame(parent, bg=T.WHITE, highlightthickness=1, highlightbackground=T.BORDER)
        box.pack(side="top", fill="both", expand=True, pady=(10, 0))
        canvas = tk.Canvas(box, bg=T.WHITE, highlightthickness=0, bd=0)
        vbar = tk.Scrollbar(box, orient="vertical", command=canvas.yview)
        canvas.configure(yscrollcommand=vbar.set)
        vbar.pack(side="right", fill="y")
        canvas.pack(side="left", fill="both", expand=True)
        grid = tk.Frame(canvas, bg=T.WHITE)
        win = canvas.create_window((0, 0), window=grid, anchor="nw")
        grid.bind("<Configure>", lambda _e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.bind("<Configure>", lambda e: canvas.itemconfigure(win, width=e.width))
        return canvas, grid

    def _guard(self, entry: tk.Entry) -> None:
        """Ctrl+H opens the mode box. Tk's Entry would otherwise delete a character on Ctrl+H
        before the window sees the key, so the field answers it first and stops it there."""
        for seq in ("<Control-h>", "<Control-H>"):
            entry.bind(seq, lambda _e: (self.open_mode_box(), "break")[1])

    # ---- cost centres ----------------------------------------------------------------------
    def _line_of(self, widget: tk.Widget):
        """(line, side) when `widget` is the amount of a Double / Single Entry or Accounting Invoice line."""
        if self._layout == DOUBLE:
            line = next((ln for ln in self._lines if widget is ln.amount_entry), None)
            return (line, line.side.get()) if line else (None, "")
        if self._layout in (SINGLE, ACC_INV):
            line = next((ln for ln in self._single_lines if widget is ln.amount_entry), None)
            if line is None:
                return None, ""
            acc = PARTY_SIDE[self._type] if self._layout == ACC_INV else SINGLE_ENTRY_ACCOUNT_SIDE.get(self._type, "Cr")
            return line, ("Dr" if acc == "Cr" else "Cr")
        return None, ""

    def wants_allocation(self, ledger: str, side: str) -> bool:
        return side == "Dr" and ledger.strip().lower() in self._cost_ledgers

    def _offer_allocation(self, widget: tk.Widget) -> bool:
        """Enter on the amount of an expense / purchase debit line: the allocation box. True = opened."""
        line, side = self._line_of(widget)
        if line is None or not self.wants_allocation(line.ledger.get(), side):
            return False
        try:
            amount = parse_amount(self._strip_designator(widget.get()))
        except ValueError:
            return False                                # the field check reports it
        if not amount:
            return False
        self._tidy_amount(widget)
        self.open_allocation(line, amount)
        return True

    def _strip_designator(self, text: str) -> str:
        code, rest = split_designator(text)
        return rest if code == self._currency else text

    def open_allocation(self, line, amount: Decimal) -> None:
        self._close_allocation()
        self._ledger_list.hide()
        shares = line.allocations
        if shares and sum((a["amount"] for a in shares), Decimal("0")) != amount:
            shares = rescale(shares, amount)            # the amount changed: keep the proportions
        box = AllocationBox(self, line.amount_entry, ledger=line.ledger.get().strip(), amount=amount,
                            allocations=shares, centres=self._centres,
                            on_done=lambda result: self._allocated(line, result),
                            on_close=lambda: self._allocation_closed(line))
        self._alloc_box = box
        box.show()

    def _allocated(self, line, shares: list[dict]) -> None:
        line.allocations = shares
        self._close_allocation()
        if shares:
            split = ", ".join(f"{a['cost_centre']} {fmt_inr(a['amount'])}" for a in shares)
            self._status.configure(text=f"{line.ledger.get().strip()} split: {split}.", fg=T.MUTED)
        for name in (a["cost_centre"] for a in shares):
            if name.lower() not in {c.lower() for c in self._centres}:
                self._centres.append(name)
        line.amount_entry.focus_set()
        self._advance(line.amount_entry, allocated=True)

    def _allocation_closed(self, line) -> None:
        """Esc in the box: it collapses; the line keeps the split it had; the cursor stays on the amount."""
        self._close_allocation()
        line.amount_entry.focus_set()

    def _close_allocation(self) -> None:
        if self._alloc_box is not None:
            self._alloc_box.destroy()
            self._alloc_box = None

    def _allocations_into(self, entry: dict, line) -> bool:
        """Adds the line's split to the saved line, checked. False (message shown) if it does not add up."""
        if not line.allocations or not self.wants_allocation(entry["ledger"], entry["side"]):
            return True
        problem = check_allocations(entry["amount"], line.allocations)
        if problem:
            self._fail(f"Cost centres for {entry['ledger']}: {problem}. Enter on its amount to fix the split.",
                       line.amount_entry)
            return False
        entry["allocations"] = [dict(a) for a in line.allocations]
        return True

    # ---- foreign currency ------------------------------------------------------------------
    @property
    def is_forex(self) -> bool:
        return self._currency != BASE

    @property
    def currency(self) -> tuple[str, Decimal]:
        return self._currency, self._fx_rate

    def _build_currency_row(self, form: tk.Widget) -> None:
        row = self._fx_row = tk.Frame(form, bg=T.WHITE)
        tk.Label(row, text="Currency", bg=T.WHITE, fg=T.TEXT, font=T.F_LABEL, width=9, anchor="w").pack(side="left")
        self._currency_entry = tk.Entry(row, width=6, font=T.F_GRID, justify="center", relief="flat", bd=0,
                                        highlightthickness=1, highlightbackground=T.LINE, highlightcolor=T.ORANGE)
        self._currency_entry.pack(side="left", ipady=3)
        self._currency_entry.insert(0, BASE)
        self._currency_entry.bind("<FocusIn>", lambda _e: self._ledger_list.hide(), add="+")
        self._guard(self._currency_entry)
        self._fx_rate_label = tk.Label(row, bg=T.WHITE, fg=T.NAVY, font=T.F_TEXT, padx=12, cursor="hand2")
        self._fx_rate_label.pack(side="left")
        self._fx_rate_label.bind("<Button-1>", lambda _e: self.is_forex and self.open_currency_box(self._currency))
        self._fx_hint = tk.Label(row, bg=T.WHITE, fg=T.MUTED, font=T.F_HINT, anchor="w")
        self._fx_hint.pack(side="left", fill="x", expand=True)

    def _fx_shown(self) -> bool:
        return bool(self._fx_row.winfo_manager())

    def _show_fx_row(self) -> None:
        """The Currency row: Single / Double Entry and Accounting Invoice (Item Invoices are in rupees)."""
        self._fx_row.pack_forget()
        if not FOREX_ENABLED or self._layout == ITEM_INV:
            return
        if self._party_row.winfo_manager():
            self._fx_row.pack(side="top", fill="x", pady=(8, 0), after=self._party_row)
        else:
            self._fx_row.pack(side="top", fill="x", pady=(8, 0), before=self._body)

    def _focus_after_header(self) -> None:
        """After the date / Party fields: the Currency field when it is shown, else the lines."""
        if self._fx_shown():
            self._currency_entry.focus_set()
        else:
            self._focus_body()

    def set_currency(self, code: str, rate: Decimal = Decimal("1")) -> None:
        self._currency, self._fx_rate = (BASE, Decimal("1")) if code == BASE else (code, rate)
        self._currency_entry.delete(0, "end")
        self._currency_entry.insert(0, self._currency)
        self._refresh_totals()
        self._refresh_single_total()

    def _currency_entered(self) -> None:
        """Enter on the Currency field: INR moves on; another currency opens the rate box."""
        try:
            code = normal_code(self._currency_entry.get())
        except ValueError as exc:
            self._status.configure(text=str(exc)[0].upper() + str(exc)[1:] + ".", fg=T.BAD_RED)
            return
        if code == BASE:
            self.set_currency(BASE)
            self._focus_body()
            return
        self.open_currency_box(code)

    def open_currency_box(self, code: str, back_to: tk.Widget | None = None) -> None:
        """The inline Exchange Rate box under the Currency field."""
        self._close_currency_box()
        self._ledger_list.hide()
        self._fx_return = back_to
        rate = rate_text(self._fx_rate) if code == self._currency and self.is_forex else ""
        box = CurrencyBox(self, self._currency_entry, currency=code, rate=rate, currencies=self._currencies,
                          on_done=self._currency_chosen, on_close=self._currency_box_closed)
        box.bind("<<CurrencyChanged>>", lambda _e: self._offer_last_rate(), add="+")
        self._fx_box = box
        box.show()
        self._offer_last_rate()

    def _merge_currencies(self, extra: list) -> None:
        known = {c for c, _n in self._currencies}
        self._currencies = list(self._currencies) + [(c.upper(), n) for c, n in extra if c.upper() not in known]

    def _offer_last_rate(self) -> None:
        box = self._fx_box
        if box is None or self._rate_source is None or box.rate.get().strip():
            return
        code = box.currency
        run_in_background(self, lambda: self._rate_source(code), lambda r: box.offer_rate(code, r),
                          lambda _exc: None)

    def _currency_chosen(self, code: str, rate: Decimal) -> None:
        back = self._fx_return
        self._close_currency_box()
        self.set_currency(code, rate)
        self._status.configure(text=f"Amounts on this voucher are in {code}; each line is saved in rupees at "
                                    f"₹{rate_text(rate)} per {code}.", fg=T.MUTED)
        if back is not None and back.winfo_exists():
            back.focus_set()
        else:
            self._focus_body()

    def _currency_box_closed(self) -> None:
        """Esc in the box: nothing changes; back to the field that opened it (one step)."""
        back = self._fx_return or self._currency_entry
        self._close_currency_box()
        if not self.is_forex:
            self._currency_entry.delete(0, "end")
            self._currency_entry.insert(0, BASE)
        back.focus_set()

    def _close_currency_box(self) -> None:
        if self._fx_box is not None:
            self._fx_box.destroy()
            self._fx_box = None
        self._fx_return = None

    def _take_designator(self, entry: tk.Entry) -> bool:
        """'USD 1,200' / '$1,200' in an amount. False = the cursor stays (rate box opened, or a clash)."""
        code, rest = split_designator(entry.get())
        if code is None:
            return True
        if code == self._currency:
            entry.delete(0, "end")
            entry.insert(0, rest)
            return True
        if self.is_forex or code == BASE or not self._fx_shown():
            what = f"in {self._currency}" if self.is_forex else "in rupees"
            self._status.configure(text=f"This voucher is {what}; type the amount without {code}, or change the "
                                        "Currency field (one currency per voucher).", fg=T.BAD_RED)
            return False
        entry.delete(0, "end")
        entry.insert(0, rest)
        self.open_currency_box(code, back_to=entry)
        return False

    def _refresh_fx(self) -> None:
        """Headings, the ₹ Value column and the rupee total for the voucher's currency."""
        fx = self.is_forex
        suffix = f" ({self._currency})" if fx else ""
        for head, word in zip(self._amount_heads, ("Debit", "Credit")):
            head.configure(text=word + suffix)
        self._s_amount_head.configure(text="Amount" + suffix)
        rows = [(ln, ln.amount_entry) for ln in self._lines] + [(ln, ln.amount_entry) for ln in self._single_lines]
        for head in self._fx_heads + [self._s_fx_head]:
            head.grid() if fx else head.grid_remove()
        total = Decimal("0")
        for line, entry in rows:
            if not fx:
                line.inr.grid_remove()
                continue
            line.inr.grid()
            try:
                amount = parse_amount(entry.get()) if entry.cget("state") == "normal" else None
            except ValueError:
                amount = None
            line.inr.configure(text=fmt_inr(to_base(amount, self._fx_rate)) if amount else "")
        if fx:
            if self._layout == DOUBLE:
                total = to_base(self._totals()[0], self._fx_rate)
            else:
                total = to_base(self._single_total_value(), self._fx_rate)
            self._fx_rate_label.configure(text=f"1 {self._currency} = ₹{rate_text(self._fx_rate)}")
            self._fx_hint.configure(text=f"Amounts below are in {self._currency} · rupee total ₹{fmt_inr(total)}")
            self._taxable_label.configure(text="Taxable value (₹)")
        else:
            self._fx_rate_label.configure(text="")
            self._fx_hint.configure(text="Rupees. Type another currency code (USD, EUR …) for a foreign voucher.")
            self._taxable_label.configure(text="Taxable value")

    # ---- Single Entry layout -----------------------------------------------------------
    def _build_single(self, box: tk.Frame) -> None:
        acc = self._acc_row = tk.Frame(box, bg=T.WHITE)
        acc.pack(side="top", fill="x", pady=(10, 0))
        tk.Label(acc, text="Account", bg=T.WHITE, fg=T.TEXT, font=T.F_LABEL, width=9, anchor="w").pack(side="left")
        self._account = tk.Entry(acc, font=T.F_GRID, width=36, relief="flat", bd=0, highlightthickness=1,
                                 highlightbackground=T.LINE, highlightcolor=T.ORANGE)
        self._account.pack(side="left", ipady=4)
        self._account.bind("<FocusIn>", lambda _e: self._show_ledger_list(self._account), add="+")
        self._account.bind("<KeyRelease>", lambda e: self._ledger_typed(e), add="+")
        self._guard(self._account)
        self._account_hint = tk.Label(acc, bg=T.WHITE, fg=T.MUTED, font=T.F_HINT, padx=10, anchor="w")
        self._account_hint.pack(side="left")

        self._s_canvas, self._s_grid = self._scroll_grid(box)
        self._s_box = self._s_canvas.master
        self._s_grid.columnconfigure(0, weight=1)
        s_heads = []
        for col, (text, anchor) in enumerate((("Particulars", "w"), ("Amount", "e"), ("₹ Value", "e"))):
            lbl = tk.Label(self._s_grid, text=text, bg=T.NAVY, fg=T.WHITE, font=T.F_GRID_HEAD, anchor=anchor,
                           padx=8, pady=5)
            lbl.grid(row=0, column=col, sticky="ew", padx=1, pady=(0, 2))
            s_heads.append(lbl)
        self._s_amount_head = s_heads[1]
        s_heads[2].grid_remove()
        self._s_fx_head = s_heads[2]

        totals = tk.Frame(box, bg=T.WHITE)
        totals.pack(side="top", fill="x", pady=(6, 0))
        self._single_total = tk.Label(totals, bg=T.LIGHT_BLUE, fg=T.NAVY, font=T.F_TOTAL, width=18, anchor="e",
                                      padx=6, pady=3)
        self._single_total.pack(side="right", padx=(2, 18))
        tk.Label(totals, text="Total", bg=T.WHITE, fg=T.NAVY, font=T.F_LABEL, padx=8).pack(side="right")

    def _add_single_line(self) -> _SingleLine:
        line = _SingleLine(self, self._s_grid, row=len(self._single_lines) + 1)
        self._single_lines.append(line)
        return line

    def _clear_single(self) -> None:
        for line in self._single_lines:
            line.destroy()
        self._single_lines = []
        for _ in range(START_ROWS):
            self._add_single_line()
        self._account.delete(0, "end")
        self._refresh_single_total()

    def _single_total_value(self) -> Decimal:
        total = Decimal("0")
        for line in self._single_lines:
            try:
                total += line.amount() or Decimal("0")
            except ValueError:
                continue
        return total

    def _refresh_single_total(self) -> None:
        self._single_total.configure(text=fmt_inr(self._single_total_value()))
        self._refresh_fx()

    def _single_entry_lines(self) -> list[dict] | None:
        """Particulars on one side, the Account with their total on the other."""
        if self._layout == ACC_INV:
            account_entry, acc_side = self._party, PARTY_SIDE[self._type]
            if not self._party.get().strip():
                return self._fail("Enter the Party A/c name.", self._party)
        else:
            account_entry, acc_side = self._account, SINGLE_ENTRY_ACCOUNT_SIDE.get(self._type, "Cr")
        account = account_entry.get().strip()
        if not account:
            return self._fail("Enter the Account (the cash or bank ledger).", self._account)
        other = "Dr" if acc_side == "Cr" else "Cr"
        lines = []
        for line in self._single_lines:
            if not line.used():
                continue
            ledger = line.ledger.get().strip()
            if not ledger:
                return self._fail("Every line needs a ledger name under Particulars.", line.ledger)
            if ledger.lower() == account.lower():
                what = "Party A/c" if self._layout == ACC_INV else "Account"
                return self._fail(f"{ledger} is the {what}; it cannot also be under Particulars.", line.ledger)
            try:
                amount = line.amount()
            except ValueError as exc:
                return self._fail(str(exc).capitalize() + ".", line.amount_entry)
            if not amount:
                return self._fail(f"Enter the amount for {ledger}.", line.amount_entry)
            entry = {"side": other, "ledger": ledger, "amount": amount}
            if not self._allocations_into(entry, line):
                return None
            lines.append(entry)
        if not lines:
            return self._fail("Enter at least one ledger and amount under Particulars.",
                              self._single_lines[0].ledger if self._single_lines else self._account)
        total = sum((ln["amount"] for ln in lines), Decimal("0"))
        return lines + [{"side": acc_side, "ledger": account, "amount": total}]

    def _on_single_focus(self, widget: tk.Widget) -> None:
        self._ensure_visible(widget, self._s_canvas, self._s_grid)
        line = next((ln for ln in self._single_lines if widget in ln.widgets), None)
        if line is not None and widget is line.ledger:
            self._show_ledger_list(widget)
        else:
            self._ledger_list.hide()

    def _advance_single(self, widget: tk.Widget) -> bool:
        """Enter in Single Entry. True if the widget belonged to the single-entry form."""
        if widget is self._account and self._layout == SINGLE:
            self._complete_ledger(widget)
            if self._account.get().strip():
                self._single_lines[0].ledger.focus_set()
            return True
        line = next((ln for ln in self._single_lines if widget in ln.widgets), None)
        if line is None:
            return False
        idx = self._single_lines.index(line)
        if widget is line.ledger:
            self._complete_ledger(widget)
            if line.ledger.get().strip():
                line.amount_entry.focus_set()
            elif self._single_total_value():
                self._narration.focus_set()            # empty Particulars ends the lines
        else:
            self._tidy_amount(widget)
            self._refresh_single_total()
            nxt = self._single_lines[idx + 1] if idx + 1 < len(self._single_lines) else self._add_single_line()
            nxt.ledger.focus_set()
        return True

    # ---- modes -------------------------------------------------------------------------
    def _layout_for(self, voucher_type: str, mode: str | None = None, invoice_mode: str | None = None) -> str:
        if voucher_type in INVOICE_TYPES:
            inv = invoice_mode or self._invoice_mode
            return inv if inv in (ITEM_INV, ACC_INV) else DOUBLE
        mode = mode or self._mode
        return SINGLE if mode == SINGLE and voucher_type in SINGLE_ENTRY_TYPES else DOUBLE

    def _lines_dirty(self) -> bool:
        if self._layout == SINGLE:
            return bool(self._account.get().strip()) or any(ln.used() for ln in self._single_lines)
        if self._layout == ACC_INV:
            return any(ln.used() for ln in self._single_lines)
        if self._layout == ITEM_INV:
            return any(ln.used() for ln in self._item_lines)
        return any(line.used() for line in self._lines)

    def _may_switch_layout(self, new_layout: str) -> bool:
        """Switching between Single and Double Entry clears the lines typed so far: ask first."""
        if not self._layout or new_layout == self._layout or not self._lines_dirty():
            return True
        return messagebox.askyesno(
            "Change layout?", f"Switching to {new_layout} clears the lines typed so far "
            "(date and narration stay).\n\nSwitch anyway?", default="no", parent=self)

    def _apply_layout(self) -> None:
        layout = self._layout_for(self._type)
        if self._type in INVOICE_TYPES:
            note = self._invoice_mode
        else:
            note = self._mode if layout == self._mode else f"{layout} ({self._type} has no Single Entry)"
        self._mode_label.configure(text=note)
        if self._type in SINGLE_ENTRY_ACCOUNT_SIDE:
            effect = ("debited: money comes in" if SINGLE_ENTRY_ACCOUNT_SIDE[self._type] == "Dr"
                      else "credited: money goes out")
            self._account_hint.configure(text=f"Cash or bank ledger, {effect}")
        if layout == self._layout:
            return
        was = self._layout
        self._layout = layout
        self._ledger_list.hide()
        for box in (self._double_box, self._single_box, self._item_box):
            box.pack_forget()
        box = {SINGLE: self._single_box, ACC_INV: self._single_box, ITEM_INV: self._item_box}.get(layout,
                                                                                                 self._double_box)
        box.pack(fill="both", expand=True)
        if layout == ACC_INV:                         # the Party A/c (above) takes the total
            self._acc_row.pack_forget()
        elif not self._acc_row.winfo_manager():
            self._acc_row.pack(side="top", fill="x", pady=(10, 0), before=self._s_box)
        self._taxable.configure(state="readonly" if layout == ITEM_INV else "normal")
        if layout == ITEM_INV and self.is_forex:     # Item Invoices are in rupees
            self.set_currency(BASE)
        self._show_fx_row()
        if was:                                        # a real switch: start the new layout clean
            first = FIRST_SIDE.get(self._type, "Dr")
            for i, line in enumerate(self._lines):
                line.clear(first if i == 0 else ("Cr" if first == "Dr" else "Dr"))
            self._clear_single()
            self._clear_items()
            self._refresh_totals()
            self.after_idle(self.focus_first)

    @property
    def mode(self) -> str:
        return self._mode

    @property
    def invoice_mode(self) -> str:
        return self._invoice_mode

    def set_mode(self, mode: str) -> None:
        if mode not in (SINGLE, DOUBLE):
            return
        if not self._may_switch_layout(self._layout_for(self._type, mode=mode)):
            return
        self._mode = mode
        self._apply_layout()

    def set_invoice_mode(self, mode: str) -> None:
        """Sales / Purchase: Item Invoice, Accounting Invoice or As Voucher."""
        if mode not in (ITEM_INV, ACC_INV, AS_VOUCHER):
            return
        if not self._may_switch_layout(self._layout_for(self._type, invoice_mode=mode)):
            return
        self._invoice_mode = mode
        self._apply_layout()
        self._show_type_fields()
        self._refresh_side_words()
        if not any(line.used() for line in self._lines):
            first = FIRST_SIDE.get(self._type, "Dr")
            for i, line in enumerate(self._lines):
                line.clear(first if i == 0 else ("Cr" if first == "Dr" else "Dr"))

    def open_mode_box(self) -> None:
        """Ctrl+H: the Change Voucher Mode box, centred on the canvas."""
        if self._mode_box is not None:
            return
        from views.masters_overlay import MastersOverlay      # here: masters_overlay imports settings only
        self._return_focus = self.focus_get()
        self._ledger_list.hide()
        if self._type in INVOICE_TYPES:
            options, current, heading = INVOICE_MODES, self._invoice_mode, f"{self._type} Mode"
        elif self._type in SINGLE_ENTRY_TYPES:
            options, current, heading = VOUCHER_MODES, self._mode, "Voucher Mode"
        else:
            self._status.configure(text=f"A {self._type} is always entered in Double Entry.", fg=T.MUTED)
            return
        self._close_drawer_only()
        box = MastersOverlay(self, mode="Voucher Mode", on_choose=self._mode_chosen, on_close=self._close_mode_box,
                             sections=[(heading, [(label, key) for label, key in options])],
                             title="Change Voucher Mode", caption=f"{self._type} · now {current}",
                             title_font=T.F_KEY, width=320)
        self._mode_box = box
        box.show()
        box.set_active(next((i for i, (m, _k) in enumerate(options) if m == current), 0))

    def _mode_chosen(self, _mode: str, choice: str) -> None:
        self._close_mode_box()
        if choice in (ITEM_INV, ACC_INV, AS_VOUCHER):
            self.set_invoice_mode(choice)
        else:
            self.set_mode(choice)

    def _close_mode_box(self) -> None:
        """Esc (or a choice): remove the box and put the cursor back on the entry line."""
        if self._mode_box is not None:
            self._mode_box.destroy()
            self._mode_box = None
        target = getattr(self, "_return_focus", None)
        if target is not None and target.winfo_exists() and target.winfo_ismapped():
            target.focus_set()
        else:
            self.focus_first()

    # ---- List of Ledger Accounts ---------------------------------------------------------
    def load_ledgers(self) -> None:
        """Reads the ledger names in a background thread (services/ledgers.py)."""
        def loaded(attr: str):
            def done(catalogue: list) -> None:
                setattr(self, attr, catalogue)
                if self._ledger_list.visible and self._list_target is not None:
                    self._show_ledger_list(self._list_target)
            return done

        failed = lambda exc: self._status.configure(text=f"List not loaded: {exc}")  # noqa: E731
        if self._ledger_source is not None:
            run_in_background(self, self._ledger_source, loaded("_ledger_cat"), failed)
        if self._item_source is not None:
            run_in_background(self, self._item_source, loaded("_item_cat"), failed)
        if self._cost_source is not None:
            run_in_background(self, self._cost_source, lambda names: setattr(self, "_cost_ledgers", set(names)),
                              lambda _exc: None)
        if self._centre_source is not None:
            run_in_background(self, self._centre_source, lambda names: setattr(self, "_centres", list(names)),
                              lambda _exc: None)
        if self._currency_source is not None:
            run_in_background(self, self._currency_source, self._merge_currencies, lambda _exc: None)

    def _show_ledger_list(self, entry: tk.Entry) -> None:
        self._list_target = entry
        is_item = any(entry is ln.item for ln in self._item_lines)
        self._ledger_list.set_title("List of Stock Items" if is_item else "List of Ledger Accounts")
        self._ledger_list.set_catalogue(self._item_cat if is_item else self._ledger_cat)
        if entry is self._account:
            only = CASH_BANK
        elif entry is self._party:
            only = ("Sundry Debtors", "Cash-in-Hand") if self._type == "Sales" else ("Sundry Creditors", "Cash-in-Hand")
        else:
            only = None
        self._ledger_list.show(only=only, text=entry.get())

    def _ledger_typed(self, event: tk.Event) -> None:
        if event.keysym in ("Up", "Down", "Return", "KP_Enter", "Escape", "Tab"):
            return
        if event.widget is self._list_target:
            if not self._ledger_list.visible:
                self._show_ledger_list(event.widget)
            self._ledger_list.filter(event.widget.get())

    def _pick_ledger(self, name: str) -> None:
        """A click in the list: put the name in the field the list belongs to."""
        target = self._list_target
        if target is not None and target.winfo_exists():
            target.delete(0, "end")
            target.insert(0, name)
            target.focus_set()

    def _complete_ledger(self, entry: tk.Entry) -> None:
        """Enter on a ledger field: use the name picked in the list (or the only match)."""
        if not self._ledger_list.visible or entry is not self._list_target:
            return
        choice = self._ledger_list.choice(entry.get())
        if choice:
            entry.delete(0, "end")
            entry.insert(0, choice)

    # ---- per-type fields: Party A/c name (Sales, Purchase), Supplier Invoice (Purchase) ----
    def _build_type_fields(self, form: tk.Widget) -> None:
        def field(row: tk.Frame, label: str, width: int) -> tk.Entry:
            tk.Label(row, text=label, bg=T.WHITE, fg=T.TEXT, font=T.F_LABEL, anchor="w").pack(side="left", padx=(0, 6))
            e = tk.Entry(row, width=width, font=T.F_GRID, relief="flat", bd=0, highlightthickness=1,
                         highlightbackground=T.LINE, highlightcolor=T.ORANGE)
            e.pack(side="left", ipady=3, padx=(0, 18))
            self._guard(e)
            return e

        self._party_row = tk.Frame(form, bg=T.WHITE)
        self._party = field(self._party_row, "Party A/c name", 30)
        self._supplier_inv = field(self._party_row, "Supplier Invoice No.", 14)
        self._supplier_date = field(self._party_row, "Date", 11)
        self._supplier_widgets = [w for w in self._party_row.winfo_children()][2:]   # labels + entries after Party
        self._type_fields = (self._party, self._supplier_inv, self._supplier_date)
        self._party.bind("<FocusIn>", lambda _e: self._show_ledger_list(self._party), add="+")
        self._party.bind("<KeyRelease>", lambda e: self._ledger_typed(e), add="+")
        for e in (self._supplier_inv, self._supplier_date):
            e.bind("<FocusIn>", lambda _e: self._ledger_list.hide(), add="+")

    def _show_type_fields(self) -> None:
        self._party_row.pack_forget()
        if self._type in INVOICE_TYPES:
            self._party_row.pack(side="top", fill="x", pady=(10, 0), before=self._body)
            for w in self._supplier_widgets:
                if self._type == "Purchase":
                    w.pack(side="left", padx=(0, 6) if isinstance(w, tk.Label) else (0, 18),
                           ipady=0 if isinstance(w, tk.Label) else 3)
                else:
                    w.pack_forget()
        self._show_fx_row()
        label = {"Sales": "Sales ledger", "Purchase": "Purchase ledger"}.get(self._type, "Ledger")
        self._item_ledger_label.configure(text=label)
        if not self._item_ledger.get().strip() and self._type in ITEM_INVOICE_LEDGER:
            self._item_ledger.insert(0, ITEM_INVOICE_LEDGER[self._type])
        elif self._type in ITEM_INVOICE_LEDGER and self._item_ledger.get().strip() in ITEM_INVOICE_LEDGER.values():
            self._item_ledger.delete(0, "end")
            self._item_ledger.insert(0, ITEM_INVOICE_LEDGER[self._type])

    def _first_type_field(self) -> tk.Entry | None:
        return self._party if getattr(self, "_type", "") in INVOICE_TYPES else None

    def _advance_type_field(self, widget: tk.Entry) -> None:
        if widget is self._party:
            self._complete_ledger(widget)
            party = widget.get().strip()
            if not party:
                return
            if self._layout == DOUBLE and self._lines and not self._lines[0].ledger.get().strip():
                self._lines[0].side.set(PARTY_SIDE[self._type])     # Sales: party By / Dr; Purchase: To / Cr
                self._lines[0].apply_side()
                self._lines[0].ledger.insert(0, party)
            after = self._supplier_inv if self._type == "Purchase" else None
            if after is None and self._fx_shown():
                after = self._currency_entry
            if not self._dispatch_offered:              # Tally: Dispatch Details follow the party
                self._dispatch_offered = True
                self.open_card("Dispatch Details", then=after)
            elif after is not None:
                after.focus_set()
            else:
                self._focus_body()
        elif widget is self._supplier_inv:
            self._supplier_date.focus_set()
        else:
            self._focus_after_header()

    def _type_details(self, lines: list[dict]) -> dict | None:
        """The extra fields of this type, checked. None (with the message shown) if one is wrong."""
        details: dict[str, str] = {}
        if self._type in INVOICE_TYPES:
            party = self._party.get().strip()
            side = PARTY_SIDE[self._type]
            if not party:
                return self._fail("Enter the Party A/c name.", self._party)
            if not any(ln["side"] == side and ln["ledger"].lower() == party.lower() for ln in lines):
                word = "debited" if side == "Dr" else "credited"
                return self._fail(f"{party} is the Party A/c but is not {word} on this voucher.", self._party)
            details["Party A/c"] = party
        if self._type == "Purchase":
            raw = self._supplier_date.get().strip()
            if raw:
                try:
                    datetime.strptime(raw, DATE_FMT)
                except ValueError:
                    return self._fail("Enter the supplier invoice date as DD-MM-YYYY.", self._supplier_date)
            details.update({"Supplier Invoice No.": self._supplier_inv.get().strip(), "Supplier Invoice Date": raw})
        for title, values in self._forms.items():
            short = DETAIL_FORMS[title][0]
            details.update({f"{short} · {k}": v for k, v in values.items() if v})
        return details

    # ---- Item Invoice ------------------------------------------------------------------------
    def _build_items(self, box: tk.Frame) -> None:
        top = tk.Frame(box, bg=T.WHITE)
        top.pack(side="top", fill="x", pady=(10, 0))
        self._item_ledger_label = tk.Label(top, text="Sales ledger", bg=T.WHITE, fg=T.TEXT, font=T.F_LABEL,
                                           width=14, anchor="w")
        self._item_ledger_label.pack(side="left")
        self._item_ledger = tk.Entry(top, font=T.F_GRID, width=28, relief="flat", bd=0, highlightthickness=1,
                                     highlightbackground=T.LINE, highlightcolor=T.ORANGE)
        self._item_ledger.pack(side="left", ipady=4)
        self._item_ledger.bind("<FocusIn>", lambda _e: self._show_ledger_list(self._item_ledger), add="+")
        self._item_ledger.bind("<KeyRelease>", lambda e: self._ledger_typed(e), add="+")
        self._guard(self._item_ledger)
        tk.Label(top, text="the items' total goes to this ledger", bg=T.WHITE, fg=T.MUTED, font=T.F_HINT,
                 padx=10).pack(side="left")

        self._i_canvas, self._i_grid = self._scroll_grid(box)
        self._i_grid.columnconfigure(0, weight=1)
        for col, (text, anchor) in enumerate((("Name of Item", "w"), ("Quantity", "e"), ("Rate", "e"),
                                              ("per", "center"), ("Amount", "e"))):
            tk.Label(self._i_grid, text=text, bg=T.NAVY, fg=T.WHITE, font=T.F_GRID_HEAD, anchor=anchor,
                     padx=8, pady=5).grid(row=0, column=col, sticky="ew", padx=1, pady=(0, 2))
        totals = tk.Frame(box, bg=T.WHITE)
        totals.pack(side="top", fill="x", pady=(6, 0))
        self._items_total = tk.Label(totals, bg=T.LIGHT_BLUE, fg=T.NAVY, font=T.F_TOTAL, width=16, anchor="e",
                                     padx=6, pady=3)
        self._items_total.pack(side="right", padx=(2, 18))
        tk.Label(totals, text="Total", bg=T.WHITE, fg=T.NAVY, font=T.F_LABEL, padx=8).pack(side="right")
        self._items_note = tk.Label(totals, bg=T.WHITE, fg=T.MUTED, font=T.F_HINT, anchor="w")
        self._items_note.pack(side="left")

    def _add_item_line(self) -> _ItemLine:
        line = _ItemLine(self, self._i_grid, row=len(self._item_lines) + 1)
        line.per.insert(0, DEFAULT_UNIT)
        self._item_lines.append(line)
        return line

    def _clear_items(self) -> None:
        for line in self._item_lines:
            line.destroy()
        self._item_lines = []
        for _ in range(START_ROWS):
            self._add_item_line()
        self._refresh_items()

    def _items_total_value(self) -> Decimal:
        total = Decimal("0")
        for line in self._item_lines:
            amount = line.show_amount()
            total += amount or Decimal("0")
        return total

    def _refresh_items(self) -> None:
        total = self._items_total_value()
        self._items_total.configure(text=fmt_inr(total))
        if self._layout == ITEM_INV and self._type == "Sales":       # GST is worked out on the items' total
            self._taxable.configure(state="normal")
            self._taxable.delete(0, "end")
            if total:
                self._taxable.insert(0, fmt_inr(total))
            self._taxable.configure(state="readonly")
            self._refresh_gst()
        note = {"Sales": "Saving takes these quantities off qty_on_hand",
                "Purchase": "Saving adds these quantities to qty_on_hand"}.get(self._type, "")
        self._items_note.configure(text=note)

    def _on_item_focus(self, widget: tk.Widget) -> None:
        self._ensure_visible(widget, self._i_canvas, self._i_grid)
        line = next((ln for ln in self._item_lines if widget in ln.widgets), None)
        if line is not None and widget is line.item:
            self._show_ledger_list(widget)
        else:
            self._ledger_list.hide()

    def _advance_item(self, widget: tk.Widget) -> bool:
        if widget is self._item_ledger:
            self._complete_ledger(widget)
            if self._item_lines:
                self._item_lines[0].item.focus_set()
            return True
        line = next((ln for ln in self._item_lines if widget in ln.widgets), None)
        if line is None:
            return False
        idx = self._item_lines.index(line)
        if widget is line.item:
            self._complete_ledger(widget)
            if line.item.get().strip():
                line.qty.focus_set()
            elif self._items_total_value():
                self._after_lines().focus_set()        # empty Name of Item ends the items
        elif widget is line.qty:
            line.rate.focus_set()
        elif widget is line.rate:
            self._tidy_amount(line.rate)
            line.per.focus_set()
        else:
            self._refresh_items()
            nxt = self._item_lines[idx + 1] if idx + 1 < len(self._item_lines) else self._add_item_line()
            nxt.item.focus_set()
        return True

    def _item_invoice_lines(self) -> tuple[list[dict], list[dict]] | None:
        """Item Invoice -> (Dr / Cr lines, items). Sales: Party Dr (items + GST), Sales ledger Cr,
        output tax ledgers Cr. Purchase: Purchase ledger Dr, Party Cr."""
        party = self._party.get().strip()
        if not party:
            return self._fail("Enter the Party A/c name.", self._party)
        ledger = self._item_ledger.get().strip()
        if not ledger:
            return self._fail(f"Enter the {self._item_ledger_label.cget('text')}.", self._item_ledger)
        items = []
        for line in self._item_lines:
            if not line.used():
                continue
            if not line.item.get().strip():
                return self._fail("Every line needs a Name of Item.", line.item)
            try:
                name, qty, rate, per, amount = line.values()
            except ValueError as exc:
                return self._fail(f"{line.item.get().strip()}: {exc}.", line.qty)
            items.append({"item": name, "quantity": qty, "rate": rate, "per": per, "amount": amount})
        if not items:
            return self._fail("Enter at least one item.", self._item_lines[0].item if self._item_lines else None)
        total = sum((it["amount"] for it in items), Decimal("0"))
        if not total:
            return self._fail("The items add up to 0.", None)
        if self._type == "Purchase":
            return [{"side": "Dr", "ledger": ledger, "amount": total},
                    {"side": "Cr", "ledger": party, "amount": total}], items
        self._refresh_items()                           # taxable value = the items' total, before GST
        try:
            gst = self._gst_values()
        except _FieldError as exc:
            return self._fail(exc.message, exc.widget)
        taxes = [(OUTPUT_TAX_LEDGERS[k], gst[k]) for k in ("cgst", "sgst", "igst") if gst[k]]
        lines = [{"side": "Dr", "ledger": party, "amount": total + sum((a for _l, a in taxes), Decimal("0"))},
                 {"side": "Cr", "ledger": ledger, "amount": total}]
        lines += [{"side": "Cr", "ledger": name, "amount": amount} for name, amount in taxes]
        return lines, items

    # ---- details cards (Dispatch / Order / Consignee, GST, Unused Vch No.) ---------------------
    def open_card(self, title: str, then: tk.Widget | None = None) -> None:
        """A centred white card. Enter on the last field or Esc closes it; what was typed is kept
        and the cursor goes to `then` (or back to the voucher lines)."""
        self._close_card()
        self._ledger_list.hide()

        def finish(values: dict) -> None:
            if title in DETAIL_FORMS:
                self._forms[title] = values
            self._close_card()
            (then.focus_set() if then is not None and then.winfo_exists() else self._focus_body())

        if title in DETAIL_FORMS:
            fields = DETAIL_FORMS[title][1]
            card = DetailsCard(self, title, fields, self._forms.get(title, {}), on_done=finish, on_close=finish)
        elif title == "GST Details":
            card = DetailsCard(self, "GST Details", ["State", "State code", "GSTIN"],
                               {"State": S.COMPANY_STATE_NAME, "State code": S.COMPANY_STATE_CODE,
                                "GSTIN": S.COMPANY_GSTIN or "not entered (config/settings.py)"},
                               on_close=finish, readonly=True, columns=1,
                               note="Place of supply equal to this state gives CGST + SGST; any other state, IGST.")
        else:
            return
        self._card = card
        card.show()

    def _info_card(self, title: str, text: str) -> None:
        self._close_card()
        card = DetailsCard(self, title, [], on_close=lambda _v: (self._close_card(), self._focus_body()),
                           readonly=True, note=text)
        self._card = card
        card.show()

    def _close_card(self) -> None:
        if self._card is not None:
            self._card.destroy()
            self._card = None

    # ---- Voucher Entry Utilities drawer (Ctrl+I) ----------------------------------------------
    def open_drawer(self) -> None:
        if self._drawer is not None or self._card is not None or self._mode_box is not None:
            return
        self._ledger_list.hide()
        self._return_focus = self.focus_get()
        self._drawer = UtilitiesDrawer(self, self._voucher_status, on_status=self._drawer_status,
                                       on_action=self._drawer_action)
        self._drawer.open()

    def _close_drawer_only(self) -> None:
        if self._drawer is not None:
            self._drawer.destroy()
            self._drawer = None

    def close_drawer(self) -> None:
        """Esc: the drawer slides away and the cursor goes back to the voucher lines."""
        self._close_drawer_only()
        target = getattr(self, "_return_focus", None)
        if target is not None and target.winfo_exists() and target.winfo_ismapped() and target is not self:
            target.focus_set()
        else:
            self.focus_first()

    def _drawer_status(self, status: str) -> None:
        self.set_status(status)
        if self._drawer is not None:
            self._drawer.set_status(self._voucher_status)

    def _drawer_action(self, action: str) -> None:
        self.close_drawer()
        if action in DETAIL_FORMS or action == "GST Details":
            self.open_card(action)
        elif action == "Autofill":
            self.autofill()
        elif action == "Unused Vch No.":
            self.show_unused_numbers()

    @property
    def status(self) -> str:
        return self._voucher_status

    def set_status(self, status: str) -> None:
        """Regular, Optional (kept out of the reports) or Post-Dated (Payment / Receipt / Contra /
        Journal dated after today; counts from its date)."""
        if status == POST_DATED and self._type not in POST_DATED_TYPES:
            self._status.configure(text=f"A {self._type} cannot be Post-Dated (Payment, Receipt, Contra, "
                                        "Journal only).", fg=T.BAD_RED)
            return
        self._voucher_status = status
        if status == REGULAR:
            self._status_badge.pack_forget()
        else:
            note = " · left out of the reports" if status == OPTIONAL else " · date must be after today"
            self._status_badge.configure(text=status + note)
            self._status_badge.pack(side="left", padx=(6, 0), after=self._mode_label)

    # ---- assistants: Autofill, Unused Vch No. -------------------------------------------------
    def _party_for_autofill(self) -> str:
        if self._type in INVOICE_TYPES:
            return self._party.get().strip()
        if self._layout == SINGLE:
            return self._account.get().strip()
        return next((ln.ledger.get().strip() for ln in self._lines if ln.ledger.get().strip()), "")

    def autofill(self) -> None:
        """Fill the lines from the last saved voucher of this type for the party (read in the background)."""
        party = self._party_for_autofill()
        if not party:
            self._status.configure(text="Enter the party first (Party A/c name, Account or the first line), "
                                        "then Autofill.", fg=T.BAD_RED)
            return
        if self._autofill_source is None:
            return
        vtype = self._type
        self._status.configure(text=f"Looking for the last {vtype} for {party}…", fg=T.MUTED)
        run_in_background(self, lambda: self._autofill_source(vtype, party),
                          lambda data: self._apply_autofill(vtype, party, data),
                          lambda exc: self._status.configure(text=f"Autofill failed: {exc}", fg=T.BAD_RED))

    def _apply_autofill(self, vtype: str, party: str, data: dict | None) -> None:
        if vtype != self._type:
            return
        if not data:
            self._status.configure(text=f"No earlier {vtype} for {party} to copy.", fg=T.MUTED)
            return
        lines, items = data["lines"], data["items"]
        if self._layout == ITEM_INV and items:
            self._clear_items()
            for i, it in enumerate(items):
                line = self._item_lines[i] if i < len(self._item_lines) else self._add_item_line()
                line.fill(it["item"], it["quantity"], it["rate"], it["per"])
            other = PARTY_SIDE.get(vtype, "Dr")
            ledger = next((ln["ledger"] for ln in lines if ln["side"] != other
                           and ln["ledger"] not in OUTPUT_TAX_LEDGERS.values()), "")
            if ledger:
                self._item_ledger.delete(0, "end")
                self._item_ledger.insert(0, ledger)
            self._refresh_items()
        elif self._layout in (SINGLE, ACC_INV):
            anchor = party.lower()
            rows = [ln for ln in lines if ln["ledger"].lower() != anchor]
            self._clear_single()
            for i, ln in enumerate(rows):
                line = self._single_lines[i] if i < len(self._single_lines) else self._add_single_line()
                line.ledger.insert(0, ln["ledger"])
                line.amount_entry.insert(0, fmt_inr(ln["amount"]))
            self._refresh_single_total()
        else:
            for line in self._lines:
                line.clear("Dr")
            for i, ln in enumerate(lines):
                line = self._lines[i] if i < len(self._lines) else self._add_line(ln["side"])
                line.side.set(ln["side"])
                line.apply_side()
                line.ledger.delete(0, "end")
                line.ledger.insert(0, ln["ledger"])
                line.amount_entry.insert(0, fmt_inr(ln["amount"]))
            self._refresh_totals()
        for title, (short, fields) in DETAIL_FORMS.items():
            values = {f: data["details"].get(f"{short} · {f}", "") for f in fields}
            if any(values.values()):
                self._forms[title] = values
        self._status.configure(text=f"Filled from the last {vtype} for {party}: check the amounts, then accept.",
                               fg=T.OK_GREEN)

    def show_unused_numbers(self) -> None:
        if self._unused_source is None:
            return
        vtype = self._type
        run_in_background(self, lambda: self._unused_source(vtype),
                          lambda gaps: self._info_card(
                              "Unused Vch No.",
                              f"{vtype}: no unused voucher numbers." if not gaps else
                              f"{vtype}: numbers not used by any saved voucher: "
                              + ", ".join(map(str, gaps[:60])) + (" …" if len(gaps) > 60 else "")),
                          lambda exc: self._status.configure(text=f"Could not check numbers: {exc}", fg=T.BAD_RED))

    # ---- background tint (Credit Note pink, Debit Note yellow) -------------------------------
    def _apply_tint(self, colour: str) -> None:
        """Repaint the screen's white surfaces; entry boxes, headings and side panels keep theirs."""
        skip = {self._ledger_list}
        stack = [self]
        while stack:
            w = stack.pop()
            if w in skip:
                continue
            stack.extend(w.winfo_children())
            if isinstance(w, (tk.Entry, tk.Listbox, tk.Scrollbar)):
                continue
            try:
                if w.cget("bg") in TINTABLE:
                    w.configure(bg=colour)
            except tk.TclError:
                pass

    # ---- altering a saved voucher (drill-down from the Day Book / Ledger / Trial Balance) -------
    def _state(self) -> tuple:
        return (tuple(w.get() for w in self._field_order() if isinstance(w, tk.Entry)),
                tuple(sorted((k, tuple(sorted(v.items()))) for k, v in self._forms.items())), self._voucher_status,
                self._currency, self._fx_rate,
                tuple(tuple((a["cost_centre"], a["amount"]) for a in ln.allocations)
                      for ln in self._lines + self._single_lines))

    def _load_existing(self, data: dict) -> None:
        """Fill the screen with a saved voucher to alter it. Lines come back exactly as saved
        (Double Entry / As Voucher; in the voucher's currency); a voucher with items opens as an
        Item Invoice."""
        self._fill_from(data)
        self.set_status(data["status"])
        self._number_label.configure(text=f"No.  {data['invoice_no'] or data['number']}")
        self._status.configure(text=f"Altering {data['type']} No. {data['invoice_no'] or data['number']}: Ctrl+A saves "
                                    "the changes, Alt+2 duplicates, Alt+X cancels, Esc on the date goes back.",
                               fg=T.MUTED)
        self.update_idletasks()
        self._snapshot = self._state()

    def _load_template(self, data: dict) -> None:
        """Alt+2: a NEW voucher with the saved one's ledgers, amounts, GST and details. It takes the
        next voucher number (set_type shows it) and gets its own invoice number when saved."""
        self._fill_from(data)
        status = data["status"]
        if status == CANCELLED or (status == POST_DATED and data["date"] <= date.today()):
            status = REGULAR
        self.set_status(status)
        self._status.configure(text=f"Duplicate of {data['type']} No. {data['invoice_no'] or data['number']}: check "
                                    "the date and amounts, then Ctrl+A saves it as a new voucher.", fg=T.MUTED)

    def _fill_from(self, data: dict) -> None:
        vtype = data["type"]
        if vtype in INVOICE_TYPES:
            self._invoice_mode = ITEM_INV if data["items"] else AS_VOUCHER
        else:
            self._mode = DOUBLE
        self.set_type(vtype)
        self._date.delete(0, "end")
        self._date.insert(0, data["date"].strftime(DATE_FMT))
        self._show_weekday()
        self._narration.insert(0, data["narration"] or "")
        details = dict(data["details"])
        if vtype in INVOICE_TYPES:            # older vouchers kept no Party A/c: the party-side line
            party = details.get("Party A/c") or next(
                (ln["ledger"] for ln in data["lines"] if ln["side"] == PARTY_SIDE[vtype]), "")
            self._party.insert(0, party)
        if vtype == "Purchase":
            self._supplier_inv.insert(0, details.get("Supplier Invoice No.", ""))
            self._supplier_date.insert(0, details.get("Supplier Invoice Date", ""))
        for title, (short, fields) in DETAIL_FORMS.items():
            values = {f: details.get(f"{short} · {f}", "") for f in fields}
            if any(values.values()):
                self._forms[title] = values
        self._dispatch_offered = True
        lines = data["lines"]
        fx = data.get("forex")
        if self._layout == ITEM_INV:
            for i, it in enumerate(data["items"]):
                line = self._item_lines[i] if i < len(self._item_lines) else self._add_item_line()
                line.fill(it["item"], it["quantity"], it["rate"], it["per"])
            party_side = PARTY_SIDE[vtype]
            ledger = next((ln["ledger"] for ln in lines if ln["side"] != party_side
                           and ln["ledger"] not in OUTPUT_TAX_LEDGERS.values()), "")
            self._item_ledger.delete(0, "end")
            self._item_ledger.insert(0, ledger)
        else:
            if fx and len(fx["amounts"]) == len(lines):
                self._currency, self._fx_rate = fx["currency"], fx["rate"]     # lines show as typed
                self._currency_entry.delete(0, "end")
                self._currency_entry.insert(0, fx["currency"])
            for i, ln in enumerate(lines):
                line = self._lines[i] if i < len(self._lines) else self._add_line(ln["side"])
                line.side.set(ln["side"])
                line.apply_side()
                line.ledger.delete(0, "end")
                line.ledger.insert(0, ln["ledger"])
                amount = fx["amounts"][i] if self.is_forex else ln["amount"]
                line.amount_entry.insert(0, fmt_inr(amount))
                if ln.get("allocations"):                 # shown in the voucher's currency, like the line
                    line.allocations = rescale(ln["allocations"], amount) if self.is_forex else list(ln["allocations"])
            self._refresh_totals()
        gst = data.get("gst")
        if vtype == "Sales" and gst:
            self._taxable.configure(state="normal")
            for entry, value in ((self._gstin, gst["gstin"]), (self._pos, gst["place_of_supply"]),
                                 (self._hsn, gst["hsn"]), (self._rate, gst["rate"]),
                                 (self._taxable, fmt_inr(gst["taxable"]))):
                entry.delete(0, "end")
                entry.insert(0, value)
        if self._layout == ITEM_INV:
            self._refresh_items()
        self._refresh_gst()
