"""
Audit Trail (Help › Activity Log, F1 then G; or L on the Corridor) — the compliance sheet over
bp_system_audit_logs, oldest entry at the top, the newest highlighted.

    From [DD-MM-YYYY]  To [DD-MM-YYYY]  Voucher No. [        ]          Verify chain   Clear filter
    # | Time | User / Machine | Source | Action | Table | Vch Type | Vch No. | Original | Orig. ₹ |
      New | New ₹ | Balances moved                                   (scrolls both ways)
    Original / New / Balances of the highlighted entry, in full, with its seal (SHA-256)

Keys: type a date range (log date, DD-MM-YYYY, either end may be blank) and / or a voucher or
invoice number (part of it is enough), Enter applies the filter and moves to the sheet; F goes
back to the filter; V verifies the whole hash chain; C clears the filter; Up / Down / Page Up /
Page Down move in the sheet; Esc (anywhere) clears the canvas and gives the keyboard back to the
Corridor. Read only: nothing on this screen can change the log. Loaded in a background thread.
"""
from __future__ import annotations

import tkinter as tk
from datetime import datetime
from pathlib import Path
from tkinter import ttk
from typing import Callable

from config import theme as T
from services import audit
from services.background import run_in_background
from views.masters_overlay import hotkey_labels
from views.report_common import title_bar

COLUMNS = (("id", "#", 54, "e"), ("logged_at", "Time", 150, "w"), ("user_id", "User / Machine", 230, "w"),
           ("source", "Source", 140, "w"), ("action", "Action", 80, "w"), ("table_name", "Table", 170, "w"),
           ("voucher_type", "Vch Type", 100, "w"), ("voucher_no", "Vch No.", 130, "w"),
           ("old_text", "Original", 360, "w"), ("old_amount", "Orig. ₹", 110, "e"),
           ("new_text", "New", 360, "w"), ("new_amount", "New ₹", 110, "e"), ("balances", "Balances moved", 320, "w"))
DATE_FMT = "%d-%m-%Y"


class AuditTrailView(tk.Frame):
    def __init__(self, parent: tk.Widget, *, db_path: Path, on_close: Callable[[], None]) -> None:
        super().__init__(parent, bg=T.WHITE)
        self._db, self._on_close = db_path, on_close
        self._rows: list[dict] = []
        title_bar(self, "Audit Trail - System Audit Log", "Enter filter    F Filter    V Verify    C Clear    Esc Corridor")

        top = tk.Frame(self, bg=T.WHITE)
        top.pack(side="top", fill="x", padx=14, pady=(8, 4))
        self._from = self._field(top, "From", 11)
        self._to = self._field(top, "To", 11)
        self._vno = self._field(top, "Voucher No.", 16)
        for label, key, command in (("Clear filter", "C", self.clear), ("Verify chain", "V", self.verify)):
            link = tk.Frame(top, bg=T.LIGHT_BLUE, cursor="hand2", highlightthickness=1, highlightbackground=T.LINE)
            link.pack(side="right", padx=(6, 0))
            for w in (link, *hotkey_labels(link, label, key, T.LIGHT_BLUE, T.NAVY, first_padx=8)):
                w.bind("<Button-1>", lambda _e, c=command: c())
            tk.Frame(link, bg=T.LIGHT_BLUE, width=8).pack(side="left")
        self._summary = tk.Label(self, bg=T.WHITE, fg=T.MUTED, font=T.F_TEXT, anchor="w")
        self._summary.pack(side="top", fill="x", padx=14, pady=(0, 4))

        box = tk.Frame(self, bg=T.WHITE, highlightthickness=1, highlightbackground=T.BORDER)
        box.pack(side="top", fill="both", expand=True, padx=14)
        self.tree = ttk.Treeview(box, columns=[c[0] for c in COLUMNS], show="headings", style="BizPulse.Treeview",
                                 selectmode="browse")
        for key, head, width, anchor in COLUMNS:
            self.tree.heading(key, text=head, anchor=anchor)
            self.tree.column(key, width=width, minwidth=40, anchor=anchor, stretch=False)
        vbar = ttk.Scrollbar(box, orient="vertical", command=self.tree.yview)
        hbar = ttk.Scrollbar(box, orient="horizontal", command=self.tree.xview)
        self.tree.configure(yscrollcommand=vbar.set, xscrollcommand=hbar.set)
        self.tree.grid(row=0, column=0, sticky="nsew")
        vbar.grid(row=0, column=1, sticky="ns")
        hbar.grid(row=1, column=0, sticky="ew")
        box.rowconfigure(0, weight=1)
        box.columnconfigure(0, weight=1)
        self.tree.tag_configure("Cancel", foreground=T.BAD_RED)
        self.tree.tag_configure("Alter", foreground=T.NAVY)
        self.tree.tag_configure("outside", background="#FFF4E5")
        self.tree.bind("<<TreeviewSelect>>", lambda _e: self._show_detail())

        detail = tk.Frame(self, bg=T.LIGHT_BLUE, highlightthickness=1, highlightbackground=T.BORDER)
        detail.pack(side="top", fill="x", padx=14, pady=(8, 10))
        self._detail = tk.Label(detail, bg=T.LIGHT_BLUE, fg=T.TEXT, font=T.F_TEXT, anchor="w", justify="left",
                                wraplength=860)
        self._detail.pack(side="top", fill="x", padx=10, pady=6)
        self._detail.bind("<Configure>", lambda e: self._detail.configure(wraplength=max(300, e.width - 10)))
        self.load()

    def _field(self, parent: tk.Widget, label: str, width: int) -> tk.Entry:
        tk.Label(parent, text=label, bg=T.WHITE, fg=T.TEXT, font=T.F_TEXT).pack(side="left", padx=(0, 6))
        e = tk.Entry(parent, width=width, font=T.F_TEXT, relief="flat", bd=0, highlightthickness=1,
                     highlightbackground=T.LINE, highlightcolor=T.ORANGE)
        e.pack(side="left", ipady=3, padx=(0, 16))
        return e

    # ---- data ----------------------------------------------------------------------------
    def _dates(self):
        out = []
        for e, name in ((self._from, "From"), (self._to, "To")):
            text = e.get().strip()
            try:
                out.append(datetime.strptime(text, DATE_FMT).date() if text else None)
            except ValueError:
                raise ValueError(f"{name}: enter the date as DD-MM-YYYY.") from None
        return out

    def load(self) -> None:
        try:
            start, end = self._dates()
        except ValueError as exc:
            self._summary.configure(text=str(exc), fg=T.BAD_RED)
            return
        vno, db = self._vno.get(), self._db
        self._summary.configure(text="Loading…", fg=T.MUTED)
        run_in_background(self, lambda: audit.load(db, start, end, vno), self._show,
                          lambda exc: self._summary.configure(text=f"Could not read the audit log: {exc}", fg=T.BAD_RED))

    def _show(self, rows: list[dict]) -> None:
        self._rows = rows
        self.tree.delete(*self.tree.get_children())
        for i, r in enumerate(rows):
            tags = (r["action"],) + (("outside",) if r["source"] == audit.OUTSIDE else ())
            self.tree.insert("", "end", iid=str(i), tags=tags,
                             values=[("" if r[k] is None else r[k]) for k, *_x in COLUMNS])
        filtered = any(e.get().strip() for e in (self._from, self._to, self._vno))
        self._summary.configure(text=f"{len(rows)} entr{'y' if len(rows) == 1 else 'ies'}"
                                     f"{' matching the filter' if filtered else ''}, oldest first"
                                     f"{' (the newest 5,000)' if len(rows) >= 5000 else ''}. "
                                     "V checks that no entry was changed or removed.", fg=T.MUTED)
        if rows:
            last = str(len(rows) - 1)
            self.tree.selection_set(last)
            self.tree.focus(last)
            self.tree.see(last)
        self._show_detail()

    def _show_detail(self) -> None:
        sel = self.tree.selection()
        if not sel:
            self._detail.configure(text="No entry highlighted. Every save, alteration and cancellation is written here.")
            return
        r = self._rows[int(sel[0])]
        what = f"{r['voucher_type'] or ''} {r['voucher_no'] or ''}".strip() or r["table_name"]
        lines = [f"Entry {r['id']} · {r['logged_at']} · {r['user_id']} · {r['source']} · {r['action']} {what}",
                 f"Original: {r['old_text'] or '—'}" + (f"   (₹ {r['old_amount']})" if r["old_amount"] else ""),
                 f"New: {r['new_text'] or '—'}" + (f"   (₹ {r['new_amount']})" if r["new_amount"] else "")]
        if r["balances"]:
            lines.append(f"Balances moved: {r['balances']}")
        lines.append(f"Seal: {r['row_hash'] or 'not sealed yet (sealed at the next save or start)'}")
        self._detail.configure(text="\n".join(lines))

    def verify(self) -> None:
        self._summary.configure(text="Checking the whole chain…", fg=T.MUTED)
        db = self._db
        run_in_background(self, lambda: audit.verify(db), self._verified,
                          lambda exc: self._summary.configure(text=f"Could not check: {exc}", fg=T.BAD_RED))

    def _verified(self, v: audit.Verify) -> None:
        head = f" Chain head: {v.head[:16]}… (note it at period close)." if v.head else ""
        self._summary.configure(text=("Intact. " if v.ok else "BROKEN. ") + v.message + head,
                                fg=T.OK_GREEN if v.ok else T.BAD_RED)

    def clear(self) -> None:
        for e in (self._from, self._to, self._vno):
            e.delete(0, "end")
        self.load()

    # ---- keys ----------------------------------------------------------------------------
    def focus_first(self) -> None:
        self.tree.focus_set()

    def handle_key(self, event: tk.Event) -> str | None:
        if event.keysym == "Escape":
            self._on_close()
            return "break"
        if event.state & (T.MOD_CTRL | T.MOD_ALT):
            return None
        typing = event.widget in (self._from, self._to, self._vno)
        if event.keysym in ("Return", "KP_Enter"):
            if typing:
                self.load()
                self.tree.focus_set()
            return "break"
        if typing:
            return None
        key = event.keysym.lower()
        if key == "f":
            self._from.focus_set()
            return "break"
        if key == "v":
            self.verify()
            return "break"
        if key == "c":
            self.clear()
            return "break"
        return None
