"""
Dashboard (Alt+D, or [D] Dashboard in the header) — analytics board filling the white canvas.

    +---------------------------------------------------------------------------+
    | Dashboard - SRIJEE CREATIONS                        F5 Refresh   Esc Back |
    +-------------------------------------+-------------------------------------+
    | Sales Trend          FY total ₹…    | Purchase Trend        FY total ₹…   |
    |  ▂ ▃ ▅ ▇ ▆ …  (Apr – Mar)           |  ▂ ▂ ▃ ▅ ▃ …                        |
    +-------------------------------------+-------------------------------------+
    | Cash In / Out Flow   ■ In ■ Out     | Accounting Ratios                   |
    |  ▅▃ ▆▂ ▇▅ …                         |  Current Ratio  Quick Ratio  GP %   |
    |                                     |  NP %   Debtors (days)  Wkg Capital |
    +-------------------------------------+-------------------------------------+

Figures: services/analytics.py, from saved vouchers for the financial year to date, loaded in
a background thread. Money in is blue, money out is orange, on every chart. Point at a month
for exact figures. Ratios that cannot be worked out show "—" (see Ratio Analysis for why).

Keys: Esc back; F5 refresh is on the action bar.
"""
from __future__ import annotations

import tkinter as tk
from datetime import date
from decimal import Decimal
from pathlib import Path
from typing import Callable

from components.column_chart import SERIES_IN, SERIES_OUT, ColumnChart, full_inr
from config import theme as T
from services.analytics import MONTHS, RatioAnalysis, Trends, monthly_trends, ratio_analysis
from services.background import run_in_background
from services.reports import ReportError, build_reports
from views.report_common import ratio_text, title_bar
from views.vouchers_view import DATE_FMT

# (row in Ratio Analysis, caption on the tile)
RATIO_TILES = [("Current Ratio", "Current Ratio"), ("Quick Ratio", "Quick Ratio"),
               ("Gross Profit %", "Gross Profit %"), ("Nett Profit %", "Nett Profit %"),
               ("Recv. Turnover in Days", "Debtors (days)"), ("Working Capital", "Working Capital")]


class _Card(tk.Frame):
    def __init__(self, parent: tk.Widget, title: str) -> None:
        super().__init__(parent, bg=T.WHITE, highlightthickness=1, highlightbackground=T.BORDER)
        head = tk.Frame(self, bg=T.WHITE)
        head.pack(side="top", fill="x", padx=12, pady=(8, 0))
        tk.Label(head, text=title, bg=T.WHITE, fg=T.NAVY, font=T.F_PANEL_HEAD).pack(side="left")
        self.subtitle = tk.Label(head, text="", bg=T.WHITE, fg=T.MUTED, font=T.F_HINT)
        self.subtitle.pack(side="right")
        self.body = tk.Frame(self, bg=T.WHITE)
        self.body.pack(side="top", fill="both", expand=True, padx=8, pady=(2, 8))


class DashboardGridView(tk.Frame):
    def __init__(self, parent: tk.Widget, *, db_path: Path, company: str, on_close: Callable[[], None],
                 upto: date | None = None) -> None:
        super().__init__(parent, bg=T.WHITE)
        self._on_close = on_close
        self._upto = upto or date.today()
        title_bar(self, f"Dashboard - {company.upper()}", "F5 Refresh    Esc Back")
        self._subtitle = tk.Label(self, text="Loading…", bg=T.WHITE, fg=T.MUTED, font=T.F_LABEL, anchor="w")
        self._subtitle.pack(side="top", fill="x", padx=14, pady=(8, 4))

        grid = tk.Frame(self, bg=T.WHITE, takefocus=1)
        grid.pack(side="top", fill="both", expand=True, padx=14, pady=(0, 12))
        for i in (0, 1):
            grid.columnconfigure(i, weight=1, uniform="col")
            grid.rowconfigure(i, weight=1, uniform="row")
        self._grid = grid

        self._sales = _Card(grid, "Sales Trend")
        self._purchases = _Card(grid, "Purchase Trend")
        self._cash = _Card(grid, "Cash In / Out Flow")
        self._ratios = _Card(grid, "Accounting Ratios")
        for card, (r, c) in zip((self._sales, self._purchases, self._cash, self._ratios),
                                ((0, 0), (0, 1), (1, 0), (1, 1))):
            card.grid(row=r, column=c, sticky="nsew", padx=(0 if c == 0 else 6, 6 if c == 0 else 0),
                      pady=(0 if r == 0 else 6, 6 if r == 0 else 0))

        self._charts: list[ColumnChart] = []
        for card, series, empty in (
            (self._sales, [("Sales", SERIES_IN)], "No sales vouchers this financial year yet"),
            (self._purchases, [("Purchases", SERIES_OUT)], "No purchase vouchers this financial year yet"),
            (self._cash, [("Cash in", SERIES_IN), ("Cash out", SERIES_OUT)], "No cash or bank movement yet"),
        ):
            chart = ColumnChart(card.body, series=series, categories=MONTHS, titles=MONTHS, empty_text=empty)
            chart.pack(fill="both", expand=True)
            self._charts.append(chart)

        self._tiles: dict[str, tuple[tk.Label, tk.Label]] = {}
        tiles = self._ratios.body
        for i in range(3):
            tiles.columnconfigure(i, weight=1, uniform="tile")
        for i in range(2):
            tiles.rowconfigure(i, weight=1, uniform="tile")
        for n, (name, caption_text) in enumerate(RATIO_TILES):
            tile = tk.Frame(tiles, bg=T.ROW_ALT, highlightthickness=1, highlightbackground=T.LINE)
            tile.grid(row=n // 3, column=n % 3, sticky="nsew", padx=3, pady=3)
            value = tk.Label(tile, text="…", bg=T.ROW_ALT, fg=T.TEXT, font=T.F_TILE, anchor="w")
            value.pack(side="top", fill="x", padx=10, pady=(10, 0))
            caption = tk.Label(tile, text=caption_text, bg=T.ROW_ALT, fg=T.MUTED, font=T.F_HINT, anchor="w")
            caption.pack(side="top", fill="x", padx=10, pady=(0, 8))
            self._tiles[name] = (value, caption)

        db = db_path
        run_in_background(self, lambda: (monthly_trends(db, self._upto),
                                         ratio_analysis(build_reports(db, self._upto))),
                          self._show, self._failed)

    def _show(self, result: tuple[Trends, RatioAnalysis]) -> None:
        tr, ra = result
        titles = [tr.month_name(i) for i in range(12)]
        self._subtitle.configure(text=f"Financial year {tr.fy_label} · {tr.fy_start.strftime(DATE_FMT)} to "
                                      f"{tr.upto.strftime(DATE_FMT)} · {tr.voucher_count} voucher(s) · "
                                      "point at a month for exact figures")
        for chart, values in zip(self._charts, ([tr.sales], [tr.purchases], [tr.cash_in, tr.cash_out])):
            chart.set_data(values, titles)
        self._sales.subtitle.configure(text=f"FY total {full_inr(sum(tr.sales, Decimal(0)))}")
        self._purchases.subtitle.configure(text=f"FY total {full_inr(sum(tr.purchases, Decimal(0)))}")
        net = sum(tr.cash_in, Decimal(0)) - sum(tr.cash_out, Decimal(0))
        self._cash.subtitle.configure(text=f"Net {'in' if net >= 0 else 'out'} {full_inr(abs(net))}")
        for name, (value, caption) in self._tiles.items():
            row = ra.ratio(name)
            value.configure(text=ratio_text(row.value, row.kind), fg=T.MUTED if row.value is None else T.TEXT)
        warn_words = ("not grouped", "overstated", "understated", "left out of the books", "twice", "not a valid")
        if any(w in n for n in ra.notes for w in warn_words):
            self._ratios.subtitle.configure(text="Check the notes: R on the Corridor (Ratio Analysis)", fg=T.BAD_RED)
        else:
            self._ratios.subtitle.configure(text="R on the Corridor: Ratio Analysis", fg=T.MUTED)

    def _failed(self, exc: Exception) -> None:
        msg = str(exc) if isinstance(exc, ReportError) else f"Could not build the Dashboard: {exc}"
        self._subtitle.configure(text=msg, fg=T.BAD_RED)

    def focus_first(self) -> None:
        self._grid.focus_set()

    def handle_key(self, event: tk.Event) -> str | None:
        if event.keysym == "Escape":
            self._on_close()
            return "break"
        return None
