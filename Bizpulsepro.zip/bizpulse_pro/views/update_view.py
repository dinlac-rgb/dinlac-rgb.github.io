"""
[U] Upgrade (Alt+U) — Software Update on the white canvas.

    Software Update                                         R Check again   O Open link   Esc Corridor
    Installed: BizPulse Pro 1.0.0 · security patch level 2026.10.0 · tax tables 2026.10
    Your BizPulse Pro System is Up to Date                      (or: 2 updates available.)
    Kind                  | Version | Installed | Title
    Security patch        | 2026.11 | 2026.10.0 | …
    notes of the highlighted update

The check runs as soon as the screen opens (services/updates.py, background thread). Keys: R
checks again; O (or Enter) opens the highlighted update's download page in the browser; Esc
clears the canvas and gives the keyboard back to the Corridor. Nothing is installed from here.
"""
from __future__ import annotations

import tkinter as tk
import webbrowser
from tkinter import ttk
from typing import Callable

from config import theme as T
from services.background import run_in_background
from services.updates import KINDS, UpdateError, UpdateResult, check
from views.masters_overlay import hotkey_labels
from views.report_common import title_bar


class UpdateView(tk.Frame):
    def __init__(self, parent: tk.Widget, *, feed_url: str, installed: dict[str, str], on_close: Callable[[], None],
                 on_note: Callable[[str], None] | None = None, checker=check) -> None:
        super().__init__(parent, bg=T.WHITE, takefocus=1)
        self._feed, self._installed, self._on_close = feed_url, installed, on_close
        self._on_note = on_note or (lambda _m: None)
        self._checker = checker
        self._result: UpdateResult | None = None
        title_bar(self, "Software Update", "R Check again    O Open link    Esc Corridor")
        top = tk.Frame(self, bg=T.WHITE)
        top.pack(side="top", fill="x", padx=14, pady=(10, 4))
        tk.Label(top, text=(f"Installed: BizPulse Pro {installed.get('app', '?')} · security patch level "
                            f"{installed.get('security', '?')} · tax tables {installed.get('tax_tables', '?')}"),
                 bg=T.WHITE, fg=T.MUTED, font=T.F_TEXT, anchor="w").pack(side="left")
        for label, key, command in (("Open link", "O", self.open_link), ("Check again", "R", self.run_check)):
            link = tk.Frame(top, bg=T.LIGHT_BLUE, cursor="hand2", highlightthickness=1, highlightbackground=T.LINE)
            link.pack(side="right", padx=(6, 0))
            for w in (link, *hotkey_labels(link, label, key, T.LIGHT_BLUE, T.NAVY, first_padx=8)):
                w.bind("<Button-1>", lambda _e, c=command: c())
            tk.Frame(link, bg=T.LIGHT_BLUE, width=8).pack(side="left")
        self.status = tk.Label(self, bg=T.WHITE, fg=T.MUTED, font=T.F_TEXT, anchor="w", justify="left", wraplength=860)
        self.status.pack(side="top", fill="x", padx=14, pady=(8, 8))
        box = tk.Frame(self, bg=T.WHITE, highlightthickness=1, highlightbackground=T.BORDER)
        box.pack(side="top", fill="both", expand=True, padx=14)
        self.tree = ttk.Treeview(box, columns=("kind", "version", "installed", "title"), show="headings",
                                 style="BizPulse.Treeview", selectmode="browse")
        for key, head, width, stretch in (("kind", "Kind", 190, False), ("version", "Version", 110, False),
                                          ("installed", "Installed", 110, False), ("title", "Title", 400, True)):
            self.tree.heading(key, text=head, anchor="w")
            self.tree.column(key, width=width, minwidth=60, stretch=stretch)
        self.tree.pack(fill="both", expand=True)
        self.tree.bind("<<TreeviewSelect>>", lambda _e: self._show_notes())
        self.tree.bind("<Double-Button-1>", lambda _e: self.open_link())
        self._notes = tk.Label(self, bg=T.WHITE, fg=T.TEXT, font=T.F_TEXT, anchor="w", justify="left", wraplength=860)
        self._notes.pack(side="top", fill="x", padx=14, pady=(6, 10))
        self.run_check()

    def run_check(self) -> None:
        self.status.configure(text="Checking the BizPulse update server…", fg=T.MUTED)
        feed, installed = self._feed, dict(self._installed)
        run_in_background(self, lambda: self._checker(feed, installed), self._checked, self._failed)

    def _checked(self, result: UpdateResult) -> None:
        self._result = result
        self.tree.delete(*self.tree.get_children())
        for i, u in enumerate(result.updates):
            self.tree.insert("", "end", iid=str(i), values=(KINDS[u.kind], u.version, u.installed, u.title))
        text = result.message
        if result.skipped:
            text += f" ({result.skipped} item(s) in the feed could not be read.)"
        self.status.configure(text=text, fg=T.OK_GREEN if not result.updates else T.NAVY)
        self._on_note(f"[Upgrade] {text}")
        if result.updates:
            self.tree.selection_set("0")
            self.tree.focus("0")
        self._show_notes()

    def _failed(self, exc: Exception) -> None:
        msg = str(exc) if isinstance(exc, UpdateError) else f"The check failed: {exc}"
        self.status.configure(text=msg, fg=T.BAD_RED)
        self._on_note(f"[Upgrade] {msg}")

    def _selected(self):
        sel = self.tree.selection()
        return self._result.updates[int(sel[0])] if sel and self._result else None

    def _show_notes(self) -> None:
        u = self._selected()
        if u is None:
            self._notes.configure(text="")
            return
        lines = [u.notes] if u.notes else []
        lines.append(f"Download: {u.url}" if u.url else "No https download link was given for this item.")
        if u.sha256:
            lines.append(f"SHA-256 of the file: {u.sha256} (compare it before installing)")
        self._notes.configure(text="\n".join(lines))

    def open_link(self) -> None:
        u = self._selected()
        if u is not None and u.url:
            webbrowser.open(u.url)
            self._on_note(f"[Upgrade] Opened the download page for {u.title} {u.version}.")

    def focus_first(self) -> None:
        self.tree.focus_set()

    def handle_key(self, event: tk.Event) -> str | None:
        if event.keysym == "Escape":
            self._on_close()
            return "break"
        if event.state & (T.MOD_CTRL | T.MOD_ALT):
            return None
        key = event.keysym.lower()
        if key == "r":
            self.run_check()
            return "break"
        if key in ("o", "return", "kp_enter"):
            self.open_link()
            return "break"
        return None
