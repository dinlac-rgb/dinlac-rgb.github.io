"""
A full-canvas list screen many BizPulse screens share: title bar, a line under it, a table, a
detail line for the highlighted row and bold-letter actions.

    ListScreen(parent, title=..., columns=[(key, heading, width, anchor)], load=lambda: rows,
               on_close=..., actions=[("P", "Print", lambda row: ...)], on_enter=lambda row: ...,
               detail=lambda row: "text", empty="Nothing to show.", subtitle="…")

Keys and mouse: Up / Down move; Enter (bound on the rows themselves) or a double-click opens the
highlighted row; a single click highlights a row and gives the list the keyboard.

`load` runs in a background thread and returns a list of dicts (keys = column keys; an optional
"_tag" colours the row: muted, bad, good, total). Keys: Up / Down move; Enter runs on_enter;
each action's letter runs it on the highlighted row (row is None when the table is empty);
F5 (the window's Refresh) or reload() reads again; Esc closes. Segoe UI 11 normal; the action
letters bold, flush in their word.
"""
from __future__ import annotations

import tkinter as tk
from tkinter import ttk
from typing import Callable, Sequence

from config import theme as T
from services.background import run_in_background
from views.masters_overlay import hotkey_labels
from views.report_common import title_bar


class ListScreen(tk.Frame):
    def __init__(self, parent: tk.Widget, *, title: str, columns: Sequence[tuple[str, str, int, str]],
                 load: Callable[[], list[dict]], on_close: Callable[[], None],
                 actions: Sequence[tuple[str, str, Callable[[dict | None], None]]] = (),
                 on_enter: Callable[[dict], None] | None = None, detail: Callable[[dict], str] | None = None,
                 empty: str = "Nothing to show.", subtitle: str = "", stretch: str | None = None) -> None:
        super().__init__(parent, bg=T.WHITE, takefocus=1)
        self._load, self._on_close, self._on_enter, self._detail_of = load, on_close, on_enter, detail
        self._actions = list(actions)
        self._empty = empty
        self.rows: list[dict] = []
        keys = "    ".join(f"{k} {label}" for k, label, _c in self._actions)
        title_bar(self, title, (keys + "    " if keys else "") + ("Enter open    " if on_enter else "") + "Esc Back")
        top = tk.Frame(self, bg=T.WHITE)
        top.pack(side="top", fill="x", padx=14, pady=(8, 4))
        self.subtitle = tk.Label(top, text=subtitle, bg=T.WHITE, fg=T.MUTED, font=T.F_TEXT, anchor="w",
                                 justify="left", wraplength=620)
        self.subtitle.pack(side="left", fill="x", expand=True)
        for key, label, command in reversed(self._actions):
            link = tk.Frame(top, bg=T.LIGHT_BLUE, cursor="hand2", highlightthickness=1, highlightbackground=T.LINE)
            link.pack(side="right", padx=(6, 0))
            for w in (link, *hotkey_labels(link, label, key, T.LIGHT_BLUE, T.NAVY, first_padx=8)):
                w.bind("<Button-1>", lambda _e, c=command: c(self.selected()))
            tk.Frame(link, bg=T.LIGHT_BLUE, width=8).pack(side="left")
        self.status = tk.Label(self, bg=T.WHITE, fg=T.MUTED, font=T.F_TEXT, anchor="w", justify="left", wraplength=880)
        self.status.pack(side="top", fill="x", padx=14, pady=(0, 4))
        box = tk.Frame(self, bg=T.WHITE, highlightthickness=1, highlightbackground=T.BORDER)
        box.pack(side="top", fill="both", expand=True, padx=14)
        self.columns = list(columns)
        self.tree = ttk.Treeview(box, columns=[c[0] for c in columns], show="headings", style="BizPulse.Treeview",
                                 selectmode="browse")
        widest = stretch or max(columns, key=lambda c: c[2])[0]
        for key, head, width, anchor in columns:
            self.tree.heading(key, text=head, anchor=anchor)
            self.tree.column(key, width=width, minwidth=40, anchor=anchor, stretch=key == widest)
        for tag, kw in (("muted", {"foreground": T.MUTED}), ("bad", {"foreground": T.BAD_RED}),
                        ("good", {"foreground": T.OK_GREEN}),
                        ("total", {"foreground": T.NAVY, "background": T.LIGHT_BLUE})):
            self.tree.tag_configure(tag, **kw)
        vbar = ttk.Scrollbar(box, orient="vertical", command=self.tree.yview)
        hbar = ttk.Scrollbar(box, orient="horizontal", command=self.tree.xview)
        self.tree.configure(yscrollcommand=vbar.set, xscrollcommand=hbar.set)
        self.tree.grid(row=0, column=0, sticky="nsew")
        vbar.grid(row=0, column=1, sticky="ns")
        hbar.grid(row=1, column=0, sticky="ew")
        box.rowconfigure(0, weight=1)
        box.columnconfigure(0, weight=1)
        self.tree.bind("<<TreeviewSelect>>", lambda _e: self._show_detail())
        self.tree.bind("<Double-Button-1>", lambda _e: self.enter())
        # Bound on the rows themselves too, so Enter opens the highlighted row and a single click
        # picks a row (keyboard ready) however the window routes keys. "break" stops the window's
        # own Enter handling from running it a second time.
        for seq in ("<Return>", "<KP_Enter>"):
            self.tree.bind(seq, lambda _e: (self.enter(), "break")[1])
        self.tree.bind("<ButtonRelease-1>", self._single_click_select)
        self.detail = tk.Label(self, bg=T.WHITE, fg=T.TEXT, font=T.F_TEXT, anchor="w", justify="left", wraplength=880)
        self.detail.pack(side="top", fill="x", padx=14, pady=(6, 10))
        self.reload()

    # ---- data ----------------------------------------------------------------------------
    def reload(self) -> None:
        self.status.configure(text="Loading…", fg=T.MUTED)
        run_in_background(self, self._load, self._show,
                          lambda exc: self.status.configure(text=f"Could not read: {exc}", fg=T.BAD_RED))

    def _show(self, rows: list[dict]) -> None:
        keep = self.tree.selection()
        self.rows = rows
        self.tree.delete(*self.tree.get_children())
        for i, r in enumerate(rows):
            self.tree.insert("", "end", iid=str(i), tags=(r.get("_tag", ""),),
                             values=[r.get(c[0], "") for c in self.columns])
        self.status.configure(text="" if rows else self._empty, fg=T.MUTED)
        if rows:
            pick = keep[0] if keep and int(keep[0]) < len(rows) else "0"
            self.tree.selection_set(pick)
            self.tree.focus(pick)
            self.tree.see(pick)
        self._show_detail()

    def selected(self) -> dict | None:
        sel = self.tree.selection()
        return self.rows[int(sel[0])] if sel and int(sel[0]) < len(self.rows) else None

    def say(self, text: str, error: bool = False, good: bool = False) -> None:
        self.status.configure(text=text, fg=T.BAD_RED if error else (T.OK_GREEN if good else T.MUTED))

    def _show_detail(self) -> None:
        row = self.selected()
        self.detail.configure(text=self._detail_of(row) if row is not None and self._detail_of else "")

    def _single_click_select(self, event) -> None:
        """One click highlights the row under the mouse and gives the list the keyboard, so Up / Down
        and Enter carry on from there (a double-click still opens it straight away)."""
        row = self.tree.identify_row(event.y)
        if row:
            self.tree.selection_set(row)
            self.tree.focus(row)
        self.tree.focus_set()

    def enter(self) -> None:
        row = self.selected()
        if row is not None and self._on_enter is not None:
            self._on_enter(row)

    # ---- keys ----------------------------------------------------------------------------
    def focus_first(self) -> None:
        self.tree.focus_set()

    def handle_key(self, event: tk.Event) -> str | None:
        if event.keysym == "Escape":
            self._on_close()
            return "break"
        if event.state & (T.MOD_CTRL | T.MOD_ALT):
            return None
        if event.keysym in ("Return", "KP_Enter"):
            self.enter()
            return "break"
        for key, _label, command in self._actions:
            if event.keysym.lower() == key.lower():
                command(self.selected())
                return "break"
        return None
