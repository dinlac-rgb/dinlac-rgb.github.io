"""
Stock Summary (S, under Reports) — full-width table on the white canvas.

    +------------------------------------------------------------------------------+
    | Stock Summary - SRIJEE CREATIONS                                      Esc    |
    +------------------------------------------------------------------------------+
    |                                     |          Closing Balance              |
    | Particulars                         |  Quantity  |     Rate    |     Value    |
    | SKU-1001                            |        40  |     250.00  |   10,000.00  |
    | SKU-1002          below floor (10)  |         4  |     120.00  |      480.00  |
    | ...                                                                          |
    | Grand Total                         |        44  |             |   10,480.00  |
    +------------------------------------------------------------------------------+

Quantities: inventory_stock_registry. Rates: inventory_pricing_rules (services/stock.py says
how the rate column is chosen; the line under the title names the column used). Loaded in a
background thread. A SKU below its min_safety_floor is marked in red with the floor.

Keys: Up / Down / Page Up / Page Down move, Esc back (F5 refresh is on the action bar).
"""
from __future__ import annotations

import tkinter as tk
from pathlib import Path
from tkinter import ttk
from typing import Callable

from config import theme as T
from services.background import run_in_background
from services.reports import ReportError
from services.stock import StockSummary, load_stock_summary
from views.report_common import money, title_bar

# (column id, heading, width)
NUM_COLUMNS = (("qty", "Quantity", 120), ("rate", "Rate", 130), ("value", "Value", 160))
SCROLL_W = 16


class StockSummaryView(tk.Frame):
    def __init__(self, parent: tk.Widget, *, db_path: Path, company: str, on_close: Callable[[], None],
                 rate_column: str | None = None) -> None:
        super().__init__(parent, bg=T.WHITE)
        self._on_close = on_close
        title_bar(self, f"Stock Summary - {company.upper()}")
        self._subtitle = tk.Label(self, text="Loading…", bg=T.WHITE, fg=T.MUTED, font=T.F_LABEL, anchor="w")
        self._subtitle.pack(side="top", fill="x", padx=14, pady=(8, 4))

        grid = tk.Frame(self, bg=T.WHITE, highlightthickness=1, highlightbackground=T.BORDER)
        grid.pack(side="top", fill="both", expand=True, padx=14)
        grid.columnconfigure(0, weight=1)
        for i, (_c, _h, w) in enumerate(NUM_COLUMNS, start=1):
            grid.columnconfigure(i, minsize=w)
        grid.columnconfigure(len(NUM_COLUMNS) + 1, minsize=SCROLL_W)
        grid.rowconfigure(2, weight=1)

        # Two-tier header: "Closing Balance" spans Quantity, Rate and Value.
        head = dict(bg=T.NAVY, fg=T.WHITE, font=T.F_GRID_HEAD)
        tk.Label(grid, text="Particulars", anchor="w", padx=10, **head).grid(row=0, column=0, rowspan=2, sticky="nsew")
        tk.Label(grid, text="Closing Balance", anchor="center", pady=4, **head).grid(
            row=0, column=1, columnspan=len(NUM_COLUMNS), sticky="nsew")
        for i, (_c, heading, _w) in enumerate(NUM_COLUMNS, start=1):
            tk.Label(grid, text=heading, anchor="e", padx=5, pady=4, **head).grid(row=1, column=i, sticky="nsew")
        tk.Label(grid, text="", **head).grid(row=0, column=len(NUM_COLUMNS) + 1, rowspan=2, sticky="nsew")
        tk.Frame(grid, bg=T.BORDER, height=1).grid(row=1, column=1, columnspan=len(NUM_COLUMNS), sticky="new")

        self._tree = ttk.Treeview(grid, columns=[c for c, _h, _w in NUM_COLUMNS], show="tree",
                                  style="BizPulse.Treeview", selectmode="browse")
        self._tree.column("#0", width=300, minwidth=200, stretch=True)
        for col, _h, w in NUM_COLUMNS:
            self._tree.column(col, width=w, minwidth=w, anchor="e", stretch=False)
        self._tree.tag_configure("item", font=T.F_LABEL, foreground=T.TEXT)
        self._tree.tag_configure("low", font=T.F_LABEL, foreground=T.BAD_RED)
        self._tree.tag_configure("alt", background=T.ROW_ALT)
        sb = ttk.Scrollbar(grid, orient="vertical", command=self._tree.yview)
        self._tree.configure(yscrollcommand=sb.set)
        self._tree.grid(row=2, column=0, columnspan=len(NUM_COLUMNS) + 1, sticky="nsew")
        sb.grid(row=2, column=len(NUM_COLUMNS) + 1, sticky="ns")

        # Grand Total baseline row, outside the scrolling area so it always shows.
        tot = dict(bg=T.LIGHT_BLUE, fg=T.NAVY)
        tk.Frame(grid, bg=T.NAVY, height=1).grid(row=3, column=0, columnspan=len(NUM_COLUMNS) + 2, sticky="ew")
        tk.Label(grid, text="Grand Total", anchor="w", padx=10, pady=6, font=T.F_LABEL_BOLD, **tot).grid(
            row=4, column=0, sticky="nsew")
        self._totals = {}
        for i, (col, _h, _w) in enumerate(NUM_COLUMNS, start=1):
            lbl = tk.Label(grid, text="", anchor="e", padx=5, pady=6, font=T.F_TOTAL, **tot)
            lbl.grid(row=4, column=i, sticky="nsew")
            self._totals[col] = lbl
        tk.Label(grid, text="", **tot).grid(row=4, column=len(NUM_COLUMNS) + 1, sticky="nsew")

        self._notice = tk.Label(self, bg=T.WHITE, fg=T.MUTED, font=T.F_LABEL, anchor="w", justify="left",
                                wraplength=880)
        self._notice.pack(side="top", fill="x", padx=14, pady=(6, 10))

        run_in_background(self, lambda: load_stock_summary(db_path, rate_column), self._show, self._failed)

    def _show(self, s: StockSummary) -> None:
        low = sum(1 for ln in s.lines if ln.below_floor)
        self._subtitle.configure(text=f"{len(s.lines)} SKU(s) · quantities from inventory_stock_registry · "
                                      f"rates from {s.rate_source}" + (f" · {low} below safety floor" if low else ""))
        for i, ln in enumerate(s.lines):
            name = ln.sku + (f"      below floor ({ln.min_floor})" if ln.below_floor else "")
            tags = ("low" if ln.below_floor else "item",) + (("alt",) if i % 2 else ())
            self._tree.insert("", "end", text=name, tags=tags, values=(
                f"{ln.quantity:,}", money(ln.rate) if ln.rate is not None else "—",
                money(ln.value) if ln.value is not None else "—"))
        self._totals["qty"].configure(text=f"{s.total_quantity:,}")
        self._totals["value"].configure(text=money(s.total_value))
        notes = list(s.notes)
        if not s.lines:
            notes.append("inventory_stock_registry has no rows yet.")
        self._notice.configure(text="\n".join(notes), fg=T.BAD_RED if s.unpriced else T.MUTED)
        self.focus_first()

    def _failed(self, exc: Exception) -> None:
        msg = str(exc) if isinstance(exc, ReportError) else f"Could not build the Stock Summary: {exc}"
        self._subtitle.configure(text="")
        self._notice.configure(text=msg, fg=T.BAD_RED)

    def focus_first(self) -> None:
        self._tree.focus_set()
        kids = self._tree.get_children()
        if kids:
            self._tree.selection_set(kids[0])
            self._tree.focus(kids[0])

    def handle_key(self, event: tk.Event) -> str | None:
        if event.keysym == "Escape":
            self._on_close()
            return "break"
        return None
