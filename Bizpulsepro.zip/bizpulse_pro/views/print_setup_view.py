"""
Print › Configuration Setup — how printed invoices look (Print › Current Invoice).

    Paper            [A4] [80 mm]                   P switches
    HSN/SAC column   [Show] [Hide]                  H switches (never on 80 mm: too narrow)
    Footer           [This is a computer-generated invoice.      ]   F edits, Enter saves

Each change is saved at once to config/settings.py (PRINT_PAPER, PRINT_SHOW_HSN, PRINT_FOOTER;
services/preferences.py checks every value) and used from the next print, no restart needed.
Esc leaves (from the footer field it first leaves the field). Segoe UI 11 normal, bold letters.
"""
from __future__ import annotations

import tkinter as tk
from pathlib import Path
from typing import Callable

from config import settings as S
from config import theme as T
from services.background import run_in_background
from services.preferences import SETTINGS_FILE, PreferencesError, read_preferences, save_preferences
from views.masters_overlay import hotkey_labels
from views.report_common import title_bar

ROWS = [("PRINT_PAPER", "Paper", "P", [("A4", "A4"), ("80 mm", "80 mm thermal roll")]),
        ("PRINT_SHOW_HSN", "HSN/SAC column", "H", [(True, "Show"), (False, "Hide")])]


class PrintSetupView(tk.Frame):
    def __init__(self, parent: tk.Widget, *, on_close: Callable[[], None], on_note: Callable[[str], None] | None = None,
                 settings_path: Path = SETTINGS_FILE) -> None:
        super().__init__(parent, bg=T.WHITE, takefocus=1)
        self._on_close, self._path = on_close, Path(settings_path)
        self._on_note = on_note or (lambda _m: None)
        self.values = read_preferences(self._path)
        title_bar(self, "Print - Configuration Setup", "P Paper    H HSN column    F Footer    Esc Back")
        grid = tk.Frame(self, bg=T.WHITE)
        grid.pack(side="top", fill="x", padx=14, pady=(14, 4))
        self._chips: dict[str, list] = {}
        for r, (key, name, letter, options) in enumerate(ROWS):
            head = tk.Frame(grid, bg=T.WHITE, width=190, height=34)
            head.grid(row=r, column=0, sticky="w", pady=4)
            head.pack_propagate(False)
            hotkey_labels(head, name, letter, T.WHITE, T.TEXT)
            box = tk.Frame(grid, bg=T.WHITE)
            box.grid(row=r, column=1, sticky="w", pady=4)
            chips = []
            for value, text in options:
                chip = tk.Label(box, text=text, font=T.F_TEXT, padx=10, pady=3, cursor="hand2",
                                highlightthickness=1, highlightbackground=T.BORDER)
                chip.pack(side="left", padx=(0, 6))
                chip.bind("<Button-1>", lambda _e, k=key, v=value: self.choose(k, v))
                chips.append((value, chip))
            self._chips[key] = chips
        head = tk.Frame(grid, bg=T.WHITE, width=190, height=34)
        head.grid(row=len(ROWS), column=0, sticky="w", pady=4)
        head.pack_propagate(False)
        hotkey_labels(head, "Footer", "F", T.WHITE, T.TEXT)
        self.footer = tk.Entry(grid, width=60, font=T.F_TEXT, relief="flat", bd=0, highlightthickness=1,
                               highlightbackground=T.LINE, highlightcolor=T.ORANGE)
        self.footer.grid(row=len(ROWS), column=1, sticky="w", ipady=3)
        self.footer.insert(0, self.values["PRINT_FOOTER"])
        self.status = tk.Label(self, bg=T.WHITE, fg=T.MUTED, font=T.F_TEXT, anchor="w", justify="left", wraplength=860,
                               text="Changes are saved at once and used from the next print.")
        self.status.pack(side="top", fill="x", padx=14, pady=(12, 0))
        self._draw()

    def _draw(self) -> None:
        for key, chips in self._chips.items():
            for value, chip in chips:
                on = self.values[key] == value and type(self.values[key]) is type(value)
                chip.configure(bg=T.ORANGE if on else T.WHITE, fg=T.TEXT_DARK if on else T.TEXT)

    def choose(self, key: str, value) -> None:
        self.values = dict(self.values, **{key: value})
        self._draw()
        self._save()

    def _save(self) -> None:
        values, path = dict(self.values), self._path
        run_in_background(self, lambda: save_preferences(values, path), lambda _p: self._saved(values), self._failed)

    def _saved(self, values: dict) -> None:
        for key in ("PRINT_PAPER", "PRINT_SHOW_HSN", "PRINT_FOOTER"):
            setattr(S, key, values[key])                     # the next print uses them, no restart
        self.status.configure(text="Saved to config/settings.py; used from the next print.", fg=T.OK_GREEN)
        self._on_note(f"[Print] Paper {values['PRINT_PAPER']}, HSN column "
                      f"{'shown' if values['PRINT_SHOW_HSN'] else 'hidden'}, footer saved.")

    def _failed(self, exc: Exception) -> None:
        self.values = read_preferences(self._path)
        self._draw()
        self.status.configure(text=str(exc) if isinstance(exc, PreferencesError) else f"Not saved: {exc}", fg=T.BAD_RED)

    def focus_first(self) -> None:
        self.focus_set()

    def handle_key(self, event: tk.Event) -> str | None:
        typing = event.widget is self.footer
        if event.keysym == "Escape":
            if typing:
                self.focus_set()
            else:
                self._on_close()
            return "break"
        if event.state & (T.MOD_CTRL | T.MOD_ALT):
            return None
        if typing:
            if event.keysym in ("Return", "KP_Enter"):
                text = self.footer.get().strip()
                self.choose("PRINT_FOOTER", text)
                self.focus_set()
                return "break"
            return None
        key = event.keysym.lower()
        for row_key, _n, letter, options in ROWS:
            if key == letter.lower():
                values = [v for v, _t in options]
                cur = self.values[row_key]
                idx = next((i for i, v in enumerate(values) if v == cur and type(v) is type(cur)), 0)
                self.choose(row_key, values[(idx + 1) % len(values)])
                return "break"
        if key == "f":
            self.footer.focus_set()
            self.footer.icursor("end")
            return "break"
        return None
