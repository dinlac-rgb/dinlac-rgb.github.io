"""
The text of [T] Tutorial (views/tutorial_view.py), kept apart so it is easy to correct.

    modules() -> [(title, [(kind, text), ...]), ...]
        kind   "p"     a paragraph
               "step"  a numbered step (numbered per module)
               "item"  a bullet row
               "note"  a muted remark
    Inside the text, **...** is drawn bold: keys and shortcut letters (Ctrl+H, M, Esc).

Figures that live in the code are read from it (the state code, invoice prefix, the 28 groups,
the voucher-type keys), so the guide always describes this copy of BizPulse.
"""
from __future__ import annotations

from datetime import date

from config import settings as S
from config.ledger_groups import RESERVED_GROUPS
from services.gst import invoice_number

NATURE = {
    "Capital Account": "Liabilities", "Current Liabilities": "Liabilities", "Loans (Liability)": "Liabilities",
    "Branch / Divisions": "Liabilities", "Suspense A/c": "Liabilities", "Current Assets": "Assets",
    "Fixed Assets": "Assets", "Investments": "Assets", "Misc. Expenses (ASSET)": "Assets",
    "Sales Accounts": "Income", "Direct Incomes": "Income", "Indirect Incomes": "Income",
    "Purchase Accounts": "Expenses", "Direct Expenses": "Expenses", "Indirect Expenses": "Expenses",
}


def _groups() -> list[tuple[str, str]]:
    primary = [g for g, parent in RESERVED_GROUPS.items() if parent is None]
    subs = [(g, parent) for g, parent in RESERVED_GROUPS.items() if parent is not None]
    out = [("p", f"BizPulse keeps {len(RESERVED_GROUPS)} reserved groups: {len(primary)} primary groups and "
                 f"{len(subs)} sub-groups, the same chart Tally uses. They are written into the "
                 "account_groups table every time BizPulse opens the database (only missing ones are added; "
                 "nothing already there is changed), so you never type them in.")]
    out.append(("p", f"The {len(primary)} primary groups and the side of the books they belong to:"))
    for nature in ("Liabilities", "Assets", "Income", "Expenses"):
        names = [g for g in primary if NATURE.get(g) == nature]
        out.append(("item", f"**{nature}**: " + ", ".join(names)))
    out.append(("p", f"The {len(subs)} sub-groups, each under its primary group:"))
    by_parent: dict[str, list[str]] = {}
    for g, parent in subs:
        by_parent.setdefault(parent, []).append(g)
    for parent, names in by_parent.items():
        out.append(("item", f"**{parent}** › " + ", ".join(names)))
    out += [
        ("step", "Press **C** Create on the Corridor, then **L** Ledger. Type the Ledger Name and pick its group "
                 "in Under (the list on the right shows every group). Opening Balance and Dr / Cr are optional."),
        ("step", "Customers go under Sundry Debtors, suppliers under Sundry Creditors, your banks under Bank "
                 "Accounts, cash under Cash-in-Hand, Output CGST / SGST / IGST under Duties & Taxes, and the "
                 "proprietor's capital under Capital Account."),
        ("step", "Need your own heading, such as Office Expenses? Create a Group (**C**, then **G**) under one of the reserved "
                 "groups (Indirect Expenses here). Reports roll it up into that reserved group."),
        ("note", "The Balance Sheet shows Capital Account, Loans and Current Liabilities on the Liabilities side "
                 "and Fixed Assets, Investments and Current Assets on the Assets side; Sales, Purchase, Direct and "
                 "Indirect groups go to the Profit & Loss A/c. Opening balances that do not agree show in red as "
                 "Difference in Opening Balances."),
    ]
    return out


def modules(today: date | None = None) -> list[tuple[str, list[tuple[str, str]]]]:
    today = today or date.today()
    first_invoice = invoice_number(S.INVOICE_PREFIX, today, 1)
    tally = "  ".join(f"**{k}** {n}" for k, n in S.VOUCHER_TYPES)
    return [
        ("Module 1: Foundational Company Accounting Setup", [
            ("p", "BizPulse keeps one company in one database file, bizpulse_local.db, in the BizPulse folder "
                  "(the folder that holds main.py). Set it up once, in this order."),
            ("step", "Create the company file: press **Alt+K** (or click K: Company) and choose **C** Create "
                     "Company. This runs your database_config.py from the BizPulse folder in the background; it "
                     "writes to the database, so BizPulse asks before it starts, and its messages appear in the "
                     "status line (all of them under **F1** › **M** Session Messages). If the script is not in the folder, "
                     "the status line says so."),
            ("step", "Start BizPulse. On every start it brings older tables up to date (gst_sales_ledger gets "
                     "igst_rate and place_of_supply) and adds the reserved account groups (Module 2)."),
            ("step", f"Set your state in config/settings.py: COMPANY_STATE_CODE = \"{S.COMPANY_STATE_CODE}\" "
                     f"({S.COMPANY_STATE_NAME}). A Sales place of supply equal to it gives CGST + SGST; any other "
                     "state gives IGST. Unregistered customers start with this state."),
            ("step", "Enter your GSTIN in COMPANY_GSTIN (same file). Sales still work without it, but the GSTR-1 "
                     "export refuses to run until it is filled in and matches the state code."),
            ("step", f"Choose the invoice series in INVOICE_PREFIX (now \"{S.INVOICE_PREFIX}\"). Sales invoices are "
                     f"numbered {first_invoice}, then 0002 and so on: the middle part is the financial year of the "
                     "voucher date (April to March), and the count starts again at 0001 each year. The next free "
                     "number shows on the Sales GST panel; a cancelled invoice keeps its number. 16 characters at most."),
            ("note", "Keep a copy of bizpulse_local.db before running any script that writes to it. Company › Shut "
                     "Company tells you when nothing is using the file, so it is safe to copy."),
        ]),
        ("Module 2: The 28 Pre-Defined Primary Account Groups", _groups()),
        ("Module 3: Single Entry vs. Double Entry Voucher Management", [
            ("p", "Open vouchers with **V** on the Corridor (the Vouchers list opens; its bold letters pick the "
                  f"type) or, on the voucher screen, the action-bar keys: {tally}, **Ctrl+F8** Credit Note, "
                  "**Ctrl+F9** Debit Note. (Settings › **K** switches to the BizPulse Express key order.)"),
            ("step", "Press **Ctrl+H** for the Change Voucher Mode box. **Up** / **Down** and **Enter**, or the bold "
                     "letter: **S** Single Entry, **D** Double Entry. **Esc** closes the box. If lines are already "
                     "typed, BizPulse asks before switching, because the lines are cleared."),
            ("step", "Single Entry (Payment, Receipt, Contra): the Account field takes the cash or bank ledger. "
                     "While you type in it, the List of Ledger Accounts on the right shows only Cash-in-Hand and "
                     "Bank ledgers (Bank Accounts, Bank OD A/c). Payment and Contra credit the Account, Receipt debits it."),
            ("step", "Then type Particulars and Amount lines; the Account takes their total on the other side. "
                     "An empty Particulars line ends the lines and moves to Narration."),
            ("step", "Double Entry (every type; Journal, Sales, Purchase and the notes always use it): on the "
                     "Dr/Cr cell press **B** (By) or **D** for Dr, **T** (To) or **C** for Cr, **Space** to flip. "
                     "On a Journal the cell reads By / To; it is saved as Dr / Cr."),
            ("step", "Entering the amount of a new line offers the amount that balances the voucher. Once the "
                     "debits equal the credits, Enter moves on to Narration (Sales: to the GST panel first)."),
            ("step", "**Ctrl+A** accepts (or Enter on Narration and Yes). **Esc** goes back exactly one field, so "
                     "a correction never loses the screen; only on the date does Esc leave, asking first if "
                     "anything is typed. **Tab** = Enter, **Shift+Tab** = Esc."),
            ("step", "Foreign currency: the Currency field follows the date. INR moves straight on; USD, EUR and "
                     "so on (or an amount typed as USD 1,200) open the Exchange Rate box. Lines are typed in "
                     "that currency and saved in rupees."),
            ("note", "**F12** hands the keyboard to the action bar on the right: **Up** / **Down** move through "
                     "Contra … Purchase, Credit / Debit Note, Change Mode, More Details and Accept, **Enter** runs the "
                     "highlighted one, **Esc** (or **F12**) puts the cursor back in your field."),
            ("note", "Cost centres: Enter on the amount of an expense or purchase debit line opens the Cost Centre "
                     "Allocation box. Type a department, project or branch and a % (or an amount); an empty name "
                     "finishes, **Esc** closes it and leaves the line as it was. Display More Reports › **C** Cost "
                     "Centre Summary shows the totals."),
            ("note", "Every save, alteration and cancellation is also written to the audit trail: **F1** then "
                     "**G** (Help › Activity Log) or **L** on the Corridor shows it, with a date and voucher-number "
                     "filter and **V** to check that no entry was changed."),
            ("note", "Saved vouchers: Enter on a Day Book row opens it for alteration, **Alt+2** duplicates it as "
                     "a new voucher with the next number, **Alt+X** cancels it (asks first; the number stays in "
                     "the series and its amounts leave the books)."),
        ]),
        ("Module 4: The Voucher Utilities Slide-Out Drawer", [
            ("p", "On the voucher screen press **Ctrl+I** (or click Ctrl+I: More Details). The Voucher Entry "
                  "Utilities drawer slides out over the left edge of the screen. Each block has a bold letter."),
            ("step", "Status, one key each: **R** Regular (the normal voucher), **O** Optional (saved and listed in "
                     "the Day Book, but left out of every report: no invoice number, no balance or stock "
                     "change), **P** Post-Dated (Payment, Receipt, Contra or Journal dated after today)."),
            ("step", "A Post-Dated voucher is saved now; its balance change waits until its date, when BizPulse "
                     "(on start) makes it Regular. The orange badge beside the voucher number shows any status "
                     "other than Regular."),
            ("step", "Details: **D** Dispatch Details, **E** Order Details, **C** Consignee Details, **G** GST "
                     "Details (your state and GSTIN, read only). Enter moves through a card; Esc closes it and "
                     "keeps what was typed."),
            ("step", "Assistants: **A** Autofill copies the lines of the last voucher of this type for the party; "
                     "**U** Unused Vch No. lists numbers no saved voucher uses."),
            ("note", "**Esc** slides the drawer away and puts the cursor back where it was."),
        ]),
        ("Module 5: Automated Banking Reconciliation & GSTR-1 Exports", [
            ("p", "Bank reconciliation: press **N** Banking on the Corridor and choose **I** Imported Bank Data."),
            ("step", "Type the bank ledger (the list on the right shows your Bank Accounts ledgers) and press "
                     "Enter. Your bank book loads on the left: every voucher on that ledger, money in and out."),
            ("step", "Press **O** and open the bank's statement file (CSV or TXT, comma, semicolon or tab "
                     "separated, with a Date column, a Description and either Withdrawal / Deposit columns or "
                     "one Amount column). It loads on the right."),
            ("step", "Press **M** Match Entries. Each book entry is paired with a statement line of the same date, "
                     "amount and direction, one to one, earliest first. Matched rows turn green on both sides and "
                     "every pair is recorded in the reconciliation trail (and the Session Messages)."),
            ("step", "Whatever stays white needs a look: a cheque that has not cleared, bank charges not yet "
                     "entered, or a date that differs. The line under the grids gives the count and net amount "
                     "left on each side."),
            ("p", "GSTR-1 JSON: press **Alt+E** (Export) and choose **G** GST Returns JSON."),
            ("step", "Type the return month as MM-YYYY and press **Enter**. BizPulse reads that month's Sales "
                     "invoices and shows the sections: B2B (buyers with a GSTIN), B2CL (other-state, unregistered, "
                     "above the B2CL limit), B2CS (the rest), the HSN/SAC summary and Documents issued (the "
                     "invoice series used, with cancelled numbers counted)."),
            ("step", "Press **E** Export JSON. The file is written to the exports folder as "
                     "GSTR1_<GSTIN>_<MMYYYY>.json and the status line shows where."),
            ("p", "Marketplace orders: **Alt+O** (Import) › **E** E-commerce Orders, then **O** to open the order "
                  "CSV. Each order is matched to your SKUs in inventory_stock_registry and its GST worked out from "
                  "the ship-to state (19 = CGST + SGST, other states IGST). Problems are listed and nothing is "
                  "written until **P** Post orders and Yes; an order already imported is never posted twice."),
            ("note", "Before uploading, import the file into the GST offline tool and let it validate: the "
                     "portal's JSON format changes from time to time. Check B2CL_LIMIT in config/settings.py "
                     "against the current rules."),
        ]),
    ]
