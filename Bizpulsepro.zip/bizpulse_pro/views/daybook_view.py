"""
Day Book — full-width transaction table drawn over the workspace.

    +--------------------------------------------------------------------------+
    | Day Book                                       Enter details    Esc Back |
    +--------------------------------------------------------------------------+
    | 3 vouchers · 09-10-2026 to 09-10-2026                                    |
    | Date       | Particulars        | Vch Type | Vch No. | Debit   | Credit  |
    | 09-10-2026 | Office Rent        | Payment  | 1       |25,000.00|         |
    | ...  (scrolls both ways)                                                 |
    |                                   Total    |         |25,000.00| 8,500.00|
    | Voucher details: lines and narration of the highlighted voucher          |
    +--------------------------------------------------------------------------+

Shows the vouchers it is given (the window passes the vouchers saved in bizpulse_local.db,
newest 5,000). Sales show their GST invoice number. Each row's amount sits in the Debit or Credit column according
to the side of the voucher's first line, as in Tally.

Keys: Up / Down / Page Up / Page Down / Home / End move through the table (the voucher's lines
show underneath); Enter or a double-click opens the voucher for alteration; Esc goes back.
    Alt+2   duplicate the highlighted voucher: a new voucher, same ledgers / amounts / GST, next number
    Alt+X   cancel the highlighted voucher (asks first). It stays in the list, greyed, marked
            Cancelled, with its number; its amounts leave the totals, the books and the GST registers.
Foreign-currency vouchers show their currency amounts under the lines (the table is in rupees).
"""
from __future__ import annotations

import tkinter as tk
from decimal import Decimal
from tkinter import ttk
from typing import Callable, Sequence

from components.macro_bar import Macro
from config import theme as T
from services.forex import rate_text
from views.vouchers_view import DATE_FMT, fmt_inr

CANCELLED = "Cancelled"

COLUMNS = (
    ("date", "Date", 100, "w", False),
    ("particulars", "Particulars", 280, "w", True),
    ("type", "Vch Type", 120, "w", False),
    ("number", "Vch No.", 130, "e", False),
    ("debit", "Debit Amount", 140, "e", False),
    ("credit", "Credit Amount", 140, "e", False),
    ("narration", "Narration", 260, "w", True),
)


class DaybookView(tk.Frame):
    def __init__(self, parent: tk.Widget, vouchers: Sequence[dict], on_close: Callable[[], None],
                 on_open: Callable[[int], None] | None = None,
                 on_duplicate: Callable[[int], None] | None = None,
                 on_cancel: Callable[[int], None] | None = None) -> None:
        super().__init__(parent, bg=T.WHITE)
        self._on_open = on_open          # drill-down: open the voucher for alteration
        self._on_duplicate = on_duplicate    # Alt+2 (voucher id)
        self._on_cancel = on_cancel          # Alt+X (voucher id)
        self._vouchers = sorted(vouchers, key=lambda v: (v["date"], v["entered_at"]))
        self._on_close = on_close

        self._build_title_bar()
        self._build_summary()
        self._build_table()
        self._build_footer()
        self._build_details()
        self._fill()

    # ---- layout ------------------------------------------------------------------------
    def _build_title_bar(self) -> None:
        bar = tk.Frame(self, bg=T.NAVY, height=34)
        bar.pack(side="top", fill="x")
        bar.pack_propagate(False)
        tk.Label(bar, text="Day Book", bg=T.NAVY, fg=T.WHITE, font=T.F_VIEW_TITLE).pack(side="left", padx=12)
        tk.Label(bar, text="Enter open    Alt+2 Duplicate    Alt+X Cancel    Esc Back", bg=T.NAVY, fg=T.HOVER_TEXT,
                 font=T.F_HEADER).pack(side="right", padx=12)

    def _build_summary(self) -> None:
        self._summary = tk.Label(self, bg=T.WHITE, fg=T.MUTED, font=T.F_LABEL, anchor="w")
        self._summary.pack(side="top", fill="x", padx=14, pady=(8, 4))

    def _build_table(self) -> None:
        box = tk.Frame(self, bg=T.WHITE, highlightthickness=1, highlightbackground=T.BORDER)
        box.pack(side="top", fill="both", expand=True, padx=14)
        self._tree = ttk.Treeview(box, columns=[c[0] for c in COLUMNS], show="headings",
                                  style="BizPulse.Treeview", selectmode="browse")
        for key, title, width, anchor, stretch in COLUMNS:
            self._tree.heading(key, text=title, anchor=anchor)
            self._tree.column(key, width=width, minwidth=60, anchor=anchor, stretch=stretch)
        vbar = ttk.Scrollbar(box, orient="vertical", command=self._tree.yview)
        hbar = ttk.Scrollbar(box, orient="horizontal", command=self._tree.xview)
        self._tree.configure(yscrollcommand=vbar.set, xscrollcommand=hbar.set)
        self._tree.grid(row=0, column=0, sticky="nsew")
        vbar.grid(row=0, column=1, sticky="ns")
        hbar.grid(row=1, column=0, sticky="ew")
        box.rowconfigure(0, weight=1)
        box.columnconfigure(0, weight=1)
        self._tree.tag_configure("odd", background=T.ROW_ALT if T.GRID_LINES else T.WHITE)   # banded rows
        self._tree.tag_configure("even", background=T.WHITE)
        self._tree.tag_configure("cancelled", foreground=T.MUTED)
        self._tree.bind("<<TreeviewSelect>>", lambda _e: self._show_details())
        self._tree.bind("<Double-Button-1>", lambda e: self.open_voucher(self._tree.identify_row(e.y)))

    def _build_footer(self) -> None:
        foot = tk.Frame(self, bg=T.WHITE)
        foot.pack(side="top", fill="x", padx=14, pady=(4, 0))
        self._credit_total = tk.Label(foot, bg=T.LIGHT_BLUE, fg=T.NAVY, font=T.F_TOTAL, width=16, anchor="e", padx=6, pady=3)
        self._credit_total.pack(side="right", padx=(2, 0))
        self._debit_total = tk.Label(foot, bg=T.LIGHT_BLUE, fg=T.NAVY, font=T.F_TOTAL, width=16, anchor="e", padx=6, pady=3)
        self._debit_total.pack(side="right", padx=2)
        tk.Label(foot, text="Total", bg=T.WHITE, fg=T.NAVY, font=T.F_LABEL_BOLD, padx=8).pack(side="right")

    def _build_details(self) -> None:
        box = tk.Frame(self, bg=T.LIGHT_BLUE, highlightthickness=1, highlightbackground=T.BORDER)
        box.pack(side="top", fill="x", padx=14, pady=(8, 12))
        self._detail_title = tk.Label(box, bg=T.LIGHT_BLUE, fg=T.NAVY, font=T.F_LABEL_BOLD, anchor="w")
        self._detail_title.pack(side="top", fill="x", padx=10, pady=(6, 2))
        self._detail_text = tk.Label(box, bg=T.LIGHT_BLUE, fg=T.TEXT, font=T.F_AMOUNT, anchor="w",
                                     justify="left")
        self._detail_text.pack(side="top", fill="x", padx=10, pady=(0, 8))

    # ---- data --------------------------------------------------------------------------
    def _fill(self) -> None:
        debit_total = credit_total = Decimal("0")
        for i, v in enumerate(self._vouchers):
            first = v["lines"][0]
            amount = v["total"]
            debit, credit = (amount, None) if first["side"] == "Dr" else (None, amount)
            tags = ("odd" if i % 2 else "even",)
            if v.get("status") == CANCELLED:          # number kept, amounts out of the totals
                debit = credit = None
                tags += ("cancelled",)
            debit_total += debit or 0
            credit_total += credit or 0
            self._tree.insert(
                "", "end", iid=str(i), tags=tags,
                values=(
                    v["date"].strftime(DATE_FMT), first["ledger"],
                    v["type"] + ("" if v.get("status", "Regular") == "Regular" else f" ({v['status']})"),
                    v.get("invoice_no") or v["number"],
                    fmt_inr(debit) if debit is not None else "",
                    fmt_inr(credit) if credit is not None else "",
                    v["narration"],
                ),
            )
        self._debit_total.configure(text=fmt_inr(debit_total))
        self._credit_total.configure(text=fmt_inr(credit_total))

        if self._vouchers:
            first_d = self._vouchers[0]["date"].strftime(DATE_FMT)
            last_d = self._vouchers[-1]["date"].strftime(DATE_FMT)
            n = len(self._vouchers)
            self._summary.configure(text=f"{n} voucher{'s' if n != 1 else ''} · {first_d} to {last_d} · saved in the database")
        else:
            self._summary.configure(text="No vouchers yet. Press Esc, then V to enter one.")
        self._show_details()

    def _show_details(self) -> None:
        sel = self._tree.selection()
        if not sel:
            self._detail_title.configure(text="Voucher details")
            self._detail_text.configure(text="Highlight a voucher to see its lines.")
            return
        v = self._vouchers[int(sel[0])]
        invoice = f" · Invoice {v['invoice_no']}" if v.get("invoice_no") else ""
        self._detail_title.configure(text=f"{v['type']} No. {v['number']}{invoice} · {v['date'].strftime(DATE_FMT)}")
        fx = v.get("forex")
        lines = []
        for i, ln in enumerate(v["lines"]):
            row = f"{ln['side']}  {ln['ledger'][:40]:<40} {fmt_inr(ln['amount']):>16}"
            if fx and i < len(fx["amounts"]):
                row += f"   {fx['currency']} {fmt_inr(fx['amounts'][i])}"
            lines.append(row)
            for a in ln.get("allocations") or []:          # cost centre split of this line
                pct = f" ({a['percent']}%)" if a.get("percent") else ""
                lines.append(f"      ↳ {a['cost_centre'][:34]:<34}{pct:<8} {fmt_inr(a['amount']):>16}")
        if fx:
            lines.append(f"In {fx['currency']} at ₹{rate_text(fx['rate'])} per {fx['currency']}; amounts above in rupees.")
        for it in v.get("items") or []:
            lines.append(f"    {it['item'][:30]:<30} {it['quantity']:>6} {it.get('per', 'Nos'):<4} @ "
                         f"{fmt_inr(it['rate'])} = {fmt_inr(it['amount'])}")
        if v.get("status", "Regular") != "Regular":
            why = {"Optional": " (left out of the reports)",
                   CANCELLED: " (number kept in the series; left out of the books, reports and GST registers)"}
            lines.append(f"Status: {v['status']}{why.get(v['status'], '')}")
        if v.get("details"):
            lines.append("    ".join(f"{k}: {val}" for k, val in v["details"].items()))
        if v["narration"]:
            lines.append(f"Narration: {v['narration']}")
        self._detail_text.configure(text="\n".join(lines))

    def open_voucher(self, iid: str) -> None:
        """Enter or double-click: the voucher opens in Accounting Voucher Alteration; Esc there
        comes back here."""
        if not iid or self._on_open is None:
            return
        vid = self._vouchers[int(iid)].get("id")
        if vid is not None:
            self._on_open(vid)

    def _selected(self) -> dict | None:
        sel = self._tree.selection()
        return self._vouchers[int(sel[0])] if sel else None

    def duplicate(self) -> None:
        """Alt+2 on the highlighted row."""
        v = self._selected()
        if v is not None and v.get("id") is not None and self._on_duplicate is not None:
            self._on_duplicate(v["id"])

    def cancel(self) -> None:
        """Alt+X on the highlighted row (the window asks before anything changes)."""
        v = self._selected()
        if v is not None and v.get("id") is not None and self._on_cancel is not None:
            self._on_cancel(v["id"])

    def select_voucher(self, voucher_id: int) -> None:
        """Highlight a voucher by id (after a refresh, the row that was being worked on)."""
        for i, v in enumerate(self._vouchers):
            if v.get("id") == voucher_id:
                self._tree.selection_set(str(i))
                self._tree.focus(str(i))
                self._tree.see(str(i))
                return

    def macros(self) -> list[Macro]:
        out = []
        if self._on_duplicate is not None:
            out.append(Macro("Alt+2", "Duplicate", self.duplicate))
        if self._on_cancel is not None:
            out.append(Macro("Alt+X", "Cancel Vch", self.cancel))
        return out

    # ---- public ------------------------------------------------------------------------
    def focus_first(self) -> None:
        self._tree.focus_set()
        children = self._tree.get_children()
        if children:
            last = children[-1]          # newest voucher, like Tally opening at the latest entry
            self._tree.selection_set(last)
            self._tree.focus(last)
            self._tree.see(last)

    def handle_key(self, event: tk.Event) -> str | None:
        """Called by the window's key dispatcher while this screen is open."""
        if event.keysym == "Escape":
            self._on_close()
            return "break"
        if event.state & T.MOD_ALT and not event.state & T.MOD_CTRL:
            if event.keysym == "2":
                self.duplicate()
                return "break"
            if event.keysym.lower() == "x":
                self.cancel()
                return "break"
            return None
        if event.keysym in ("Return", "KP_Enter"):
            sel = self._tree.selection()
            if sel:
                self.open_voucher(sel[0])
            return "break"
        return None   # arrows, Page Up/Down, Home/End: the table handles them itself
