"""
The list screens behind the Data, Import, Banking, Display More Reports and Masters menus. Each
is a views/list_screen.ListScreen (title bar, table, detail line, bold-letter actions, Esc back,
data read in a background thread), built by one function here:

    restore_screen          Data › Restore                R restores the highlighted copy
    ledger_import_screen    Import › Masters               O open CSV, P post
    voucher_import_screen   Import › Vouchers CSV          O open CSV, P post
    bank_activities_screen  Banking › Banking Activities
    bank_payments_screen    Banking › Cheque Printing / Payment Advice   P prints the highlighted payment
    cheque_register_screen  Banking › Cheque Register
    deposit_slip_screen     Banking › Deposit Slip         P prints the highlighted day's slip
    post_dated_screen       Banking › Post-dated Summary
    hsn_screen              Display More Reports › HSN/SAC Summary
    movement_screen         Display More Reports › Movement Analysis
    gstr3b_screen           Display More Reports › GSTR-3B Return  V / X month back / forward
    goto_screen             F4 Go To: every screen by name, Enter opens it
    voucher_types_screen    Masters › Voucher Type (the fixed types and their keys)
"""
from __future__ import annotations

from datetime import date
from decimal import Decimal
from pathlib import Path
from tkinter import filedialog, messagebox
from typing import Callable

from services import banking_docs as BD
from services import csv_import as CI
from services import extra_reports as XR
from services.reports import financial_year_start
from views.list_screen import ListScreen
from views.vouchers_view import DATE_FMT, fmt_inr

STATUS_TAG = {"Ready": "", "Created": "good", "Posted": "good", "Exists": "muted", "Already imported": "muted",
              "Error": "bad", "Failed": "bad"}


def _fy(today: date | None = None) -> tuple[date, date]:
    end = today or date.today()
    return financial_year_start(end), end


# ---- Data › Restore ----------------------------------------------------------------------------
def restore_screen(parent, *, db_path: Path, backup_dir: Path, on_close, on_restore: Callable[[dict], None]):
    from services.data_tools import list_backups

    def detail(r: dict) -> str:
        return (f"{r['path']}\nCompany: {r['company'] or '—'} · vouchers: {r['vouchers'] or '—'}. R puts this copy in "
                "place of the open company file; today's file is first saved as a safety copy.")

    return ListScreen(parent, title="Restore - Backups and Safety Copies",
                      columns=(("saved", "Saved", 140, "w"), ("file", "File", 380, "w"), ("kind", "Kind", 110, "w"),
                               ("company", "Company", 200, "w"), ("vouchers", "Vouchers", 90, "e"),
                               ("size", "Size", 80, "e")),
                      load=lambda: list_backups(backup_dir, db_path), on_close=on_close,
                      actions=[("R", "Restore", lambda row: row and on_restore(row))], detail=detail, stretch="file",
                      subtitle=f"Newest first. Backups are in {Path(backup_dir).name}/; safety copies made before "
                               "upgrades sit beside the company file.",
                      empty="No backups yet: Data › Backup makes one.")


# ---- Import › Masters / Vouchers CSV -------------------------------------------------------------------
def _import_screen(parent, *, title: str, columns, plan: Callable[[Path], list[dict]],
                   post: Callable[[list[dict]], tuple[list, list]], describe: Callable[[dict], str], on_close,
                   on_note: Callable[[str], None], what: str):
    from services.background import run_in_background
    state: dict = {"rows": [], "file": None, "busy": False}

    def load() -> list[dict]:
        return [dict(r, _tag=STATUS_TAG.get(r["status"], ""), state=r["status"] + (f": {r['note']}" if r["note"] else ""))
                for r in state["rows"]]

    def open_file(_row) -> None:
        if state["busy"]:
            return
        path = filedialog.askopenfilename(parent=screen, title=f"{what} (CSV)",
                                          filetypes=[("CSV files", "*.csv *.txt"), ("All files", "*.*")])
        if path:
            read(Path(path))

    def read(path: Path) -> None:
        state["busy"] = True
        screen.say(f"Reading {path.name}…")

        def done(rows):
            state.update(rows=rows, file=path, busy=False)
            screen.reload()
            ready = sum(1 for r in rows if r["status"] == "Ready")
            screen.subtitle.configure(text=f"{path.name}: {len(rows)} {what.lower()}, {ready} ready. "
                                           "P posts the ready ones; errors are listed with the reason.")

        def failed(exc):
            state["busy"] = False
            screen.say(f"Could not read {path.name}: {exc}", error=True)

        run_in_background(screen, lambda: plan(path), done, failed)

    def post_rows(_row) -> None:
        ready = [r for r in state["rows"] if r["status"] == "Ready"]
        if state["busy"] or not ready:
            screen.say("Nothing is Ready to post. O opens a file." if not state["busy"] else "Still working…",
                       error=not state["busy"])
            return
        if not messagebox.askyesno(f"Post {what.lower()}?", f"Post {len(ready)} {what.lower()} from "
                                   f"{state['file'].name}?", parent=screen):
            return
        state["busy"] = True
        screen.say(f"Posting {len(ready)}…")

        def done(result):
            ok, bad = result
            state["busy"] = False
            for r in ok:
                on_note(f"[Import] {describe(r)}")
            screen.reload()
            screen.say(f"Posted {len(ok)}" + (f"; {len(bad)} failed (see the list)." if bad else "."),
                       error=bool(bad), good=not bad)

        run_in_background(screen, lambda: post(state["rows"]), done,
                          lambda exc: (state.update(busy=False), screen.say(f"Posting stopped: {exc}", error=True)))

    screen = ListScreen(parent, title=title, columns=columns, load=load, on_close=on_close,
                        actions=[("O", "Open file", open_file), ("P", "Post", post_rows)],
                        subtitle="O opens a CSV file. Nothing is written until P and Yes.",
                        empty="No file opened yet.", stretch="state")
    screen.read_file = read                         # for tests and for a path given on opening
    screen.import_state = state
    return screen


def ledger_import_screen(parent, *, store, on_close, on_note):
    return _import_screen(
        parent, title="Import - Masters (Ledgers)", what="Ledgers",
        columns=(("line", "Line", 50, "e"), ("name", "Ledger", 220, "w"), ("under", "Under", 170, "w"),
                 ("opening", "Opening", 110, "e"), ("drcr", "Dr/Cr", 50, "center"), ("state", "Status", 300, "w")),
        plan=lambda p: CI.plan_ledgers(p, store), post=lambda rows: CI.post_ledgers(rows, store),
        describe=lambda r: f"Ledger '{r['name']}' created under {r['under']}.", on_close=on_close, on_note=on_note)


def voucher_import_screen(parent, *, db_path: Path, store, on_close, on_note):
    def row_view(p):
        rows = CI.plan_vouchers(p, db_path)
        for r in rows:
            r["when"] = r["date"].strftime(DATE_FMT) if r["date"] else ""
            r["amount"] = fmt_inr(r["total"]) if r["total"] else ""
            r["count"] = len(r["lines"])
        return rows
    return _import_screen(
        parent, title="Import - Vouchers CSV", what="Vouchers",
        columns=(("ref", "Ref", 90, "w"), ("when", "Date", 96, "w"), ("type", "Type", 90, "w"),
                 ("count", "Lines", 60, "e"), ("amount", "Amount", 120, "e"), ("state", "Status", 360, "w")),
        plan=row_view, post=lambda rows: CI.post_vouchers(rows, store),
        describe=lambda r: f"{r['note']} posted from {r['key']} (₹{r['amount']}).", on_close=on_close, on_note=on_note)


# ---- Banking ----------------------------------------------------------------------------------------
def bank_activities_screen(parent, *, db_path: Path, on_close, on_open_ledger: Callable[[str], None]):
    def load():
        rows = [{"ledger": a.ledger, "entries": a.entries, "in": fmt_inr(a.money_in), "out": fmt_inr(a.money_out),
                 "balance": f"{fmt_inr(abs(a.balance))} {'Dr' if a.balance >= 0 else 'Cr'}",
                 "matched": f"{a.matched} of {a.entries}"} for a in BD.activities(db_path)]
        return rows
    return ListScreen(parent, title="Banking Activities",
                      columns=(("ledger", "Bank ledger", 240, "w"), ("entries", "Entries", 80, "e"),
                               ("in", "Money in", 130, "e"), ("out", "Money out", 130, "e"),
                               ("balance", "Balance", 150, "e"), ("matched", "Matched to statement", 170, "e")),
                      load=load, on_close=on_close, on_enter=lambda r: on_open_ledger(r["ledger"]),
                      subtitle="Every bank ledger, all dates. Enter opens its Ledger Statement; Banking › Imported "
                               "Bank Data matches it to the bank's statement.",
                      empty="No bank ledgers yet (ledgers under Bank Accounts or Bank OD A/c).")


def bank_payments_screen(parent, *, db_path: Path, title: str, action: str, on_close,
                         on_print: Callable[[dict], None]):
    def load():
        return [{"when": p["date"].strftime(DATE_FMT), "number": p["number"], "bank": p["bank"], "payee": p["payee"],
                 "cheque": p["cheque"]["no"], "amount": fmt_inr(p["amount"]), "_p": p}
                for p in sorted(BD.bank_payments(db_path), key=lambda p: (p["date"], p["number"]), reverse=True)]
    return ListScreen(parent, title=title,
                      columns=(("when", "Date", 96, "w"), ("number", "Payment No.", 100, "e"), ("bank", "From bank", 180, "w"),
                               ("payee", "Payee", 240, "w"), ("cheque", "Cheque No.", 110, "w"), ("amount", "Amount", 130, "e")),
                      load=load, on_close=on_close, actions=[("P", action, lambda r: r and on_print(r["_p"]))],
                      detail=lambda r: r["_p"]["voucher"].get("narration") or "",
                      subtitle="Payments out of a bank ledger, newest first. Cheque details come from the voucher's "
                               "Cheque Details card (Ctrl+I › Q).", empty="No payments from a bank ledger yet.")


def cheque_register_screen(parent, *, db_path: Path, on_close):
    def load():
        return [{"when": r["date"].strftime(DATE_FMT), "type": r["type"], "number": r["number"], "cheque": r["cheque_no"],
                 "cdate": r["cheque_date"], "bank": r["bank"], "party": r["party"], "amount": fmt_inr(r["amount"])}
                for r in sorted(BD.cheque_register(db_path), key=lambda r: (r["date"], r["number"]), reverse=True)]
    return ListScreen(parent, title="Cheque Register",
                      columns=(("when", "Voucher date", 104, "w"), ("type", "Type", 80, "w"), ("number", "No.", 60, "e"),
                               ("cheque", "Cheque No.", 110, "w"), ("cdate", "Cheque date", 104, "w"),
                               ("bank", "Bank", 160, "w"), ("party", "Party", 200, "w"), ("amount", "Amount", 120, "e")),
                      load=load, on_close=on_close,
                      subtitle="Cheques issued (Payment) and received (Receipt), from each voucher's Cheque Details.",
                      empty="No vouchers with Cheque Details yet (Ctrl+I › Q on a Payment or Receipt).")


def deposit_slip_screen(parent, *, db_path: Path, on_close, on_print: Callable[[dict], None]):
    def load():
        return [{"when": b["date"].strftime(DATE_FMT), "bank": b["bank"], "count": len(b["rows"]),
                 "amount": fmt_inr(sum((x["amount"] for x in b["rows"]), Decimal("0"))), "_b": b}
                for b in BD.deposit_batches(db_path)]
    return ListScreen(parent, title="Deposit Slip",
                      columns=(("when", "Date", 100, "w"), ("bank", "Bank", 260, "w"), ("count", "Cheques", 80, "e"),
                               ("amount", "Amount", 140, "e")),
                      load=load, on_close=on_close, actions=[("P", "Print slip", lambda r: r and on_print(r["_b"]))],
                      detail=lambda r: "  ".join(f"{x['cheque_no']} {x['from']} {fmt_inr(x['amount'])}" for x in r["_b"]["rows"]),
                      subtitle="Cheques received into each bank, one slip per bank and day.",
                      empty="No Receipts by cheque into a bank yet (Cheque Details on the Receipt: Ctrl+I › Q).")


def post_dated_screen(parent, *, db_path: Path, on_close, on_open: Callable[[int], None]):
    def load():
        return [{"when": r["date"].strftime(DATE_FMT), "type": r["type"], "number": r["number"], "party": r["party"],
                 "cheque": r["cheque_no"], "amount": fmt_inr(r["amount"]),
                 "due": "due today" if r["days"] <= 0 else f"in {r['days']} day(s)", "_id": r["id"],
                 "_tag": "bad" if r["days"] <= 0 else ""} for r in BD.post_dated(db_path)]
    return ListScreen(parent, title="Post-dated Summary",
                      columns=(("when", "Date", 100, "w"), ("due", "Due", 110, "w"), ("type", "Type", 90, "w"),
                               ("number", "No.", 60, "e"), ("party", "Party", 240, "w"), ("cheque", "Cheque No.", 110, "w"),
                               ("amount", "Amount", 130, "e")),
                      load=load, on_close=on_close, on_enter=lambda r: on_open(r["_id"]),
                      subtitle="Vouchers marked Post-Dated (Ctrl+I › P). They enter the books on their date, when "
                               "BizPulse starts. Enter opens one.", empty="No post-dated vouchers.")


# ---- Display More Reports ------------------------------------------------------------------------------
def hsn_screen(parent, *, db_path: Path, company_state: str, on_close, today: date | None = None):
    start, end = _fy(today)

    def load():
        rows = XR.hsn_summary(db_path, start, end, company_state)
        out = [{"hsn": r.hsn, "rate": f"{r.rate.normalize():f}", "invoices": r.invoices, "taxable": fmt_inr(r.taxable),
                "cgst": fmt_inr(r.cgst), "sgst": fmt_inr(r.sgst), "igst": fmt_inr(r.igst),
                "total": fmt_inr(r.cgst + r.sgst + r.igst)} for r in rows]
        if rows:
            tot = {k: sum((getattr(r, k) for r in rows), Decimal("0")) for k in ("taxable", "cgst", "sgst", "igst")}
            out.append({"hsn": "Total", "invoices": sum(r.invoices for r in rows), "_tag": "total",
                        **{k: fmt_inr(v) for k, v in tot.items()}, "total": fmt_inr(tot["cgst"] + tot["sgst"] + tot["igst"])})
        return out
    return ListScreen(parent, title="HSN/SAC Summary",
                      columns=(("hsn", "HSN/SAC", 100, "w"), ("rate", "Rate %", 70, "e"), ("invoices", "Invoices", 80, "e"),
                               ("taxable", "Taxable value", 140, "e"), ("cgst", "CGST", 110, "e"), ("sgst", "SGST", 110, "e"),
                               ("igst", "IGST", 110, "e"), ("total", "Total tax", 120, "e")),
                      load=load, on_close=on_close, stretch="hsn",
                      subtitle=f"Sales, {start.strftime(DATE_FMT)} to {end.strftime(DATE_FMT)} (Regular vouchers).",
                      empty="No Sales invoices this financial year.")


def movement_screen(parent, *, db_path: Path, on_close, today: date | None = None):
    start, end = _fy(today)

    def load():
        return [{"item": r.item, "qin": r.qty_in or "", "vin": fmt_inr(r.value_in) if r.value_in else "",
                 "qout": r.qty_out or "", "vout": fmt_inr(r.value_out) if r.value_out else "",
                 "hand": "" if r.on_hand is None else r.on_hand, "_tag": "bad" if (r.on_hand or 0) < 0 else ""}
                for r in XR.movement(db_path, start, end)]
    return ListScreen(parent, title="Movement Analysis",
                      columns=(("item", "Item", 260, "w"), ("qin", "Inward qty", 100, "e"), ("vin", "Inward value", 130, "e"),
                               ("qout", "Outward qty", 100, "e"), ("vout", "Outward value", 130, "e"),
                               ("hand", "On hand now", 110, "e")),
                      load=load, on_close=on_close,
                      subtitle=f"Item Invoices {start.strftime(DATE_FMT)} to {end.strftime(DATE_FMT)}: Purchases in, Sales "
                               "out; on hand = inventory_stock_registry today.", empty="No item movements yet.")


def gstr3b_screen(parent, *, db_path: Path, company_state: str, input_ledgers: dict, on_close,
                  today: date | None = None):
    when = {"y": (today or date.today()).year, "m": (today or date.today()).month}

    def period() -> str:
        return f"{when['m']:02d}-{when['y']}"

    def load():                                       # background thread: no Tk calls in here
        g = XR.gstr3b(db_path, when["y"], when["m"], company_state, input_ledgers)
        money = lambda v: fmt_inr(v) if v else "0.00"  # noqa: E731
        rows = [{"table": "3.1(a)", "what": "Outward taxable supplies", "taxable": money(g.outward["taxable"]),
                 "igst": money(g.outward["igst"]), "cgst": money(g.outward["cgst"]), "sgst": money(g.outward["sgst"])},
                {"table": "3.1(c)", "what": "Nil-rated supplies", "taxable": money(g.nil_rated)}]
        for state, taxable in sorted(g.unregistered_inter.items()):
            rows.append({"table": "3.2", "what": f"Unregistered persons, {state}", "taxable": money(taxable),
                         "igst": money(g.unregistered_igst[state]), "_tag": "muted"})
        rows.append({"table": "4(A)(5)", "what": "Input tax credit (Input CGST / SGST / IGST ledgers)",
                     "igst": money(g.itc["igst"]), "cgst": money(g.itc["cgst"]), "sgst": money(g.itc["sgst"])})
        rows.append({"table": "Net", "what": "Output tax less ITC (before the portal's set-off)", "_tag": "total",
                     **{h: money(g.net(h)) for h in ("igst", "cgst", "sgst")}})
        rows.append({"table": "", "what": f"{g.invoices} Sales invoice(s) in {g.period}", "_tag": "muted"})
        return rows

    def subtitle() -> str:
        return (f"Return period {period()}. V previous month, X next month. A summary to check before filing; "
                "the portal computes the return.")

    def shift(step: int) -> None:
        m = when["m"] + step
        when["y"], when["m"] = when["y"] + (m - 1) // 12, (m - 1) % 12 + 1
        screen.subtitle.configure(text=subtitle())
        screen.reload()

    screen = ListScreen(parent, title="GSTR-3B Return (summary)",
                        columns=(("table", "Table", 80, "w"), ("what", "Particulars", 360, "w"),
                                 ("taxable", "Taxable value", 140, "e"), ("igst", "IGST", 110, "e"),
                                 ("cgst", "CGST", 110, "e"), ("sgst", "SGST", 110, "e")),
                        load=load, on_close=on_close, subtitle=subtitle(),
                        actions=[("V", "Previous month", lambda _r: shift(-1)), ("X", "Next month", lambda _r: shift(1))],
                        stretch="what",
                        detail=lambda r: ("ITC is what you posted to the Input tax ledgers this month; compare it with "
                                          "GSTR-2B." if r["table"].startswith("4") else ""))
    screen.period = period
    return screen


# ---- F4 Go To, Voucher Types ---------------------------------------------------------------------------
def goto_screen(parent, *, destinations: list[tuple[str, str, Callable[[], None]]], on_close):
    return ListScreen(parent, title="Go To",
                      columns=(("name", "Screen", 300, "w"), ("where", "Also on", 420, "w")),
                      load=lambda: [{"name": n, "where": w, "_go": go} for n, w, go in destinations],
                      on_close=on_close, on_enter=lambda r: r["_go"](),
                      subtitle="Every screen by name. Up / Down and Enter opens it.")


def voucher_types_screen(parent, *, voucher_keys: list[tuple[str, str]], on_close):
    about = {"Contra": "cash ↔ bank", "Payment": "money out", "Receipt": "money in", "Journal": "adjustments",
             "Sales": "invoices, GST register", "Purchase": "supplier invoices, stock in",
             "Credit Note": "sales returns", "Debit Note": "purchase returns"}
    return ListScreen(parent, title="Voucher Types",
                      columns=(("name", "Voucher type", 200, "w"), ("key", "Key", 100, "w"), ("use", "Used for", 360, "w")),
                      load=lambda: [{"name": n, "key": k, "use": about.get(n, "")} for k, n in voucher_keys],
                      on_close=on_close,
                      subtitle="BizPulse's voucher types are fixed. Their keys follow Settings › K (Keyboard Shortcuts).")
