"""Shared pieces for the report screens (Balance Sheet, Profit & Loss A/c)."""
from __future__ import annotations

import tkinter as tk
from decimal import Decimal
from tkinter import ttk

from config import theme as T
from services.reports import Node
from views.vouchers_view import fmt_inr


def money(value: Decimal) -> str:
    """Report style: 12,34,567.00; negatives in brackets (Tally shows a minus sign; brackets read better)."""
    return f"({fmt_inr(-value)})" if value < 0 else fmt_inr(value)


def title_bar(parent: tk.Widget, title: str, hint: str = "Esc Back") -> tk.Label:
    bar = tk.Frame(parent, bg=T.NAVY, height=34)
    bar.pack(side="top", fill="x")
    bar.pack_propagate(False)
    lbl = tk.Label(bar, text=title, bg=T.NAVY, fg=T.WHITE, font=T.F_VIEW_TITLE)
    lbl.pack(side="left", padx=12)
    tk.Label(bar, text=hint, bg=T.NAVY, fg=T.HOVER_TEXT, font=T.F_HEADER).pack(side="right", padx=12)
    return lbl


def report_tree(parent: tk.Widget, first_heading: str, amount_heading: str = "Amount") -> ttk.Treeview:
    """Particulars | (sub-amount) | Amount, with group rows bold and ledgers indented under them."""
    tree = ttk.Treeview(parent, columns=("sub", "amount"), show="tree headings", style="BizPulse.Treeview",
                        selectmode="browse")
    tree.heading("#0", text=first_heading, anchor="w")
    tree.heading("sub", text="", anchor="e")
    tree.heading("amount", text=amount_heading, anchor="e")
    tree.column("#0", width=260, minwidth=160, stretch=True)
    tree.column("sub", width=130, minwidth=110, anchor="e", stretch=False)
    tree.column("amount", width=150, minwidth=140, anchor="e", stretch=False)
    tree.tag_configure("group", font=T.F_LABEL_BOLD, foreground=T.NAVY)
    tree.tag_configure("ledger", font=T.F_LABEL, foreground=T.TEXT)
    tree.tag_configure("warn", font=T.F_LABEL_BOLD, foreground=T.BAD_RED)
    tree.tag_configure("total", font=T.F_LABEL_BOLD, foreground=T.NAVY, background=T.LIGHT_BLUE)
    tree.tag_configure("highlight", font=T.F_LABEL_BOLD, foreground=T.TEXT_DARK, background="#FFE3C8")
    tree.tag_configure("note", font=T.F_HINT, foreground=T.MUTED)
    return tree


def insert_node(tree: ttk.Treeview, node: Node, parent: str = "", tag: str = "group", open_: bool = True,
                show_amount_in: str = "amount") -> str:
    """Group amount in the right-hand column; its ledgers' amounts in the inner column."""
    values = ("", money(node.amount)) if show_amount_in == "amount" else (money(node.amount), "")
    iid = tree.insert(parent, "end", text=node.name, values=values, tags=(tag,), open=open_)
    for child in node.children:
        if child.children:
            insert_node(tree, child, iid, tag="group", open_=open_, show_amount_in="sub")
        else:
            tree.insert(iid, "end", text=child.name, values=(money(child.amount), ""), tags=("ledger",))
    return iid


def ratio_text(value: Decimal | None, kind: str) -> str:
    """Ratio Analysis / Dashboard figures: '—' when it cannot be worked out (never a fake 0)."""
    if value is None:
        return "—"
    if kind == "money":
        return money(value)
    if kind == "ratio":
        return f"{value:.2f} : 1"
    if kind == "percent":
        return f"{value:.2f} %"
    if kind == "days":
        return f"{value:.0f} days"
    return f"{value:.2f}"
