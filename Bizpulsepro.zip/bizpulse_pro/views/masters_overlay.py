"""
List of Masters — the light-blue box drawn over the workspace for Create, Alter and
Chart of Accounts (no separate window).

    box = MastersOverlay(area, mode="Create", on_choose=cb, on_close=cb)
    box.handle_key(event)   # call from the window's key dispatcher while the box is open

Keys: each master's bold letter opens it, Up / Down move the orange bar, Enter opens the
highlighted master, Esc closes the box. Choosing a master closes the box too; the caller
decides what happens next (on_choose(mode, master)): every master opens its Create / Alter form
on the canvas (views/master_form.py), Voucher Type lists the fixed types, and the company's GST
and PAN details open Company › Alter. An entry in MASTER_NOT_BUILT (empty now) shows a muted tag.
"""
from __future__ import annotations

import tkinter as tk
from typing import Callable, Collection, Sequence

from components.pointer_guard import PointerGuard
from config import theme as T
from config.settings import MASTER_NOT_BUILT, MASTER_SECTIONS

# Template per gateway item: box title and the line shown under it.
MODES = {
    "Create": {"title": "List of Masters", "caption": "Create"},
    "Alter": {"title": "List of Masters", "caption": "Alter"},
    "Chart of Accounts": {"title": "Chart of Accounts", "caption": "Display"},
}


def split_on_hotkey(label: str, key: str) -> tuple[str, str, str]:
    """'Stock Category', 'A' -> ('Stock C', 'a', 'tegory'). Prefers a letter that starts a word."""
    starts = [i for i, ch in enumerate(label) if ch.isalpha() and (i == 0 or not label[i - 1].isalpha())]
    idx = next((i for i in starts if label[i].upper() == key), None)
    if idx is None:
        idx = label.upper().find(key)
    if idx < 0:
        return label, "", ""
    return label[:idx], label[idx], label[idx + 1:]


def hotkey_labels(parent: tk.Widget, label: str, key: str, bg: str, fg: str,
                  first_padx: int = 0) -> list[tk.Label]:
    """Draw a menu label with its shortcut letter in bold, flush against the rest of the word:
    'Banking', 'N' -> 'Ba' + bold 'n' + 'king'. No space, no underline, no padding between the
    pieces (padx=0, bd=0, highlightthickness=0). Packs them left to right and returns them."""
    parts: list[tk.Label] = []
    before, letter, after = split_on_hotkey(label, key)
    for text, font in ((before, T.F_TEXT), (letter, T.F_KEY), (after, T.F_TEXT)):
        if not text:
            continue
        lbl = tk.Label(parent, text=text, bg=bg, fg=fg, font=font, padx=0, pady=3, bd=0, highlightthickness=0)
        lbl.pack(side="left", padx=(first_padx if not parts else 0, 0))
        parts.append(lbl)
    return parts


class MastersOverlay(tk.Frame):
    WIDTH = 340

    def __init__(self, area: tk.Widget, mode: str,
                 on_choose: Callable[[str, str], None], on_close: Callable[[], None],
                 sections: Sequence[tuple[str, Sequence[tuple[str, str]]]] = MASTER_SECTIONS,
                 title: str | None = None, caption: str | None = None,
                 not_built: Collection[str] = (), title_font=None, width: int | None = None) -> None:
        super().__init__(area.winfo_toplevel(), bg=T.LIGHT_BLUE, highlightbackground=T.NAVY,
                         highlightthickness=1, takefocus=1)
        self.mode = mode
        self._area = area
        self._on_choose = on_choose
        self._on_close = on_close
        self._rows: list[dict] = []
        self._pointer = PointerGuard()          # the bar follows the mouse only when it really moves
        self._tags: set[tk.Widget] = set()
        self._not_built = set(not_built)
        if mode in ("Create", "Alter") and sections is MASTER_SECTIONS and not not_built:
            self._not_built = set(MASTER_NOT_BUILT)    # Group, Ledger, GST Classification open real forms
        self._active = 0
        template = dict(MODES.get(mode, {"title": "List of Masters", "caption": mode}))
        if title is not None:
            template["title"] = title
        if caption is not None:
            template["caption"] = caption

        tk.Label(self, text=template["title"], bg=T.NAVY, fg=T.WHITE, font=title_font or T.F_PANEL_HEAD,
                 pady=8).pack(side="top", fill="x")
        self._width = width or self.WIDTH
        tk.Label(self, text=template["caption"], bg=T.LIGHT_BLUE, fg=T.MUTED, font=T.F_MASTER_SECTION,
                 anchor="e").pack(side="top", fill="x", padx=14, pady=(4, 0))

        body = tk.Frame(self, bg=T.LIGHT_BLUE)
        body.pack(side="top", fill="both", expand=True, padx=14, pady=(0, 6))
        for section, items in sections:
            tk.Label(body, text=section.upper(), bg=T.LIGHT_BLUE, fg=T.MUTED, font=T.F_MASTER_SECTION,
                     anchor="w").pack(side="top", fill="x", pady=(8, 1))
            for label, key in items:
                self._add_row(body, label, key)

        tk.Label(self, text="Esc close   Enter open   Letter = shortcut", bg=T.LIGHT_BLUE, fg=T.MUTED,
                 font=T.F_HINT).pack(side="bottom", pady=(2, 8))

    # ---- public ------------------------------------------------------------------------
    def show(self) -> None:
        """Centre the box on the working area, draw it on top, and give it the keyboard."""
        self.place(in_=self._area, relx=0.5, rely=0.5, anchor="center", width=self._width)
        self.lift()
        self.set_active(0)
        self.focus_set()

    def handle_key(self, event: tk.Event) -> str | None:
        if event.state & (T.MOD_CTRL | T.MOD_ALT):
            return None
        keysym = event.keysym
        if keysym == "Escape":
            self._on_close()
            return "break"
        if keysym in ("Up", "Down"):
            self.set_active(self._active + (-1 if keysym == "Up" else 1))
            return "break"
        if keysym in ("Return", "KP_Enter"):
            self.choose(self._active)
            return "break"
        if len(keysym) == 1 and keysym.isalpha():
            letter = keysym.upper()
            hit = next((i for i, r in enumerate(self._rows) if r["key"] == letter), None)
            if hit is not None:
                self.choose(hit)
            return "break"
        return None

    def set_active(self, index: int) -> None:
        if not self._rows:
            return
        self._active = index % len(self._rows)
        for i, row in enumerate(self._rows):
            on = i == self._active
            for w in row["widgets"]:
                w.configure(bg=T.ORANGE if on else T.LIGHT_BLUE)
                if isinstance(w, tk.Label):
                    w.configure(fg=T.TEXT_DARK if on else (T.MUTED if w in self._tags else T.NAVY))

    def choose(self, index: int) -> None:
        self.set_active(index)
        self._on_choose(self.mode, self._rows[self._active]["label"])

    @property
    def active_label(self) -> str:
        return self._rows[self._active]["label"]

    # ---- internal ----------------------------------------------------------------------
    def _add_row(self, parent: tk.Widget, label: str, key: str) -> None:
        index = len(self._rows)
        row = tk.Frame(parent, bg=T.LIGHT_BLUE, cursor="hand2")
        row.pack(side="top", fill="x")
        # Segoe UI 11 throughout; only the hotkey letter is bold, flush with its word. No underline.
        parts: list[tk.Widget] = list(hotkey_labels(row, label, key, T.LIGHT_BLUE, T.NAVY, first_padx=16))
        if label in self._not_built:
            tag = tk.Label(row, text="not built yet", bg=T.LIGHT_BLUE, fg=T.MUTED, font=T.F_HINT, padx=8)
            tag.pack(side="right")
            parts.append(tag)
            self._tags.add(tag)
        for w in (row, *parts):
            w.bind("<Motion>", lambda e, n=index: self._pointer.moved(e) and self.set_active(n))
            w.bind("<Button-1>", lambda _e, n=index: self.choose(n))
        self._rows.append({"label": label, "key": key, "widgets": (row, *parts)})
