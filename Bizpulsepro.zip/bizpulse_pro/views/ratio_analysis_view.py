"""
Ratio Analysis (R, under Reports) — two columns on the white canvas.

    +-----------------------------------------------------------------------------+
    | Ratio Analysis - SRIJEE CREATIONS                                     Esc   |
    +--------------------------------------+--------------------------------------+
    | Principal Groups                     | Principal Ratios                     |
    |  Working Capital        93,300.00    |  Current Ratio            12.40 : 1  |
    |  Cash-in-Hand           ...          |  Quick Ratio              ...        |
    |  ...                                 |  ...                                 |
    +--------------------------------------+--------------------------------------+
    | How it is worked out: Current Assets : Current Liabilities                  |
    +-----------------------------------------------------------------------------+

Figures: services/analytics.py (from the same saved vouchers as the Balance Sheet and P&L,
financial year to date), loaded in a background thread. A ratio whose divisor is nil shows
"—". The line at the bottom explains the highlighted row.

Keys: Up / Down move, Tab switches column, Esc back (F5 refresh is on the action bar).
"""
from __future__ import annotations

import tkinter as tk
from datetime import date
from pathlib import Path
from tkinter import ttk
from typing import Callable

from config import theme as T
from services.analytics import RatioAnalysis, RatioRow, ratio_analysis
from services.background import run_in_background
from services.reports import ReportError, build_reports
from views.report_common import ratio_text, title_bar
from views.vouchers_view import DATE_FMT


class RatioAnalysisView(tk.Frame):
    def __init__(self, parent: tk.Widget, *, db_path: Path, company: str, on_close: Callable[[], None],
                 period_end: date | None = None) -> None:
        super().__init__(parent, bg=T.WHITE)
        self._on_close = on_close
        self._rows: dict[str, RatioRow] = {}
        title_bar(self, f"Ratio Analysis - {company.upper()}", "Tab other column    Esc Back")
        self._subtitle = tk.Label(self, text="Loading…", bg=T.WHITE, fg=T.MUTED, font=T.F_LABEL, anchor="w")
        self._subtitle.pack(side="top", fill="x", padx=14, pady=(8, 4))

        body = tk.Frame(self, bg=T.WHITE)
        body.pack(side="top", fill="both", expand=True, padx=14)
        body.columnconfigure(0, weight=1, uniform="half")
        body.columnconfigure(1, weight=1, uniform="half")
        body.rowconfigure(1, weight=1)
        self._trees: list[ttk.Treeview] = []
        for col, heading in enumerate(("Principal Groups", "Principal Ratios")):
            pad = (0, 6) if col == 0 else (6, 0)
            tk.Label(body, text=heading, bg=T.WHITE, fg=T.NAVY, font=T.F_VIEW_TITLE, anchor="w").grid(
                row=0, column=col, sticky="ew", padx=pad, pady=(0, 4))
            box = tk.Frame(body, bg=T.WHITE, highlightthickness=1, highlightbackground=T.BORDER)
            box.grid(row=1, column=col, sticky="nsew", padx=pad)
            tree = ttk.Treeview(box, columns=("value",), show="tree headings", style="BizPulse.Treeview",
                                selectmode="browse")
            tree.heading("#0", text="Particulars", anchor="w")
            tree.heading("value", text="Amount" if col == 0 else "Ratio", anchor="e")
            tree.column("#0", width=220, minwidth=160, stretch=True)
            tree.column("value", width=160, minwidth=140, anchor="e", stretch=False)
            tree.tag_configure("row", font=T.F_LABEL, foreground=T.TEXT)
            tree.tag_configure("na", font=T.F_LABEL, foreground=T.MUTED)
            tree.tag_configure("key", font=T.F_LABEL_BOLD, foreground=T.NAVY)
            tree.pack(side="left", fill="both", expand=True)
            tree.bind("<<TreeviewSelect>>", lambda _e, t=tree: self._explain(t))
            tree.bind("<FocusIn>", lambda _e, t=tree: self._explain(t))
            self._trees.append(tree)

        self._explain_lbl = tk.Label(self, bg=T.LIGHT_BLUE, fg=T.TEXT, font=T.F_LABEL, anchor="w", justify="left",
                                     padx=10, pady=6, highlightthickness=1, highlightbackground=T.BORDER,
                                     wraplength=880)
        self._explain_lbl.pack(side="top", fill="x", padx=14, pady=(8, 4))
        self._notice = tk.Label(self, bg=T.WHITE, fg=T.MUTED, font=T.F_HINT, anchor="w", justify="left",
                                wraplength=880)
        self._notice.pack(side="top", fill="x", padx=14, pady=(0, 10))

        run_in_background(self, lambda: ratio_analysis(build_reports(db_path, period_end or date.today())),
                          self._show, self._failed)

    def _show(self, ra: RatioAnalysis) -> None:
        self._subtitle.configure(text=f"{ra.period_start.strftime(DATE_FMT)} to {ra.period_end.strftime(DATE_FMT)} · "
                                      "financial year to date · from saved vouchers")
        for tree, rows in zip(self._trees, (ra.groups, ra.ratios)):
            for row in rows:
                tag = "na" if row.value is None else ("key" if row.label in ("Working Capital", "Nett Profit") else "row")
                iid = tree.insert("", "end", text=row.label, values=(ratio_text(row.value, row.kind),), tags=(tag,))
                self._rows[f"{id(tree)}:{iid}"] = row
        warn_words = ("not grouped", "overstated", "understated", "left out of the books", "twice", "not a valid")
        self._notice.configure(text="\n".join(ra.notes),
                               fg=T.BAD_RED if any(w in n for n in ra.notes for w in warn_words) else T.MUTED)
        self.focus_first()

    def _explain(self, tree: ttk.Treeview) -> None:
        sel = tree.selection()
        row = self._rows.get(f"{id(tree)}:{sel[0]}") if sel else None
        if row is not None:
            text = f"{row.label}:  {row.formula}"
            if row.note:
                text += f"\n{row.note}"
            self._explain_lbl.configure(text=text)

    def _failed(self, exc: Exception) -> None:
        msg = str(exc) if isinstance(exc, ReportError) else f"Could not build the Ratio Analysis: {exc}"
        self._subtitle.configure(text="")
        self._notice.configure(text=msg, fg=T.BAD_RED)

    def focus_first(self, index: int = 0) -> None:
        tree = self._trees[index]
        tree.focus_set()
        kids = tree.get_children()
        if kids and not tree.selection():
            tree.selection_set(kids[0])
            tree.focus(kids[0])
        self._explain(tree)

    def handle_key(self, event: tk.Event) -> str | None:
        if event.keysym == "Escape":
            self._on_close()
            return "break"
        if event.keysym == "Tab":
            self.focus_first(1 if self.focus_get() is self._trees[0] else 0)
            return "break"
        return None
