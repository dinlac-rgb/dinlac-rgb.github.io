"""
Comparative Profit & Loss A/c / Balance Sheet — the same group rows, one column per period.

    Particulars              FY 2025-26     FY 2026-27 to date     Change        %
    Sales Accounts           8,40,000.00        5,10,000.00     -3,30,000.00   -39.3
    ...

Keys: C switches the comparison (last year vs this year  <->  quarters of this year);
Esc closes it and goes back to the screen it was opened from. With two columns, Change and %
show the movement from the first column to the second.
Figures: services/comparative.py, loaded in a background thread.
"""
from __future__ import annotations

import tkinter as tk
from datetime import date
from decimal import Decimal
from pathlib import Path
from tkinter import ttk
from typing import Callable

from config import theme as T
from services.background import run_in_background
from services.comparative import MODES, Comparison, comparative
from views.masters_overlay import hotkey_labels
from views.report_common import money, title_bar
from views.vouchers_view import DATE_FMT

TITLES = {"pl": "Profit & Loss A/c", "bs": "Balance Sheet"}
MODE_TEXT = {"year": "Last year vs this year", "quarters": "Quarters of this year"}


class ComparativeView(tk.Frame):
    def __init__(self, parent: tk.Widget, *, db_path: Path, kind: str, company: str, on_close: Callable[[], None],
                 mode: str = "year", today: date | None = None) -> None:
        super().__init__(parent, bg=T.WHITE)
        self._db, self.kind, self.mode, self._today = db_path, kind, mode, today
        self._on_close = on_close
        title_bar(self, f"{TITLES[kind]} - Comparative - {company.upper()}", "C Switch periods    Esc Back")
        top = tk.Frame(self, bg=T.WHITE)
        top.pack(side="top", fill="x", padx=14, pady=(8, 4))
        self._subtitle = tk.Label(top, text="Loading…", bg=T.WHITE, fg=T.MUTED, font=T.F_TEXT, anchor="w")
        self._subtitle.pack(side="left")
        link = tk.Frame(top, bg=T.LIGHT_BLUE, cursor="hand2", highlightthickness=1, highlightbackground=T.LINE)
        link.pack(side="right")
        for w in (link, *hotkey_labels(link, "Change comparison", "C", T.LIGHT_BLUE, T.NAVY, first_padx=8)):
            w.bind("<Button-1>", lambda _e: self.switch())
        tk.Frame(link, bg=T.LIGHT_BLUE, width=8).pack(side="left")

        self._box = tk.Frame(self, bg=T.WHITE, highlightthickness=1, highlightbackground=T.BORDER)
        self._box.pack(side="top", fill="both", expand=True, padx=14)
        self._tree: ttk.Treeview | None = None
        self._notes = tk.Label(self, bg=T.WHITE, fg=T.MUTED, font=T.F_TEXT, anchor="w", justify="left", wraplength=880)
        self._notes.pack(side="top", fill="x", padx=14, pady=(6, 0))
        self._guard = tk.Label(self, bg=T.WHITE, fg=T.BAD_RED, font=T.F_TEXT, anchor="w", justify="left",
                               wraplength=880)
        self._guard.pack(side="top", fill="x", padx=14, pady=(2, 10))
        self._load()

    def _load(self) -> None:
        self._subtitle.configure(text=f"{MODE_TEXT[self.mode]} · loading…")
        db, kind, mode, today = self._db, self.kind, self.mode, self._today
        run_in_background(self, lambda: comparative(db, kind, mode, today), self._show,
                          lambda exc: self._subtitle.configure(text=f"Could not build it: {exc}", fg=T.BAD_RED))

    def _show(self, c: Comparison) -> None:
        if self._tree is not None:
            self._tree.destroy()
        two = len(c.columns) == 2
        cols = [f"c{i}" for i in range(len(c.columns))] + (["chg", "pct"] if two else [])
        tree = ttk.Treeview(self._box, columns=cols, show="tree headings", style="BizPulse.Treeview", selectmode="browse")
        tree.heading("#0", text="Particulars", anchor="w")
        tree.column("#0", width=230, minwidth=160, stretch=True)
        for i, col in enumerate(c.columns):
            tree.heading(f"c{i}", text=col.label, anchor="e")
            tree.column(f"c{i}", width=135, minwidth=110, anchor="e", stretch=False)
        if two:
            tree.heading("chg", text="Change", anchor="e")
            tree.column("chg", width=125, minwidth=100, anchor="e", stretch=False)
            tree.heading("pct", text="%", anchor="e")
            tree.column("pct", width=70, minwidth=60, anchor="e", stretch=False)
        tree.tag_configure("group", foreground=T.TEXT)
        tree.tag_configure("heading", foreground=T.MUTED)
        tree.tag_configure("total", foreground=T.NAVY, background=T.LIGHT_BLUE)
        tree.tag_configure("net", foreground=T.TEXT_DARK, background="#FFE3C8")
        for label, amounts, style in c.rows:
            if style == "heading":
                tree.insert("", "end", text=label, tags=("heading",))
                continue
            values = [money(a) for a in amounts]
            if two:
                change = amounts[1] - amounts[0]
                pct = f"{(change * 100 / abs(amounts[0])).quantize(Decimal('0.1'))}" if amounts[0] else "—"
                values += [money(change), pct]
            tree.insert("", "end", text=label, values=values, tags=(style,))
        tree.pack(fill="both", expand=True)
        self._tree = tree
        span = f"{c.columns[0].start.strftime(DATE_FMT)} to {c.columns[-1].end.strftime(DATE_FMT)}" if c.columns else ""
        self._subtitle.configure(text=f"{MODE_TEXT[c.mode]} · {span}", fg=T.MUTED)
        guard = [n for n in c.notes if "Difference in Opening Balances" in n]
        self._notes.configure(text="\n".join(n for n in c.notes if n not in guard))
        self._guard.configure(text="\n".join(guard))
        self.focus_first()

    def switch(self) -> None:
        self.mode = MODES[(MODES.index(self.mode) + 1) % len(MODES)]
        self._load()

    def focus_first(self) -> None:
        if self._tree is not None:
            self._tree.focus_set()
        else:
            self.focus_set()

    def handle_key(self, event: tk.Event) -> str | None:
        if event.state & (T.MOD_CTRL | T.MOD_ALT):
            return None
        if event.keysym == "Escape":
            self._on_close()
            return "break"
        if event.keysym.lower() == "c":
            self.switch()
            return "break"
        return None
