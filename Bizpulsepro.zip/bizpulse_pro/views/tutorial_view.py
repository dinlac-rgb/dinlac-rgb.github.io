"""
[T] Tutorial (Alt+T) — the step-by-step operating guide, a vertical scrolling board on the
white canvas.

    Tutorial - Operating Guide         1-5 module   Up/Down scroll   PgUp/PgDn page   Esc Corridor
    CONTENTS
      1  Foundational Company Accounting Setup
      2  The 28 Pre-Defined Primary Account Groups
      ...
    ┌ Module 1: Foundational Company Accounting Setup ─────────────────────────┐
      1.  Create the company file: press Alt+K ...
      2.  ...

Keys: 1 – 5 jump to a module (a click on a contents line does the same); Up / Down scroll a
few lines; Page Up / Page Down a page; Home / End the top and bottom; Esc clears the canvas and
gives the keyboard back to the Corridor. The mouse wheel scrolls too.
Typography: Segoe UI 11 normal throughout; keys and shortcut letters bold; module headings
are set apart with colour and a light-blue band, not size. Text: views/tutorial_content.py.
"""
from __future__ import annotations

import re
import tkinter as tk
from typing import Callable

from config import theme as T
from views.report_common import title_bar
from views.tutorial_content import modules

BOLD = re.compile(r"\*\*(.+?)\*\*")


class TutorialView(tk.Frame):
    def __init__(self, parent: tk.Widget, *, on_close: Callable[[], None]) -> None:
        super().__init__(parent, bg=T.WHITE, takefocus=1)
        self._on_close = on_close
        title_bar(self, "Tutorial - Operating Guide", "1-5 module    Up/Down scroll    PgUp/PgDn page    Esc Corridor")
        box = tk.Frame(self, bg=T.WHITE)
        box.pack(side="top", fill="both", expand=True, padx=14, pady=(8, 10))
        self.text = tk.Text(box, wrap="word", font=T.F_TEXT, bg=T.WHITE, fg=T.TEXT, relief="flat", bd=0,
                            highlightthickness=0, padx=16, pady=8, spacing1=2, spacing3=2, cursor="arrow",
                            takefocus=0)
        bar = tk.Scrollbar(box, orient="vertical", command=self.text.yview)
        self.text.configure(yscrollcommand=bar.set)
        bar.pack(side="right", fill="y")
        self.text.pack(side="left", fill="both", expand=True)
        t = self.text
        t.tag_configure("key", font=T.F_KEY)
        t.tag_configure("h0", foreground=T.MUTED, spacing1=4, spacing3=4)
        t.tag_configure("h1", foreground=T.NAVY, background=T.LIGHT_BLUE, spacing1=16, spacing3=8, lmargin1=6,
                        lmargin2=6, rmargin=6)
        t.tag_configure("p", lmargin1=6, lmargin2=6, spacing3=6)
        t.tag_configure("step", lmargin1=18, lmargin2=40, spacing3=5)
        t.tag_configure("item", lmargin1=18, lmargin2=34, spacing3=3)
        t.tag_configure("note", foreground=T.MUTED, lmargin1=18, lmargin2=18, spacing1=4, spacing3=8)
        t.tag_configure("index", lmargin1=18, lmargin2=18, foreground=T.NAVY)
        self.titles: list[str] = []
        self._fill()
        t.configure(state="disabled")

    def _write(self, text: str, *tags: str) -> None:
        """Text with **bold** keys; every piece also carries `tags`."""
        pos = 0
        for m in BOLD.finditer(text):
            if m.start() > pos:
                self.text.insert("end", text[pos:m.start()], tags)
            self.text.insert("end", m.group(1), tags + ("key",))
            pos = m.end()
        self.text.insert("end", text[pos:], tags)

    def _fill(self) -> None:
        content = modules()
        self._write("CONTENTS\n", "h0")
        for i, (title, _body) in enumerate(content, start=1):
            tag = f"goto{i}"
            short = title.split(": ", 1)[-1]
            self._write(f"**{i}**   {short}\n", "index", tag)
            self.text.tag_bind(tag, "<Button-1>", lambda _e, n=i: self.jump(n))
            self.text.tag_bind(tag, "<Enter>", lambda _e: self.text.configure(cursor="hand2"))
            self.text.tag_bind(tag, "<Leave>", lambda _e: self.text.configure(cursor="arrow"))
        for i, (title, body) in enumerate(content, start=1):
            self.titles.append(title)
            self.text.insert("end", "\n")
            self.text.mark_set(f"module{i}", "end-1c")
            self.text.mark_gravity(f"module{i}", "left")
            self._write(f"{title}\n", "h1")
            n = 0
            for kind, line in body:
                if kind == "step":
                    n += 1
                    self._write(f"{n}.  {line}\n", "step")
                elif kind == "item":
                    self._write(f"•  {line}\n", "item")
                else:
                    self._write(f"{line}\n", kind)
        self.text.insert("end", "\n")
        self._write("On every screen: **Esc** goes back, **F1** opens Help, **Alt** + a header letter opens that "
                    "menu (K Company, Y Data, Z Exchange, O Import, E Export, P Print; S Settings, D Dashboard, "
                    "T Tutorial).\n", "note")

    # ---- moving ---------------------------------------------------------------------------
    def jump(self, number: int) -> None:
        if 1 <= number <= len(self.titles):
            self.text.yview(f"module{number}")

    def focus_first(self) -> None:
        self.focus_set()                 # the board takes the keys; the text itself is read only

    def handle_key(self, event: tk.Event) -> str | None:
        if event.keysym == "Escape":
            self._on_close()
            return "break"
        if event.state & (T.MOD_CTRL | T.MOD_ALT):
            return None
        key = event.keysym
        moves = {"Up": ("scroll", -3, "units"), "Down": ("scroll", 3, "units"),
                 "Prior": ("scroll", -1, "pages"), "Next": ("scroll", 1, "pages")}
        if key in moves:
            self.text.yview(*moves[key])
            return "break"
        if key == "Home":
            self.text.yview_moveto(0)
            return "break"
        if key == "End":
            self.text.yview_moveto(1)
            return "break"
        if key.isdigit():
            self.jump(int(key))
            return "break"
        return None
