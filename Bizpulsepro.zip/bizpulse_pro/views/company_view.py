"""
Company › Create Company / Alter Company (also Masters › GST Registration, Company GST Details,
PAN/CIN Details) and Company › Select Company (F3).

    Company Name        [Srijee Creations                          ]
    State Code          [19] West Bengal
    GSTIN               [19AAAAA0000A1Z5]
    PAN                 [AAAAA0000A]
    CIN                 [                     ]
    Address             [                                          ]
    Invoice Prefix      [SRJ]   numbers look like SRJ/26-27/0001

Keys: Enter moves to the next field and, on the last one, saves (Create asks first); Ctrl+A
saves from any field; Esc goes back one field, and on the first field leaves (asking if anything
changed). Everything is checked by services/company.check before it is written.

Create makes a NEW database file (services/schema.create_company_file): companies/<name>.db,
or bizpulse_local.db itself when there is no company yet (first start). Alter writes the profile
into the open company's database (bp_company) and applies it at once. Select lists the company
files; choosing another one restarts BizPulse with it.
"""
from __future__ import annotations

import tkinter as tk
from pathlib import Path
from tkinter import messagebox
from typing import Callable

from config import theme as T
from services import company as C
from services.gst import STATE_NAMES
from views.list_screen import ListScreen
from views.report_common import title_bar

FORM = (("name", "Company Name", 44), ("state_code", "State Code", 5), ("gstin", "GSTIN", 18), ("pan", "PAN", 12),
        ("cin", "CIN", 24), ("address", "Address", 60), ("invoice_prefix", "Invoice Prefix", 7))


class CompanyFormView(tk.Frame):
    def __init__(self, parent: tk.Widget, *, mode: str, values: dict, on_close: Callable[[], None],
                 on_save: Callable[[dict, Callable[[str], None], Callable[[str], None]], None], note: str = "",
                 focus: str = "name") -> None:
        """mode: "create" or "alter". on_save(values, done, failed) does the writing (background)."""
        super().__init__(parent, bg=T.WHITE)
        self.mode, self._on_close, self._on_save, self._focus = mode, on_close, on_save, focus
        title_bar(self, "Company Creation" if mode == "create" else "Company Alteration",
                  "Enter next    Ctrl+A Save    Esc Back")
        if note:
            tk.Label(self, text=note, bg=T.WHITE, fg=T.NAVY, font=T.F_TEXT, anchor="w", justify="left",
                     wraplength=860).pack(side="top", fill="x", padx=14, pady=(10, 0))
        form = tk.Frame(self, bg=T.WHITE)
        form.pack(side="top", fill="x", padx=14, pady=10)
        self.entries: dict[str, tk.Entry] = {}
        self._hints: dict[str, tk.Label] = {}
        for r, (key, label, width) in enumerate(FORM):
            tk.Label(form, text=label, bg=T.WHITE, fg=T.TEXT, font=T.F_TEXT, anchor="w", width=16).grid(
                row=r, column=0, sticky="w", pady=4)
            e = tk.Entry(form, width=width, font=T.F_TEXT, relief="flat", bd=0, highlightthickness=1,
                         highlightbackground=T.LINE, highlightcolor=T.ORANGE)
            e.grid(row=r, column=1, sticky="w", pady=4, ipady=3)
            e.insert(0, str(values.get(key, "") or ""))
            e.bind("<KeyRelease>", lambda _e: self._refresh_hints(), add="+")
            hint = tk.Label(form, bg=T.WHITE, fg=T.MUTED, font=T.F_TEXT, anchor="w")
            hint.grid(row=r, column=2, sticky="w", padx=10)
            self.entries[key], self._hints[key] = e, hint
        self.status = tk.Label(self, bg=T.WHITE, fg=T.MUTED, font=T.F_TEXT, anchor="w", justify="left", wraplength=860)
        self.status.pack(side="top", fill="x", padx=14)
        self._start = self.values()
        self._saving = False
        self._refresh_hints()

    def values(self) -> dict:
        return {k: e.get().strip() for k, e in self.entries.items()}

    def _refresh_hints(self) -> None:
        code = self.entries["state_code"].get().strip().zfill(2) if self.entries["state_code"].get().strip() else ""
        self._hints["state_code"].configure(text=STATE_NAMES.get(code, "01 to 38, or 97 (West Bengal is 19)"))
        prefix = self.entries["invoice_prefix"].get().strip().upper() or "SRJ"
        self._hints["invoice_prefix"].configure(text=f"invoice numbers look like {prefix}/26-27/0001")
        self._hints["gstin"].configure(text="blank = not registered yet")
        self._hints["cin"].configure(text="companies registered with the MCA only")

    # ---- saving --------------------------------------------------------------------------
    def save(self) -> None:
        if self._saving:
            return
        try:
            clean = C.check(self.values())
        except C.CompanyError as exc:
            self.status.configure(text=str(exc), fg=T.BAD_RED)
            return
        if self.mode == "create" and not messagebox.askyesno(
                "Create company?", f"Create the company '{clean['name']}' in a new database file?", parent=self):
            return
        self._saving = True
        self.status.configure(text="Saving…", fg=T.MUTED)
        self._on_save(clean, self._saved, self._failed)

    def _saved(self, message: str) -> None:
        self._saving = False
        if self.winfo_exists():
            self._start = self.values()
            self.status.configure(text=message, fg=T.OK_GREEN)

    def _failed(self, message: str) -> None:
        self._saving = False
        if self.winfo_exists():
            self.status.configure(text=message, fg=T.BAD_RED)

    # ---- keys ----------------------------------------------------------------------------
    def focus_first(self) -> None:
        self.entries.get(self._focus, self.entries["name"]).focus_set()

    def handle_key(self, event: tk.Event) -> str | None:
        order = list(self.entries.values())
        widget = event.widget
        if event.state & T.MOD_CTRL and event.keysym.lower() == "a":
            self.save()
            return "break"
        if event.keysym == "Escape":
            if widget in order and order.index(widget) > 0:
                order[order.index(widget) - 1].focus_set()
                return "break"
            if self.values() != self._start and not messagebox.askyesno(
                    "Leave?", "The changes on this screen will be lost.\n\nGo back anyway?", default="no", parent=self):
                return "break"
            self._on_close()
            return "break"
        if event.keysym in ("Return", "KP_Enter", "Tab"):
            if widget in order and order.index(widget) < len(order) - 1:
                order[order.index(widget) + 1].focus_set()
            else:
                self.save()
            return "break"
        return None


def select_company_screen(parent: tk.Widget, *, app_dir: Path, main_file: str, active: str,
                          on_choose: Callable[[str], None], on_close: Callable[[], None]) -> ListScreen:
    def load() -> list[dict]:
        rows = []
        for rel, name in C.company_files(app_dir, main_file):
            here = rel == active
            rows.append({"name": name, "file": rel, "state": "open now" if here else "",
                         "_tag": "good" if here else ""})
        return rows

    def choose(row: dict | None) -> None:
        if row is not None:
            on_choose(row["file"])

    return ListScreen(parent, title="Select Company", columns=(("name", "Company", 360, "w"),
                                                             ("file", "File", 300, "w"), ("state", "", 120, "w")),
                      load=load, on_close=on_close, on_enter=choose,
                      subtitle="Each company is its own database file. Enter opens the highlighted one "
                               "(BizPulse restarts with it).",
                      empty="No company file yet: Company › Create Company makes one.")
