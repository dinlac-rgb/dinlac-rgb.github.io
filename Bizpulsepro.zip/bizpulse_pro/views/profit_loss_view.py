"""
Profit & Loss A/c (P, under Reports) — full-width, one row per heading.

    Profit & Loss A/c - SRIJEE CREATIONS            01-04-2026 to 09-10-2026
    ------------------------------------------------------------------------
    Sales Accounts                                              10,000.00
    Direct Incomes                                                   0.00
    Less: Opening Stock                                          2,000.00
    Less: Purchases                                              6,000.00
    Less: Direct Expenses                                          500.00
    Add: Closing Stock                                           2,400.00
    Gross Profit                                                 3,900.00
    Add: Indirect Incomes                                            0.00
    Less: Indirect Expenses                                      1,200.00
    NET PROFIT                                                   2,700.00   <- highlighted
    ------------------------------------------------------------------------
    Stock: notes on how opening / closing stock were taken (config/stock_valuation.py)
    From your other tables (cross-check only): gst_sales_ledger …, workforce_payroll …

Each heading opens to show its ledgers. Figures: services/reports.py (vouchers saved in
bizpulse_local.db for the financial year to date), loaded in a background thread.
Keys: Up / Down, Left / Right open or close a heading, Esc back.
"""
from __future__ import annotations

import tkinter as tk
from datetime import date
from pathlib import Path
from tkinter import ttk
from typing import Callable

from config import theme as T
from services.background import run_in_background
from services.reports import Node, ReportError, Reports, build_reports
from views.report_common import insert_node, money, report_tree, title_bar
from views.vouchers_view import DATE_FMT

# (label, group in Reports.pl, sign shown). Gross and net rows are added in between.
TRADING_ROWS = [
    ("Sales Accounts", "Sales Accounts"),
    ("Direct Incomes", "Direct Incomes"),
    ("Less: Opening Stock", "Opening Stock"),
    ("Less: Purchases", "Purchase Accounts"),
    ("Less: Direct Expenses", "Direct Expenses"),
    ("Add: Closing Stock", "Closing Stock"),
]
PL_ROWS = [
    ("Add: Indirect Incomes", "Indirect Incomes"),
    ("Less: Indirect Expenses", "Indirect Expenses"),
]
STOCK_ROWS = {"Opening Stock": "not entered", "Closing Stock": "not in books"}
WARN_WORDS = ("overstated", "understated", "left out of the books", "twice", "not a valid")


class ProfitLossView(tk.Frame):
    def __init__(self, parent: tk.Widget, *, db_path: Path, company: str, on_close: Callable[[], None],
                 on_compare: Callable[[], None] | None = None,
                 period_end: date | None = None) -> None:
        super().__init__(parent, bg=T.WHITE)
        self._on_close = on_close
        self._on_compare = on_compare          # C: comparative columns
        title_bar(self, f"Profit & Loss A/c - {company.upper()}", "C Compare    Left / Right open    Esc Back")

        self._subtitle = tk.Label(self, text="Loading…", bg=T.WHITE, fg=T.MUTED, font=T.F_LABEL, anchor="w")
        self._subtitle.pack(side="top", fill="x", padx=14, pady=(8, 4))

        box = tk.Frame(self, bg=T.WHITE, highlightthickness=1, highlightbackground=T.BORDER)
        box.pack(side="top", fill="both", expand=True, padx=14)
        self._tree = report_tree(box, "Particulars")
        self._tree.column("#0", width=520)
        sb = ttk.Scrollbar(box, orient="vertical", command=self._tree.yview)
        self._tree.configure(yscrollcommand=sb.set)
        sb.pack(side="right", fill="y")
        self._tree.pack(side="left", fill="both", expand=True)

        self._reference = tk.Label(self, bg=T.LIGHT_BLUE, fg=T.TEXT, font=T.F_HINT, anchor="w", justify="left",
                                   padx=10, pady=6, highlightthickness=1, highlightbackground=T.BORDER)
        self._reference.pack(side="top", fill="x", padx=14, pady=(8, 10))

        run_in_background(self, lambda: build_reports(db_path, period_end or date.today()), self._show, self._failed)

    def _row(self, label: str, node: Node, sign_note: str = "") -> None:
        shown = Node(label, node.amount, node.children)
        iid = insert_node(self._tree, shown, open_=False)
        if sign_note:
            self._tree.set(iid, "sub", sign_note)

    def _show(self, r: Reports) -> None:
        self._subtitle.configure(text=f"{r.period_start.strftime(DATE_FMT)} to {r.period_end.strftime(DATE_FMT)} · "
                                      f"{r.voucher_count} voucher(s) · financial year to date")
        for label, key in TRADING_ROWS:
            node = r.pl[key]
            self._row(label, node, STOCK_ROWS[key] if key in STOCK_ROWS and not node.amount else "")
        gross_label = "Gross Profit" if r.gross_profit >= 0 else "Gross Loss"
        self._tree.insert("", "end", text=gross_label, values=("", money(r.gross_profit)), tags=("total",))
        for label, key in PL_ROWS:
            self._row(label, r.pl[key])
        net_label = "NET PROFIT" if r.net_profit >= 0 else "NET LOSS"
        self._tree.insert("", "end", text=net_label, values=("", money(r.net_profit)), tags=("highlight",))

        ref = []
        if r.stock_notes:
            ref.append("Stock (config/stock_valuation.py):")
            ref += [f"   {note}" for note in r.stock_notes]
        ref.append("From your other tables (cross-check only, not added to the figures above):")
        ref += [f"   {table}: {text}" for table, text in r.reference.items()]
        if r.not_grouped:
            ref.append(f"   Ledgers with no group (not in this account): "
                       f"{', '.join(n for n, _b in r.not_grouped[:8])}. Add them to config/ledger_groups.py.")
        warn = any(w in n for n in r.stock_notes for w in WARN_WORDS)
        self._reference.configure(text="\n".join(ref), fg=T.BAD_RED if warn else T.TEXT)
        self.focus_first()

    def _failed(self, exc: Exception) -> None:
        msg = str(exc) if isinstance(exc, ReportError) else f"Could not build the Profit & Loss A/c: {exc}"
        self._subtitle.configure(text=msg, fg=T.BAD_RED)

    def focus_first(self) -> None:
        self._tree.focus_set()
        kids = self._tree.get_children()
        if kids:
            self._tree.selection_set(kids[0])
            self._tree.focus(kids[0])

    def handle_key(self, event: tk.Event) -> str | None:
        if event.keysym == "Escape":
            self._on_close()
            return "break"
        if event.keysym.lower() == "c" and not event.state & (T.MOD_CTRL | T.MOD_ALT) and self._on_compare:
            self._on_compare()
            return "break"
        return None
