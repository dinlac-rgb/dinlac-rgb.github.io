"""
[S] Settings (Alt+S) — the preferences grid on the white canvas.

    Settings - Preferences          T F D K G choose   Left/Right change   R Restart   Esc Corridor
    ▌ Theme              [Pro Dark Blue] [Lite Classic] [Slate Minimal]
      Header, panels and highlight colour. The working canvas stays white.
      Font Scale         [Segoe UI 11 Normal (default)] [Segoe UI 12 High Visibility]
      Display Density    [Compact] [Comfortable]
      Keyboard Shortcuts [Standard Tally Layout] [BizPulse Express Hotkeys]
      Grid Lines         [Show Separation Lines] [Flat Canvas Sheets]
    Saved to config/settings.py · applies at the next start.            Restart now

Keys: the bold letter (T, F, D, K, G) goes to its row, and pressing it again moves to the next
option; Left / Right change the option, Up / Down move between rows, Enter or Space moves to
the next option; R restarts BizPulse so the saved choices take effect; Esc clears the canvas
and gives the keyboard back to the Corridor. A click on an option chooses it.

Every change is written at once to config/settings.py (services/preferences.py, in a
background thread). The screens already built keep their look until the next start, so a row
whose saved choice differs from what is running says "after restart".
"""
from __future__ import annotations

import tkinter as tk
from pathlib import Path
from typing import Callable

from config import settings as S
from config import theme as T
from services.background import run_in_background
from services.preferences import SETTINGS_FILE, PreferencesError, read_preferences, save_preferences
from views.masters_overlay import hotkey_labels
from views.report_common import title_bar


def _express_text() -> str:
    return "  ".join(f"{k} {n}" for k, n in S.KEYBOARD_LAYOUTS["BizPulse Express"])


# key, row name, hotkey, [(value, option label)], description
ROWS = [
    ("THEME", "Theme", "T",
     [("Pro Dark Blue", "Pro Dark Blue"), ("Lite Classic", "Lite Classic"), ("Slate Minimal", "Slate Minimal")],
     "Header, panels and highlight colour. Pro Dark Blue is the solid #0D2C54; the working canvas stays white."),
    ("FONT_SCALE", "Font Scale", "F",
     [(11, "Segoe UI 11 Normal (default)"), (12, "Segoe UI 12 High Visibility")],
     "Every label, table and menu, normal weight; shortcut letters stay bold."),
    ("ROW_DENSITY", "Display Density", "D",
     [("Compact", "Compact Layout"), ("Comfortable", "Comfortable Layout")],
     "Compact: thinner table rows and voucher grid cells, so more rows fit on screen."),
    ("KEYBOARD_LAYOUT", "Keyboard Shortcuts", "K",
     [("Standard Tally", "Standard Tally Layout"), ("BizPulse Express", "BizPulse Express Hotkeys")],
     "Voucher-type keys. Tally: F4 Contra  F5 Payment  F6 Receipt  F7 Journal  F8 Sales  F9 Purchase. "
     "Express: " + _express_text() + ". Ctrl+F8 / Ctrl+F9 stay Credit / Debit Note."),
    ("GRID_LINES", "Grid Lines", "G",
     [(True, "Show Spreadsheet Separation Lines"), (False, "Flat Canvas Sheets")],
     "Cell borders on voucher grids, column separators in table headings and banded Day Book rows."),
]


class SettingsView(tk.Frame):
    def __init__(self, parent: tk.Widget, *, on_close: Callable[[], None],
                 on_note: Callable[[str], None] | None = None,
                 on_restart: Callable[[], None] | None = None,
                 settings_path: Path = SETTINGS_FILE, running: dict | None = None) -> None:
        super().__init__(parent, bg=T.WHITE, takefocus=1)
        self._on_close, self._on_restart = on_close, on_restart
        self._on_note = on_note or (lambda _m: None)
        self._path = Path(settings_path)
        self.values = read_preferences(self._path)
        # what this run of BizPulse is using (read at start); a different saved value waits for a restart
        self._running = running if running is not None else {k: getattr(S, k) for k, *_r in ROWS}
        self._saving = False
        self._again = False
        self._row = 0
        title_bar(self, "Settings - Preferences", "T F D K G choose    Left/Right change    R Restart    Esc Corridor")

        tk.Label(self, text=f"Saved in {self._path.parent.name}/{self._path.name}; read when BizPulse starts.",
                 bg=T.WHITE, fg=T.MUTED, font=T.F_TEXT, anchor="w").pack(side="top", fill="x", padx=14, pady=(10, 4))
        grid = tk.Frame(self, bg=T.WHITE)
        grid.pack(side="top", fill="x", padx=14)
        grid.columnconfigure(2, weight=1)
        self._rows: list[dict] = []
        for i, (key, name, letter, options, about) in enumerate(ROWS):
            marker = tk.Frame(grid, bg=T.WHITE, width=4)
            marker.grid(row=i * 2, column=0, rowspan=2, sticky="ns", padx=(0, 10), pady=(8, 0))
            head = tk.Frame(grid, bg=T.WHITE, width=190, height=34)
            head.grid(row=i * 2, column=1, sticky="w", pady=(8, 0))
            head.pack_propagate(False)
            for lbl in hotkey_labels(head, name, letter, T.WHITE, T.TEXT):
                lbl.bind("<Button-1>", lambda _e, r=i: self.select_row(r))
            chips_box = tk.Frame(grid, bg=T.WHITE)
            chips_box.grid(row=i * 2, column=2, sticky="w", pady=(8, 0))
            chips = []
            for value, text in options:
                chip = tk.Label(chips_box, text=text, font=T.F_TEXT, padx=10, pady=3, cursor="hand2",
                                highlightthickness=1, highlightbackground=T.BORDER)
                chip.pack(side="left", padx=(0, 6))
                chip.bind("<Button-1>", lambda _e, r=i, v=value: (self.select_row(r), self.choose(v)))
                chips.append((value, chip))
            pending = tk.Label(chips_box, bg=T.WHITE, fg=T.ORANGE, font=T.F_TEXT, padx=6)
            pending.pack(side="left")
            tk.Label(grid, text=about, bg=T.WHITE, fg=T.MUTED, font=T.F_TEXT, anchor="w", justify="left",
                     wraplength=700).grid(row=i * 2 + 1, column=1, columnspan=2, sticky="w", pady=(0, 4))
            self._rows.append({"key": key, "letter": letter.lower(), "options": options, "chips": chips,
                               "marker": marker, "pending": pending})

        foot = tk.Frame(self, bg=T.WHITE)
        foot.pack(side="top", fill="x", padx=14, pady=(14, 0))
        self._status = tk.Label(foot, bg=T.WHITE, fg=T.MUTED, font=T.F_TEXT, anchor="w", justify="left",
                                wraplength=640)
        self._status.pack(side="left", fill="x", expand=True)
        if on_restart is not None:
            link = tk.Frame(foot, bg=T.LIGHT_BLUE, cursor="hand2", highlightthickness=1, highlightbackground=T.LINE)
            link.pack(side="right")
            for w in (link, *hotkey_labels(link, "Restart now", "R", T.LIGHT_BLUE, T.NAVY, first_padx=8)):
                w.bind("<Button-1>", lambda _e: self.restart())
            tk.Frame(link, bg=T.LIGHT_BLUE, width=8).pack(side="left")
        self._draw()
        self._say("Choose with the bold letters or the arrow keys; each choice is saved at once.")

    # ---- drawing -------------------------------------------------------------------------
    def _draw(self) -> None:
        for i, row in enumerate(self._rows):
            current = self.values[row["key"]]
            row["marker"].configure(bg=T.ORANGE if i == self._row else T.WHITE)
            for value, chip in row["chips"]:
                on = value == current and type(value) is type(current)
                chip.configure(bg=T.ORANGE if on else (T.LIGHT_BLUE if i == self._row else T.WHITE),
                               fg=T.TEXT_DARK if on else T.TEXT)
            waiting = current != self._running.get(row["key"])
            row["pending"].configure(text="after restart" if waiting else "")

    def _say(self, text: str, error: bool = False) -> None:
        self._status.configure(text=text, fg=T.BAD_RED if error else T.MUTED)

    # ---- choosing ------------------------------------------------------------------------
    @property
    def current_row(self) -> str:
        return self._rows[self._row]["key"]

    def select_row(self, index: int) -> None:
        self._row = max(0, min(index, len(self._rows) - 1))
        self._draw()

    def step(self, delta: int) -> None:
        """Left / Right (or the row letter again): the previous / next option of the current row."""
        row = self._rows[self._row]
        values = [v for v, _t in row["options"]]
        current = self.values[row["key"]]
        idx = next((i for i, v in enumerate(values) if v == current and type(v) is type(current)), 0)
        self.choose(values[(idx + delta) % len(values)])

    def choose(self, value) -> None:
        row = self._rows[self._row]
        if self.values[row["key"]] == value and type(self.values[row["key"]]) is type(value):
            return
        self.values = dict(self.values, **{row["key"]: value})
        self._draw()
        self._save()

    def _save(self) -> None:
        if self._saving:                      # one write at a time; the newest choices follow
            self._again = True
            return
        self._saving = True
        values, path = dict(self.values), self._path
        run_in_background(self, lambda: save_preferences(values, path), lambda _p: self._saved(values),
                          self._failed)

    def _saved(self, values: dict) -> None:
        self._saving = False
        if self._again:
            self._again = False
            self._save()
            return
        changed = [f"{name}: {dict((v, t) for v, t in opts)[values[key]]}"
                   for key, name, _l, opts, _a in ROWS if values[key] != self._running.get(key)]
        if changed:
            self._say(f"Saved to config/settings.py. Waiting for a restart: {'; '.join(changed)}. "
                      "R restarts BizPulse now.")
        else:
            self._say("Saved to config/settings.py. Matches what is running now.")
        row = next(r for r in ROWS if r[0] == self.current_row)
        self._on_note(f"[Settings] {row[1]}: {dict(row[3])[values[row[0]]]} saved to config/settings.py "
                      f"(applies at the next start).")

    def _failed(self, exc: Exception) -> None:
        self._saving = False
        self._again = False
        self.values = read_preferences(self._path)          # show what the file really holds
        self._draw()
        msg = str(exc) if isinstance(exc, PreferencesError) else f"Not saved: {exc}"
        self._say(msg, error=True)
        self._on_note(f"[Settings] {msg}")

    def restart(self) -> None:
        if self._saving:
            self._say("Still saving; press R again in a moment.")
            return
        if self._on_restart is not None:
            self._on_restart()

    # ---- keys ----------------------------------------------------------------------------
    def focus_first(self) -> None:
        self.focus_set()

    def handle_key(self, event: tk.Event) -> str | None:
        if event.keysym == "Escape":
            self._on_close()
            return "break"
        if event.state & (T.MOD_CTRL | T.MOD_ALT):
            return None
        key = event.keysym
        if key in ("Up", "Down"):
            self.select_row(self._row + (-1 if key == "Up" else 1))
            return "break"
        if key in ("Left", "Right"):
            self.step(-1 if key == "Left" else 1)
            return "break"
        if key in ("Return", "KP_Enter", "space"):
            self.step(1)
            return "break"
        letter = key.lower()
        if letter == "r":
            self.restart()
            return "break"
        for i, row in enumerate(self._rows):
            if row["letter"] == letter:
                if i == self._row:
                    self.step(1)
                else:
                    self.select_row(i)
                return "break"
        return None
