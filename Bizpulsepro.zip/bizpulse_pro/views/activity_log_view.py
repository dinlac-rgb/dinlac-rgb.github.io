"""
Session Messages (Help › Session Messages, F1 then M) — every status message of this session.
(Help › Activity Log, F1 then G, is the audit trail: views/audit_trail_view.py.)

The window has no log panel any more (the left side stays a clean canvas); the status bar at
the bottom shows the latest message, and this screen shows all of them, newest at the bottom,
updating live while it is open.

Keys: Up / Down / Page Up / Page Down scroll, Esc back.
"""
from __future__ import annotations

import tkinter as tk
from typing import Callable

from components.subsystem_monitor import SubsystemMonitor
from config import theme as T
from views.report_common import title_bar


class ActivityLogView(tk.Frame):
    def __init__(self, parent: tk.Widget, *, monitor: SubsystemMonitor, on_close: Callable[[], None]) -> None:
        super().__init__(parent, bg=T.WHITE)
        self._on_close = on_close
        title_bar(self, "Session Messages")
        box = tk.Frame(self, bg=T.WHITE, highlightthickness=1, highlightbackground=T.BORDER)
        box.pack(side="top", fill="both", expand=True, padx=14, pady=10)
        sb = tk.Scrollbar(box, orient="vertical")
        sb.pack(side="right", fill="y")
        self._text = tk.Text(box, bg=T.WHITE, fg=T.TEXT, font=T.F_LOG, wrap="word", relief="flat", bd=0,
                             padx=10, pady=8, yscrollcommand=sb.set)
        self._text.pack(side="left", fill="both", expand=True)
        sb.configure(command=self._text.yview)
        self._append(monitor.text())
        self._unsubscribe = monitor.subscribe(lambda line: self._append(line + "\n"))
        self._text.bind("<Key>", self._read_only)
        self.bind("<Destroy>", lambda e: self._unsubscribe() if e.widget is self else None)

    def _append(self, text: str) -> None:
        self._text.insert("end", text)
        self._text.see("end")

    @staticmethod
    def _read_only(event: tk.Event) -> str | None:
        nav = {"Up", "Down", "Prior", "Next", "Home", "End", "Left", "Right", "Escape"}
        ctrl_copy = event.state & T.MOD_CTRL and event.keysym.lower() in ("c", "a")
        return None if event.keysym in nav or ctrl_copy else "break"

    def focus_first(self) -> None:
        self._text.focus_set()

    def handle_key(self, event: tk.Event) -> str | None:
        if event.keysym == "Escape":
            self._on_close()
            return "break"
        return None
