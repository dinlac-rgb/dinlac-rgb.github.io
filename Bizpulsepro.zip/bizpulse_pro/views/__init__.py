"""Screens drawn over the workspace: List of Masters, Accounting Voucher, Day Book."""
