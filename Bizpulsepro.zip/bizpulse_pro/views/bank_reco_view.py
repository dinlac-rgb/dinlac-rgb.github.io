"""
Banking › Imported Bank Data — the bank reconciliation helper, side by side on the canvas.

    Bank ledger [HDFC Bank      ]   Statement: hdfc_oct.csv           O Open statement   M Match Entries
    +--------- Bank Book (BizPulse) ----------+  +-------- Bank Statement (file) ---------+
    | Date | Particulars | Vch | In | Out | ✓ |  | Date | Description | In | Out | ✓       |
    +-----------------------------------------+  +-----------------------------------------+
    12 matched · 3 left in the book (₹ …) · 2 left on the statement (₹ …)

Keys: type the bank ledger (the list on the right helps) and Enter; O opens a statement file
(CSV); M matches entries with the same date and amount and records each pair in the audit trail
(bp_bank_reconciliation, also written to the Activity Log); Esc goes back. Matched rows turn
green on both sides; entries matched earlier stay green. Everything that reads or writes the
database runs in a background thread (services/bank_reco.py).
"""
from __future__ import annotations

import tkinter as tk
from decimal import Decimal
from pathlib import Path
from tkinter import filedialog, ttk
from typing import Callable

from components.ledger_list import LedgerListPanel
from config import theme as T
from services import bank_reco as B
from services.background import run_in_background
from views.masters_overlay import hotkey_labels
from views.report_common import title_bar
from views.vouchers_view import DATE_FMT, fmt_inr

MATCHED = "#E3F4E8"


class BankRecoView(tk.Frame):
    def __init__(self, parent: tk.Widget, *, db_path: Path, on_close: Callable[[], None],
                 on_note: Callable[[str], None] | None = None, ledger: str = "") -> None:
        super().__init__(parent, bg=T.WHITE)
        self._db, self._on_close = db_path, on_close
        self._on_note = on_note or (lambda _m: None)
        self._ledger_name = ""
        self._book: list[B.BookEntry] = []
        self._statement: B.Statement | None = None
        self._file = ""
        title_bar(self, "Imported Bank Data - Bank Reconciliation", "O Open    M Match    Esc Back")

        top = tk.Frame(self, bg=T.WHITE)
        top.pack(side="top", fill="x", padx=14, pady=(8, 4))
        tk.Label(top, text="Bank ledger", bg=T.WHITE, fg=T.TEXT, font=T.F_TEXT).pack(side="left")
        self._ledger = tk.Entry(top, width=24, font=T.F_TEXT, relief="flat", bd=0, highlightthickness=1,
                                highlightbackground=T.LINE, highlightcolor=T.ORANGE)
        self._ledger.pack(side="left", padx=8, ipady=3)
        self._file_lbl = tk.Label(top, text="Statement: none opened", bg=T.WHITE, fg=T.MUTED, font=T.F_TEXT)
        self._file_lbl.pack(side="left", padx=10)
        for label, key, command in (("Match Entries", "M", self.match), ("Open statement", "O", self.open_file)):
            link = tk.Frame(top, bg=T.LIGHT_BLUE, cursor="hand2", highlightthickness=1, highlightbackground=T.LINE)
            link.pack(side="right", padx=(6, 0))
            parts = hotkey_labels(link, label, key, T.LIGHT_BLUE, T.NAVY, first_padx=8)
            tk.Frame(link, bg=T.LIGHT_BLUE, width=8).pack(side="left")
            for w in (link, *parts):
                w.bind("<Button-1>", lambda _e, c=command: c())

        body = tk.Frame(self, bg=T.WHITE)
        body.pack(side="top", fill="both", expand=True, padx=14)
        self._list = LedgerListPanel(body, on_pick=self._picked)
        grids = tk.Frame(body, bg=T.WHITE)
        grids.pack(side="left", fill="both", expand=True)
        self._list.pack_before = grids
        grids.columnconfigure(0, weight=1, uniform="half")
        grids.columnconfigure(1, weight=1, uniform="half")
        grids.rowconfigure(1, weight=1)
        self._book_tree = self._grid(grids, 0, "Bank Book (BizPulse)",
                                     (("date", "Date", 84), ("part", "Particulars", 110), ("in", "In", 88),
                                      ("out", "Out", 88), ("ok", "", 22)))
        self._stmt_tree = self._grid(grids, 1, "Bank Statement (file)",
                                     (("date", "Date", 84), ("desc", "Description", 110), ("in", "In", 88),
                                      ("out", "Out", 88), ("ok", "", 22)))
        self._summary = tk.Label(self, bg=T.WHITE, fg=T.MUTED, font=T.F_TEXT, anchor="w", justify="left",
                                 wraplength=880)
        self._summary.pack(side="top", fill="x", padx=14, pady=(6, 10))

        self._ledger.bind("<FocusIn>", lambda _e: self._list.show(text=self._ledger.get()), add="+")
        self._ledger.bind("<KeyRelease>", lambda e: self._list.filter(self._ledger.get())
                          if e.keysym not in ("Up", "Down", "Return", "Escape") else None, add="+")
        run_in_background(self, lambda: B.bank_ledgers(db_path),
                          lambda names: self._list.set_catalogue([("Bank ledgers", names)] if names else []),
                          lambda exc: self._say(f"Bank ledgers not loaded: {exc}", True))
        self._list.set_title("Bank Ledgers")
        if ledger:
            self._picked(ledger)

    def _grid(self, parent: tk.Widget, col: int, heading: str, columns) -> ttk.Treeview:
        pad = (0, 6) if col == 0 else (6, 0)
        tk.Label(parent, text=heading, bg=T.WHITE, fg=T.NAVY, font=T.F_TEXT, anchor="w").grid(
            row=0, column=col, sticky="ew", padx=pad, pady=(4, 2))
        box = tk.Frame(parent, bg=T.WHITE, highlightthickness=1, highlightbackground=T.BORDER)
        box.grid(row=1, column=col, sticky="nsew", padx=pad)
        tree = ttk.Treeview(box, columns=[c[0] for c in columns], show="headings", style="BizPulse.Treeview",
                            selectmode="browse")
        for key, head, width in columns:
            tree.heading(key, text=head, anchor="e" if key in ("in", "out") else "w")
            tree.column(key, width=width, minwidth=24, anchor="e" if key in ("in", "out") else "w",
                        stretch=key in ("part", "desc"))
        tree.tag_configure("matched", background=MATCHED)
        sb = ttk.Scrollbar(box, orient="vertical", command=tree.yview)
        tree.configure(yscrollcommand=sb.set)
        sb.pack(side="right", fill="y")
        tree.pack(side="left", fill="both", expand=True)
        return tree

    # ---- loading -------------------------------------------------------------------------
    def _picked(self, name: str) -> None:
        self._ledger.delete(0, "end")
        self._ledger.insert(0, name)
        self._list.hide()
        self._ledger_name = name
        self._say("Loading the bank book…")
        run_in_background(self, lambda: (B.bank_book(self._db, name), B.reconciled_trail(self._db, name)),
                          self._book_loaded, lambda exc: self._say(f"Bank book not loaded: {exc}", True))

    def _book_loaded(self, result) -> None:
        self._book, self._trail = result
        if self._statement is not None:
            for r in self._statement.rows:
                r.matched = False
            B.mark_previous(self._statement, self._trail)
        self._redraw()
        self._book_tree.focus_set()

    def open_file(self, path: str | None = None) -> None:
        """O: choose the bank's statement file (CSV)."""
        if path is None:
            path = filedialog.askopenfilename(parent=self, title="Bank statement (CSV)",
                                              filetypes=[("Statement files", "*.csv *.txt"), ("All files", "*.*")])
        if not path:
            return
        self._say(f"Reading {Path(path).name}…")
        run_in_background(self, lambda: B.read_statement(Path(path)), lambda st: self._statement_loaded(path, st),
                          lambda exc: self._say(str(exc), True))

    def _statement_loaded(self, path: str, st: B.Statement) -> None:
        self._statement, self._file = st, Path(path).name
        self._file_lbl.configure(text=f"Statement: {self._file} ({len(st.rows)} lines)", fg=T.TEXT)
        B.mark_previous(st, getattr(self, "_trail", []))
        self._redraw()

    # ---- matching ------------------------------------------------------------------------
    def match(self) -> None:
        """M: pair entries with the same date and amount, and record the pairs."""
        if not self._ledger_name:
            self._say("Choose the bank ledger first.", True)
            return
        if self._statement is None:
            self._say("Open the bank statement first (O).", True)
            return
        pairs = B.match(self._book, self._statement)
        if not pairs:
            self._say("No new pairs: nothing left with the same date and amount on both sides.")
            return
        ledger, file_name = self._ledger_name, self._file
        self._say(f"Recording {len(pairs)} match(es)…")
        run_in_background(self, lambda: B.record_matches(self._db, ledger, pairs, file_name),
                          lambda n: self._matched(pairs, n), lambda exc: self._say(str(exc), True))

    def _matched(self, pairs, recorded: int) -> None:
        for entry, row in pairs:
            entry.matched = row.matched = True
            self._on_note(f"[Bank reconciliation] {self._ledger_name}: {entry.vtype} No. {entry.number} of "
                          f"{entry.date.strftime(DATE_FMT)} ({fmt_inr(abs(entry.amount))} "
                          f"{'in' if entry.amount > 0 else 'out'}) matched statement line {row.line} "
                          f"“{row.description}” in {self._file}.")
        self._redraw(f"{recorded} pair(s) matched and recorded in the audit trail. ")

    # ---- drawing -------------------------------------------------------------------------
    def _redraw(self, prefix: str = "") -> None:
        for tree in (self._book_tree, self._stmt_tree):
            tree.delete(*tree.get_children())
        for e in self._book:
            self._book_tree.insert("", "end", tags=("matched",) if e.matched else (), values=(
                e.date.strftime(DATE_FMT), f"{e.particulars} ({e.vtype} {e.number})",
                fmt_inr(e.amount) if e.amount > 0 else "", fmt_inr(-e.amount) if e.amount < 0 else "",
                "✓" if e.matched else ""))
        rows = self._statement.rows if self._statement else []
        for r in rows:
            self._stmt_tree.insert("", "end", tags=("matched",) if r.matched else (), values=(
                r.date.strftime(DATE_FMT), r.description, fmt_inr(r.amount) if r.amount > 0 else "",
                fmt_inr(-r.amount) if r.amount < 0 else "", "✓" if r.matched else ""))
        left_book = [e for e in self._book if not e.matched]
        left_stmt = [r for r in rows if not r.matched]
        net = lambda xs: sum((x.amount for x in xs), Decimal("0"))  # noqa: E731
        text = (f"{prefix}{sum(1 for e in self._book if e.matched)} matched · "
                f"{len(left_book)} left in the bank book (net {fmt_inr(net(left_book))}) · "
                f"{len(left_stmt)} left on the statement (net {fmt_inr(net(left_stmt))})")
        if self._statement and self._statement.notes:
            text += "\n" + " ".join(self._statement.notes)
        self._say(text)

    def _say(self, text: str, error: bool = False) -> None:
        self._summary.configure(text=text, fg=T.BAD_RED if error else T.MUTED)

    # ---- keys --------------------------------------------------------------------------
    def focus_first(self) -> None:
        self._ledger.focus_set() if not self._ledger_name else self._book_tree.focus_set()

    def handle_key(self, event: tk.Event) -> str | None:
        if event.state & (T.MOD_CTRL | T.MOD_ALT):
            return None
        if event.keysym == "Escape":
            self._on_close()
            return "break"
        if event.widget is self._ledger:
            if event.keysym in ("Up", "Down") and self._list.visible:
                self._list.move(-1 if event.keysym == "Up" else 1)
                return "break"
            if event.keysym in ("Return", "KP_Enter", "Tab"):
                name = self._list.choice(self._ledger.get()) or self._ledger.get().strip()
                if name:
                    self._picked(name)
                return "break"
            return None
        if event.keysym.lower() == "m":
            self.match()
            return "break"
        if event.keysym.lower() == "o":
            self.open_file()
            return "break"
        return None
