"""
Trial Balance — every ledger's closing balance, Debit | Credit, grouped by primary group.

    Balance Sheet ledgers: balance to date (opening balances included)
    Profit & Loss ledgers: this financial year
    Profit & Loss A/c:     profit brought forward from earlier years (so the columns agree)
    Difference in opening balances / Not grouped: shown when they exist, as in Tally

Drill-down: Enter or a double-click on a ledger opens its Ledger Statement; there, Enter or a
double-click on a voucher opens it in Accounting Voucher Alteration. Esc steps back one level
each time (voucher -> statement -> Trial Balance -> Corridor).
Figures: services/reports.py, loaded in a background thread. Optional vouchers are left out.
"""
from __future__ import annotations

import tkinter as tk
from datetime import date
from decimal import Decimal
from pathlib import Path
from tkinter import ttk
from typing import Callable

from config import theme as T
from services.background import run_in_background
from services.reports import NOT_GROUPED, OPENING_DIFFERENCE, SUBGROUP_OF, ReportError, Reports, build_reports
from views.report_common import title_bar
from views.vouchers_view import DATE_FMT, fmt_inr

ORDER = ["Capital Account", "Loans (Liability)", "Current Liabilities", "Branch / Divisions", "Suspense A/c",
         "Fixed Assets", "Investments", "Current Assets", "Misc. Expenses (ASSET)", "Sales Accounts",
         "Purchase Accounts", "Direct Incomes", "Direct Expenses", "Indirect Incomes", "Indirect Expenses", NOT_GROUPED]
ZERO = Decimal("0.00")


def drcr(value: Decimal) -> tuple[str, str]:
    return (fmt_inr(value), "") if value > 0 else ("", fmt_inr(-value)) if value < 0 else ("", "")


class TrialBalanceView(tk.Frame):
    def __init__(self, parent: tk.Widget, *, db_path: Path, company: str, on_close: Callable[[], None],
                 on_open_ledger: Callable[[str], None] | None = None, upto: date | None = None) -> None:
        super().__init__(parent, bg=T.WHITE)
        self._on_close, self._on_open_ledger = on_close, on_open_ledger
        title_bar(self, f"Trial Balance - {company.upper()}", "Enter open ledger    Esc Back")
        self._subtitle = tk.Label(self, text="Loading…", bg=T.WHITE, fg=T.MUTED, font=T.F_LABEL, anchor="w")
        self._subtitle.pack(side="top", fill="x", padx=14, pady=(8, 4))
        box = tk.Frame(self, bg=T.WHITE, highlightthickness=1, highlightbackground=T.BORDER)
        box.pack(side="top", fill="both", expand=True, padx=14)
        self._tree = ttk.Treeview(box, columns=("dr", "cr"), show="tree headings", style="BizPulse.Treeview",
                                  selectmode="browse")
        self._tree.heading("#0", text="Particulars", anchor="w")
        self._tree.heading("dr", text="Debit", anchor="e")
        self._tree.heading("cr", text="Credit", anchor="e")
        self._tree.column("#0", width=380, stretch=True)
        for c in ("dr", "cr"):
            self._tree.column(c, width=160, minwidth=140, anchor="e", stretch=False)
        self._tree.tag_configure("group", foreground=T.NAVY)
        self._tree.tag_configure("ledger", foreground=T.TEXT)
        self._tree.tag_configure("warn", foreground=T.BAD_RED)
        sb = ttk.Scrollbar(box, orient="vertical", command=self._tree.yview)
        self._tree.configure(yscrollcommand=sb.set)
        sb.pack(side="right", fill="y")
        self._tree.pack(side="left", fill="both", expand=True)
        self._tree.bind("<Double-Button-1>", lambda e: self.open_row(self._tree.identify_row(e.y)))
        totals = tk.Frame(self, bg=T.LIGHT_BLUE, highlightthickness=1, highlightbackground=T.NAVY)
        totals.pack(side="top", fill="x", padx=14, pady=(6, 10))
        tk.Label(totals, text="Grand Total", bg=T.LIGHT_BLUE, fg=T.NAVY, font=T.F_TEXT, padx=10, pady=6).pack(side="left")
        self._cr_total = tk.Label(totals, bg=T.LIGHT_BLUE, fg=T.NAVY, font=T.F_TEXT, width=16, anchor="e", padx=6)
        self._cr_total.pack(side="right", padx=(0, 18))
        self._dr_total = tk.Label(totals, bg=T.LIGHT_BLUE, fg=T.NAVY, font=T.F_TEXT, width=16, anchor="e", padx=6)
        self._dr_total.pack(side="right")
        self._guard = tk.Label(self, bg=T.WHITE, fg=T.BAD_RED, font=T.F_TEXT, anchor="w")
        self._guard.pack(side="top", fill="x", padx=14, pady=(0, 10))
        self._ledger_rows: dict[str, str] = {}          # tree iid -> ledger name
        run_in_background(self, lambda: build_reports(db_path, upto or date.today()), self._show, self._failed)

    def _show(self, r: Reports) -> None:
        self._subtitle.configure(text=f"{r.period_start.strftime(DATE_FMT)} to {r.period_end.strftime(DATE_FMT)} · "
                                      "Profit & Loss ledgers for the year, the rest to date · Enter on a ledger opens it")
        by_group: dict[str, list[tuple[str, Decimal]]] = {}
        for ledger, bal in r.tb_balances.items():
            grp = r.tb_groups.get(ledger, NOT_GROUPED)
            primary = SUBGROUP_OF.get(grp, grp)
            by_group.setdefault(primary, []).append((ledger, bal))
        dr_total = cr_total = ZERO
        for primary in ORDER + sorted(g for g in by_group if g not in ORDER):
            rows = by_group.get(primary)
            if not rows:
                continue
            total = sum((b for _l, b in rows), ZERO)
            gid = self._tree.insert("", "end", text=primary, values=drcr(total), open=True,
                                    tags=("warn" if primary == NOT_GROUPED else "group",))
            for ledger, bal in sorted(rows, key=lambda t: t[0].lower()):
                iid = self._tree.insert(gid, "end", text=ledger, values=drcr(bal), tags=("ledger",))
                self._ledger_rows[iid] = ledger
            dr_total += sum((b for _l, b in rows if b > 0), ZERO)
            cr_total += sum((-b for _l, b in rows if b < 0), ZERO)
        if r.profit_before_vouchers:
            value = -r.profit_before_vouchers                 # profit is a credit
            self._tree.insert("", "end", text="Profit & Loss A/c (brought forward)", values=drcr(value), tags=("group",))
            dr_total, cr_total = dr_total + max(value, ZERO), cr_total + max(-value, ZERO)
        if r.opening_difference:
            value = -r.opening_difference
            self._tree.insert("", "end", text=OPENING_DIFFERENCE, values=drcr(value), tags=("warn",))
            dr_total, cr_total = dr_total + max(value, ZERO), cr_total + max(-value, ZERO)
        self._dr_total.configure(text=fmt_inr(dr_total))
        self._cr_total.configure(text=fmt_inr(cr_total), fg=T.NAVY if dr_total == cr_total else T.BAD_RED)
        # Statutory guard: the openings (and the columns) must agree.
        lines = []
        if r.opening_difference:
            lines.append(f"Difference in Opening Balances: ₹{fmt_inr(abs(r.opening_difference))}")
        if dr_total != cr_total:
            lines.append(f"Debit and Credit totals differ by ₹{fmt_inr(abs(dr_total - cr_total))}")
        self._guard.configure(text="    ".join(lines))
        self.focus_first()

    def _failed(self, exc: Exception) -> None:
        self._subtitle.configure(text=str(exc) if isinstance(exc, ReportError) else f"Could not build it: {exc}",
                                 fg=T.BAD_RED)

    def open_row(self, iid: str) -> None:
        if iid in self._ledger_rows and self._on_open_ledger is not None:
            self._on_open_ledger(self._ledger_rows[iid])

    def focus_first(self) -> None:
        self._tree.focus_set()
        kids = self._tree.get_children()
        if kids and not self._tree.selection():
            first = self._tree.get_children(kids[0]) or kids
            self._tree.selection_set(first[0])
            self._tree.focus(first[0])

    def handle_key(self, event: tk.Event) -> str | None:
        if event.keysym == "Escape":
            self._on_close()
            return "break"
        if event.keysym in ("Return", "KP_Enter"):
            sel = self._tree.selection()
            if sel:
                self.open_row(sel[0])
            return "break"
        return None
