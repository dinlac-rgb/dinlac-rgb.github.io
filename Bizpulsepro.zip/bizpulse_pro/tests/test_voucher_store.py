"""
Tests for saving vouchers. Uses a throw-away copy of the bizpulse_local.db layout in a temp
folder (your real database is never touched).  Run from the bizpulse_pro folder:

    python -m unittest discover -s tests -v
"""
from __future__ import annotations

import sqlite3
import sys
import tempfile
import time
import unittest
from datetime import date, datetime
from decimal import Decimal as D
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from services.gst import (check_gstin, check_hsn, check_state_code, financial_year_label,  # noqa: E402
                          invoice_number, split_tax, tax_for)
from services.migrations import ensure_igst_column  # noqa: E402
from services.voucher_store import StoreError, VoucherStore  # noqa: E402

SCHEMA = """
CREATE TABLE gst_sales_ledger (invoice_no TEXT PRIMARY KEY, customer_name TEXT, customer_gstin TEXT,
    hsn_code TEXT, taxable_value REAL, cgst_rate REAL, sgst_rate REAL);
CREATE TABLE workforce_payroll (emp_id TEXT PRIMARY KEY, emp_name_role TEXT, gross_pay REAL,
    provident_fund REAL, tax_deduction REAL);
CREATE TABLE inventory_stock_registry (product_sku TEXT PRIMARY KEY, qty_on_hand INTEGER,
    min_safety_floor INTEGER, last_audit_date TEXT);
CREATE TABLE corporate_ledger_summary (account_id TEXT PRIMARY KEY, account_name TEXT,
    outstanding_balance REAL, credit_ceiling REAL);
INSERT INTO corporate_ledger_summary VALUES ('C001', 'Gupta Stores', 40000.0, 50000.0);
INSERT INTO corporate_ledger_summary VALUES ('C002', 'Bose & Sons', 0.0, 0.0);
INSERT INTO workforce_payroll VALUES ('E1', 'Ravi - Clerk', 18000, 2160, 0);
"""
GSTIN = "27AAPFU0939F1ZV"   # well-known valid sample GSTIN


def voucher(vtype: str, lines: list[tuple[str, str, str]], gst: dict | None = None, d: date = date(2026, 10, 9)) -> dict:
    ls = [{"side": s, "ledger": l, "amount": D(a)} for s, l, a in lines]
    return {"type": vtype, "date": d, "lines": ls, "narration": "test",
            "total": sum((x["amount"] for x in ls if x["side"] == "Dr"), D("0")),
            "entered_at": datetime(2026, 10, 9, 11, 0, 0), "gst": gst}


def sales(customer: str = "Gupta Stores", taxable: str = "10000", rate: str = "18", gstin: str = "",
          pos: str = "19") -> dict:
    t = D(taxable)
    tax = tax_for(t, D(rate), pos, "19")
    total = t + tax["cgst"] + tax["sgst"] + tax["igst"]
    lines = [("Dr", customer, str(total)), ("Cr", "Sales", str(t))]
    for name, key in (("Output CGST", "cgst"), ("Output SGST", "sgst"), ("Output IGST", "igst")):
        if tax[key]:
            lines.append(("Cr", name, str(tax[key])))
    return voucher("Sales", lines, gst={"customer": customer, "gstin": gstin, "place_of_supply": pos, "hsn": "8471",
                                        "rate": D(rate), "taxable": t, **tax, "invoice_value": total})


class GstHelpers(unittest.TestCase):
    def test_gstin(self):
        self.assertEqual(check_gstin(GSTIN.lower()), GSTIN)
        self.assertEqual(check_gstin("  "), "")
        with self.assertRaises(ValueError):
            check_gstin(GSTIN[:-1] + ("W" if GSTIN[-1] != "W" else "X"))   # wrong check character

    def test_hsn_and_invoice(self):
        self.assertEqual(check_hsn("8471"), "8471")
        with self.assertRaises(ValueError):
            check_hsn("847")
        self.assertEqual(financial_year_label(date(2027, 3, 31)), "26-27")
        self.assertEqual(financial_year_label(date(2027, 4, 1)), "27-28")
        self.assertEqual(invoice_number("SRJ", date(2026, 10, 9), 1), "SRJ/26-27/0001")
        self.assertEqual(split_tax(D("999.99"), D("18")), (D("90.00"), D("90.00")))

    def test_place_of_supply(self):
        self.assertEqual(check_state_code("9"), "09")
        self.assertEqual(check_state_code("97"), "97")
        with self.assertRaises(ValueError):
            check_state_code("39")
        intra = tax_for(D("10000"), D("18"), "19", "19")
        self.assertEqual((intra["cgst"], intra["sgst"], intra["igst"]), (D("900.00"), D("900.00"), D("0.00")))
        inter = tax_for(D("10000"), D("18"), "27", "19")
        self.assertEqual((inter["cgst"], inter["sgst"], inter["igst"], inter["igst_rate"]),
                         (D("0.00"), D("0.00"), D("1800.00"), D("18")))


class VoucherStoreTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.db = Path(self.tmp.name) / "bizpulse_local.db"
        con = sqlite3.connect(self.db)
        con.executescript(SCHEMA)        # your original layout: no igst_rate
        con.execute("INSERT INTO gst_sales_ledger VALUES ('OLD/25-26/0001', 'Old Customer', NULL, '8471', 100.0, 9.0, 9.0)")
        con.commit()
        con.close()
        self.upgrade_message = ensure_igst_column(self.db)
        self.store = VoucherStore(self.db, "SRJ")

    def tearDown(self):
        self.tmp.cleanup()

    def q(self, sql, *args):
        con = sqlite3.connect(self.db)
        try:
            return con.execute(sql, args).fetchall()
        finally:
            con.close()

    def test_igst_upgrade(self):
        self.assertIn("Added igst_rate", self.upgrade_message)
        self.assertEqual(self.q("SELECT invoice_no, igst_rate FROM gst_sales_ledger"), [("OLD/25-26/0001", 0.0)])
        copies = list(Path(self.tmp.name).glob("bizpulse_local.pre-upgrade-*.db"))
        self.assertEqual(len(copies), 1)
        old = sqlite3.connect(copies[0])
        try:   # the safety copy is the database exactly as it was: no igst_rate yet
            self.assertNotIn("igst_rate", [r[1] for r in old.execute("PRAGMA table_info(gst_sales_ledger)")])
        finally:
            old.close()
        self.assertIn("up to date", ensure_igst_column(self.db))     # second run: no change
        self.assertEqual(len(list(Path(self.tmp.name).glob("bizpulse_local.pre-upgrade-*.db"))), 1)
        # place_of_supply: the old unregistered, CGST+SGST row is intra-state, so West Bengal (19)
        self.assertEqual(self.q("SELECT place_of_supply FROM gst_sales_ledger"), [("19",)])

    def test_place_of_supply_backfill(self):
        tmp = Path(self.tmp.name) / "old.db"
        con = sqlite3.connect(tmp)
        con.executescript(SCHEMA)
        con.executemany("INSERT INTO gst_sales_ledger VALUES (?, ?, ?, '8471', 100.0, ?, ?)", [
            ("A1", "Registered MH", "27AAPFU0939F1ZV", 0.0, 0.0),     # GSTIN -> 27
            ("A2", "Walk-in WB", None, 9.0, 9.0),                     # no GSTIN, CGST+SGST -> 19
        ])
        con.commit()
        con.close()
        from services.migrations import upgrade_database
        upgrade_database(tmp, "19")
        con = sqlite3.connect(tmp)
        con.execute("UPDATE gst_sales_ledger SET igst_rate = 18 WHERE invoice_no = 'A1'")
        con.execute("INSERT INTO gst_sales_ledger (invoice_no, customer_name, hsn_code, taxable_value, cgst_rate, "
                    "sgst_rate, igst_rate) VALUES ('A3', 'Walk-in other state', '8471', 1, 0, 0, 18)")
        rows = dict(con.execute("SELECT invoice_no, place_of_supply FROM gst_sales_ledger").fetchall())
        con.close()
        self.assertEqual(rows, {"A1": "27", "A2": "19", "A3": None})

    def test_sales_refused_without_upgrade(self):
        con = sqlite3.connect(self.db)
        con.executescript("DROP TABLE gst_sales_ledger; CREATE TABLE gst_sales_ledger (invoice_no TEXT PRIMARY KEY, "
                          "customer_name TEXT, customer_gstin TEXT, hsn_code TEXT, taxable_value REAL, "
                          "cgst_rate REAL, sgst_rate REAL);")
        con.close()
        with self.assertRaises(StoreError) as cm:
            self.store.save(sales())
        self.assertIn("igst_rate", str(cm.exception))

    def test_inter_state_sale_uses_igst(self):
        r = self.store.save(sales(customer="Bose & Sons", gstin=GSTIN, pos="27"))
        self.assertEqual(self.q("SELECT customer_gstin, cgst_rate, sgst_rate, igst_rate, place_of_supply FROM "
                                "gst_sales_ledger WHERE invoice_no = ?", r.invoice_no), [(GSTIN, 0.0, 0.0, 18.0, "27")])
        self.assertEqual(self.q("SELECT total_paise FROM bp_vouchers"), [(1180000,)])

    def test_payment_saves_voucher_and_lines_only(self):
        r = self.store.save(voucher("Payment", [("Dr", "Office Rent", "25000"), ("Cr", "HDFC Bank", "25000")]))
        self.assertEqual(r.number, 1)
        self.assertEqual(self.q("SELECT voucher_type, voucher_no, voucher_date, total_paise FROM bp_vouchers"),
                         [("Payment", 1, "2026-10-09", 2500000)])
        self.assertEqual(self.q("SELECT side, ledger, amount_paise FROM bp_voucher_lines ORDER BY line_no"),
                         [("Dr", "Office Rent", 2500000), ("Cr", "HDFC Bank", 2500000)])
        self.assertEqual(self.q("SELECT count(*) FROM gst_sales_ledger"), [(1,)])     # only the old row
        self.assertEqual(self.q("SELECT outstanding_balance FROM corporate_ledger_summary WHERE account_id='C001'"), [(40000.0,)])
        self.assertEqual(self.store.next_number("Payment"), 2)
        self.assertEqual(self.store.next_number("Receipt"), 1)

    def test_sales_writes_gstr1_row_and_customer_balance(self):
        self.assertEqual(self.store.next_invoice_no(date(2026, 10, 9)), "SRJ/26-27/0001")
        r = self.store.save(sales(gstin=GSTIN))
        self.assertEqual(r.invoice_no, "SRJ/26-27/0001")
        self.assertEqual(self.q("SELECT * FROM gst_sales_ledger WHERE invoice_no LIKE 'SRJ%'"),
                         [("SRJ/26-27/0001", "Gupta Stores", GSTIN, "8471", 10000.0, 9.0, 9.0, 0.0, "19")])
        self.assertEqual(self.q("SELECT outstanding_balance FROM corporate_ledger_summary WHERE account_id='C001'"), [(51800.0,)])
        self.assertEqual(self.q("SELECT invoice_no FROM bp_vouchers"), [("SRJ/26-27/0001",)])
        r2 = self.store.save(sales(customer="Bose & Sons", taxable="500", rate="5"))
        self.assertEqual(r2.invoice_no, "SRJ/26-27/0002")
        self.assertEqual(self.q("SELECT customer_gstin, cgst_rate FROM gst_sales_ledger WHERE invoice_no='SRJ/26-27/0002'"),
                         [(None, 2.5)])

    def test_receipt_reduces_balance_and_unknown_party_is_reported(self):
        self.store.save(voucher("Receipt", [("Dr", "Cash", "5000"), ("Cr", "gupta stores ", "5000")]))
        self.assertEqual(self.q("SELECT outstanding_balance FROM corporate_ledger_summary WHERE account_id='C001'"), [(35000.0,)])
        r = self.store.save(voucher("Receipt", [("Dr", "Cash", "100"), ("Cr", "New Customer", "100")]))
        self.assertEqual(r.unmatched_parties, ["New Customer"])

    def test_credit_ceiling_warning(self):
        w = self.store.credit_warnings(sales(taxable="10000"))
        self.assertEqual([(x.account, x.after, x.ceiling) for x in w], [("Gupta Stores", D("51800.00"), D("50000"))])
        self.assertEqual(self.store.credit_warnings(sales(taxable="5000")), [])
        self.assertEqual(self.store.credit_warnings(sales(customer="Bose & Sons")), [])   # ceiling 0 = no limit

    def test_all_or_nothing(self):
        # Block the balance update: the voucher, its lines and the GSTR-1 row must not be kept either.
        con = sqlite3.connect(self.db)
        con.executescript("CREATE TRIGGER no_upd BEFORE UPDATE ON corporate_ledger_summary "
                          "BEGIN SELECT RAISE(ABORT, 'blocked for test'); END;")
        con.close()
        self.store.save(voucher("Payment", [("Dr", "Rent", "10"), ("Cr", "Cash", "10")]))   # creates bp_ tables
        with self.assertRaises(StoreError):
            self.store.save(sales())
        self.assertEqual(self.q("SELECT count(*) FROM bp_vouchers"), [(1,)])
        self.assertEqual(self.q("SELECT count(*) FROM bp_voucher_lines"), [(2,)])
        self.assertEqual(self.q("SELECT count(*) FROM gst_sales_ledger"), [(1,)])     # only the old row

    def test_schema_checks(self):
        con = sqlite3.connect(self.db)
        con.executescript("DROP TABLE gst_sales_ledger;")
        con.close()
        with self.assertRaises(StoreError) as cm:
            self.store.save(sales())
        self.assertIn("gst_sales_ledger is missing", str(cm.exception))
        self.assertEqual(self.q("SELECT count(*) FROM sqlite_master WHERE name='bp_vouchers'"), [(0,)])
        # Other voucher types still save.
        self.store.save(voucher("Contra", [("Dr", "HDFC Bank", "1000"), ("Cr", "Cash", "1000")]))

    def test_missing_database_is_not_created(self):
        missing = VoucherStore(Path(self.tmp.name) / "nope.db", "SRJ")
        with self.assertRaises(StoreError):
            missing.save(voucher("Payment", [("Dr", "A", "1"), ("Cr", "B", "1")]))
        self.assertFalse((Path(self.tmp.name) / "nope.db").exists())

    def test_busy_database(self):
        holder = sqlite3.connect(self.db, isolation_level=None)
        holder.execute("BEGIN IMMEDIATE")
        started = time.time()
        with self.assertRaises(StoreError) as cm:
            self.store.save(voucher("Payment", [("Dr", "A", "1"), ("Cr", "B", "1")]))
        holder.execute("ROLLBACK")
        holder.close()
        self.assertIn("busy", str(cm.exception))
        self.assertLess(time.time() - started, 10)

    def test_load_all_round_trip(self):
        self.store.save(voucher("Payment", [("Dr", "Rent", "1234.50"), ("Cr", "Cash", "1234.50")], d=date(2026, 10, 1)))
        self.store.save(sales())
        rows = self.store.load_all()
        self.assertEqual([(v["type"], v["number"]) for v in rows], [("Payment", 1), ("Sales", 1)])
        self.assertEqual(rows[0]["lines"][0]["amount"], D("1234.50"))
        self.assertEqual(rows[1]["invoice_no"], "SRJ/26-27/0001")


if __name__ == "__main__":
    unittest.main()
