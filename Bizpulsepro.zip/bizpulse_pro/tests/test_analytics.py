"""
Dashboard trends, Ratio Analysis and Stock Summary (temp database; your real one is never
touched). Run from the bizpulse_pro folder:  python -m unittest discover -s tests -v
"""
from __future__ import annotations

import sqlite3
import sys
import unittest
from datetime import date
from decimal import Decimal as D
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
sys.path.insert(0, str(Path(__file__).resolve().parent))

import services.reports as R  # noqa: E402
from services.analytics import monthly_trends, ratio_analysis  # noqa: E402
from services.stock import load_stock_summary  # noqa: E402
from services.voucher_store import VoucherStore  # noqa: E402
import test_reports as TR  # noqa: E402
from test_voucher_store import voucher  # noqa: E402

END = date(2026, 10, 9)


class AnalyticsTests(unittest.TestCase):
    """Same books as the report tests: capital 1,00,000; purchases 6,000 (May); rent 1,200 (Jun);
    sales 10,000 + GST to Gupta Stores (9 Oct); 500 of sales last year."""
    setUp = TR.ReportTests.setUp
    tearDown = TR.ReportTests.tearDown

    def test_monthly_trends(self):
        VoucherStore(self.db, "SRJ").save(
            voucher("Contra", [("Dr", "HDFC Bank", "3000"), ("Cr", "Cash", "3000")], d=date(2026, 7, 1)))
        t = monthly_trends(self.db, END)
        self.assertEqual(t.fy_label, "2026-27")
        self.assertEqual(t.sales[6], D("10000.00"))            # October
        self.assertEqual(sum(t.sales), D("10000.00"))           # last year's 500 is not in this year
        self.assertEqual(t.purchases[1], D("6000.00"))          # May
        self.assertEqual(t.cash_in[0], D("100000.00"))          # capital brought in, April
        self.assertEqual(t.cash_out[1], D("6000.00"))
        self.assertEqual(t.cash_out[2], D("1250.00"))           # rent 1,200 + Mystery 50, June
        self.assertEqual((t.cash_in[3], t.cash_out[3]), (D("0.00"), D("0.00")))   # Contra nets to nil
        self.assertEqual(t.month_name(9), "Jan 2027")

    def test_ratios(self):
        ra = ratio_analysis(R.build_reports(self.db, END))
        get = lambda name: ra.ratio(name).value  # noqa: E731
        self.assertEqual(get("Sales Accounts"), D("10000.00"))
        self.assertEqual(get("Gross Profit %"), D("40.00"))     # (10,000 - 6,000) / 10,000
        self.assertEqual(get("Nett Profit %"), D("28.00"))      # 2,800 / 10,000
        self.assertEqual(get("Sundry Debtors"), D("11800.00"))
        self.assertEqual(get("Recv. Turnover in Days"), D("226.56"))   # 11,800 / 10,000 x 192 days (1 Apr - 9 Oct)
        ca = get("Working Capital") + D("1800.00")              # current liabilities = output GST 1,800
        self.assertEqual(get("Current Ratio"), (ca / D("1800")).quantize(D("0.01")))
        self.assertIsNone(get("Inventory Turnover"))            # stock not in the accounts
        self.assertTrue(ra.ratio("Inventory Turnover").note)

    def test_divisor_nil_shows_dash(self):
        con = sqlite3.connect(self.db)
        con.execute("DELETE FROM bp_voucher_lines")
        con.execute("DELETE FROM bp_vouchers")
        con.commit()
        con.close()
        ra = ratio_analysis(R.build_reports(self.db, END))
        self.assertIsNone(ra.ratio("Gross Profit %").value)
        self.assertIsNone(ra.ratio("Current Ratio").value)


class StockTests(unittest.TestCase):
    def setUp(self):
        import tempfile
        self.tmp = tempfile.TemporaryDirectory()
        self.db = Path(self.tmp.name) / "bizpulse_local.db"
        con = sqlite3.connect(self.db)
        con.executescript("""
            CREATE TABLE inventory_stock_registry (product_sku TEXT PRIMARY KEY, qty_on_hand INTEGER,
                min_safety_floor INTEGER, last_audit_date TEXT);
            INSERT INTO inventory_stock_registry VALUES ('A1', 40, 10, NULL), ('B2', 4, 10, NULL), ('C3', 7, 0, NULL);
        """)
        con.commit()
        con.close()

    def tearDown(self):
        self.tmp.cleanup()

    def _pricing(self, ddl: str, rows: str) -> None:
        con = sqlite3.connect(self.db)
        con.executescript(ddl + rows)
        con.commit()
        con.close()

    def test_cost_column_newest_rule(self):
        self._pricing("CREATE TABLE inventory_pricing_rules (sku TEXT, cost_price REAL, selling_price REAL, "
                      "effective_from TEXT);",
                      "INSERT INTO inventory_pricing_rules VALUES ('A1', 240, 300, '2026-04-01'), "
                      "('A1', 250, 320, '2026-08-01'), ('b2', 120.5, 150, '2026-04-01');")
        s = load_stock_summary(self.db)
        self.assertEqual(s.rate_source, "inventory_pricing_rules.cost_price")
        a1, b2, c3 = s.lines
        self.assertEqual((a1.rate, a1.value), (D("250.00"), D("10000.00")))   # newest rule
        self.assertEqual(b2.value, D("482.00"))                                 # SKU match ignores case
        self.assertTrue(b2.below_floor)
        self.assertIsNone(c3.rate)
        self.assertEqual((s.total_quantity, s.total_value), (51, D("10482.00")))
        self.assertTrue(any("more than one pricing rule" in n for n in s.notes))
        self.assertTrue(any("no rate" in n for n in s.notes))

    def test_selling_price_only_is_flagged(self):
        self._pricing("CREATE TABLE inventory_pricing_rules (product_sku TEXT, mrp REAL);",
                      "INSERT INTO inventory_pricing_rules VALUES ('A1', 99);")
        s = load_stock_summary(self.db)
        self.assertEqual(s.lines[0].value, D("3960.00"))
        self.assertTrue(any("selling price" in n for n in s.notes))

    def test_named_column_and_unknown_layout(self):
        self._pricing("CREATE TABLE inventory_pricing_rules (product_sku TEXT, landed REAL, x REAL);",
                      "INSERT INTO inventory_pricing_rules VALUES ('A1', 10, 1);")
        self.assertEqual(load_stock_summary(self.db).total_value, D("0.00"))     # cannot tell: nothing valued
        self.assertEqual(load_stock_summary(self.db, "landed").total_value, D("400.00"))

    def test_no_pricing_table(self):
        s = load_stock_summary(self.db)
        self.assertEqual((s.total_quantity, s.total_value, s.rate_source), (51, D("0.00"), "none"))

    def test_read_only(self):
        before = self.db.read_bytes()
        load_stock_summary(self.db)
        self.assertEqual(before, self.db.read_bytes())


if __name__ == "__main__":
    unittest.main()


class StockInBooksTests(unittest.TestCase):
    """Opening stock from config/stock_valuation.py, closing stock from the Stock Summary (at cost)."""
    setUp_books = TR.ReportTests.setUp
    tearDown_books = TR.ReportTests.tearDown

    def setUp(self):
        import config.stock_valuation as SV
        self.SV = SV
        self._saved_sv = (dict(SV.OPENING_STOCK), SV.INCLUDE_STOCK_IN_BOOKS, SV.STOCK_RATE_COLUMN)
        self.setUp_books()
        con = sqlite3.connect(self.db)
        con.executescript("""
            INSERT INTO inventory_stock_registry VALUES ('A1', 10, 2, NULL);
            CREATE TABLE inventory_pricing_rules (product_sku TEXT, cost_price REAL, mrp REAL);
            INSERT INTO inventory_pricing_rules VALUES ('A1', 240, 400);
        """)
        con.commit()
        con.close()
        SV.OPENING_STOCK.clear()
        SV.OPENING_STOCK["2026-27"] = "2000.00"

    def tearDown(self):
        opening, include, column = self._saved_sv
        self.SV.OPENING_STOCK.clear()
        self.SV.OPENING_STOCK.update(opening)
        self.SV.INCLUDE_STOCK_IN_BOOKS, self.SV.STOCK_RATE_COLUMN = include, column
        self.tearDown_books()

    def test_profit_and_loss_with_stock(self):
        r = R.build_reports(self.db, END)
        self.assertEqual((r.opening_stock, r.closing_stock), (D("2000.00"), D("2400.00")))
        self.assertEqual(r.gross_profit, D("4400.00"))      # 10,000 - 2,000 - 6,000 + 2,400
        self.assertEqual(r.net_profit, D("3200.00"))        # less rent 1,200
        self.assertEqual(r.profit_before_period, D("2500.00"))   # last year's 500 + opening stock b/f

    def test_balance_sheet_still_balances(self):
        r = R.build_reports(self.db, END)
        self.assertEqual(r.liabilities_total, r.assets_total)
        self.assertEqual(r.assets_total, D("107500.00"))    # 1,05,100 before stock + closing stock 2,400
        self.assertEqual(R.group_totals(r)["Stock-in-Hand"], D("2400.00"))
        pl_ac = next(n for n in r.liabilities if n.name == "Profit & Loss A/c")
        self.assertEqual([c.name for c in pl_ac.children],
                         ["Opening balance", "Opening stock b/f", "Current period"])

    def test_ratios_use_stock(self):
        ra = ratio_analysis(R.build_reports(self.db, END))
        self.assertEqual(ra.ratio("Stock-in-Hand").value, D("2400.00"))
        self.assertEqual(ra.ratio("Inventory Turnover").value, D("2.55"))   # COGS 5,600 / average 2,200
        self.assertNotEqual(ra.ratio("Quick Ratio").value, ra.ratio("Current Ratio").value)

    def test_selling_price_keeps_both_out(self):
        self.SV.STOCK_RATE_COLUMN = "mrp"
        r = R.build_reports(self.db, END)
        self.assertEqual((r.opening_stock, r.closing_stock), (D("0.00"), D("0.00")))
        self.assertEqual(r.gross_profit, D("4000.00"))
        self.assertTrue(any("left out of the books" in n for n in r.stock_notes))
        self.assertEqual(r.liabilities_total, r.assets_total)

    def test_missing_opening_stock_is_flagged(self):
        self.SV.OPENING_STOCK.clear()
        r = R.build_reports(self.db, END)
        self.assertEqual(r.gross_profit, D("6400.00"))      # closing counted, no opening
        self.assertTrue(any("overstated" in n for n in r.stock_notes))
        self.assertEqual(r.liabilities_total, r.assets_total)

    def test_invalid_opening_and_switch_off(self):
        self.SV.OPENING_STOCK["2026-27"] = "abc"
        self.assertTrue(any("not a valid amount" in n for n in R.build_reports(self.db, END).stock_notes))
        self.SV.INCLUDE_STOCK_IN_BOOKS = False
        r = R.build_reports(self.db, END)
        self.assertEqual((r.closing_stock, r.gross_profit), (D("0.00"), D("4000.00")))
