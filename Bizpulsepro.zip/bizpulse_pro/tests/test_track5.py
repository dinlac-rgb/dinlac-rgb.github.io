"""
Track 5 and the software-update check:
    services/updates.py, views/update_view.py            [U] Upgrade (Alt+U)
    services/ecommerce.py, views/ecommerce_view.py       O: Import › E-commerce Orders
    services/cost_centres.py, components/allocation_box.py and the voucher screen
GUI tests need a display (Tk) and are skipped where there is none.
Run from the bizpulse_pro folder:  python -m unittest discover -s tests -v
"""
from __future__ import annotations

import gc
import io
import sqlite3
import sys
import tempfile
import time
import tkinter as tk
import unittest
from datetime import date
from decimal import Decimal as D
from pathlib import Path
from unittest import mock

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
sys.path.insert(0, str(Path(__file__).resolve().parent))

from config import settings as S  # noqa: E402
from config import theme as T  # noqa: E402
from services import cost_centres as CC  # noqa: E402
from services import ecommerce as E  # noqa: E402
from services import updates as U  # noqa: E402
from services.masters import DDL as MASTER_DDL  # noqa: E402
from services.inventory_masters import INVENTORY_DDL  # noqa: E402
from services.migrations import upgrade_database  # noqa: E402
from services.voucher_book import VoucherBook  # noqa: E402
from services.voucher_store import StoreError  # noqa: E402
from test_voucher_store import SCHEMA, voucher  # noqa: E402

INSTALLED = {"app": "1.0.0", "security": "2026.10.0", "tax_tables": "2026.10"}
FEED = b"""{"published": "2026-10-10", "items": [
  {"kind": "app", "version": "1.0.0", "title": "same"},
  {"kind": "app", "version": "1.10.0", "title": "BizPulse Pro 1.10.0", "url": "https://example.invalid/d"},
  {"kind": "tax_tables", "version": "2026.11", "title": "GST tables", "url": "http://insecure"},
  {"kind": "security", "version": "2026.9.9"},
  {"kind": "mystery", "version": "9"},
  {"version": "1"}]}"""

ORDERS = """Order ID,Order Date,SKU,Quantity,Item Total,Ship To State,GST Rate,HSN,Buyer Name,Marketplace
A-1,05-10-2026,SKU-1,2,1180,West Bengal,18,8471,Rita,Amazon
A-2,2026-10-06 10:15:00,sku-1,1,100,07,18,8471,Arun,Amazon
A-3,06-10-2026,SKU-2,5,500,19,18,8471,,Flipkart
A-4,06-10-2026,NOPE,1,50,19,18,8471,,Flipkart
A-5,07-10-2026,SKU-1,1,105,Karnataka,,,Meena,Meesho
A-6,07-10-2026,SKU-1,1,105,,18,8471,,Meesho
"""


class Key:
    def __init__(self, keysym, widget=None, state=0):
        self.keysym, self.widget, self.state = keysym, widget, state


# ---- [U] Upgrade -------------------------------------------------------------------------------
class UpdateTests(unittest.TestCase):
    def test_feed_comparison(self):
        r = U.parse_feed(FEED, INSTALLED)
        self.assertEqual([(u.kind, u.version) for u in r.updates], [("app", "1.10.0"), ("tax_tables", "2026.11")])
        self.assertEqual(r.updates[1].url, "")                          # plain http links are dropped
        self.assertEqual(r.skipped, 2)
        self.assertEqual(r.message, "2 updates available.")
        self.assertTrue(U.newer("1.10.0", "1.9.2"))
        self.assertFalse(U.newer("2026.10", "2026.10.0"))

    def test_up_to_date_message(self):
        r = U.parse_feed(b'{"items": [{"kind": "app", "version": "1.0.0"}]}', INSTALLED)
        self.assertEqual(r.message, "Your BizPulse Pro System is Up to Date")

    def test_no_feed_and_http_refused(self):
        with self.assertRaises(U.UpdateError) as ctx:
            U.check("", INSTALLED)
        self.assertIn("nothing was checked", str(ctx.exception))
        with self.assertRaises(U.UpdateError):
            U.check("http://example.invalid/feed.json", INSTALLED)
        self.assertEqual(S.UPDATE_FEED_URL, "")                          # shipped blank: no address invented

    def test_check_reads_the_feed(self):
        class Resp(io.BytesIO):
            def __enter__(self):
                return self

            def __exit__(self, *a):
                return False
        with mock.patch("urllib.request.urlopen", return_value=Resp(FEED)) as op:
            r = U.check("https://updates.example.invalid/feed.json", INSTALLED)
        self.assertEqual(len(r.updates), 2)
        self.assertIn("BizPulse-Pro/1.0.0", op.call_args[0][0].get_header("User-agent"))
        with mock.patch("urllib.request.urlopen", side_effect=OSError("no route")):
            with self.assertRaises(U.UpdateError):
                U.check("https://updates.example.invalid/feed.json", INSTALLED)

    def test_no_pricing_in_the_app(self):
        root = Path(__file__).resolve().parent.parent
        for f in list(root.glob("views/*.py")) + list(root.glob("components/*.py")) + [root / "config" / "settings.py"]:
            text = f.read_text(encoding="utf-8").lower()
            for word in ("per month", "/month", "pricing plan", "₹ per year", "price list"):
                self.assertNotIn(word, text, f.name)


# ---- shared database ----------------------------------------------------------------------------
class DbCase(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.db = Path(self.tmp.name) / "bizpulse_local.db"
        con = sqlite3.connect(self.db)
        con.executescript(SCHEMA)
        con.executescript(MASTER_DDL + ";" + INVENTORY_DDL)
        con.execute("INSERT INTO inventory_stock_registry VALUES ('SKU-1', 10, 0, NULL), ('SKU-2', 1, 0, NULL)")
        con.execute("INSERT INTO bp_gst_classifications VALUES ('Apparel 5', '6109', '5', 'None', 'x', 'x')")
        con.execute("INSERT INTO bp_stock_items (name, alias, unit, gst_classification, created_at, updated_at) "
                    "VALUES ('SKU-1', NULL, 'Nos', 'Apparel 5', 'x', 'x')")
        con.commit()
        con.close()
        upgrade_database(self.db, "19")
        self.book = VoucherBook(self.db, "SRJ")
        self.csv = Path(self.tmp.name) / "orders.csv"
        self.csv.write_text(ORDERS, encoding="utf-8")

    def tearDown(self):
        self.tmp.cleanup()

    def q(self, sql, *args):
        con = sqlite3.connect(self.db)
        try:
            return con.execute(sql, args).fetchall()
        finally:
            con.close()

    def plan(self):
        return E.read_orders(self.csv, self.db, company_state="19", gst_rates=tuple(S.GST_RATES))

    @staticmethod
    def build():
        return dict(company_state="19", party_ledger=S.ECOM_PARTY_LEDGER, sales_ledger="Sales",
                    tax_ledgers=S.OUTPUT_TAX_LEDGERS, round_off_ledger="Round Off", round_off_limit=D("1.00"))


# ---- E-commerce Orders --------------------------------------------------------------------------
class EcommerceTests(DbCase):
    def test_read_matches_skus_and_states(self):
        p = self.plan()
        self.assertEqual(p.rows, 6)
        self.assertEqual(len(p.errors), 2)
        self.assertIn("SKU 'NOPE'", p.errors[0])
        self.assertIn("no ship-to state", p.errors[1])
        by = {i.order_id: i for i in p.invoices}
        self.assertEqual(by["A-1"].pos, "19")
        self.assertEqual(by["A-2"].pos, "07")
        self.assertEqual(by["A-2"].date, date(2026, 10, 6))
        self.assertEqual((by["A-5"].rate, by["A-5"].hsn, by["A-5"].pos), (D("5"), "6109", "29"))   # from the master
        self.assertEqual(by["A-3"].status, "Short stock")
        self.assertEqual([i.order_id for i in p.ready], ["A-1", "A-2", "A-5"])
        self.assertEqual(by["A-1"].taxable, D("1000.00"))

    def test_post_vouchers_gst_stock_and_rerun(self):
        result = E.post(self.plan(), self.book, **self.build())
        self.assertEqual([n for _i, n in result.posted], ["SRJ/26-27/0001", "SRJ/26-27/0002", "SRJ/26-27/0003"])
        rows = self.q("SELECT invoice_no, taxable_value, cgst_rate, sgst_rate, igst_rate, place_of_supply "
                      "FROM gst_sales_ledger ORDER BY invoice_no")
        self.assertEqual(rows[0], ("SRJ/26-27/0001", 1000.0, 9.0, 9.0, 0.0, "19"))
        self.assertEqual(rows[1][4], 18.0)
        self.assertEqual(self.q("SELECT qty_on_hand FROM inventory_stock_registry WHERE product_sku = 'SKU-1'"), [(6,)])
        a2 = self.book.load_voucher(2)
        lines = {(ln["side"], ln["ledger"]): ln["amount"] for ln in a2["lines"]}
        self.assertEqual(lines[("Dr", S.ECOM_PARTY_LEDGER)], D("100.00"))          # what the buyer paid
        self.assertEqual(lines[("Cr", "Sales")], D("84.75"))
        self.assertEqual(lines[("Cr", "Output IGST")], D("15.26"))
        self.assertEqual(lines[("Dr", "Round Off")], D("0.01"))
        self.assertEqual(a2["details"][E.ORDER_FIELD], "A-2")
        again = self.plan()                                                      # same file twice: nothing new
        self.assertEqual({i.status for i in again.invoices}, {"Already imported", "Short stock"})
        self.assertEqual(len(self.q("SELECT * FROM bp_system_audit_logs WHERE action = 'Create'")), 3)

    def test_bad_file(self):
        self.csv.write_text("hello,world\n1,2\n", encoding="utf-8")
        with self.assertRaises(E.EcomError):
            self.plan()


# ---- Cost centres ------------------------------------------------------------------------------
class CostCentreServiceTests(DbCase):
    def test_rules(self):
        self.assertEqual(CC.share(D("1000"), D("33.33")), D("333.30"))
        self.assertIsNone(CC.check(D("100"), [{"cost_centre": "A", "amount": D("60")}, {"cost_centre": "B", "amount": D("40")}]))
        self.assertIn("add up", CC.check(D("100"), [{"cost_centre": "A", "amount": D("60")}]))
        self.assertIn("twice", CC.check(D("100"), [{"cost_centre": "A", "amount": D("50")}, {"cost_centre": "a", "amount": D("50")}]))
        r = CC.rescale([{"cost_centre": "A", "amount": D("1")}, {"cost_centre": "B", "amount": D("2")}], D("10.00"))
        self.assertEqual([a["amount"] for a in r], [D("3.33"), D("6.67")])

    def test_store_load_alter_and_summary(self):
        v = voucher("Payment", [("Dr", "Office Rent", "1000"), ("Cr", "HDFC Bank", "1000")], d=date(2026, 10, 5))
        v["lines"][0]["allocations"] = [{"cost_centre": "Marketing", "amount": D("600"), "percent": "60"},
                                        {"cost_centre": "Operations", "amount": D("400"), "percent": "40"}]
        r = self.book.save(v)
        self.assertEqual(self.q("SELECT line_no, cost_centre, amount_paise FROM bp_cost_allocations ORDER BY share_no"),
                         [(1, "Marketing", 60000), (1, "Operations", 40000)])
        back = self.book.load_voucher(r.voucher_id)
        self.assertEqual([a["cost_centre"] for a in back["lines"][0]["allocations"]], ["Marketing", "Operations"])
        self.assertIn("[Marketing 600.00, Operations 400.00]",
                      self.q("SELECT new_text FROM bp_system_audit_logs")[0][0])
        rows = CC.summary(self.db, date(2026, 4, 1), date(2026, 10, 31))
        self.assertEqual([(x.centre, x.ledger, x.amount) for x in rows],
                         [("Marketing", "Office Rent", D("600")), ("Operations", "Office Rent", D("400"))])
        bad = voucher("Payment", [("Dr", "Office Rent", "1000"), ("Cr", "HDFC Bank", "1000")])
        bad["lines"][0]["allocations"] = [{"cost_centre": "Marketing", "amount": D("600")}]
        with self.assertRaises(StoreError):
            self.book.save(bad)
        v2 = voucher("Payment", [("Dr", "Office Rent", "1000"), ("Cr", "HDFC Bank", "1000")], d=date(2026, 10, 5))
        self.book.alter(r.voucher_id, v2)                                    # alteration without a split
        self.assertEqual(self.q("SELECT count(*) FROM bp_cost_allocations"), [(0,)])
        self.assertIn("Indirect Expenses", S.COST_CENTRE_GROUPS)


# ---- GUI -----------------------------------------------------------------------------------------
class GuiCase(DbCase):
    def setUp(self):
        super().setUp()
        try:
            self.root = tk.Tk()
        except tk.TclError as exc:
            self.tmp.cleanup()
            raise unittest.SkipTest(f"no display: {exc}")
        T.apply_ttk_styles(self.root)
        self.root.geometry("1100x720")

    def tearDown(self):
        for _ in range(5):
            self.root.update()
            time.sleep(0.02)
        self.root.destroy()
        gc.collect()   # old Tk objects go away on the main thread, not in a worker
        super().tearDown()

    def settle(self, until, n=150):
        for _ in range(n):
            self.root.update()
            if until():
                return
            time.sleep(0.02)


class GuiTests(GuiCase):
    def test_update_view_up_to_date(self):
        from views.update_view import UpdateView
        closed = []
        v = UpdateView(self.root, feed_url="https://x.invalid/f.json", installed=INSTALLED,
                       on_close=lambda: closed.append(1), checker=lambda _u, _i: U.UpdateResult())
        v.pack(fill="both", expand=True)
        self.settle(lambda: v.status.cget("text") == U.UP_TO_DATE)
        self.assertEqual(v.status.cget("text"), "Your BizPulse Pro System is Up to Date")
        self.assertEqual(str(v.status.cget("font")), "{Segoe UI} 11 normal")
        v.handle_key(Key("Escape"))
        self.assertEqual(closed, [1])

    def test_update_view_without_feed_claims_nothing(self):
        from views.update_view import UpdateView
        v = UpdateView(self.root, feed_url="", installed=INSTALLED, on_close=lambda: None)
        v.pack(fill="both", expand=True)
        self.settle(lambda: "nothing was checked" in v.status.cget("text"))
        self.assertNotIn("Up to Date", v.status.cget("text"))

    def test_ecommerce_view_reads_and_posts(self):
        from views.ecommerce_view import EcommerceView
        notes = []
        v = EcommerceView(self.root, db_path=self.db, store=self.book, settings=S, on_close=lambda: None,
                          on_note=notes.append)
        v.pack(fill="both", expand=True)
        v.open_file(str(self.csv))
        self.settle(lambda: len(v.tree.get_children()) == 4)
        self.assertIn("2 row error", v.summary.cget("text"))
        with mock.patch("views.ecommerce_view.messagebox.askyesno", return_value=True):
            v.post()
        self.settle(lambda: v.summary.cget("text").startswith("Posted"))
        self.assertEqual(v.summary.cget("text"), "Posted 3 invoice(s).")
        self.assertTrue(any("SRJ/26-27/0001" in n for n in notes))

    def make_voucher(self):
        from views.vouchers_view import VoucherView
        self.saved = []
        v = VoucherView(self.root, voucher_type="Payment", number_for=lambda _t: 1,
                        on_accept=lambda x, done: (self.saved.append(x), done(True)), on_close=lambda: None,
                        mode="Single Entry", cost_source=lambda: {"office rent"},
                        centre_source=lambda: ["Marketing", "Operations"])
        v.pack(fill="both", expand=True)
        self.settle(lambda: v._cost_ledgers)
        v._account.insert(0, "HDFC Bank")
        line = v._single_lines[0]
        line.ledger.insert(0, "Office Rent")
        line.amount_entry.insert(0, "1000")
        return v, line

    def test_allocation_box_split_by_percent(self):
        v, line = self.make_voucher()
        v._advance(line.amount_entry)
        box = v._alloc_box
        self.assertIsNotNone(box)
        n0, p0, a0 = box.rows[0]
        n0.insert(0, "mark")
        v.handle_key(Key("Return", n0))
        self.assertEqual(n0.get(), "Marketing")                              # completed from the known names
        p0.insert(0, "60")
        v.handle_key(Key("Return", p0))
        self.assertEqual(a0.get(), "600.00")
        v.handle_key(Key("Return", a0))
        n1, p1, a1 = box.rows[1]
        n1.insert(0, "Operations")
        v.handle_key(Key("Return", n1))
        p1.insert(0, "40")
        v.handle_key(Key("Return", p1))
        self.assertEqual(a1.get(), "400.00")
        v.handle_key(Key("Return", a1))
        v.handle_key(Key("Return", box.rows[2][0]))                          # empty name: finish
        self.assertIsNone(v._alloc_box)
        self.assertEqual([(a["cost_centre"], a["amount"]) for a in line.allocations],
                         [("Marketing", D("600.00")), ("Operations", D("400.00"))])
        self.root.update()
        self.assertIs(v.focus_get(), v._single_lines[1].ledger)              # on to the next line
        v.accept()
        self.assertEqual(len(self.saved[0]["lines"][0]["allocations"]), 2)

    def test_escape_collapses_and_partial_is_refused(self):
        v, line = self.make_voucher()
        v._advance(line.amount_entry)
        box = v._alloc_box
        box.rows[0][0].insert(0, "Marketing")
        box.rows[0][2].insert(0, "500")
        v.handle_key(Key("Return", box.rows[1][0]))                          # half allocated: not accepted
        self.assertIsNotNone(v._alloc_box)
        self.assertIn("add up", box._error.cget("text"))
        v.handle_key(Key("Escape", box.rows[1][0]))                          # collapses, line unchanged
        self.assertIsNone(v._alloc_box)
        self.assertEqual(line.allocations, [])
        self.root.update()
        self.assertIs(v.focus_get(), line.amount_entry)
        line.ledger.delete(0, "end")
        line.ledger.insert(0, "Bank Charges")                                # not a cost ledger: no box
        v._advance(line.amount_entry)
        self.assertIsNone(v._alloc_box)


if __name__ == "__main__":
    unittest.main()
