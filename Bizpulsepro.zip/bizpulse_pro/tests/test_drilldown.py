"""
Phase 3: account_groups seeding, voucher alteration (drill-down), ledger statements, Trial
Balance figures, GSTIN / HSN structure checks, and the bank reconciliation helper.
GUI tests need a display (Tk) and are skipped where there is none.
Run from the bizpulse_pro folder:  python -m unittest discover -s tests -v
"""
from __future__ import annotations

import gc
import sqlite3
import sys
import tempfile
import time
import tkinter as tk
import unittest
from datetime import date
from decimal import Decimal as D
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
sys.path.insert(0, str(Path(__file__).resolve().parent))

import services.reports as R  # noqa: E402
from config import theme as T  # noqa: E402
from services import bank_reco as B  # noqa: E402
from services.group_seeder import seed_account_groups  # noqa: E402
from services.gst_check import check_gstin_structure, check_hsn_structure  # noqa: E402
from services.migrations import upgrade_database  # noqa: E402
from services.voucher_book import VoucherBook  # noqa: E402
from services.voucher_store import StoreError  # noqa: E402
from test_masters import make_gstin  # noqa: E402
from test_voucher_store import SCHEMA, sales, voucher  # noqa: E402


class DbCase(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.db = Path(self.tmp.name) / "bizpulse_local.db"
        con = sqlite3.connect(self.db)
        con.executescript(SCHEMA)
        con.execute("INSERT INTO inventory_stock_registry VALUES ('SKU-1', 10, 0, NULL)")
        con.commit()
        con.close()
        upgrade_database(self.db, "19")
        self.book = VoucherBook(self.db, "SRJ")

    def tearDown(self):
        self.tmp.cleanup()

    def q(self, sql, *args):
        con = sqlite3.connect(self.db)
        try:
            return con.execute(sql, args).fetchall()
        finally:
            con.close()


class SeederTests(DbCase):
    def test_new_table_gets_28_and_is_idempotent(self):
        self.assertIn("28 of the 28 reserved groups added", seed_account_groups(self.db))
        rows = self.q("SELECT name, parent, nature, is_primary FROM account_groups")
        self.assertEqual(len(rows), 28)
        self.assertEqual(sum(r[3] for r in rows), 15)
        self.assertIn(("Duties & Taxes", "Current Liabilities", "Liabilities", 0), rows)
        self.assertIn(("Sundry Debtors", "Current Assets", "Assets", 0), rows)
        self.assertIn("all present", seed_account_groups(self.db))
        self.assertEqual(len(self.q("SELECT * FROM account_groups")), 28)

    def test_existing_table_keeps_its_rows(self):
        con = sqlite3.connect(self.db)
        con.executescript("CREATE TABLE account_groups (id INTEGER PRIMARY KEY, group_name TEXT, under TEXT);"
                          "INSERT INTO account_groups (group_name, under) VALUES ('capital account', NULL),"
                          "('Office Expenses', 'Indirect Expenses');")
        con.commit()
        con.close()
        self.assertIn("27 of the 28", seed_account_groups(self.db))
        self.assertEqual(len(self.q("SELECT * FROM account_groups")), 29)
        self.assertEqual(self.q("SELECT under FROM account_groups WHERE group_name = 'Bank Accounts'"),
                         [("Current Assets",)])

    def test_table_without_a_name_column_is_left_alone(self):
        con = sqlite3.connect(self.db)
        con.execute("CREATE TABLE account_groups (code TEXT)")
        con.commit()
        con.close()
        self.assertIn("no name column", seed_account_groups(self.db))
        self.assertEqual(self.q("SELECT count(*) FROM account_groups"), [(0,)])


class AlterTests(DbCase):
    def test_alter_sales_reverses_and_reapplies(self):
        r = self.book.save(sales(taxable="10000"))                 # Gupta 40,000 + 11,800
        self.assertEqual(self.q("SELECT outstanding_balance FROM corporate_ledger_summary WHERE account_id='C001'"),
                         [(51800.0,)])
        data = self.book.load_voucher(r.voucher_id)
        self.assertEqual((data["invoice_no"], data["gst"]["rate"], data["gst"]["taxable"]),
                         (r.invoice_no, "18", D("10000.00")))
        new = sales(taxable="5000")
        res = self.book.alter(r.voucher_id, new)
        self.assertEqual(res.invoice_no, r.invoice_no)              # same invoice number
        self.assertEqual(self.q("SELECT outstanding_balance FROM corporate_ledger_summary WHERE account_id='C001'"),
                         [(45900.0,)])                               # 40,000 + 5,900, not + 11,800 too
        self.assertEqual(self.q("SELECT taxable_value FROM gst_sales_ledger"), [(5000.0,)])
        self.assertEqual(self.book.load_voucher(r.voucher_id)["total"], D("5900.00"))

    def test_alter_rules(self):
        r = self.book.save(voucher("Journal", [("Dr", "A", "1"), ("Cr", "B", "1")]))
        with self.assertRaises(StoreError):
            self.book.alter(r.voucher_id, voucher("Payment", [("Dr", "A", "1"), ("Cr", "B", "1")]))
        s = self.book.save(sales())
        with self.assertRaises(StoreError):                         # another financial year
            self.book.alter(s.voucher_id, sales() | {"date": date(2027, 4, 2)})
        with self.assertRaises(StoreError):
            self.book.alter(99999, voucher("Journal", [("Dr", "A", "1"), ("Cr", "B", "1")]))

    def test_alter_item_purchase_moves_stock_by_difference(self):
        v = voucher("Purchase", [("Dr", "Purchases", "400"), ("Cr", "Bose", "400")])
        v["items"] = [{"item": "SKU-1", "quantity": 4, "rate": D("100"), "per": "Nos", "amount": D("400")}]
        r = self.book.save(v)
        self.assertEqual(self.q("SELECT qty_on_hand FROM inventory_stock_registry"), [(14,)])
        v2 = voucher("Purchase", [("Dr", "Purchases", "600"), ("Cr", "Bose", "600")])
        v2["items"] = [{"item": "SKU-1", "quantity": 6, "rate": D("100"), "per": "Nos", "amount": D("600")}]
        self.book.alter(r.voucher_id, v2)
        self.assertEqual(self.q("SELECT qty_on_hand FROM inventory_stock_registry"), [(16,)])
        v2["status"] = "Optional"
        self.book.alter(r.voucher_id, v2)                           # now Optional: its stock is taken back
        self.assertEqual(self.q("SELECT qty_on_hand FROM inventory_stock_registry"), [(10,)])

    def test_ledger_statement_and_trial_balance(self):
        self.book.save(voucher("Journal", [("Dr", "Cash", "1000"), ("Cr", "Capital", "1000")], d=date(2026, 3, 1)))
        self.book.save(voucher("Payment", [("Dr", "Rent", "300"), ("Cr", "Cash", "300")], d=date(2026, 5, 1)))
        self.book.save(voucher("Receipt", [("Dr", "Cash", "50"), ("Cr", "Sales", "50")], d=date(2026, 6, 1)))
        st = self.book.ledger_statement("cash", date(2026, 10, 9))
        self.assertEqual(st["opening"], D("1000.00"))               # before 1 April
        self.assertEqual([r["amount"] for r in st["rows"]], [D("-300.00"), D("50.00")])
        self.assertEqual((st["rows"][0]["particulars"], st["closing"]), ("Rent", D("750.00")))
        saved = dict(R.LEDGER_GROUPS)
        R.LEDGER_GROUPS.update({"Cash": "Cash-in-Hand", "Capital": "Capital Account", "Rent": "Indirect Expenses",
                                "Sales": "Sales Accounts"})
        try:
            r = R.build_reports(self.db, date(2026, 10, 9))
        finally:
            R.LEDGER_GROUPS.clear()
            R.LEDGER_GROUPS.update(saved)
        total = sum(r.tb_balances.values(), D("0")) - r.profit_before_vouchers - r.opening_difference
        self.assertEqual(total, D("0.00"))                          # Debit = Credit
        self.assertEqual(r.tb_balances["Rent"], D("300.00"))


class GstCheckTests(unittest.TestCase):
    def test_gstin(self):
        good = make_gstin("19", "ABCDE1234F")
        r = check_gstin_structure(good.lower())
        self.assertTrue(r.ok)
        self.assertEqual(r.badge, "FORMAT VALID")
        self.assertIn("West Bengal (19)", r.detail)
        self.assertIn("CGST + SGST", r.detail)
        self.assertNotIn("ACTIVE", r.badge + r.detail.upper().replace("INACTIVE", ""))
        self.assertIn("not checked", r.detail)                       # says plainly what it did not check
        other = check_gstin_structure(make_gstin("27", "ABCDE1234F"))
        self.assertIn("IGST", other.detail)
        bad = check_gstin_structure(good[:-1] + ("0" if good[-1] != "0" else "1"))
        self.assertEqual((bad.ok, bad.badge), (False, "NOT VALID"))

    def test_hsn(self):
        self.assertIn("chapter 85", check_hsn_structure("8517").detail)
        self.assertIn("services", check_hsn_structure("998314").detail)
        self.assertFalse(check_hsn_structure("7701").ok)
        self.assertFalse(check_hsn_structure("85").ok)


class BankRecoTests(DbCase):
    def write(self, name, text):
        path = Path(self.tmp.name) / name
        path.write_text(text, encoding="utf-8")
        return path

    def test_statement_reading(self):
        p = self.write("hdfc.csv", "HDFC BANK\nAccount 50100\n\nDate,Narration,Chq No,Withdrawal Amt,Deposit Amt,Balance\n"
                                   "05/10/26,NEFT GUPTA STORES,,,\"11,800.00\",20000\n06/10/26,RENT OCT,,2500.00,,17500\n"
                                   "Totals,,,,,\n")
        st = B.read_statement(p)
        self.assertEqual([(r.date, r.amount) for r in st.rows],
                         [(date(2026, 10, 5), D("11800.00")), (date(2026, 10, 6), D("-2500.00"))])
        self.assertEqual(st.skipped, 1)
        p2 = self.write("sbi.txt", "Txn Date;Description;Amount\n05-Oct-2026;UPI;500.00 Dr\n")
        self.assertEqual(B.read_statement(p2).rows[0].amount, D("-500.00"))
        with self.assertRaises(B.RecoError):
            B.read_statement(self.write("bad.csv", "a,b\n1,2\n"))

    def test_match_record_and_trail(self):
        saved = dict(R.LEDGER_GROUPS)
        R.LEDGER_GROUPS.update({"HDFC Bank": "Bank Accounts"})
        try:
            self.book.save(voucher("Receipt", [("Dr", "HDFC Bank", "11800"), ("Cr", "Gupta Stores", "11800")],
                                   d=date(2026, 10, 5)))
            self.book.save(voucher("Payment", [("Dr", "Rent", "2500"), ("Cr", "HDFC Bank", "2500")], d=date(2026, 10, 6)))
            self.book.save(voucher("Payment", [("Dr", "Tea", "40"), ("Cr", "HDFC Bank", "40")], d=date(2026, 10, 7)))
            self.assertEqual(B.bank_ledgers(self.db), ["HDFC Bank"])
            book = B.bank_book(self.db, "HDFC Bank")
            st = B.read_statement(self.write("s.csv", "Date,Description,Withdrawal,Deposit\n05-10-2026,NEFT,,11800\n"
                                                      "06-10-2026,RENT,2500,\n09-10-2026,CHARGES,59,\n"))
            pairs = B.match(book, st)
            self.assertEqual([(e.vtype, r.description) for e, r in pairs], [("Receipt", "NEFT"), ("Payment", "RENT")])
            self.assertEqual(B.record_matches(self.db, "HDFC Bank", pairs, "s.csv"), 2)
            self.assertEqual(B.record_matches(self.db, "HDFC Bank", pairs, "s.csv"), 0)      # no duplicates
            book2 = B.bank_book(self.db, "HDFC Bank")
            self.assertEqual([e.matched for e in book2], [True, True, False])
            st2 = B.read_statement(Path(self.tmp.name) / "s.csv")
            self.assertEqual(B.mark_previous(st2, B.reconciled_trail(self.db, "HDFC Bank")), 2)
            self.assertEqual(B.match(book2, st2), [])                                     # the 40 / 59 do not pair
        finally:
            R.LEDGER_GROUPS.clear()
            R.LEDGER_GROUPS.update(saved)


class GuiCase(DbCase):
    def setUp(self):
        super().setUp()
        try:
            self.root = tk.Tk()
        except tk.TclError as exc:
            self.tmp.cleanup()
            raise unittest.SkipTest(f"no display: {exc}")
        T.apply_ttk_styles(self.root)
        self.root.geometry("1100x720")

    def tearDown(self):
        for _ in range(5):
            self.root.update()
            time.sleep(0.02)
        self.root.destroy()
        gc.collect()   # old Tk objects go away on the main thread, not in a worker
        super().tearDown()


class Key:
    def __init__(self, keysym, widget=None, state=0):
        self.keysym, self.widget, self.state = keysym, widget, state


class DrillGuiTests(GuiCase):
    def test_voucher_opens_for_alteration_clean(self):
        from views.vouchers_view import VoucherView
        r = self.book.save(sales(taxable="10000"))
        data = self.book.load_voucher(r.voucher_id)
        accepted = []
        v = VoucherView(self.root, voucher_type="Sales", number_for=lambda _t: 99, on_accept=lambda vv, done:
                        accepted.append(vv), on_close=lambda: None, existing=data)
        v.pack(fill="both", expand=True)
        self.root.update()
        self.assertFalse(v._dirty())                                  # nothing changed yet
        self.assertIn(r.invoice_no, v._number_label.cget("text"))
        self.assertEqual([m.key for m in v.macros()], ["Ctrl+I", "Ctrl+A"])     # no type switching
        self.assertEqual(v._party.get(), "Gupta Stores")              # no Party A/c saved: the debited party
        v._narration.insert("end", " changed")
        self.assertTrue(v._dirty())
        v.accept()
        self.assertEqual(len(accepted), 1, v._status.cget("text"))
        self.assertEqual(accepted[0]["total"], D("11800.00"))

    def test_daybook_enter_opens_voucher(self):
        from views.daybook_view import DaybookView
        self.book.save(voucher("Journal", [("Dr", "A", "1"), ("Cr", "B", "1")]))
        opened = []
        d = DaybookView(self.root, self.book.load_all(), on_close=lambda: None, on_open=opened.append)
        d.pack(fill="both", expand=True)
        self.root.update()
        d.focus_first()
        d.handle_key(Key("Return"))
        self.assertEqual(len(opened), 1)

    def test_trial_balance_view_opens_ledger(self):
        from views.trial_balance_view import TrialBalanceView
        self.book.save(voucher("Journal", [("Dr", "Cash", "100"), ("Cr", "Capital", "100")], d=date(2026, 5, 1)))
        opened = []
        tb = TrialBalanceView(self.root, db_path=self.db, company="Srijee", on_close=lambda: None,
                              on_open_ledger=opened.append, upto=date(2026, 10, 9))
        tb.pack(fill="both", expand=True)
        for _ in range(100):
            self.root.update()
            if tb._ledger_rows:
                break
            time.sleep(0.02)
        self.assertEqual(tb._dr_total.cget("text"), tb._cr_total.cget("text"))
        iid = next(i for i, n in tb._ledger_rows.items() if n == "Cash")
        tb.open_row(iid)
        self.assertEqual(opened, ["Cash"])


if __name__ == "__main__":
    unittest.main()
