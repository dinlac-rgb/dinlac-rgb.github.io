"""
The audit trail: services/audit.py (bp_system_audit_logs, triggers, hash chain), its hooks in
the voucher and master writes, and views/audit_trail_view.py.
GUI tests need a display (Tk) and are skipped where there is none.
Run from the bizpulse_pro folder:  python -m unittest discover -s tests -v
"""
from __future__ import annotations

import gc
import sqlite3
import sys
import tempfile
import time
import tkinter as tk
import unittest
from datetime import date, timedelta
from decimal import Decimal as D
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
sys.path.insert(0, str(Path(__file__).resolve().parent))

from config import theme as T  # noqa: E402
from services import audit  # noqa: E402
from services.masters import MasterStore  # noqa: E402
from services.migrations import upgrade_database  # noqa: E402
from services.voucher_book import VoucherBook  # noqa: E402
from services.voucher_store import StoreError  # noqa: E402
from test_voucher_store import SCHEMA, sales, voucher  # noqa: E402


class DbCase(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.db = Path(self.tmp.name) / "bizpulse_local.db"
        con = sqlite3.connect(self.db)
        con.executescript(SCHEMA)
        con.close()
        upgrade_database(self.db, "19")
        audit.install(self.db)
        self.book = VoucherBook(self.db, "SRJ")

    def tearDown(self):
        self.tmp.cleanup()

    def log(self):
        return audit.load(self.db)

    def raw(self):
        con = sqlite3.connect(self.db, isolation_level=None)
        return con


class VoucherEntryTests(DbCase):
    def test_create_alter_cancel_each_leave_one_entry(self):
        r = self.book.save(sales(taxable="10000"))
        rows = self.log()
        self.assertEqual(len(rows), 1)                                   # one voucher entry, no row noise
        e = rows[0]
        self.assertEqual((e["action"], e["voucher_type"], e["voucher_no"], e["source"]),
                         ("Create", "Sales", r.invoice_no, "BizPulse"))
        self.assertRegex(e["logged_at"], r"^\d{4}-\d\d-\d\d \d\d:\d\d:\d\d$")
        self.assertIn("@", e["user_id"])
        self.assertIn("Dr Gupta Stores 11,800.00", e["new_text"])
        self.assertEqual(e["new_amount"], "11800.00")
        self.assertEqual(e["balances"], "Gupta Stores 40,000.00 -> 51,800.00")

        v = sales(taxable="20000")
        self.book.alter(r.voucher_id, v)
        e = self.log()[-1]
        self.assertEqual(e["action"], "Alter")
        self.assertIn("11,800.00", e["old_text"])
        self.assertIn("23,600.00", e["new_text"])
        self.assertEqual((e["old_amount"], e["new_amount"]), ("11800.00", "23600.00"))
        self.assertEqual(e["balances"], "Gupta Stores 51,800.00 -> 63,600.00")

        self.book.cancel(r.voucher_id)
        e = self.log()[-1]
        self.assertEqual((e["action"], e["new_amount"]), ("Cancel", "0.00"))
        self.assertIn("23,600.00", e["old_text"])
        self.assertEqual(e["balances"], "Gupta Stores 63,600.00 -> 40,000.00")
        self.assertEqual(len(self.log()), 3)
        self.assertTrue(audit.verify(self.db).ok)

    def test_failed_save_leaves_no_entry(self):
        v = voucher("Payment", [("Dr", "A", "5"), ("Cr", "B", "5")])
        v["items"] = [{"item": "NOPE", "quantity": 1, "rate": D("5"), "per": "Nos", "amount": D("5")}]
        con = self.raw()
        con.execute("DROP TABLE inventory_stock_registry")
        con.close()
        with self.assertRaises(StoreError):
            self.book.save(v)
        self.assertEqual(self.log(), [])

    def test_post_dated_realise(self):
        later = date.today() + timedelta(days=3)
        v = voucher("Receipt", [("Dr", "Cash", "500"), ("Cr", "Gupta Stores", "500")], d=later)
        v["status"] = "Post-Dated"
        self.book.save(v)
        self.book.realise_post_dated(later)
        e = self.log()[-1]
        self.assertEqual(e["action"], "Realise")
        self.assertEqual(e["balances"], "Gupta Stores 40,000.00 -> 39,500.00")


class RowEntryTests(DbCase):
    def test_master_change_is_labelled(self):
        m = MasterStore(self.db)
        m.save_ledger({"name": "Cash", "under": "Cash-in-Hand", "opening": "1000", "drcr": "Dr"})
        audit.install(self.db)                       # bp_ledgers is new: triggers now cover it
        m.save_ledger({"name": "Cash", "under": "Cash-in-Hand", "opening": "1500", "drcr": "Dr"}, alter=True)
        e = [r for r in self.log() if r["table_name"] == "bp_ledgers"][-1]
        self.assertEqual((e["source"], e["action"], e["old_amount"], e["new_amount"]),
                         ("BizPulse Masters", "Update", "1000.00", "1500.00"))
        self.assertIn("opening_paise=150000", e["new_text"])

    def test_outside_write_is_caught_and_sealed_later(self):
        con = self.raw()
        con.execute("UPDATE gst_sales_ledger SET taxable_value = 1 WHERE 0")             # nothing changed
        con.execute("INSERT INTO gst_sales_ledger (invoice_no, customer_name, hsn_code, taxable_value) "
                    "VALUES ('X-1', 'Someone', '8471', 99)")
        con.close()
        e = self.log()[-1]
        self.assertEqual((e["source"], e["user_id"], e["action"], e["voucher_no"]),
                         (audit.OUTSIDE, audit.OUTSIDE, "Insert", "X-1"))
        self.assertIsNone(e["row_hash"])
        self.assertIn("sealed at the next", audit.verify(self.db).message)
        self.book.save(sales())                                       # the next save seals it
        self.assertTrue(all(r["row_hash"] for r in self.log()))
        self.assertTrue(audit.verify(self.db).ok)


class ImmutabilityTests(DbCase):
    def test_append_only_and_tamper_evident(self):
        for t in ("1000", "2000", "3000"):
            self.book.save(sales(taxable=t))
        con = self.raw()
        with self.assertRaises(sqlite3.DatabaseError):
            con.execute(f"DELETE FROM {audit.LOG} WHERE id = 2")
        with self.assertRaises(sqlite3.DatabaseError):
            con.execute(f"UPDATE {audit.LOG} SET new_amount = '1.00' WHERE id = 2")
        with self.assertRaises(sqlite3.DatabaseError):
            con.execute(f"UPDATE {audit.LOG} SET row_hash = 'x' WHERE id = 2")          # sealed: no re-sealing
        head = audit.verify(self.db).head
        self.assertEqual(len(head), 64)
        con.execute(f"DROP TRIGGER {audit.LOG}_no_update")            # someone with other tools …
        con.execute(f"UPDATE {audit.LOG} SET new_amount = '1.00' WHERE id = 2")
        con.close()
        v = audit.verify(self.db)
        self.assertFalse(v.ok)
        self.assertIn("Entry 2", v.message)

    def test_deleted_entry_is_noticed(self):
        for t in ("1000", "2000", "3000"):
            self.book.save(sales(taxable=t))
        con = self.raw()
        con.execute(f"DROP TRIGGER {audit.LOG}_no_delete")
        con.execute(f"DELETE FROM {audit.LOG} WHERE id = 2")
        con.close()
        self.assertIn("missing", audit.verify(self.db).message)


class FilterTests(DbCase):
    def test_by_voucher_and_date(self):
        r1 = self.book.save(sales(taxable="1000"))
        self.book.save(voucher("Journal", [("Dr", "A", "5"), ("Cr", "B", "5")]))
        self.assertEqual([e["voucher_no"] for e in audit.load(self.db, voucher_no=r1.invoice_no[-4:])], [r1.invoice_no])
        today = date.today()
        self.assertEqual(len(audit.load(self.db, today, today)), 2)
        self.assertEqual(audit.load(self.db, today + timedelta(days=1)), [])


class GuiTests(DbCase):
    def setUp(self):
        super().setUp()
        try:
            self.root = tk.Tk()
        except tk.TclError as exc:
            self.tmp.cleanup()
            raise unittest.SkipTest(f"no display: {exc}")
        T.apply_ttk_styles(self.root)
        self.root.geometry("1100x720")

    def tearDown(self):
        for _ in range(5):
            self.root.update()
            time.sleep(0.02)
        self.root.destroy()
        gc.collect()   # old Tk objects go away on the main thread, not in a worker
        super().tearDown()

    def settle(self, until, n=150):
        for _ in range(n):
            self.root.update()
            if until():
                return
            time.sleep(0.02)

    def test_sheet_filter_verify_escape(self):
        from views.audit_trail_view import AuditTrailView

        class Key:
            def __init__(s, keysym, widget=None, state=0):
                s.keysym, s.widget, s.state = keysym, widget, state

        r = self.book.save(sales(taxable="1000"))
        self.book.save(voucher("Journal", [("Dr", "A", "5"), ("Cr", "B", "5")]))
        closed = []
        v = AuditTrailView(self.root, db_path=self.db, on_close=lambda: closed.append(1))
        v.pack(fill="both", expand=True)
        self.settle(lambda: len(v.tree.get_children()) == 2)
        self.assertEqual(v.tree.selection(), ("1",))                    # newest highlighted, at the bottom
        self.assertIn("Journal", v._detail.cget("text"))
        v._vno.insert(0, r.invoice_no)
        v.handle_key(Key("Return", v._vno))
        self.settle(lambda: len(v.tree.get_children()) == 1)
        self.assertEqual(v.tree.set("0", "voucher_no"), r.invoice_no)
        v.handle_key(Key("v", v.tree))
        self.settle(lambda: v._summary.cget("text").startswith("Intact"))
        self.assertIn("Chain head", v._summary.cget("text"))
        v._from.insert(0, "31-02-2026")
        v.handle_key(Key("Return", v._from))
        self.assertIn("DD-MM-YYYY", v._summary.cget("text"))
        v.handle_key(Key("Escape", v._from))                           # from anywhere
        self.assertEqual(closed, [1])
        self.assertEqual(str(v._detail.cget("font")), "{Segoe UI} 11 normal")


if __name__ == "__main__":
    unittest.main()
