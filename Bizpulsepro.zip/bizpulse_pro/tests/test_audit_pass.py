"""
The production audit pass: built-ins behind every menu option (backup / restore, exports, client
pack, CSV imports, banking lists, HSN / movement / GSTR-3B, the last three masters), the
mouse-highlight guard and the print setup screen.
GUI tests need a display (Tk) and are skipped where there is none.
Run from the bizpulse_pro folder:  python -m unittest discover -s tests -v
"""
from __future__ import annotations

import gc
import shutil
import sqlite3
import sys
import tempfile
import time
import tkinter as tk
import unittest
import zipfile
from datetime import date, timedelta
from decimal import Decimal as D
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "tests"))

from config import settings as S  # noqa: E402
from config import theme as T  # noqa: E402
from services import banking_docs as BD  # noqa: E402
from services import csv_import as CI  # noqa: E402
from services import data_tools as DT  # noqa: E402
from services import extra_reports as XR  # noqa: E402
from services.inventory_masters import InventoryStore  # noqa: E402
from services.masters import MasterError  # noqa: E402
from services.migrations import upgrade_database  # noqa: E402
from services.preferences import read_preferences  # noqa: E402
from services.schema import ensure_schema  # noqa: E402
from services.voucher_book import VoucherBook  # noqa: E402
from test_voucher_store import SCHEMA, sales, voucher  # noqa: E402

COMPANY = {"name": "Srijee Creations", "state_code": "19", "gstin": "", "pan": "", "address": ""}


class DbCase(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.dir = Path(self.tmp.name)
        self.db = self.dir / "bizpulse_local.db"
        con = sqlite3.connect(self.db)
        con.executescript(SCHEMA)
        con.execute("INSERT INTO inventory_stock_registry VALUES ('SKU-1', 10, 0, NULL)")
        con.commit()
        con.close()
        ensure_schema(self.db)
        upgrade_database(self.db, "19")
        self.m = InventoryStore(self.db)
        self.m.save_ledger({"name": "HDFC Bank", "under": "Bank Accounts"})
        self.m.save_ledger({"name": "Input IGST", "under": "Duties & Taxes"})
        self.m.save_ledger({"name": "Office Rent", "under": "Indirect Expenses"})
        self.book = VoucherBook(self.db, "SRJ")

    def tearDown(self):
        self.tmp.cleanup()

    def seed(self):
        oct3 = date(2026, 10, 3)
        self.book.save(sales(taxable="10000"))
        self.book.save(sales(taxable="2000", pos="07"))
        p = voucher("Payment", [("Dr", "Office Rent", "5000"), ("Cr", "HDFC Bank", "5000")], d=oct3)
        p["details"] = {"Cheque · Cheque No.": "000123", "Cheque · Favouring": "Sen Properties"}
        self.book.save(p)
        r = voucher("Receipt", [("Dr", "HDFC Bank", "2950"), ("Cr", "Gupta Stores", "2950")], d=oct3)
        r["details"] = {"Cheque · Cheque No.": "445566", "Cheque · Bank Name": "SBI"}
        self.book.save(r)
        pd = voucher("Payment", [("Dr", "Office Rent", "100"), ("Cr", "HDFC Bank", "100")],
                     d=date.today() + timedelta(days=5))
        pd["status"] = "Post-Dated"
        self.book.save(pd)
        self.book.save(voucher("Journal", [("Dr", "Input IGST", "360"), ("Cr", "Bose & Sons", "360")], d=date(2026, 10, 6)))
        it = voucher("Purchase", [("Dr", "Purchases", "500"), ("Cr", "Bose & Sons", "500")], d=date(2026, 10, 7))
        it["items"] = [{"item": "SKU-1", "quantity": 5, "rate": D("100"), "per": "Nos", "amount": D("500")}]
        self.book.save(it)


class DataToolsTests(DbCase):
    def test_backup_and_restore_round_trip(self):
        self.seed()
        backups = self.dir / "backups"
        copy = DT.backup(self.db, backups)
        self.assertEqual(DT.check(copy), "")
        self.book.save(voucher("Journal", [("Dr", "A", "1"), ("Cr", "B", "1")]))           # after the backup
        self.assertEqual(len(self.book.load_all()), 8)
        rows = DT.list_backups(backups, self.db)
        self.assertEqual(rows[0]["file"], copy.name)
        self.assertEqual(rows[0]["vouchers"], "7")
        safety = DT.restore(copy, self.db, backups)
        self.assertIn("before-restore", safety.name)
        self.assertEqual(len(self.book.load_all()), 7)                                      # back as it was
        self.assertEqual(len(VoucherBook(safety, "SRJ").load_all()), 8)                    # undo is possible

    def test_restore_refuses_bad_files(self):
        junk = self.dir / "junk.db"
        junk.write_bytes(b"not a database at all" * 100)
        with self.assertRaises(DT.DataError):
            DT.restore(junk, self.db, self.dir / "backups")
        empty = self.dir / "empty.db"
        sqlite3.connect(empty).close()
        with self.assertRaises(DT.DataError):
            DT.restore(empty, self.db, self.dir / "backups")

    def test_exports_and_client_pack(self):
        self.seed()
        csv_path = DT.ledger_balances_csv(self.db, self.dir / "exports", date(2026, 10, 31))
        text = csv_path.read_text(encoding="utf-8-sig")
        self.assertIn("HDFC Bank,Bank Accounts", text)
        last = text.strip().splitlines()[-1].split(",")
        self.assertEqual(last[2], last[3])                                                 # debits = credits
        html = DT.final_accounts_html(self.db, COMPANY, date(2026, 10, 31))
        self.assertIn("Balance Sheet as at 31-10-2026", html)
        pack = DT.client_pack(self.db, self.dir / "exports", COMPANY, date(2026, 10, 31))
        with zipfile.ZipFile(pack) as z:
            self.assertEqual(sorted(z.namelist()), ["README.txt", "day_book.csv", "final_accounts.html",
                                                    "ledger_balances.csv"])


class ImportTests(DbCase):
    def test_ledgers(self):
        f = self.dir / "ledgers.csv"
        f.write_text("Ledger Name,Group,Opening Balance,Dr/Cr,GSTIN\n"
                     "Roy Traders,Sundry Debtors,1500,Dr,\nSen Supplies,sundry creditors,-800,,\n"
                     "HDFC Bank,Bank Accounts,,,\nGhost,No Such Group,,,\n", encoding="utf-8")
        rows = CI.plan_ledgers(f, self.m)
        self.assertEqual([r["status"] for r in rows], ["Ready", "Ready", "Exists", "Error"])
        self.assertEqual((rows[1]["under"], rows[1]["opening"], rows[1]["drcr"]), ("Sundry Creditors", "800.00", "Cr"))
        done, failed = CI.post_ledgers(rows, self.m)
        self.assertEqual((len(done), len(failed)), (2, 0))
        self.assertEqual(self.m.load("Ledger", "Sen Supplies")["drcr"], "Cr")

    def test_vouchers_and_no_double_post(self):
        f = self.dir / "vouchers.csv"
        f.write_text("Ref,Date,Type,Ledger,Debit,Credit,Narration\n"
                     "1,05-10-2026,Payment,Office Rent,1000,,Rent\n1,05-10-2026,Payment,HDFC Bank,,1000,\n"
                     "2,06-10-2026,Journal,A,50,,\n2,06-10-2026,Journal,B,,40,\n"
                     "3,06-10-2026,Sales,X,10,,\n", encoding="utf-8")
        rows = CI.plan_vouchers(f, self.db)
        status = {r["ref"]: r["status"] for r in rows}
        self.assertEqual(status, {"1": "Ready", "2": "Error", "3": "Error"})
        done, _failed = CI.post_vouchers(rows, self.book)
        self.assertEqual(len(done), 1)
        again = {r["ref"]: r["status"] for r in CI.plan_vouchers(f, self.db)}
        self.assertEqual(again["1"], "Already imported")


class BankingAndReportTests(DbCase):
    def test_banking_lists(self):
        self.seed()
        acts = {a.ledger: a for a in BD.activities(self.db)}
        self.assertEqual(acts["HDFC Bank"].money_out, D("5000"))                         # post-dated not yet in
        payees = {p["payee"]: p for p in BD.bank_payments(self.db)}       # a post-dated cheque is printed ahead
        self.assertEqual(set(payees), {"Sen Properties", "Office Rent"})
        self.assertEqual(payees["Sen Properties"]["cheque"]["no"], "000123")
        self.assertEqual({r["cheque_no"] for r in BD.cheque_register(self.db)}, {"000123", "445566"})
        batch = BD.deposit_batches(self.db)[0]
        self.assertEqual((batch["bank"], batch["rows"][0]["drawn_on"]), ("HDFC Bank", "SBI"))
        self.assertEqual(len(BD.post_dated(self.db)), 1)

    def test_hsn_movement_3b(self):
        self.seed()
        start, end = date(2026, 4, 1), date(2026, 10, 31)
        hsn = XR.hsn_summary(self.db, start, end, "19")
        self.assertEqual(sum(r.taxable for r in hsn), D("12000.00"))
        mv = {r.item: r for r in XR.movement(self.db, start, end)}
        self.assertEqual((mv["SKU-1"].qty_in, mv["SKU-1"].on_hand), (5, 15))
        g = XR.gstr3b(self.db, 2026, 10, "19", S.INPUT_TAX_LEDGERS)
        self.assertEqual(g.outward["taxable"], D("12000.00"))
        self.assertEqual(g.itc["igst"], D("3.60") * 100)
        self.assertEqual(g.net("igst"), D("0.00"))
        self.assertIn("07 Delhi", g.unregistered_inter)


class MasterTests(DbCase):
    def test_currency_category_godown(self):
        self.m.save_currency({"code": "usd", "name": "US Dollar", "symbol": "$"})
        self.assertEqual(self.m.currency_list(), [("USD", "US Dollar")])
        with self.assertRaises(MasterError):
            self.m.save_currency({"code": "INR", "name": "Rupee"})
        self.m.save_stock_category({"name": "Apparel"})
        self.m.save_stock_category({"name": "Shirts", "under": "apparel"})
        self.assertEqual(self.m.load("Stock Category", "Shirts")["under"], "Apparel")
        with self.assertRaises(MasterError):                                   # no loops
            self.m.save_stock_category({"name": "Apparel", "under": "Shirts"}, alter=True)
        self.m.save_godown({"name": "Kolkata Warehouse", "address": "Howrah"})
        self.assertEqual(self.m.load("Godown", "Kolkata Warehouse")["address"], "Howrah")


# ---- GUI ---------------------------------------------------------------------------------------
class Ev:
    def __init__(self, x, y):
        self.x_root, self.y_root = x, y


class Key:
    def __init__(self, keysym, widget=None, state=0):
        self.keysym, self.widget, self.state = keysym, widget, state


class GuiTests(DbCase):
    def setUp(self):
        super().setUp()
        try:
            self.root = tk.Tk()
        except tk.TclError as exc:
            self.tmp.cleanup()
            raise unittest.SkipTest(f"no display: {exc}")
        T.apply_ttk_styles(self.root)
        self.root.geometry("1100x720")

    def tearDown(self):
        for _ in range(5):
            self.root.update()
            time.sleep(0.02)
        self.root.destroy()
        gc.collect()   # old Tk objects go away on the main thread, not in a worker
        super().tearDown()

    def test_pointer_guard_in_menu_boxes(self):
        from components.gateway_menu import GatewayMenu
        from views.masters_overlay import MastersOverlay
        area = tk.Frame(self.root)
        area.pack(fill="both", expand=True)
        box = MastersOverlay(area, "Create", on_choose=lambda *_a: None, on_close=lambda: None)
        box.set_active(3)                                              # chosen with the keyboard
        row = box._rows[0]["widgets"][0]
        row.event_generate("<Motion>", x=5, y=5)                        # box opened under a resting pointer
        self.root.update()
        self.assertEqual(box._active, 3)
        box._pointer.moved(Ev(100, 100))                               # where the pointer rests
        self.assertFalse(box._pointer.moved(Ev(100, 100)))             # synthetic event, same place
        self.assertTrue(box._pointer.moved(Ev(104, 100)))              # a real movement
        gw = GatewayMenu(area, S.GATEWAY_SECTIONS, on_select=lambda _l: None, submenus=S.GATEWAY_SUBMENUS)
        gw.show()
        gw.set_active(2)
        gw._hover(gw._nav()[0], Ev(50, 50))                            # first event: only recorded
        self.assertEqual(gw._active, 2)
        gw._hover(gw._nav()[0], Ev(50, 50))                            # no movement: keyboard choice stays
        self.assertEqual(gw._active, 2)
        gw._hover(gw._nav()[0], Ev(58, 52))                            # moved: the bar follows the mouse
        self.assertEqual(gw._active, 0)

    def test_print_setup_saves_to_a_settings_copy(self):
        from views.print_setup_view import PrintSetupView
        path = self.dir / "settings.py"
        shutil.copy(ROOT / "config" / "settings.py", path)
        before = (S.PRINT_PAPER, S.PRINT_SHOW_HSN, S.PRINT_FOOTER)
        try:
            v = PrintSetupView(self.root, on_close=lambda: None, settings_path=path)
            v.pack(fill="both", expand=True)
            v.handle_key(Key("p"))
            for _ in range(100):
                self.root.update()
                if read_preferences(path)["PRINT_PAPER"] == "80 mm":
                    break
                time.sleep(0.02)
            self.assertEqual(read_preferences(path)["PRINT_PAPER"], "80 mm")
            for _ in range(100):
                self.root.update()
                if S.PRINT_PAPER == "80 mm":
                    break
                time.sleep(0.02)
            self.assertEqual(S.PRINT_PAPER, "80 mm")                    # used from the next print
        finally:
            S.PRINT_PAPER, S.PRINT_SHOW_HSN, S.PRINT_FOOTER = before

    def test_tool_screens_load(self):
        from views import tool_screens as TS
        self.seed()
        screens = [TS.cheque_register_screen(self.root, db_path=self.db, on_close=lambda: None),
                   TS.hsn_screen(self.root, db_path=self.db, company_state="19", on_close=lambda: None,
                                 today=date(2026, 10, 31)),
                   TS.gstr3b_screen(self.root, db_path=self.db, company_state="19", input_ledgers=S.INPUT_TAX_LEDGERS,
                                    on_close=lambda: None, today=date(2026, 10, 10))]
        for s in screens:
            s.pack(fill="both", expand=True)
        for _ in range(100):
            self.root.update()
            if all(s.rows for s in screens):
                break
            time.sleep(0.02)
        self.assertEqual(len(screens[0].rows), 2)
        self.assertEqual(screens[1].rows[-1]["hsn"], "Total")
        g = screens[2]
        g.handle_key(Key("v"))
        self.assertEqual(g.period(), "09-2026")


if __name__ == "__main__":
    unittest.main()
