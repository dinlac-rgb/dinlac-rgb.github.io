"""
Foreign-currency vouchers (services/forex.py, the Currency row and Exchange Rate box), Alt+2
duplicate and Alt+X cancel (VoucherBook.cancel, Day Book, voucher screen).
GUI tests need a display (Tk) and are skipped where there is none.
Run from the bizpulse_pro folder:  python -m unittest discover -s tests -v
"""
from __future__ import annotations

import gc
import sqlite3
import sys
import tempfile
import time
import tkinter as tk
import unittest
from datetime import date
from decimal import Decimal as D
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
sys.path.insert(0, str(Path(__file__).resolve().parent))

from config import theme as T  # noqa: E402
from services import reports as R  # noqa: E402
from services.forex import convert_lines, normal_code, parse_rate, split_designator, to_base  # noqa: E402
from services.gstr1 import build_gstr1  # noqa: E402
from services.migrations import upgrade_database  # noqa: E402
from services.voucher_book import VoucherBook  # noqa: E402
from services.voucher_store import StoreError  # noqa: E402
from test_masters import make_gstin  # noqa: E402
from test_voucher_store import SCHEMA, sales, voucher  # noqa: E402

ALT = 0x0008


def usd_payment(d=date(2026, 10, 5)):
    lines, amounts, note = convert_lines([{"side": "Dr", "ledger": "Freight Abroad", "amount": D("100.01")},
                                          {"side": "Cr", "ledger": "HDFC Bank", "amount": D("100.01")}], D("83.25"))
    v = voucher("Payment", [(ln["side"], ln["ledger"], str(ln["amount"])) for ln in lines], d=d)
    v["forex"] = {"currency": "USD", "rate": D("83.25"), "amounts": amounts, "note": note}
    return v


class ForexRuleTests(unittest.TestCase):
    def test_designators(self):
        self.assertEqual(split_designator("USD 1,200"), ("USD", "1,200"))
        self.assertEqual(split_designator("1200 eur"), ("EUR", "1200"))
        self.assertEqual(split_designator("$1,200.50"), ("USD", "1,200.50"))
        self.assertEqual(split_designator("1,200"), (None, "1,200"))
        self.assertEqual(normal_code(""), "INR")
        self.assertEqual(normal_code("gbp"), "GBP")
        with self.assertRaises(ValueError):
            normal_code("US")

    def test_rate_checks(self):
        self.assertEqual(parse_rate("83.25"), D("83.25"))
        for bad in ("0", "-1", "abc", "1.1234567"):
            with self.assertRaises(ValueError, msg=bad):
                parse_rate(bad)

    def test_conversion_balances_after_rounding(self):
        lines = [{"side": "Dr", "ledger": "A", "amount": D("0.01")}, {"side": "Dr", "ledger": "B", "amount": D("0.01")},
                 {"side": "Cr", "ledger": "C", "amount": D("0.02")}]
        out, foreign, note = convert_lines(lines, D("0.5"))           # 0.005 -> 0.01 each, 0.01 on C
        dr = sum(ln["amount"] for ln in out if ln["side"] == "Dr")
        cr = sum(ln["amount"] for ln in out if ln["side"] == "Cr")
        self.assertEqual(dr, cr)
        self.assertEqual(foreign, [D("0.01"), D("0.01"), D("0.02")])
        self.assertIn("Rounding", note)
        self.assertEqual(to_base(D("100.01"), D("83.25")), D("8325.83"))


class DbCase(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.db = Path(self.tmp.name) / "bizpulse_local.db"
        con = sqlite3.connect(self.db)
        con.executescript(SCHEMA)
        con.execute("INSERT INTO inventory_stock_registry VALUES ('SKU-1', 10, 0, NULL)")
        con.commit()
        con.close()
        upgrade_database(self.db, "19")
        self.book = VoucherBook(self.db, "SRJ")

    def tearDown(self):
        self.tmp.cleanup()

    def q(self, sql, *args):
        con = sqlite3.connect(self.db)
        try:
            return con.execute(sql, args).fetchall()
        finally:
            con.close()


class ForexStoreTests(DbCase):
    def test_saved_in_rupees_with_foreign_amounts_kept(self):
        r = self.book.save(usd_payment())
        self.assertEqual(self.q("SELECT amount_paise FROM bp_voucher_lines WHERE voucher_id = ?", r.voucher_id),
                         [(832583,), (832583,)])
        self.assertEqual(self.q("SELECT currency, rate, foreign_cents FROM bp_voucher_forex ORDER BY line_no"),
                         [("USD", "83.25", 10001), ("USD", "83.25", 10001)])
        back = self.book.load_voucher(r.voucher_id)
        self.assertEqual(back["forex"]["amounts"], [D("100.01"), D("100.01")])
        self.assertEqual(self.book.last_rate("USD"), D("83.25"))
        self.assertIsNone(self.book.last_rate("EUR"))
        self.assertEqual(self.book.load_all()[0]["forex"]["currency"], "USD")

    def test_alter_back_to_rupees_drops_forex_rows(self):
        r = self.book.save(usd_payment())
        v = voucher("Payment", [("Dr", "Freight Abroad", "8000"), ("Cr", "HDFC Bank", "8000")], d=date(2026, 10, 5))
        self.book.alter(r.voucher_id, v)
        self.assertEqual(self.q("SELECT count(*) FROM bp_voucher_forex"), [(0,)])
        self.assertIsNone(self.book.load_voucher(r.voucher_id)["forex"])


class CancelTests(DbCase):
    def test_sales_cancel_keeps_number_and_takes_back_effects(self):
        r1 = self.book.save(sales(taxable="10000"))                   # Gupta Stores: 40,000 -> 51,800
        r2 = self.book.save(sales(taxable="2000"))
        self.assertEqual(self.q("SELECT outstanding_balance FROM corporate_ledger_summary WHERE account_id='C001'"),
                         [(54160.0,)])
        result = self.book.cancel(r2.voucher_id)
        self.assertTrue(result.account_updates)
        self.assertEqual(self.q("SELECT outstanding_balance FROM corporate_ledger_summary WHERE account_id='C001'"),
                         [(51800.0,)])
        self.assertEqual(self.q("SELECT status, invoice_no, voucher_no FROM bp_vouchers WHERE id = ?", r2.voucher_id),
                         [("Cancelled", r2.invoice_no, 2)])
        self.assertEqual(self.q("SELECT count(*) FROM gst_sales_ledger WHERE invoice_no = ?", r2.invoice_no), [(0,)])
        self.assertEqual(self.book.unused_numbers("Sales"), [])            # no hole in the series
        self.assertEqual(self.book.next_number("Sales"), 3)
        r3 = self.book.save(sales(taxable="500"))
        self.assertTrue(r3.invoice_no.endswith("0003"), r3.invoice_no)     # cancelled invoice number not reused
        self.assertEqual(self.q("SELECT field FROM bp_voucher_details WHERE voucher_id = ?", r2.voucher_id),
                         [("Cancelled on",)])
        self.assertIsNotNone(r1)

    def test_reports_ledger_and_gstr1_leave_it_out(self):
        self.book.save(sales(taxable="10000"))
        r2 = self.book.save(sales(taxable="2000"))
        self.book.cancel(r2.voucher_id)
        rep = R.build_reports(self.db, date(2026, 10, 31))
        self.assertEqual(rep.pl["Sales Accounts"].amount, D("10000.00"))
        st = self.book.ledger_statement("Sales", date(2026, 10, 31))
        self.assertEqual(len(st["rows"]), 1)
        g = build_gstr1(self.db, 2026, 10, make_gstin("19", "AAPFU0939F"), "19")
        doc = g.payload["doc_issue"]["doc_det"][0]["docs"][0]
        self.assertEqual((doc["totnum"], doc["cancel"], doc["net_issue"]), (2, 1, 1))
        self.assertEqual(g.summary["b2cs"]["count"], 1)

    def test_item_purchase_cancel_puts_stock_back(self):
        v = voucher("Purchase", [("Dr", "Purchases", "500"), ("Cr", "Bose & Sons", "500")])
        v["items"] = [{"item": "SKU-1", "quantity": 5, "rate": D("100"), "per": "Nos", "amount": D("500")}]
        r = self.book.save(v)
        self.assertEqual(self.q("SELECT qty_on_hand FROM inventory_stock_registry"), [(15,)])
        self.book.cancel(r.voucher_id)
        self.assertEqual(self.q("SELECT qty_on_hand FROM inventory_stock_registry"), [(10,)])

    def test_cancelled_cannot_be_altered_or_cancelled_again(self):
        r = self.book.save(voucher("Journal", [("Dr", "A", "1"), ("Cr", "B", "1")]))
        self.book.cancel(r.voucher_id)
        with self.assertRaises(StoreError):
            self.book.cancel(r.voucher_id)
        with self.assertRaises(StoreError):
            self.book.alter(r.voucher_id, voucher("Journal", [("Dr", "A", "2"), ("Cr", "B", "2")]))
        self.assertEqual(self.book.load_all()[0]["status"], "Cancelled")


class GuiCase(DbCase):
    def setUp(self):
        super().setUp()
        try:
            self.root = tk.Tk()
        except tk.TclError as exc:
            self.tmp.cleanup()
            raise unittest.SkipTest(f"no display: {exc}")
        T.apply_ttk_styles(self.root)
        self.root.geometry("1100x720")

    def tearDown(self):
        for _ in range(5):
            self.root.update()
            time.sleep(0.02)
        self.root.destroy()
        gc.collect()   # old Tk objects go away on the main thread, not in a worker
        super().tearDown()


class Key:
    def __init__(self, keysym, widget=None, state=0):
        self.keysym, self.widget, self.state = keysym, widget, state


class VoucherScreenTests(GuiCase):
    def make(self, **kw):
        from views.vouchers_view import VoucherView
        self.saved = []
        v = VoucherView(self.root, voucher_type="Payment", number_for=self.book.next_number,
                        on_accept=lambda x, done: (self.saved.append(x), done(True)), on_close=lambda: None,
                        mode="Single Entry", rate_source=lambda _c: D("83.10"), **kw)
        v.pack(fill="both", expand=True)
        self.root.update()
        return v

    def test_currency_box_and_rupee_lines(self):
        v = self.make()
        self.assertIn(v._currency_entry, v._field_order())
        self.assertEqual(v._field_order().index(v._currency_entry), 1)       # right after the date
        v._currency_entry.delete(0, "end")
        v._currency_entry.insert(0, "usd")
        v._advance(v._currency_entry)
        self.assertIsNotNone(v._fx_box)
        for _ in range(30):                                                    # last rate offered
            self.root.update()
            if v._fx_box.rate.get():
                break
            time.sleep(0.02)
        self.assertEqual(v._fx_box.rate.get(), "83.10")
        v._fx_box.rate.delete(0, "end")
        v._fx_box.rate.insert(0, "83.25")
        v.handle_key(Key("Return", v._fx_box.rate))
        self.assertIsNone(v._fx_box)
        self.assertEqual(v.currency, ("USD", D("83.25")))
        v._account.insert(0, "HDFC Bank")
        v._single_lines[0].ledger.insert(0, "Freight Abroad")
        v._single_lines[0].amount_entry.insert(0, "100.01")
        v._refresh_single_total()
        self.assertEqual(v._single_lines[0].inr.cget("text"), "8,325.83")
        self.assertEqual(v._s_amount_head.cget("text"), "Amount (USD)")
        v.accept()
        x = self.saved[0]
        self.assertEqual([ln["amount"] for ln in x["lines"]], [D("8325.83"), D("8325.83")])
        self.assertEqual(x["forex"]["amounts"], [D("100.01"), D("100.01")])
        self.assertEqual(x["total"], D("8325.83"))
        self.assertEqual(v.currency, ("INR", D("1")))                         # next voucher starts in rupees

    def test_designator_in_amount_and_escape_steps_back(self):
        v = self.make()
        amount = v._single_lines[0].amount_entry
        amount.insert(0, "EUR 50")
        self.assertFalse(v._valid_here(amount))
        self.assertEqual(v._fx_box.currency, "EUR")
        self.assertEqual(amount.get(), "50")
        v.handle_key(Key("Escape", v._fx_box.rate))                          # closes the box only
        self.assertIsNone(v._fx_box)
        self.assertEqual(v.currency[0], "INR")
        self.root.update()
        self.assertIs(v.focus_get(), amount)
        v.handle_key(Key("Escape", v._currency_entry))                       # one field back: the date
        self.root.update()
        self.assertIs(v.focus_get(), v._date)

    def test_duplicate_template_takes_next_number(self):
        r = self.book.save(usd_payment())
        data = self.book.load_voucher(r.voucher_id)
        v = self.make(template=data)
        self.assertIn("No.  2", v._number_label.cget("text"))
        self.assertEqual(v.currency, ("USD", D("83.25")))
        self.assertEqual([ln.ledger.get() for ln in v._lines[:2]], ["Freight Abroad", "HDFC Bank"])
        self.assertEqual(v._lines[0].amount_entry.get(), "100.01")
        self.assertIn("Duplicate of Payment No. 1", v._status.cget("text"))
        v.accept()
        self.assertEqual(self.saved[0]["forex"]["amounts"], [D("100.01"), D("100.01")])

    def test_alteration_alt_keys(self):
        r = self.book.save(voucher("Journal", [("Dr", "A", "5"), ("Cr", "B", "5")]))
        hits = []
        v = self.make(existing=self.book.load_voucher(r.voucher_id), on_duplicate=lambda: hits.append("dup"),
                      on_cancel_voucher=lambda: hits.append("cancel"))
        self.assertEqual([m.key for m in v.macros()][:2], ["Alt+2", "Alt+X"])
        v.handle_key(Key("2", v._date, ALT))
        v.handle_key(Key("x", v._date, ALT))
        self.assertEqual(hits, ["dup", "cancel"])

    def test_canvas_white(self):
        v = self.make()
        self.assertEqual(T.WHITE.upper(), "#FFFFFF")
        self.assertEqual(v.cget("bg").upper(), "#FFFFFF")


class DaybookTests(GuiCase):
    def test_alt_keys_and_cancelled_row(self):
        from views.daybook_view import DaybookView
        r1 = self.book.save(voucher("Journal", [("Dr", "A", "5"), ("Cr", "B", "5")]))
        r2 = self.book.save(voucher("Journal", [("Dr", "A", "7"), ("Cr", "B", "7")]))
        self.book.cancel(r2.voucher_id)
        hits = []
        dv = DaybookView(self.root, self.book.load_all(), on_close=lambda: None,
                         on_duplicate=lambda i: hits.append(("dup", i)), on_cancel=lambda i: hits.append(("x", i)))
        dv.pack(fill="both", expand=True)
        dv.focus_first()
        self.root.update()
        self.assertEqual(dv._debit_total.cget("text"), "5.00")              # cancelled one not in the total
        row = dv._tree.item(dv._tree.get_children()[-1])
        self.assertIn("cancelled", row["tags"])
        self.assertEqual(row["values"][4], "")
        dv.handle_key(Key("2", dv._tree, ALT))
        dv.select_voucher(r1.voucher_id)
        dv.handle_key(Key("X", dv._tree, ALT))
        self.assertEqual(hits, [("dup", r2.voucher_id), ("x", r1.voucher_id)])
        self.assertEqual([m.key for m in dv.macros()], ["Alt+2", "Alt+X"])


if __name__ == "__main__":
    unittest.main()
