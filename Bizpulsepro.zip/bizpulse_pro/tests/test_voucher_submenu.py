"""
Corridor's inline Vouchers submenu, the per-type voucher screens (Journal By/To, Sales Party A/c,
Purchase supplier invoice, Credit / Debit Note tints) and the action-bar keys.
GUI tests need a display (Tk) and are skipped where there is none.
Run from the bizpulse_pro folder:  python -m unittest discover -s tests -v
"""
from __future__ import annotations

import gc
import sqlite3
import sys
import tempfile
import time
import tkinter as tk
import unittest
from datetime import date
from decimal import Decimal as D
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
sys.path.insert(0, str(Path(__file__).resolve().parent))

from components.gateway_menu import GatewayMenu  # noqa: E402
from components.macro_bar import Macro, MacroBar  # noqa: E402
from config import settings as S  # noqa: E402
from config import theme as T  # noqa: E402
from services.voucher_store import VoucherStore  # noqa: E402
from views.vouchers_view import DOUBLE, VoucherView  # noqa: E402


def make_root():
    try:
        root = tk.Tk()
    except tk.TclError as exc:
        raise unittest.SkipTest(f"no display: {exc}")
    T.apply_ttk_styles(root)
    root.geometry("1100x720")
    return root


class Key:
    def __init__(self, keysym, widget=None, state=0):
        self.keysym, self.widget, self.state = keysym, widget, state


def settle(root, n=5):
    for _ in range(n):
        root.update()
        time.sleep(0.02)


class SubmenuTests(unittest.TestCase):
    def setUp(self):
        self.root = make_root()
        self.chosen = []
        canvas = tk.Frame(self.root, bg=T.WHITE)
        canvas.pack(fill="both", expand=True)
        self.root.update()
        self.menu = GatewayMenu(canvas, S.GATEWAY_SECTIONS, on_select=self.chosen.append,
                                submenus=S.GATEWAY_SUBMENUS)
        self.menu.show()
        settle(self.root)

    def tearDown(self):
        self.root.destroy()
        gc.collect()   # old Tk objects go away on the main thread, not in a worker

    def test_v_opens_submenu_and_letters_choose_inside_it(self):
        m = self.menu
        m.handle_key(Key("v"))
        self.assertEqual(m.expanded, "Vouchers")
        self.assertEqual(self.chosen, [])                    # V opens the list, not a screen
        self.assertEqual(m.active_label, "Contra")
        m.handle_key(Key("p"))                               # P = Payment here, not Profit & Loss
        self.assertEqual(self.chosen, ["Payment"])
        m.handle_key(Key("u"))
        m.handle_key(Key("t"))
        self.assertEqual(self.chosen, ["Payment", "Purchase", "Debit Note"])

    def test_enter_opens_and_arrows_stay_in_submenu(self):
        m = self.menu
        m.set_active(next(i for i, r in enumerate(m._top) if r.label == "Vouchers"))
        m.handle_key(Key("Return"))
        self.assertEqual(m.expanded, "Vouchers")
        for _ in range(3):
            m.handle_key(Key("Down"))
        self.assertEqual(m.active_label, "Journal")
        m.handle_key(Key("Up"))
        m.handle_key(Key("Return"))
        self.assertEqual(self.chosen, ["Receipt"])

    def test_escape_collapses_back_to_vouchers_row(self):
        m = self.menu
        m.handle_key(Key("v"))
        m.handle_key(Key("Down"))
        self.assertEqual(m.handle_key(Key("Escape")), "break")
        self.assertIsNone(m.expanded)
        self.assertEqual(m.active_label, "Vouchers")
        self.assertFalse(m._sub_frames["Vouchers"].winfo_manager())

    def test_submenu_fits_the_canvas(self):
        m = self.menu
        m.handle_key(Key("v"))
        settle(self.root)
        bottom = m.winfo_y() + m.winfo_height()
        self.assertLessEqual(bottom, m.master.winfo_height())
        m.handle_key(Key("Escape"))
        settle(self.root)
        self.assertTrue(all(sec.winfo_manager() for sec, _l in m._section_frames))   # all sections back

    def test_submenu_items_and_typography(self):
        self.assertEqual([k for k, _l in S.VOUCHER_SUBMENU], list("CPRJSUNT"))
        row = m_row = next(r for r in self.menu._subs["Vouchers"] if r.label == "Purchase")
        texts = [(w.cget("text"), str(w.cget("font"))) for w in m_row.widgets if isinstance(w, tk.Label)]
        self.assertEqual(texts, [("P", "{Segoe UI} 11 normal"), ("u", "{Segoe UI} 11 bold"),
                                 ("rchase", "{Segoe UI} 11 normal")])
        self.assertTrue(all(int(w.cget("padx")) == 0 for w in row.widgets[2:] if isinstance(w, tk.Label)))


class VoucherTypeTests(unittest.TestCase):
    def setUp(self):
        self.root = make_root()
        self.saved = []
        self.view = VoucherView(self.root, voucher_type="Journal", number_for=lambda _t: 1,
                                on_accept=lambda v, done: (self.saved.append(v), done(True)), on_close=lambda: None)
        self.view.pack(fill="both", expand=True)
        self.root.update()

    def tearDown(self):
        settle(self.root)
        self.root.destroy()
        gc.collect()   # old Tk objects go away on the main thread, not in a worker

    def test_journal_reads_by_to(self):
        v = self.view
        self.assertEqual(v._layout, DOUBLE)
        self.assertEqual(v._side_head.cget("text"), "By/To")
        self.assertEqual([ln.side_text.get() for ln in v._lines], ["By", "To"])
        self.assertEqual([ln.side.get() for ln in v._lines], ["Dr", "Cr"])      # saved as Dr / Cr
        v.set_type("Payment")
        v.set_mode(DOUBLE)
        self.assertEqual(v._side_head.cget("text"), "Dr/Cr")

    def test_notes_are_tinted_and_tint_clears(self):
        v = self.view
        v.set_type("Credit Note")
        self.assertEqual(v.cget("bg"), S.VOUCHER_TINTS["Credit Note"])
        self.assertEqual(v._lines[0].ledger.cget("bg"), T.WHITE)                  # entry boxes stay white
        v.set_type("Debit Note")
        self.assertEqual(v.cget("bg"), S.VOUCHER_TINTS["Debit Note"])
        v.set_type("Journal")
        self.assertEqual(v.cget("bg"), T.WHITE)

    def test_action_bar_follows_type(self):
        v = self.view
        self.assertEqual(v.active_macro(), "F7")
        v.set_type("Sales")
        self.assertEqual(v.active_macro(), "F8")
        v.set_type("Credit Note")
        self.assertEqual(v.active_macro(), "Ctrl+F8")
        keys = [m.key for m in v.macros()]
        self.assertNotIn("F10", keys)
        self.assertIn("Ctrl+F9", keys)

    def test_ctrl_f9_key_on_the_bar(self):
        bar = MacroBar(self.root)
        hits = []
        bar.set([Macro.fkey("F9", "Purchase", lambda: hits.append("F9")),
                 Macro.fkey("Ctrl+F9", "Debit Note", lambda: hits.append("Ctrl+F9"))])
        bar.handle_key(Key("F9"))
        bar.handle_key(Key("F9", state=T.MOD_CTRL))
        self.assertEqual(hits, ["F9", "Ctrl+F9"])

    def test_purchase_supplier_invoice_saved_in_details(self):
        v = self.view
        v.set_type("Purchase")
        v.set_invoice_mode("As Voucher")
        self.assertTrue(v._party_row.winfo_manager())
        self.assertTrue(v._supplier_inv.winfo_manager())
        v._party.insert(0, "Bose Suppliers")
        v._supplier_inv.insert(0, "INV-778")
        v._supplier_date.insert(0, "31-13-2026")
        v._lines[0].side.set("Dr"); v._lines[0].apply_side()
        v._lines[0].ledger.insert(0, "Purchases"); v._lines[0].amount_entry.insert(0, "500")
        v._lines[1].side.set("Cr"); v._lines[1].apply_side()
        v._lines[1].ledger.insert(0, "Bose Suppliers"); v._lines[1].amount_entry.insert(0, "500")
        v.accept()
        self.assertEqual(self.saved, [])
        self.assertIn("DD-MM-YYYY", v._status.cget("text"))
        v._supplier_date.delete(0, "end")
        v._supplier_date.insert(0, "30-09-2026")
        v.accept()
        self.assertEqual(self.saved[0]["details"], {"Party A/c": "Bose Suppliers", "Supplier Invoice No.": "INV-778",
                                                    "Supplier Invoice Date": "30-09-2026"})

    def test_sales_party_must_be_debited(self):
        v = self.view
        v.set_type("Sales")
        v.set_invoice_mode("As Voucher")
        self.assertTrue(v._party_row.winfo_manager())
        self.assertFalse(v._supplier_inv.winfo_manager())              # supplier fields: Purchase only
        v._party.insert(0, "Gupta Stores")
        v._advance_type_field(v._party)                       # fills the first Dr line, opens Dispatch Details
        self.assertEqual((v._lines[0].side.get(), v._lines[0].ledger.get()), ("Dr", "Gupta Stores"))
        self.assertEqual(v._card.title, "Dispatch Details")
        v.handle_key(Key("Escape"))
        self.assertIsNone(v._card)
        v._lines[0].ledger.delete(0, "end")
        v._lines[0].ledger.insert(0, "Someone Else")
        v._lines[0].amount_entry.insert(0, "100")
        v._lines[1].ledger.insert(0, "Sales"); v._lines[1].amount_entry.insert(0, "100")
        v.accept()
        self.assertIn("not debited", v._status.cget("text"))


class DetailsStoreTests(unittest.TestCase):
    def test_details_round_trip(self):
        from test_voucher_store import SCHEMA, voucher
        with tempfile.TemporaryDirectory() as tmp:
            db = Path(tmp) / "bizpulse_local.db"
            con = sqlite3.connect(db)
            con.executescript(SCHEMA)
            con.close()
            store = VoucherStore(db, "SRJ")
            v = voucher("Purchase", [("Dr", "Purchases", "500"), ("Cr", "Bose", "500")], d=date(2026, 9, 30))
            v["details"] = {"Supplier Invoice No.": "INV-778", "Supplier Invoice Date": "", "Party": " "}
            store.save(v)
            store.save(voucher("Journal", [("Dr", "A", "1"), ("Cr", "B", "1")]))      # no details at all
            loaded = store.load_all()
        self.assertEqual(loaded[0]["details"], {"Supplier Invoice No.": "INV-778"})   # blanks not stored
        self.assertEqual(loaded[1]["details"], {})
        self.assertEqual(loaded[0]["total"], D("500.00"))


if __name__ == "__main__":
    unittest.main()
