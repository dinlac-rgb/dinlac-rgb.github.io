"""
Masters (Group, Ledger, GST Classification): the store's checks and writes, how the reports
use them, the Create / Alter forms (Enter forward, Esc back, last Enter saves), the voucher
screen's Esc-back / Tab rules, and the Vouchers submenu telling the window it opened.
GUI tests need a display (Tk) and are skipped where there is none.
Run from the bizpulse_pro folder:  python -m unittest discover -s tests -v
"""
from __future__ import annotations

import gc
import sqlite3
import sys
import tempfile
import time
import tkinter as tk
import unittest
from datetime import date
from decimal import Decimal as D
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
sys.path.insert(0, str(Path(__file__).resolve().parent))

import services.reports as R  # noqa: E402
from config import settings as S  # noqa: E402
from config import theme as T  # noqa: E402
from config.ledger_groups import RESERVED_GROUPS  # noqa: E402
from services.gst import GSTIN_CHARS  # noqa: E402
from services.ledgers import load_ledger_catalogue  # noqa: E402
from services.masters import MasterError, MasterStore  # noqa: E402
from services.voucher_store import VoucherStore  # noqa: E402
from test_voucher_store import SCHEMA, voucher  # noqa: E402


def make_gstin(state: str, pan: str) -> str:
    body = f"{state}{pan}1Z"
    factor, total = 2, 0
    for ch in reversed(body):
        addend = factor * GSTIN_CHARS.index(ch)
        factor = 1 if factor == 2 else 2
        total += addend // 36 + addend % 36
    return body + GSTIN_CHARS[(36 - total % 36) % 36]


class Key:
    def __init__(self, keysym, widget=None, state=0):
        self.keysym, self.widget, self.state = keysym, widget, state


def settle(root, until=None, n=100):
    for _ in range(n):
        root.update()
        if until is not None and until():
            return
        time.sleep(0.02)


class DbCase(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.db = Path(self.tmp.name) / "bizpulse_local.db"
        con = sqlite3.connect(self.db)
        con.executescript(SCHEMA)
        con.close()
        self.m = MasterStore(self.db)

    def tearDown(self):
        self.tmp.cleanup()


class MasterStoreTests(DbCase):
    def test_twenty_eight_reserved_groups(self):
        self.assertEqual(len(RESERVED_GROUPS), 28)
        self.assertEqual(self.m.group_names()[:28], list(RESERVED_GROUPS))

    def test_groups(self):
        self.m.save_group({"name": "  Office   Expenses ", "under": "indirect expenses"})
        self.assertEqual(self.m.custom_groups(), {"Office Expenses": "Indirect Expenses"})
        for bad in ({"name": "office expenses", "under": "Indirect Expenses"},       # duplicate
                    {"name": "Sundry Debtors", "under": "Current Assets"},           # reserved
                    {"name": "Travel", "under": "No Such Group"},
                    {"name": "", "under": "Current Assets"},
                    {"name": "Bad\x07Name", "under": "Current Assets"}):
            with self.assertRaises(MasterError):
                self.m.save_group(bad)
        self.m.save_group({"name": "Travel", "under": "Office Expenses"})
        self.assertEqual(self.m.primary_of("Travel"), "Indirect Expenses")
        with self.assertRaises(MasterError):                                        # a loop
            self.m.save_group({"name": "Office Expenses", "under": "Travel"}, alter=True)

    def test_ledgers(self):
        pan = "ABCDE1234F"
        good = make_gstin("19", pan)
        msg = self.m.save_ledger({"name": "Roy Traders", "under": "Sundry Debtors", "address": "Hill Cart Road",
                                  "state": "west bengal", "pan": pan.lower(), "gstin": good,
                                  "opening": "12,500.50", "drcr": "Dr"})
        self.assertIn("opening 12,500.50 Dr", msg)
        loaded = self.m.load("Ledger", "roy traders")
        self.assertEqual((loaded["state"], loaded["pan"], loaded["opening"], loaded["mailing_name"]),
                         ("West Bengal", pan, "12500.50", "Roy Traders"))
        cases = [
            {"name": "X1", "under": "Sundry Debtors", "state": "Maharashtra", "gstin": good},     # state mismatch
            {"name": "X2", "under": "Sundry Debtors", "pan": "ZZZZZ9999Z", "gstin": good},       # PAN mismatch
            {"name": "X3", "under": "Sundry Debtors", "pan": "1234"},                            # PAN format
            {"name": "X4", "under": "Sales Accounts", "opening": "100", "drcr": "Cr"},           # P&L opening
            {"name": "X5", "under": "Sundry Debtors", "opening": "-5"},
            {"name": "Current Assets", "under": "Sundry Debtors"},                               # a group's name
            {"name": "ROY TRADERS", "under": "Sundry Debtors"},                                  # duplicate
            {"name": "X6", "under": "Sundry Debtors", "state": "Atlantis"},
        ]
        for values in cases:
            with self.assertRaises(MasterError, msg=values["name"]):
                self.m.save_ledger(values)
        self.m.save_ledger({"name": "Roy Traders", "under": "Sundry Debtors", "opening": "500", "drcr": "Cr"},
                           alter=True)
        self.assertEqual(self.m.load("Ledger", "Roy Traders")["drcr"], "Cr")

    def test_gst_classification(self):
        self.m.save_classification({"name": "Electronics GST 18%", "hsn": "8517", "rate": "18%", "cess": "none"})
        self.assertEqual(self.m.load("GST Classification", "electronics gst 18%"),
                         {"name": "Electronics GST 18%", "hsn": "8517", "rate": "18", "cess": "None"})
        for bad in ({"name": "A", "hsn": "85", "rate": "18"}, {"name": "B", "hsn": "8517", "rate": "12"},
                    {"name": "C", "hsn": "8517", "rate": "18", "cess": "Sometimes"}):
            with self.assertRaises(MasterError):
                self.m.save_classification(bad)

    def test_missing_database(self):
        with self.assertRaises(MasterError):
            MasterStore(Path(self.tmp.name) / "none.db").save_group({"name": "A", "under": "Current Assets"})


class ReportsUseMastersTests(DbCase):
    def test_custom_group_and_openings(self):
        saved = dict(R.LEDGER_GROUPS)
        R.LEDGER_GROUPS.clear()
        R.LEDGER_GROUPS.update({"Cash": "Cash-in-Hand"})
        try:
            self.m.save_group({"name": "Office Expenses", "under": "Indirect Expenses"})
            self.m.save_ledger({"name": "Stationery", "under": "Office Expenses"})
            self.m.save_ledger({"name": "Cash", "under": "Cash-in-Hand", "opening": "1000", "drcr": "Dr"})
            self.m.save_ledger({"name": "Capital - Srijee", "under": "Capital Account", "opening": "800",
                                "drcr": "Cr"})
            VoucherStore(self.db, "SRJ").save(voucher("Payment", [("Dr", "Stationery", "150"), ("Cr", "Cash", "150")],
                                                      d=date(2026, 10, 1)))
            r = R.build_reports(self.db, date(2026, 10, 9))
        finally:
            R.LEDGER_GROUPS.clear()
            R.LEDGER_GROUPS.update(saved)
        self.assertEqual(r.pl["Indirect Expenses"].amount, D("150.00"))      # custom group -> its reserved group
        cash = next(n for n in r.assets if n.name == "Current Assets")
        self.assertEqual(cash.amount, D("850.00"))                          # 1,000 opening - 150 paid
        self.assertEqual(r.opening_difference, D("200.00"))                 # 1,000 Dr vs 800 Cr
        self.assertIn(R.OPENING_DIFFERENCE, [n.name for n in r.liabilities])
        self.assertEqual(r.liabilities_total, r.assets_total)

    def test_ledger_list_includes_masters(self):
        self.m.save_ledger({"name": "Roy Traders", "under": "Sundry Debtors"})
        cats = dict(load_ledger_catalogue(self.db))
        self.assertIn("Roy Traders", cats["Sundry Debtors"])


class GuiCase(DbCase):
    def setUp(self):
        super().setUp()
        try:
            self.root = tk.Tk()
        except tk.TclError as exc:
            self.tmp.cleanup()
            raise unittest.SkipTest(f"no display: {exc}")
        T.apply_ttk_styles(self.root)
        self.root.geometry("1100x720")

    def tearDown(self):
        settle(self.root, n=5)
        self.root.destroy()
        gc.collect()   # old Tk objects go away on the main thread, not in a worker
        super().tearDown()


class MasterFormTests(GuiCase):
    def make(self, kind, alter=False):
        from views.master_form import MasterFormView
        self.closed, self.messages = [], []
        form = MasterFormView(self.root, kind=kind, alter=alter, store=self.m, on_close=lambda: self.closed.append(1),
                              on_saved=self.messages.append)
        form.pack(fill="both", expand=True)
        settle(self.root, until=lambda: form._catalogues["groups"])
        return form

    def type_into(self, form, key, text):
        e = form._entries[key]
        e.delete(0, "end")
        e.insert(0, text)
        return e

    def test_group_form_enter_forward_esc_back_and_save(self):
        f = self.make("Group")
        name = self.type_into(f, "name", "Office Expenses")
        f.handle_key(Key("Return", name))
        under = self.type_into(f, "under", "Indirect Exp")
        f.handle_key(Key("ISO_Left_Tab", under))                 # Shift+Tab: back one field, form stays open
        self.assertEqual(self.closed, [])
        f._focused(f._fields[1])
        f._list.filter("Indirect Exp")
        f.handle_key(Key("Return", under))                       # last field: completes from the list and saves
        settle(self.root, until=lambda: self.messages)
        self.assertEqual(self.m.custom_groups(), {"Office Expenses": "Indirect Expenses"})
        self.assertEqual(f._entries["name"].get(), "")           # cleared for the next group

    def test_first_field_escape_closes(self):
        f = self.make("Group")
        f.handle_key(Key("Escape", f._entries["name"]))
        self.assertEqual(self.closed, [1])

    def test_escape_from_any_field_leaves_the_form(self):
        from unittest import mock
        for kind, field in (("Group", "under"), ("Ledger", "gstin"), ("GST Classification", "rate")):
            f = self.make(kind)                                  # (make() starts a fresh self.closed)
            f._entries["name"].insert(0, "Something typed")
            inner = f._entries[field]
            inner.focus_force()
            with mock.patch("views.master_form.messagebox.askyesno", return_value=False) as ask:
                f.handle_key(Key("Escape", inner))               # typed: asks once; No keeps the form
            self.assertEqual((ask.call_count, self.closed), (1, []), kind)
            with mock.patch("views.master_form.messagebox.askyesno", return_value=True):
                f.handle_key(Key("Escape", inner))               # Yes: closed from the middle of the form
            self.assertEqual(self.closed, [1], kind)
            f.destroy()

    def test_ledger_form_checks_fields_and_saves(self):
        f = self.make("Ledger")
        self.assertEqual([fl.label for fl in f._fields],
                         ["Ledger Name", "Under", "Name", "Address", "State", "PAN/IT No.", "GSTIN/UIN",
                          "Opening Balance", "Dr / Cr"])
        self.type_into(f, "name", "Roy Traders")
        under = self.type_into(f, "under", "Nowhere")
        f.handle_key(Key("Return", under))
        self.assertIn("not in the list", f._status.cget("text"))     # the cursor stays on Under
        self.type_into(f, "under", "sundry debtors")
        self.type_into(f, "opening", "2500")
        side = f._entries["drcr"]
        f.handle_key(Key("Down", side))
        self.assertEqual(side.get(), "Cr")
        f.handle_key(Key("Return", side))
        settle(self.root, until=lambda: self.messages)
        self.assertEqual(self.m.load("Ledger", "Roy Traders")["opening"], "2500.00")
        self.assertEqual(self.m.load("Ledger", "Roy Traders")["drcr"], "Cr")

    def test_gst_classification_form_and_alter(self):
        f = self.make("GST Classification")
        self.assertEqual(f._entries["cess"].get(), "None")
        self.type_into(f, "name", "Electronics GST 18%")
        self.type_into(f, "hsn", "8517")
        self.type_into(f, "rate", "18")
        f.handle_key(Key("Tab", f._entries["cess"]))              # Tab = Enter: last field saves
        settle(self.root, until=lambda: self.messages)
        self.assertEqual(self.m.classification_names(), ["Electronics GST 18%"])
        g = self.make("GST Classification", alter=True)
        settle(self.root, until=lambda: g._catalogues["existing"])
        name = self.type_into(g, "name", "electronics gst 18%")
        g.handle_key(Key("Return", name))
        settle(self.root, until=lambda: g._loaded)
        self.assertEqual((g._entries["hsn"].get(), g._entries["name"].cget("state")), ("8517", "readonly"))
        self.type_into(g, "rate", "5")
        g.handle_key(Key("Return", g._entries["cess"]))
        settle(self.root, until=lambda: self.messages)
        self.assertEqual(self.m.load("GST Classification", "Electronics GST 18%")["rate"], "5")


class VoucherKeyTests(GuiCase):
    def test_escape_steps_back_and_tab_moves_forward(self):
        from views.vouchers_view import VoucherView
        closed = []
        v = VoucherView(self.root, voucher_type="Journal", number_for=lambda _t: 1,
                        on_accept=lambda vv, done: done(True), on_close=lambda: closed.append(1))
        v.pack(fill="both", expand=True)
        self.root.update()
        line = v._lines[0]
        line.ledger.focus_force()
        settle(self.root, n=3)
        v.handle_key(Key("Escape", line.ledger))
        settle(self.root, n=3)
        self.assertIs(v.focus_get(), line.side_entry)           # one field back, still on the voucher
        self.assertEqual(closed, [])
        v.handle_key(Key("Tab", line.side_entry))               # Tab behaves like Enter
        settle(self.root, n=3)
        self.assertIs(v.focus_get(), line.ledger)
        line.amount_entry.insert(0, "12.345")
        v.handle_key(Key("Return", line.amount_entry))          # a wrong amount keeps the cursor there
        self.assertIn("decimal", v._status.cget("text"))
        line.amount_entry.delete(0, "end")                      # nothing typed, so leaving does not ask
        v.handle_key(Key("Escape", v._date))                    # on the first field Esc leaves
        self.assertEqual(closed, [1])


class SubmenuSignalTests(GuiCase):
    def test_on_change_fires_for_open_and_close(self):
        from components.gateway_menu import GatewayMenu
        seen = []
        canvas = tk.Frame(self.root)
        canvas.pack(fill="both", expand=True)
        menu = GatewayMenu(canvas, S.GATEWAY_SECTIONS, on_select=lambda _l: None, submenus=S.GATEWAY_SUBMENUS,
                           on_change=lambda: seen.append(menu.expanded))
        menu.show()
        menu.handle_key(Key("v"))
        menu.handle_key(Key("Escape"))
        self.assertEqual(seen, ["Vouchers", None])
        self.assertEqual([k for k, _n in S.NOTE_VOUCHER_TYPES], ["Ctrl+F8", "Ctrl+F9"])
        self.assertEqual(S.VOUCHER_TINTS, {"Credit Note": "#FDECEF", "Debit Note": "#FFF7D6"})


if __name__ == "__main__":
    unittest.main()
