"""
Inventory masters: Stock Group, Unit, Stock Item (store checks and writes, inventory_stock_registry,
Stock Summary valuation) and their forms (Enter forward, Esc back, skipped fields, worked-out value).
GUI tests need a display (Tk) and are skipped where there is none.
Run from the bizpulse_pro folder:  python -m unittest discover -s tests -v
"""
from __future__ import annotations

import gc
import sqlite3
import sys
import tempfile
import time
import tkinter as tk
import unittest
from decimal import Decimal as D
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
sys.path.insert(0, str(Path(__file__).resolve().parent))

from config import theme as T  # noqa: E402
from services.inventory_masters import InventoryStore  # noqa: E402
from services.masters import MasterError  # noqa: E402
from services.stock import load_stock_summary  # noqa: E402
from test_voucher_store import SCHEMA  # noqa: E402


class Key:
    def __init__(self, keysym, widget=None, state=0):
        self.keysym, self.widget, self.state = keysym, widget, state


def settle(root, until=None, n=100):
    for _ in range(n):
        root.update()
        if until is not None and until():
            return
        time.sleep(0.02)


class DbCase(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.db = Path(self.tmp.name) / "bizpulse_local.db"
        con = sqlite3.connect(self.db)
        con.executescript(SCHEMA)
        con.execute("INSERT INTO inventory_stock_registry VALUES ('SKU-OLD', 7, 2, NULL)")
        con.commit()
        con.close()
        self.s = InventoryStore(self.db)

    def tearDown(self):
        self.tmp.cleanup()

    def registry(self, sku):
        con = sqlite3.connect(self.db)
        try:
            return con.execute("SELECT product_sku, qty_on_hand, min_safety_floor FROM inventory_stock_registry "
                               "WHERE product_sku = ?", (sku,)).fetchone()
        finally:
            con.close()


class StoreTests(DbCase):
    def test_stock_groups(self):
        self.s.save_stock_group({"name": "Garments", "under": "primary", "add": "Yes"})
        self.s.save_stock_group({"name": "Kurtis", "under": "garments", "add": "n"})
        self.assertEqual(self.s.stock_groups(), {"Garments": "Primary", "Kurtis": "Garments"})
        self.assertEqual(self.s.load("Stock Group", "kurtis")["add"], "No")
        for bad in ({"name": "garments", "under": "Primary"}, {"name": "Primary"},
                    {"name": "Sarees", "under": "Nowhere"}, {"name": "X", "add": "maybe"}):
            with self.assertRaises(MasterError):
                self.s.save_stock_group(bad)
        with self.assertRaises(MasterError):                                   # a loop
            self.s.save_stock_group({"name": "Garments", "under": "Kurtis"}, alter=True)

    def test_units(self):
        self.s.save_unit({"type": "Simple", "symbol": "Nos", "formal": "Numbers", "decimals": "0"})
        self.s.save_unit({"type": "simple", "symbol": "Box", "formal": "Boxes"})
        for bad in ({"type": "Simple", "symbol": "nos"}, {"type": "Simple", "symbol": "Kg", "decimals": "5"},
                    {"type": "Simple", "symbol": "Two Words"}, {"type": "Triple", "symbol": "X"},
                    {"type": "Compound", "first": "Box", "second": "Box", "conversion": "10"},
                    {"type": "Compound", "first": "Box", "second": "Pcs", "conversion": "10"}):
            with self.assertRaises(MasterError):
                self.s.save_unit(bad)
        msg = self.s.save_unit({"type": "Compound", "first": "box", "conversion": "10", "second": "nos"})
        self.assertIn("Box of 10 Nos", msg)
        self.assertEqual(self.s.simple_units(), ["Box", "Nos"])

    def test_stock_item_writes_registry_and_values(self):
        self.s.save_unit({"type": "Simple", "symbol": "Pcs", "formal": "Pieces"})
        self.s.save_classification({"name": "Garments 5%", "hsn": "6204", "rate": "5"})
        msg = self.s.save_stock_item({"name": "Kurti Blue", "alias": "KB-01", "under": "Primary", "unit": "pcs",
                                      "gst": "Yes", "classification": "garments 5%", "qty": "40", "rate": "250"})
        self.assertIn("opening 40 Pcs @ 250.00 = 10,000.00", msg)
        self.assertEqual(self.registry("Kurti Blue"), ("Kurti Blue", 40, 0))
        loaded = self.s.load("Stock Item", "kurti blue")
        self.assertEqual((loaded["classification"], loaded["value"]), ("Garments 5%", "10,000.00"))
        summary = load_stock_summary(self.db)                            # valued at the master's opening rate
        line = next(ln for ln in summary.lines if ln.sku == "Kurti Blue")
        self.assertEqual((line.rate, line.value), (D("250.00"), D("10000.00")))
        self.assertTrue(summary.at_cost)
        self.s.save_stock_item({"name": "Kurti Blue", "alias": "KB-01", "unit": "Pcs", "qty": "45", "rate": "250"},
                               alter=True)
        self.assertEqual(self.registry("Kurti Blue")[1], 45)            # moved by the difference
        for bad in ({"name": "Kurti Red", "unit": "Kg"},                                      # no such unit
                    {"name": "Kurti Red", "unit": "Pcs", "alias": "kb-01"},                   # alias taken
                    {"name": "Kurti Red", "unit": "Pcs", "classification": "Nope"},
                    {"name": "Kurti Red", "unit": "Pcs", "qty": "1.5"},
                    {"name": "kurti blue", "unit": "Pcs"}):                                  # duplicate
            with self.assertRaises(MasterError):
                self.s.save_stock_item(bad)
        self.s.save_stock_item({"name": "Kurti Red", "unit": "Pcs", "gst": "No", "classification": "Nope"})
        self.assertEqual(self.s.load("Stock Item", "Kurti Red")["classification"], "")     # GST No: none kept

    def test_existing_sku_is_linked_not_doubled(self):
        self.s.save_unit({"type": "Simple", "symbol": "Nos"})
        with self.assertRaises(MasterError):
            self.s.save_stock_item({"name": "sku-old", "unit": "Nos", "qty": "5"})
        self.assertEqual(self.s.item_names(), [])                       # nothing saved
        self.s.save_stock_item({"name": "SKU-OLD", "unit": "Nos", "rate": "80"})
        self.assertEqual(self.registry("SKU-OLD")[1], 7)               # quantity untouched
        self.s.save_stock_item({"name": "SKU-OLD", "unit": "Nos", "qty": "3", "rate": "80"}, alter=True)
        self.assertEqual(self.registry("SKU-OLD")[1], 10)


class GuiCase(DbCase):
    def setUp(self):
        super().setUp()
        try:
            self.root = tk.Tk()
        except tk.TclError as exc:
            self.tmp.cleanup()
            raise unittest.SkipTest(f"no display: {exc}")
        T.apply_ttk_styles(self.root)
        self.root.geometry("1100x720")

    def tearDown(self):
        settle(self.root, n=5)
        self.root.destroy()
        gc.collect()   # old Tk objects go away on the main thread, not in a worker
        super().tearDown()

    def make(self, kind, alter=False):
        from views.master_form import MasterFormView
        self.closed, self.messages = [], []
        form = MasterFormView(self.root, kind=kind, alter=alter, store=self.s, on_close=lambda: self.closed.append(1),
                              on_saved=self.messages.append)
        form.pack(fill="both", expand=True)
        settle(self.root, n=10)
        return form

    def put(self, form, key, text):
        e = form._entries[key]
        e.delete(0, "end")
        e.insert(0, text)
        return e


class FormTests(GuiCase):
    def test_stock_group_form(self):
        f = self.make("Stock Group")
        self.assertEqual([fl.label for fl in f._fields],
                         ["Stock Group Name", "Under", "Should quantities of items be ADDED?"])
        self.assertEqual((f._entries["under"].get(), f._entries["add"].get()), ("Primary", "Yes"))
        name = self.put(f, "name", "Garments")
        f.handle_key(Key("Return", name))
        f.handle_key(Key("Return", f._entries["under"]))
        add = f._entries["add"]
        f.handle_key(Key("Down", add))
        self.assertEqual(add.get(), "No")
        f.handle_key(Key("ISO_Left_Tab", add))               # Shift+Tab: one field back, form stays
        self.assertEqual(self.closed, [])
        f.handle_key(Key("Return", add))
        settle(self.root, until=lambda: self.messages)
        self.assertEqual(self.s.load("Stock Group", "Garments")["add"], "No")

    def test_unit_form_skips_compound_fields(self):
        f = self.make("Unit")
        self.assertEqual(f._entries["type"].get(), "Simple")
        self.put(f, "symbol", "Pcs")
        self.put(f, "formal", "Pieces")
        decimals = self.put(f, "decimals", "7")
        f.handle_key(Key("Return", decimals))
        self.assertIn("0 to 4", f._status.cget("text"))     # checked: cursor stays
        self.put(f, "decimals", "2")
        f.handle_key(Key("Return", decimals))                 # Simple: compound fields skipped, so this saves
        settle(self.root, until=lambda: self.messages)
        self.assertEqual(self.s.load("Unit", "pcs")["decimals"], "2")

    def test_stock_item_form_value_skip_and_save(self):
        self.s.save_unit({"type": "Simple", "symbol": "Pcs"})
        f = self.make("Stock Item")
        settle(self.root, until=lambda: f._catalogues["units"])
        self.assertEqual([fl.label for fl in f._fields],
                         ["Stock Item Name", "Alias", "Under", "Units", "GST Applicable", "GST Classification",
                          "Opening Quantity", "Rate per unit (INR)", "Value (INR)"])
        self.put(f, "name", "Saree Red")
        self.put(f, "unit", "pcs")
        gst = self.put(f, "gst", "No")
        f._entries["gst"].focus_force()
        settle(self.root, n=3)
        f.handle_key(Key("Return", gst))                      # GST No: classification skipped
        settle(self.root, n=3)
        self.assertIs(f.focus_get(), f._entries["qty"])
        f.handle_key(Key("ISO_Left_Tab", f._entries["qty"]))  # Shift+Tab back also skips it
        settle(self.root, n=3)
        self.assertIs(f.focus_get(), f._entries["gst"])
        self.put(f, "qty", "12")
        rate = self.put(f, "rate", "450")
        f._refresh_value()
        self.assertEqual(f._entries["value"].get(), "5,400.00")
        self.assertEqual(f._entries["value"].cget("state"), "readonly")
        f.handle_key(Key("Return", rate))                     # value is worked out, so rate is the last field
        settle(self.root, until=lambda: self.messages)
        self.assertEqual(self.registry("Saree Red")[1], 12)
        self.assertEqual(f._entries["value"].cget("state"), "readonly")

    def test_escape_on_first_field_closes(self):
        f = self.make("Unit")
        f.handle_key(Key("Escape", f._entries["type"]))
        self.assertEqual(self.closed, [1])

    def test_unit_alter_starts_on_symbol(self):
        self.s.save_unit({"type": "Simple", "symbol": "Nos", "formal": "Numbers"})
        f = self.make("Unit", alter=True)
        self.assertEqual(f._fields[0].key, "symbol")
        settle(self.root, until=lambda: f._catalogues["existing"])
        sym = self.put(f, "symbol", "nos")
        f.handle_key(Key("Return", sym))
        settle(self.root, until=lambda: f._loaded)
        self.assertEqual(f._entries["formal"].get(), "Numbers")

    def test_list_of_masters_offers_the_inventory_forms(self):
        from views.masters_overlay import MastersOverlay
        area = tk.Frame(self.root)
        area.pack(fill="both", expand=True)
        box = MastersOverlay(area, "Create", on_choose=lambda *_a: None, on_close=lambda: None)
        self.assertFalse({"Stock Group", "Unit", "Stock Item", "Godown", "Currency", "Stock Category"} & box._not_built)
        self.assertEqual(box._not_built, set())                  # every master opens a screen now


if __name__ == "__main__":
    unittest.main()
