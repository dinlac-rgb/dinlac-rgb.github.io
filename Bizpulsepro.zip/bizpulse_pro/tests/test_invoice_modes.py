"""
Sales / Purchase invoice modes (Item Invoice, Accounting Invoice, As Voucher), Dispatch Details,
the Voucher Entry Utilities drawer (status, details, Autofill, Unused Vch No.), and the store side:
stock updates, Optional / Post-Dated vouchers, and reports leaving Optional ones out.
GUI tests need a display (Tk) and are skipped where there is none.
Run from the bizpulse_pro folder:  python -m unittest discover -s tests -v
"""
from __future__ import annotations

import gc
import sqlite3
import sys
import tempfile
import time
import tkinter as tk
import unittest
from datetime import date, timedelta
from decimal import Decimal as D
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
sys.path.insert(0, str(Path(__file__).resolve().parent))

import services.reports as R  # noqa: E402
from config import theme as T  # noqa: E402
from services.migrations import upgrade_database  # noqa: E402
from services.voucher_store import StoreError, VoucherStore  # noqa: E402
from test_voucher_store import SCHEMA, voucher  # noqa: E402
from views.vouchers_view import ACC_INV, AS_VOUCHER, ITEM_INV, VoucherView  # noqa: E402


class Key:
    def __init__(self, keysym, widget=None, state=0):
        self.keysym, self.widget, self.state = keysym, widget, state


def settle(root, n=5):
    for _ in range(n):
        root.update()
        time.sleep(0.02)


class InvoiceViewTests(unittest.TestCase):
    def setUp(self):
        try:
            self.root = tk.Tk()
        except tk.TclError as exc:
            raise unittest.SkipTest(f"no display: {exc}")
        T.apply_ttk_styles(self.root)
        self.saved = []
        self.view = VoucherView(self.root, voucher_type="Sales", number_for=lambda _t: 1,
                                on_accept=lambda v, done: (self.saved.append(v), done(True)), on_close=lambda: None,
                                autofill_source=self._autofill, unused_source=lambda _t: [3, 5])
        self.view.pack(fill="both", expand=True)
        settle(self.root)

    def tearDown(self):
        settle(self.root)
        self.root.destroy()
        gc.collect()   # old Tk objects go away on the main thread, not in a worker

    @staticmethod
    def _autofill(vtype, party):
        if party.lower() != "gupta stores":
            return None
        return {"lines": [{"side": "Dr", "ledger": "Gupta Stores", "amount": D("590")},
                          {"side": "Cr", "ledger": "Sales", "amount": D("500")},
                          {"side": "Cr", "ledger": "Output IGST", "amount": D("90")}],
                "items": [{"item": "SKU-1", "quantity": 5, "rate": D("100"), "per": "Nos", "amount": D("500")}],
                "details": {"Dispatch · Destination": "Siliguri"}}

    def _fill_gst(self, rate="18"):
        v = self.view
        v._rate.insert(0, rate)
        v._hsn.insert(0, "6109")

    def test_sales_opens_as_item_invoice_and_mode_box_has_three_modes(self):
        v = self.view
        self.assertEqual(v._layout, ITEM_INV)
        v.handle_key(Key("h", state=T.MOD_CTRL))
        self.assertEqual([r["label"] for r in v._mode_box._rows], ["Item Invoice", "Accounting Invoice", "As Voucher"])
        self.assertEqual([r["key"] for r in v._mode_box._rows], ["I", "A", "V"])
        self.assertEqual(v._mode_box.active_label, ITEM_INV)
        v.handle_key(Key("Down"))
        v.handle_key(Key("Return"))
        self.assertIsNone(v._mode_box)
        self.assertEqual(v._layout, ACC_INV)
        self.assertFalse(v._acc_row.winfo_manager())          # the Party A/c takes the Account's place
        v.handle_key(Key("h", state=T.MOD_CTRL))
        v.handle_key(Key("v"))
        self.assertEqual((v.invoice_mode, v._side_head.cget("text")), (AS_VOUCHER, "By/To"))
        v._on_side_key(v._lines[0], Key("t"))
        self.assertEqual(v._lines[0].side_text.get(), "To")

    def test_item_invoice_sales_builds_party_sales_and_tax_lines(self):
        v = self.view
        v._party.insert(0, "Gupta Stores")
        a, b = v._item_lines
        a.item.insert(0, "SKU-1"); a.qty.insert(0, "5"); a.rate.insert(0, "100")
        b.item.insert(0, "SKU-2"); b.qty.insert(0, "2"); b.rate.insert(0, "250.50")
        v._refresh_items()
        self.assertEqual(v._taxable.get(), "1,001.00")       # taxable value follows the items
        self._fill_gst()
        v.accept()
        self.assertEqual(len(self.saved), 1, v._status.cget("text"))
        got = [(ln["side"], ln["ledger"], ln["amount"]) for ln in self.saved[0]["lines"]]
        self.assertEqual(got, [("Dr", "Gupta Stores", D("1181.18")), ("Cr", "Sales", D("1001.00")),
                               ("Cr", "Output CGST", D("90.09")), ("Cr", "Output SGST", D("90.09"))])
        self.assertEqual([(i["item"], i["quantity"], i["amount"]) for i in self.saved[0]["items"]],
                         [("SKU-1", 5, D("500.00")), ("SKU-2", 2, D("501.00"))])

    def test_quantity_must_be_whole(self):
        v = self.view
        v._party.insert(0, "Gupta Stores")
        a = v._item_lines[0]
        a.item.insert(0, "SKU-1"); a.qty.insert(0, "1.5"); a.rate.insert(0, "10")
        self._fill_gst()
        v.accept()
        self.assertEqual(self.saved, [])
        self.assertIn("whole number", v._status.cget("text"))

    def test_accounting_invoice_purchase(self):
        v = self.view
        v.set_type("Purchase")
        v.set_invoice_mode(ACC_INV)
        v._party.insert(0, "Bose Suppliers")
        v._single_lines[0].ledger.insert(0, "Freight Inward")
        v._single_lines[0].amount_entry.insert(0, "1200")
        v.accept()
        got = [(ln["side"], ln["ledger"], ln["amount"]) for ln in self.saved[0]["lines"]]
        self.assertEqual(got, [("Dr", "Freight Inward", D("1200.00")), ("Cr", "Bose Suppliers", D("1200.00"))])

    def test_dispatch_card_after_party_and_details_saved(self):
        v = self.view
        v._party.insert(0, "Gupta Stores")
        v._advance_type_field(v._party)
        card = v._card
        self.assertEqual(card.title, "Dispatch Details")
        self.assertEqual(list(card._entries), ["Delivery Note No(s)", "Dispatch Doc No", "Dispatched through",
                                               "Destination", "Carrier Name/Agent", "Bill of Lading / RR No",
                                               "Date", "Motor Vehicle No"])
        self.assertEqual(card.cget("bg"), T.WHITE)
        card._entries["Destination"].insert(0, "Siliguri")
        card._entries["Motor Vehicle No"].insert(0, "WB 74 1234")
        v.handle_key(Key("Escape"))                               # Esc closes and keeps what was typed
        self.assertIsNone(v._card)
        self.assertEqual(v._forms["Dispatch Details"]["Destination"], "Siliguri")
        v._advance_type_field(v._party)                           # offered once per voucher
        self.assertIsNone(v._card)
        a = v._item_lines[0]
        a.item.insert(0, "SKU-1"); a.qty.insert(0, "1"); a.rate.insert(0, "100")
        self._fill_gst()
        v.accept()
        self.assertEqual(len(self.saved), 1, v._status.cget("text"))
        self.assertEqual(self.saved[0]["details"]["Dispatch · Destination"], "Siliguri")
        self.assertEqual(self.saved[0]["details"]["Dispatch · Motor Vehicle No"], "WB 74 1234")

    def test_drawer_status_and_escape(self):
        v = self.view
        v._party.focus_force()
        settle(self.root)
        v.handle_key(Key("i", state=T.MOD_CTRL))
        self.assertIsNotNone(v._drawer)
        v.handle_key(Key("p"))                                    # Sales cannot be Post-Dated
        self.assertEqual(v.status, "Regular")
        v.handle_key(Key("o"))
        self.assertEqual(v.status, "Optional")
        self.assertTrue(v._status_badge.winfo_manager())
        label_bg = {lbl: w[0].cget("bg") for lbl, w in v._drawer._blocks.values()}
        self.assertEqual(label_bg["Optional"], T.ORANGE)
        v.handle_key(Key("Escape"))
        self.assertIsNone(v._drawer)

    def test_post_dated_payment_needs_future_date(self):
        v = self.view
        v.set_type("Payment")
        v.set_status("Post-Dated")
        self.assertEqual(v.status, "Post-Dated")
        v.set_mode("Double Entry")
        v._lines[0].ledger.insert(0, "Rent"); v._lines[0].amount_entry.insert(0, "10")
        v._lines[1].ledger.insert(0, "Cash"); v._lines[1].amount_entry.insert(0, "10")
        v.accept()
        self.assertIn("after today", v._status.cget("text"))
        v._date.delete(0, "end")
        v._date.insert(0, (date.today() + timedelta(days=3)).strftime("%d-%m-%Y"))
        v.accept()
        self.assertEqual(self.saved[0]["status"], "Post-Dated")
        self.assertEqual(v.status, "Regular")                     # the next voucher starts Regular

    def test_autofill_from_party_last_voucher(self):
        v = self.view
        v._party.insert(0, "gupta stores")
        v.autofill()
        for _ in range(50):
            settle(self.root, 1)
            if v._item_lines[0].item.get():
                break
        self.assertEqual((v._item_lines[0].item.get(), v._item_lines[0].qty.get()), ("SKU-1", "5"))
        self.assertEqual(v._forms["Dispatch Details"]["Destination"], "Siliguri")
        v._party.delete(0, "end")
        v._party.insert(0, "Nobody")
        v.autofill()
        for _ in range(50):
            settle(self.root, 1)
            if "No earlier" in v._status.cget("text"):
                break
        self.assertIn("No earlier Sales for Nobody", v._status.cget("text"))

    def test_unused_numbers_card(self):
        v = self.view
        v.show_unused_numbers()
        for _ in range(50):
            settle(self.root, 1)
            if v._card is not None:
                break
        self.assertEqual(v._card.title, "Unused Vch No.")
        v.handle_key(Key("Escape"))
        self.assertIsNone(v._card)


class StoreStatusTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.db = Path(self.tmp.name) / "bizpulse_local.db"
        con = sqlite3.connect(self.db)
        con.executescript(SCHEMA)
        con.execute("INSERT INTO inventory_stock_registry VALUES ('SKU-1', 10, 2, NULL)")
        con.commit()
        con.close()
        upgrade_database(self.db, "19")
        self.store = VoucherStore(self.db, "SRJ")

    def tearDown(self):
        self.tmp.cleanup()

    def qty(self):
        con = sqlite3.connect(self.db)
        try:
            return con.execute("SELECT qty_on_hand FROM inventory_stock_registry WHERE product_sku='SKU-1'").fetchone()[0]
        finally:
            con.close()

    def item_purchase(self, qty=4, status="Regular"):
        v = voucher("Purchase", [("Dr", "Purchases", str(qty * 100)), ("Cr", "Bose", str(qty * 100))])
        v["items"] = [{"item": "sku-1", "quantity": qty, "rate": D("100"), "per": "Nos", "amount": D(qty * 100)}]
        v["status"] = status
        return v

    def test_purchase_adds_and_sale_takes_stock(self):
        r = self.store.save(self.item_purchase(4))
        self.assertEqual((self.qty(), r.stock_updates), (14, ["SKU-1: 10 -> 14"]))
        sale = self.item_purchase(3)
        sale["type"] = "Sales"
        sale["gst"] = None
        sale["items"][0]["quantity"] = 20
        self.assertEqual([(s.item, s.on_hand, s.wanted) for s in self.store.stock_shortfalls(sale)], [("SKU-1", 14, 20)])
        self.assertEqual(self.store.load_all()[0]["items"][0]["item"], "sku-1")

    def test_unknown_item_saves_nothing(self):
        v = self.item_purchase()
        v["items"][0]["item"] = "NOPE"
        with self.assertRaises(StoreError):
            self.store.save(v)
        self.assertEqual((self.qty(), self.store.load_all()), (10, []))

    def test_optional_changes_nothing_and_is_left_out_of_reports(self):
        self.store.save(self.item_purchase(4, status="Optional"))
        self.assertEqual(self.qty(), 10)
        loaded = self.store.load_all()
        self.assertEqual(loaded[0]["status"], "Optional")
        saved = dict(R.LEDGER_GROUPS)
        R.LEDGER_GROUPS.update({"Purchases": "Purchase Accounts"})
        try:
            r = R.build_reports(self.db, date(2026, 10, 31))
        finally:
            R.LEDGER_GROUPS.clear()
            R.LEDGER_GROUPS.update(saved)
        self.assertEqual((r.voucher_count, r.pl["Purchase Accounts"].amount), (0, D("0.00")))

    def test_post_dated_rules_and_realise(self):
        bad = voucher("Sales", [("Dr", "A", "1"), ("Cr", "B", "1")], d=date.today() + timedelta(days=2))
        bad["status"] = "Post-Dated"
        with self.assertRaises(StoreError):
            self.store.save(bad)
        con = sqlite3.connect(self.db)
        con.execute("INSERT INTO corporate_ledger_summary VALUES ('C9', 'Roy Traders', 1000, 0)")
        con.commit()
        con.close()
        later = date.today() + timedelta(days=2)
        v = voucher("Receipt", [("Dr", "Cash", "400"), ("Cr", "Roy Traders", "400")], d=later)
        v["status"] = "Post-Dated"
        r = self.store.save(v)
        self.assertEqual(r.account_updates, [])                     # nothing yet
        self.assertEqual(self.store.realise_post_dated(date.today()), [])
        msgs = self.store.realise_post_dated(later)
        self.assertEqual(len(msgs), 1)
        con = sqlite3.connect(self.db)
        bal = con.execute("SELECT outstanding_balance FROM corporate_ledger_summary WHERE account_id='C9'").fetchone()[0]
        con.close()
        self.assertEqual(bal, 600.0)
        self.assertEqual(self.store.load_all()[0]["status"], "Regular")
        self.assertEqual(self.store.realise_post_dated(later), [])  # only once

    def test_old_database_gets_status_column(self):
        con = sqlite3.connect(self.db)
        con.executescript("""CREATE TABLE bp_vouchers (id INTEGER PRIMARY KEY AUTOINCREMENT, voucher_type TEXT NOT NULL,
            voucher_no INTEGER NOT NULL, voucher_date TEXT NOT NULL, narration TEXT NOT NULL DEFAULT '',
            total_paise INTEGER NOT NULL, invoice_no TEXT, entered_at TEXT NOT NULL, UNIQUE (voucher_type, voucher_no));""")
        con.commit()
        con.close()
        self.assertEqual(self.store.load_all(), [])
        self.store.save(voucher("Journal", [("Dr", "A", "1"), ("Cr", "B", "1")]))
        self.assertEqual(self.store.load_all()[0]["status"], "Regular")

    def test_unused_numbers_and_last_voucher(self):
        self.store.save(voucher("Journal", [("Dr", "A", "1"), ("Cr", "B", "1")]))
        con = sqlite3.connect(self.db)
        con.execute("UPDATE bp_vouchers SET voucher_no = 4")
        con.commit()
        con.close()
        self.assertEqual(self.store.unused_numbers("Journal"), [1, 2, 3])
        self.store.save(self.item_purchase(2))
        last = self.store.last_voucher_for("Purchase", " bose ")
        self.assertEqual((last["items"][0]["quantity"], last["lines"][0]["ledger"]), (2, "Purchases"))
        self.assertIsNone(self.store.last_voucher_for("Purchase", "Nobody"))


if __name__ == "__main__":
    unittest.main()
