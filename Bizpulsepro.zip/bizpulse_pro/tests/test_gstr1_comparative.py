"""
GSTR-1 JSON (services/gstr1.py, views/gstr1_view.py), the comparative P&L / Balance Sheet
(services/comparative.py, views/comparative_view.py) and the red opening-balance guard.
GUI tests need a display (Tk) and are skipped where there is none.
Run from the bizpulse_pro folder:  python -m unittest discover -s tests -v
"""
from __future__ import annotations

import gc
import json
import sqlite3
import sys
import tempfile
import time
import tkinter as tk
import unittest
from datetime import date
from decimal import Decimal as D
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
sys.path.insert(0, str(Path(__file__).resolve().parent))

from config import theme as T  # noqa: E402
from services.comparative import comparative, periods  # noqa: E402
from services.gstr1 import Gstr1Error, _doc_series, build_gstr1, write_gstr1  # noqa: E402
from services.masters import MasterStore  # noqa: E402
from services.migrations import upgrade_database  # noqa: E402
from services.voucher_book import VoucherBook  # noqa: E402
from test_masters import make_gstin  # noqa: E402
from test_voucher_store import SCHEMA, sales  # noqa: E402

COMPANY = make_gstin("19", "AAPFU0939F")
BUYER = make_gstin("19", "ABCDE1234F")


class DbCase(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.db = Path(self.tmp.name) / "bizpulse_local.db"
        con = sqlite3.connect(self.db)
        con.executescript(SCHEMA)
        con.close()
        upgrade_database(self.db, "19")
        self.book = VoucherBook(self.db, "SRJ")

    def tearDown(self):
        self.tmp.cleanup()

    def sale(self, d, **kw):
        v = sales(**kw)
        v["date"] = d
        return self.book.save(v)


class Gstr1Tests(DbCase):
    def setUp(self):
        super().setUp()
        oct_ = date(2026, 10, 5)
        self.sale(oct_, customer="Roy Traders", gstin=BUYER, taxable="10000")           # B2B
        self.sale(oct_, customer="Walk-in", taxable="2000")                              # B2CS intra
        self.sale(oct_, customer="Delhi Buyer", taxable="150000", rate="18", pos="07")   # B2CL inter > 1 lakh
        self.sale(oct_, customer="Small Inter", taxable="1000", pos="07")                # B2CS inter
        self.sale(date(2026, 9, 30), customer="September", taxable="500")                # other month

    def test_sections(self):
        g = build_gstr1(self.db, 2026, 10, COMPANY, "19")
        p = g.payload
        self.assertEqual((p["gstin"], p["fp"]), (COMPANY, "102026"))
        self.assertEqual([b["ctin"] for b in p["b2b"]], [BUYER])
        det = p["b2b"][0]["inv"][0]["itms"][0]["itm_det"]
        self.assertEqual((det["txval"], det["rt"], det["camt"], det["samt"], det["iamt"]), (10000.0, 18.0, 900.0, 900.0, 0.0))
        self.assertEqual([b["pos"] for b in p["b2cl"]], ["07"])
        self.assertEqual(p["b2cl"][0]["inv"][0]["itms"][0]["itm_det"]["iamt"], 27000.0)
        b2cs = {(r["sply_ty"], r["pos"]): r for r in p["b2cs"]}
        self.assertEqual(set(b2cs), {("INTRA", "19"), ("INTER", "07")})
        self.assertEqual(b2cs[("INTRA", "19")]["txval"], 2000.0)
        self.assertEqual(b2cs[("INTER", "07")]["iamt"], 180.0)
        self.assertEqual(len(p["hsn"]["hsn_b2b"]), 1)
        self.assertEqual(p["hsn"]["hsn_b2c"][0]["txval"], 153000.0)
        docs = p["doc_issue"]["doc_det"][0]["docs"]
        self.assertEqual(len(docs), 1)
        self.assertTrue(docs[0]["from"].startswith("SRJ/26-27/"))
        self.assertEqual(g.summary["b2b"]["count"], 1)
        self.assertEqual(g.summary["b2cs"]["count"], 2)

    def test_write_file(self):
        g = build_gstr1(self.db, 2026, 10, COMPANY, "19")
        path = write_gstr1(g, Path(self.tmp.name) / "exports")
        self.assertEqual(path.name, f"GSTR1_{COMPANY}_102026.json")
        self.assertEqual(json.loads(path.read_text())["fp"], "102026")
        self.assertFalse(list(path.parent.glob("*.tmp")))

    def test_company_gstin_required(self):
        with self.assertRaises(Gstr1Error):
            build_gstr1(self.db, 2026, 10, "", "19")
        with self.assertRaises(Gstr1Error):
            build_gstr1(self.db, 2026, 10, make_gstin("27", "AAPFU0939F"), "19")   # other state

    def test_orphan_rows_warned(self):
        con = sqlite3.connect(self.db)
        con.execute("INSERT INTO gst_sales_ledger (invoice_no, customer_name, hsn_code, taxable_value) "
                    "VALUES ('OLD-1', 'x', '8471', 10)")
        con.commit()
        con.close()
        g = build_gstr1(self.db, 2026, 10, COMPANY, "19")
        self.assertTrue(any("no Sales voucher" in w for w in g.warnings))

    def test_doc_series_gaps(self):
        docs = _doc_series(["SRJ/26-27/0001", "SRJ/26-27/0002", "SRJ/26-27/0005"])
        self.assertEqual(docs, [{"num": 1, "from": "SRJ/26-27/0001", "to": "SRJ/26-27/0005", "totnum": 5,
                                 "cancel": 2, "net_issue": 3}])


class ComparativeTests(DbCase):
    def test_periods(self):
        yr = periods("year", date(2026, 10, 10))
        self.assertEqual([p[0] for p in yr], ["FY 2025-26", "FY 2026-27 to date"])
        self.assertEqual((yr[0][1], yr[0][2]), (date(2025, 4, 1), date(2026, 3, 31)))
        qs = periods("quarters", date(2026, 10, 10))
        self.assertEqual([p[0] for p in qs], ["Q1 Apr-Jun", "Q2 Jul-Sep", "Q3 Oct-Oct"])

    def test_pl_quarters_same_rows(self):
        self.sale(date(2026, 5, 10), taxable="1000")
        self.sale(date(2026, 8, 10), taxable="3000")
        c = comparative(self.db, "pl", "quarters", date(2026, 10, 10))
        self.assertEqual(len(c.columns), 3)
        sales_row = next(r for r in c.rows if r[0] == "Sales Accounts")
        self.assertEqual(sales_row[1][:2], [D("1000.00"), D("3000.00")])
        self.assertTrue(all(len(r[1]) == 3 for r in c.rows))

    def test_bs_year_and_opening_difference_note(self):
        m = MasterStore(self.db)
        m.save_ledger({"name": "Cash", "under": "Cash-in-Hand", "opening": "1000", "drcr": "Dr"})
        c = comparative(self.db, "bs", "year", date(2026, 10, 10))
        self.assertEqual([r[0] for r in c.rows if r[2] == "heading"], ["LIABILITIES", "ASSETS"])
        self.assertTrue(any("Difference in Opening Balances" in n for n in c.notes))


class GuiCase(DbCase):
    def setUp(self):
        super().setUp()
        try:
            self.root = tk.Tk()
        except tk.TclError as exc:
            self.tmp.cleanup()
            raise unittest.SkipTest(f"no display: {exc}")
        T.apply_ttk_styles(self.root)
        self.root.geometry("1100x720")

    def tearDown(self):
        self.settle(n=5)
        self.root.destroy()
        gc.collect()   # old Tk objects go away on the main thread, not in a worker
        super().tearDown()

    def settle(self, until=None, n=150):
        for _ in range(n):
            self.root.update()
            if until and until():
                return
            time.sleep(0.02)


class Key:
    def __init__(self, keysym, widget=None, state=0):
        self.keysym, self.widget, self.state = keysym, widget, state


class GuiTests(GuiCase):
    def test_comparative_toggle_and_escape(self):
        from views.comparative_view import ComparativeView
        closed = []
        v = ComparativeView(self.root, db_path=self.db, kind="pl", company="Srijee", on_close=lambda: closed.append(1),
                            today=date(2026, 10, 10))
        v.pack(fill="both", expand=True)
        self.settle(lambda: v._tree is not None)
        self.assertEqual(len(v._tree["columns"]), 4)                     # 2 years + Change + %
        v.handle_key(Key("c"))
        self.settle(lambda: v._tree is not None and len(v._tree["columns"]) == 3)
        self.assertEqual(v.mode, "quarters")
        v.handle_key(Key("Escape"))
        self.assertEqual(closed, [1])

    def test_c_on_balance_sheet_and_pl(self):
        from views.balance_sheet_view import BalanceSheetView
        from views.profit_loss_view import ProfitLossView
        for cls in (BalanceSheetView, ProfitLossView):
            hits = []
            v = cls(self.root, db_path=self.db, company="Srijee", on_close=lambda: None,
                    on_compare=lambda: hits.append(1))
            v.handle_key(Key("c"))
            self.assertEqual(hits, [1], cls.__name__)
            v.destroy()

    def test_trial_balance_guard_is_red(self):
        from views.trial_balance_view import TrialBalanceView
        MasterStore(self.db).save_ledger({"name": "Cash", "under": "Cash-in-Hand", "opening": "1000", "drcr": "Dr"})
        v = TrialBalanceView(self.root, db_path=self.db, company="Srijee", on_close=lambda: None)
        v.pack(fill="both", expand=True)
        self.settle(lambda: v._guard.cget("text"))
        self.assertIn("Difference in Opening Balances: ₹1,000.00", v._guard.cget("text"))
        self.assertEqual(v._guard.cget("fg"), T.BAD_RED)

    def test_gstr1_view_exports_and_logs(self):
        from views.gstr1_view import Gstr1View
        self.sale(date(2026, 10, 5), customer="Roy Traders", gstin=BUYER, taxable="10000")
        notes = []
        out = Path(self.tmp.name) / "exports"
        v = Gstr1View(self.root, db_path=self.db, export_dir=out, gstin=COMPANY, company_state="19",
                      b2cl_limit=D("100000"), version="", on_close=lambda: None, on_note=notes.append)
        v.pack(fill="both", expand=True)
        v._period.delete(0, "end")
        v._period.insert(0, "10-2026")
        v.load()
        self.settle(lambda: v._result is not None)
        v.export()
        self.settle(lambda: notes)
        self.assertTrue((out / f"GSTR1_{COMPANY}_102026.json").exists())
        self.assertIn("[GSTR-1]", notes[0])


if __name__ == "__main__":
    unittest.main()
