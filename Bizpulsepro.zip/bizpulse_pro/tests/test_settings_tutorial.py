"""
[S] Settings (services/preferences.py, views/settings_view.py) and [T] Tutorial
(views/tutorial_content.py, views/tutorial_view.py). Every write goes to a COPY of
config/settings.py in a temporary folder, never the real one.
GUI tests need a display (Tk) and are skipped where there is none.
Run from the bizpulse_pro folder:  python -m unittest discover -s tests -v
"""
from __future__ import annotations

import gc
import shutil
import sys
import tempfile
import time
import tkinter as tk
import unittest
from datetime import date
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from config import settings as S  # noqa: E402
from config import theme as T  # noqa: E402
from services.preferences import (DEFAULTS, PreferencesError, read_preferences,  # noqa: E402
                                  save_preferences)
from views.tutorial_content import modules  # noqa: E402


class TempSettings(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.path = Path(self.tmp.name) / "settings.py"
        shutil.copy(ROOT / "config" / "settings.py", self.path)

    def tearDown(self):
        self.tmp.cleanup()

    def load(self) -> dict:
        ns: dict = {"__file__": str(ROOT / "config" / "settings.py")}
        exec(compile(self.path.read_text(encoding="utf-8"), str(self.path), "exec"), ns)
        return ns


class PreferenceFileTests(TempSettings):
    def test_shipped_defaults(self):
        self.assertEqual(read_preferences(self.path), DEFAULTS)
        self.assertEqual(S.VOUCHER_TYPES[0], ("F4", "Contra"))

    def test_save_rewrites_only_the_block(self):
        before = self.path.read_text(encoding="utf-8")
        save_preferences({"THEME": "Slate Minimal", "FONT_SCALE": 12, "ROW_DENSITY": "Compact",
                          "KEYBOARD_LAYOUT": "BizPulse Express", "GRID_LINES": False}, self.path)
        after = self.path.read_text(encoding="utf-8")
        self.assertEqual(read_preferences(self.path)["THEME"], "Slate Minimal")
        ns = self.load()                                        # the new file loads and is used
        self.assertEqual((ns["FONT_SCALE"], ns["GRID_LINES"]), (12, False))
        self.assertEqual(ns["VOUCHER_TYPES"][0], ("F4", "Sales"))
        self.assertEqual(before.split("# >>> BIZPULSE PREFERENCES")[0], after.split("# >>> BIZPULSE PREFERENCES")[0])
        self.assertEqual(before.split("# <<< BIZPULSE PREFERENCES")[1], after.split("# <<< BIZPULSE PREFERENCES")[1])
        self.assertEqual(self.path.with_suffix(".py.bak").read_text(encoding="utf-8"), before)
        self.assertFalse(self.path.with_suffix(".py.tmp").exists())

    def test_only_allowed_values(self):
        before = self.path.read_text(encoding="utf-8")
        for bad in ({"THEME": "Neon"}, {"GRID_LINES": 1}, {"FONT_SCALE": True}, {"FONT_SCALE": 14},
                    {"EVIL": "x"}, {"THEME": "x'\nimport os#"}):
            with self.assertRaises(PreferencesError, msg=bad):
                save_preferences(bad, self.path)
        self.assertEqual(self.path.read_text(encoding="utf-8"), before)

    def test_missing_markers_change_nothing(self):
        self.path.write_text("THEME = 'Pro Dark Blue'\n", encoding="utf-8")
        with self.assertRaises(PreferencesError):
            save_preferences({"THEME": "Lite Classic"}, self.path)
        self.assertEqual(self.path.read_text(encoding="utf-8"), "THEME = 'Pro Dark Blue'\n")

    def test_theme_defaults(self):
        self.assertEqual(T.NAVY, "#0D2C54")
        self.assertEqual(T.WHITE, "#FFFFFF")
        self.assertEqual(T.F_TEXT, ("Segoe UI", 11, "normal"))
        self.assertEqual(T.ROW_HEIGHT, 28)


class TutorialContentTests(unittest.TestCase):
    def test_modules_and_facts(self):
        mods = modules(date(2026, 10, 10))
        self.assertEqual([m[0] for m in mods], [
            "Module 1: Foundational Company Accounting Setup",
            "Module 2: The 28 Pre-Defined Primary Account Groups",
            "Module 3: Single Entry vs. Double Entry Voucher Management",
            "Module 4: The Voucher Utilities Slide-Out Drawer",
            "Module 5: Automated Banking Reconciliation & GSTR-1 Exports"])
        text = " ".join(line for _t, body in mods for _k, line in body)
        for fact in ("SRJ/26-27/0001", 'COMPANY_STATE_CODE = "19"', "15 primary groups", "13 sub-groups",
                     "**Ctrl+H**", "**Ctrl+I**", "**M** Match Entries", "database_config.py", "GST offline tool"):
            self.assertIn(fact, text)


class GuiCase(TempSettings):
    def setUp(self):
        super().setUp()
        try:
            self.root = tk.Tk()
        except tk.TclError as exc:
            self.tmp.cleanup()
            raise unittest.SkipTest(f"no display: {exc}")
        T.apply_ttk_styles(self.root)
        self.root.geometry("1100x720")

    def tearDown(self):
        for _ in range(5):
            self.root.update()
            time.sleep(0.02)
        self.root.destroy()
        gc.collect()   # old Tk objects go away on the main thread, not in a worker
        super().tearDown()

    def settle(self, until, n=150):
        for _ in range(n):
            self.root.update()
            if until():
                return
            time.sleep(0.02)


class Key:
    def __init__(self, keysym, widget=None, state=0):
        self.keysym, self.widget, self.state = keysym, widget, state


class SettingsScreenTests(GuiCase):
    def make(self):
        from views.settings_view import SettingsView
        self.closed, self.notes = [], []
        v = SettingsView(self.root, on_close=lambda: self.closed.append(1), on_note=self.notes.append,
                         settings_path=self.path, running=dict(DEFAULTS))
        v.pack(fill="both", expand=True)
        self.root.update()
        return v

    def test_letters_arrows_autosave_and_escape(self):
        v = self.make()
        v.handle_key(Key("t"))                                    # on Theme already: next option
        self.settle(lambda: read_preferences(self.path)["THEME"] == "Lite Classic")
        self.assertEqual(read_preferences(self.path)["THEME"], "Lite Classic")
        self.settle(lambda: self.notes)
        self.assertIn("[Settings] Theme: Lite Classic saved", self.notes[-1])
        self.assertEqual(v._rows[0]["pending"].cget("text"), "after restart")
        v.handle_key(Key("g"))                                    # another row: jump to it
        self.assertEqual(v.current_row, "GRID_LINES")
        v.handle_key(Key("Right"))
        self.settle(lambda: read_preferences(self.path)["GRID_LINES"] is False)
        self.assertIs(read_preferences(self.path)["GRID_LINES"], False)
        v.handle_key(Key("Up"))
        self.assertEqual(v.current_row, "KEYBOARD_LAYOUT")
        v.handle_key(Key("Escape"))
        self.assertEqual(self.closed, [1])

    def test_typography(self):
        v = self.make()
        chip = v._rows[1]["chips"][0][1]
        self.assertEqual(str(chip.cget("font")), "{Segoe UI} 11 normal")
        self.assertEqual(chip.cget("text"), "Segoe UI 11 Normal (default)")
        def labels(w):
            for c in w.winfo_children():
                yield c
                yield from labels(c)
        letters = {(w.cget("text"), str(w.cget("font"))) for w in labels(v) if isinstance(w, tk.Label)}
        for letter in "TFDKG":
            self.assertIn((letter, "{Segoe UI} 11 bold"), letters)       # the shortcut letter, flush and bold
        self.assertIn(("eyboard Shortcuts", "{Segoe UI} 11 normal"), letters)
        self.assertEqual(v.cget("bg").upper(), "#FFFFFF")


class TutorialScreenTests(GuiCase):
    def test_board_scrolls_jumps_and_escapes(self):
        from views.tutorial_view import TutorialView
        closed = []
        v = TutorialView(self.root, on_close=lambda: closed.append(1))
        v.pack(fill="both", expand=True)
        self.root.update()
        self.assertEqual(len(v.titles), 5)
        self.assertEqual(str(v.text.cget("state")), "disabled")
        bold = v.text.tag_ranges("key")
        self.assertIn("Ctrl+H", [v.text.get(bold[i], bold[i + 1]) for i in range(0, len(bold), 2)])
        self.assertEqual(v.text.tag_cget("key", "font"), "{Segoe UI} 11 bold")
        top = v.text.yview()[0]
        v.handle_key(Key("5"))
        self.root.update()
        self.assertGreater(v.text.yview()[0], top)
        v.handle_key(Key("Home"))
        self.root.update()
        self.assertEqual(v.text.yview()[0], 0.0)
        v.handle_key(Key("Escape"))
        self.assertEqual(closed, [1])


if __name__ == "__main__":
    unittest.main()
