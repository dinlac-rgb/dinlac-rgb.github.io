"""
Balance Sheet / Profit & Loss figures from saved vouchers (temp database; your real one is
never touched). Run from the bizpulse_pro folder:  python -m unittest discover -s tests -v
"""
from __future__ import annotations

import sqlite3
import sys
import tempfile
import unittest
from datetime import date
from decimal import Decimal as D
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
sys.path.insert(0, str(Path(__file__).resolve().parent))

import services.reports as R  # noqa: E402
from services.migrations import upgrade_database  # noqa: E402
from services.voucher_store import VoucherStore  # noqa: E402
from test_voucher_store import SCHEMA, sales, voucher  # noqa: E402

GROUPS = {
    "Cash": "Cash-in-Hand", "Sales": "Sales Accounts", "Output CGST": "Duties & Taxes", "Output SGST": "Duties & Taxes",
    "Capital A/c": "Capital Account", "Purchases": "Purchase Accounts", "Office Rent": "Indirect Expenses",
    "HDFC Bank": "Bank Accounts",
}


class ReportTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.db = Path(self.tmp.name) / "bizpulse_local.db"
        con = sqlite3.connect(self.db)
        con.executescript(SCHEMA)
        con.close()
        upgrade_database(self.db, "19")
        self._saved = dict(R.LEDGER_GROUPS)
        R.LEDGER_GROUPS.clear()
        R.LEDGER_GROUPS.update(GROUPS)
        s = VoucherStore(self.db, "SRJ")
        s.save(voucher("Receipt", [("Dr", "Cash", "500"), ("Cr", "Sales", "500")], d=date(2026, 3, 15)))   # last year
        s.save(voucher("Journal", [("Dr", "Cash", "100000"), ("Cr", "Capital A/c", "100000")], d=date(2026, 4, 1)))
        s.save(voucher("Purchase", [("Dr", "Purchases", "6000"), ("Cr", "Cash", "6000")], d=date(2026, 5, 2)))
        s.save(sales())                                                                     # 9 Oct: Gupta 11,800
        s.save(voucher("Payment", [("Dr", "Office Rent", "1200"), ("Cr", "HDFC Bank", "1200")], d=date(2026, 6, 1)))
        s.save(voucher("Payment", [("Dr", "Mystery", "50"), ("Cr", "Cash", "50")], d=date(2026, 6, 2)))
        s.save(voucher("Payment", [("Dr", "Office Rent", "999"), ("Cr", "Cash", "999")], d=date(2026, 12, 1)))  # after end

    def tearDown(self):
        R.LEDGER_GROUPS.clear()
        R.LEDGER_GROUPS.update(self._saved)
        self.tmp.cleanup()

    def test_profit_and_loss(self):
        r = R.build_reports(self.db, date(2026, 10, 9))
        self.assertEqual(r.period_start, date(2026, 4, 1))
        self.assertEqual(r.pl["Sales Accounts"].amount, D("10000.00"))
        self.assertEqual(r.pl["Purchase Accounts"].amount, D("6000.00"))
        self.assertEqual(r.pl["Indirect Expenses"].amount, D("1200.00"))     # the December voucher is excluded
        self.assertEqual(r.gross_profit, D("4000.00"))
        self.assertEqual(r.net_profit, D("2800.00"))
        self.assertEqual(r.profit_before_period, D("500.00"))
        self.assertEqual(r.voucher_count, 5)
        self.assertIn("gst_sales_ledger", r.reference)
        self.assertIn("workforce_payroll", r.reference)

    def test_balance_sheet_balances_and_groups(self):
        r = R.build_reports(self.db, date(2026, 10, 9))
        liab = {n.name: n.amount for n in r.liabilities}
        assets = {n.name: n.amount for n in r.assets}
        self.assertEqual(liab["Capital Account"], D("100000.00"))
        self.assertEqual(liab["Current Liabilities"], D("1800.00"))           # output CGST + SGST
        self.assertEqual(liab["Profit & Loss A/c"], D("3300.00"))            # 500 earlier + 2,800 now
        self.assertEqual(assets["Current Assets"], D("105050.00"))           # cash 94,450 - bank 1,200 + Gupta 11,800
        self.assertEqual(assets[R.NOT_GROUPED], D("50.00"))
        self.assertEqual(r.not_grouped, [("Mystery", D("50.00"))])
        self.assertEqual(r.liabilities_total, r.assets_total)
        self.assertEqual(r.assets_total, D("105100.00"))
        debtors = next(c for c in next(n for n in r.assets if n.name == "Current Assets").children
                       if c.name == "Sundry Debtors")
        self.assertEqual([(c.name, c.amount) for c in debtors.children], [("Gupta Stores", D("11800.00"))])

    def test_empty_and_missing_database(self):
        empty = Path(self.tmp.name) / "empty.db"
        sqlite3.connect(empty).close()
        r = R.build_reports(empty, date(2026, 10, 9))
        self.assertEqual((r.liabilities_total, r.assets_total, r.voucher_count), (D("0.00"), D("0.00"), 0))
        with self.assertRaises(R.ReportError):
            R.build_reports(Path(self.tmp.name) / "nope.db", date(2026, 10, 9))

    def test_reports_never_write(self):
        before = self.db.stat().st_mtime_ns
        R.build_reports(self.db, date(2026, 10, 9))
        self.assertEqual(self.db.stat().st_mtime_ns, before)


if __name__ == "__main__":
    unittest.main()
