"""
Keyboard and focus paths: Enter / single click on list rows (Go To and every list screen), and the
action bar's keyboard mode (F12). Master-form Esc is covered in test_masters.py.
GUI tests need a display (Tk) and are skipped where there is none.
Run from the bizpulse_pro folder:  python -m unittest discover -s tests -v
"""
from __future__ import annotations

import gc
import sys
import time
import tkinter as tk
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from components.macro_bar import Macro, MacroBar  # noqa: E402
from config import theme as T  # noqa: E402


class GuiCase(unittest.TestCase):
    def setUp(self):
        try:
            self.root = tk.Tk()
        except tk.TclError as exc:
            raise unittest.SkipTest(f"no display: {exc}")
        T.apply_ttk_styles(self.root)
        self.root.geometry("1100x720")

    def tearDown(self):
        for _ in range(5):
            self.root.update()
            time.sleep(0.02)
        self.root.destroy()
        gc.collect()   # old Tk objects go away on the main thread, not in a worker

    def settle(self, until, n=100):
        for _ in range(n):
            self.root.update()
            if until():
                return
            time.sleep(0.02)


class ListRowTests(GuiCase):
    def make(self):
        from views.list_screen import ListScreen
        self.opened = []
        s = ListScreen(self.root, title="Go To", columns=(("name", "Screen", 300, "w"),),
                       load=lambda: [{"name": n} for n in ("Balance Sheet", "Day Book", "Trial Balance")],
                       on_close=lambda: None, on_enter=lambda r: self.opened.append(r["name"]))
        s.pack(fill="both", expand=True)
        self.settle(lambda: s.rows)
        s.focus_first()
        self.root.update()
        return s

    def test_down_then_enter_opens_once(self):
        s = self.make()
        s.tree.event_generate("<Down>")
        s.tree.event_generate("<Down>")
        s.tree.event_generate("<Return>")
        self.root.update()
        self.assertEqual(self.opened, ["Trial Balance"])              # once: the binding stops the event

    def test_single_click_highlights_and_takes_the_keyboard(self):
        s = self.make()
        self.root.update()
        x, y, _w, h = s.tree.bbox("1")
        s.tree.event_generate("<ButtonPress-1>", x=x + 10, y=y + h // 2)
        s.tree.event_generate("<ButtonRelease-1>", x=x + 10, y=y + h // 2)
        self.root.update()
        self.assertEqual(s.selected()["name"], "Day Book")
        self.assertEqual(self.opened, [])                             # a single click does not open
        self.assertIs(s.focus_get(), s.tree)
        s.tree.event_generate("<KP_Enter>")
        self.root.update()
        self.assertEqual(self.opened, ["Day Book"])


class ActionBarTests(GuiCase):
    def make(self):
        self.ran = []
        bar = MacroBar(self.root)
        bar.pack(side="right", fill="y")
        entry = tk.Entry(self.root)
        entry.pack()
        names = ["Contra", "Payment", "Receipt", "Journal", "Sales", "Purchase", "Credit Note", "Debit Note",
                 "More Details"]
        keys = ["F4", "F5", "F6", "F7", "F8", "F9", "Ctrl+F8", "Ctrl+F9", "Ctrl+I"]
        bar.set([Macro(k, n, lambda n=n: self.ran.append(n)) for k, n in zip(keys, names)], active="F5")
        entry.focus_force()
        self.root.update()
        return bar, entry

    def test_cursor_starts_on_current_and_wraps(self):
        bar, _entry = self.make()
        self.assertTrue(bar.enter_keyboard())
        self.assertEqual(bar.current().label, "Payment")              # the voucher type on screen
        self.assertEqual(str(bar._buttons["F5"].cget("bg")), T.ORANGE)
        bar.move(-1)
        bar.move(-1)
        self.assertEqual(bar.current().label, "More Details")          # round and round
        bar.move(1)
        self.assertEqual(bar.current().label, "Contra")
        self.assertEqual(str(bar._buttons["F4"].cget("bg")), T.ORANGE)
        self.assertEqual(str(bar._buttons["F5"].cget("bg")), T.NAVY)
        bar.current().command()
        self.assertEqual(self.ran, ["Contra"])
        bar.leave_keyboard()
        self.assertEqual(str(bar._buttons["F5"].cget("bg")), T.ORANGE)   # the current type again

    def test_click_elsewhere_leaves_keyboard_mode(self):
        bar, entry = self.make()
        bar.enter_keyboard()
        self.root.update()
        self.assertTrue(bar.keyboard)
        entry.focus_force()
        self.settle(lambda: not bar.keyboard)
        self.assertFalse(bar.keyboard)

    def test_empty_bar_does_not_take_the_keyboard(self):
        bar = MacroBar(self.root)
        self.assertFalse(bar.enter_keyboard())
        self.assertFalse(bar.keyboard)


if __name__ == "__main__":
    unittest.main()
