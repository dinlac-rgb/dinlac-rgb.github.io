"""
Voucher screen: Single / Double Entry modes, the Change Voucher Mode box, and the List of
Ledger Accounts panel. Needs a display (Tk); skipped where there is none.
Run from the bizpulse_pro folder:  python -m unittest discover -s tests -v
"""
from __future__ import annotations

import gc
import sqlite3
import sys
import tempfile
import time
import tkinter as tk
import unittest
from decimal import Decimal as D
from pathlib import Path
from unittest import mock

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from config import theme as T  # noqa: E402
from services.ledgers import load_ledger_catalogue  # noqa: E402
from views.vouchers_view import DOUBLE, SINGLE, VoucherView  # noqa: E402


def make_root():
    try:
        root = tk.Tk()
    except tk.TclError as exc:                       # no display (headless server)
        raise unittest.SkipTest(f"no display: {exc}")
    T.apply_ttk_styles(root)
    return root


class Key:
    """Just enough of a Tk event for handle_key."""
    def __init__(self, keysym, widget=None, state=0):
        self.keysym, self.widget, self.state = keysym, widget, state


CATALOGUE = [("Cash-in-Hand", ["Cash"]), ("Bank Accounts", ["HDFC Bank"]),
             ("Sundry Debtors", ["Gupta Stores", "Gupta Traders"]), ("Indirect Expenses", ["Office Rent"])]


class VoucherModeTests(unittest.TestCase):
    def setUp(self):
        self.root = make_root()
        self.saved = []
        self.view = VoucherView(self.root, voucher_type="Payment", number_for=lambda _t: 1,
                                on_accept=lambda v, done: (self.saved.append(v), done(True)), on_close=lambda: None,
                                ledger_source=lambda: CATALOGUE, mode=SINGLE)
        self.view.pack(fill="both", expand=True)
        self.root.update()
        for _ in range(100):                                     # the ledger list loads in a thread
            self.root.update()
            if self.view._ledger_cat:
                break
            time.sleep(0.02)

    def tearDown(self):
        for _ in range(5):                                       # let pending after() calls finish
            self.root.update()
            time.sleep(0.05)
        self.root.destroy()
        gc.collect()   # old Tk objects go away on the main thread, not in a worker

    def test_single_entry_is_default_and_saves_balanced_lines(self):
        v = self.view
        self.assertEqual(v._layout, SINGLE)
        v._account.insert(0, "HDFC Bank")
        v._single_lines[0].ledger.insert(0, "Office Rent")
        v._single_lines[0].amount_entry.insert(0, "25000")
        v._single_lines[1].ledger.insert(0, "Electricity")
        v._single_lines[1].amount_entry.insert(0, "3,200.50")
        v.accept()
        self.assertEqual(len(self.saved), 1, v._status.cget("text"))
        lines = [(ln["side"], ln["ledger"], ln["amount"]) for ln in self.saved[0]["lines"]]
        self.assertEqual(lines, [("Dr", "Office Rent", D("25000.00")), ("Dr", "Electricity", D("3200.50")),
                                 ("Cr", "HDFC Bank", D("28200.50"))])
        self.assertEqual(self.saved[0]["total"], D("28200.50"))

    def test_receipt_debits_the_account(self):
        v = self.view
        v.set_type("Receipt")
        v._account.insert(0, "Cash")
        v._single_lines[0].ledger.insert(0, "Gupta Stores")
        v._single_lines[0].amount_entry.insert(0, "500")
        v.accept()
        sides = {ln["ledger"]: ln["side"] for ln in self.saved[0]["lines"]}
        self.assertEqual(sides, {"Gupta Stores": "Cr", "Cash": "Dr"})

    def test_single_entry_checks(self):
        v = self.view
        v._single_lines[0].ledger.insert(0, "Office Rent")
        v._single_lines[0].amount_entry.insert(0, "100")
        v.accept()
        self.assertEqual(self.saved, [])
        self.assertIn("Account", v._status.cget("text"))
        v._account.insert(0, "office rent")
        v.accept()
        self.assertIn("cannot also be under Particulars", v._status.cget("text"))

    def test_journal_always_double(self):
        v = self.view
        v.set_type("Journal")
        self.assertEqual(v._layout, DOUBLE)
        self.assertIn("no Single Entry", v._mode_label.cget("text"))
        v.set_type("Payment")
        self.assertEqual(v._layout, SINGLE)

    def test_mode_box_ctrl_h_arrows_return_and_escape(self):
        v = self.view
        v.handle_key(Key("h", state=T.MOD_CTRL))
        self.assertIsNotNone(v._mode_box)
        self.assertEqual(v._mode_box.active_label, SINGLE)       # opens on the current mode
        v.handle_key(Key("Escape"))
        self.assertIsNone(v._mode_box)                          # Esc closes only the box
        self.assertEqual(v._layout, SINGLE)
        v.open_mode_box()
        v.handle_key(Key("Up"))
        self.assertEqual(v._mode_box.active_label, DOUBLE)
        v.handle_key(Key("Return"))
        self.assertIsNone(v._mode_box)
        self.assertEqual((v.mode, v._layout), (DOUBLE, DOUBLE))
        self.assertIn(("Ctrl+H", "Change Mode"), [(m.key, m.label) for m in v.macros()])

    def test_ctrl_h_in_a_field_does_not_delete_text(self):
        v = self.view
        v._account.insert(0, "Cash")
        v._account.icursor("end")
        v._account.focus_force()
        self.root.update()
        v._account.event_generate("<Control-h>")
        self.root.update()
        self.assertEqual(v._account.get(), "Cash")
        self.assertIsNotNone(v._mode_box)

    def test_switching_layout_with_typed_lines_asks(self):
        v = self.view
        v._account.insert(0, "Cash")
        with mock.patch("views.vouchers_view.messagebox.askyesno", return_value=False):
            v.set_mode(DOUBLE)
        self.assertEqual((v._layout, v._account.get()), (SINGLE, "Cash"))
        with mock.patch("views.vouchers_view.messagebox.askyesno", return_value=True):
            v.set_mode(DOUBLE)
        self.assertEqual(v._layout, DOUBLE)

    def test_double_entry_by_to_keys(self):
        v = self.view
        v.set_mode(DOUBLE)
        line = v._lines[0]
        v._on_side_key(line, Key("t"))
        self.assertEqual(line.side.get(), "Cr")
        v._on_side_key(line, Key("b"))
        self.assertEqual(line.side.get(), "Dr")

    def test_ledger_list_shows_filters_picks_and_escape_hides(self):
        v = self.view
        self.assertTrue(v._ledger_cat)                            # loaded in the background
        v.set_mode(DOUBLE)
        entry = v._lines[0].ledger
        v._show_ledger_list(entry)
        self.assertTrue(v._ledger_list.visible)
        entry.insert(0, "gupta s")
        v._ledger_list.filter(entry.get())
        v._complete_ledger(entry)                                # one name starts with it: completed
        self.assertEqual(entry.get(), "Gupta Stores")
        entry.delete(0, "end")
        entry.insert(0, "gupta")
        v._ledger_list.filter("gupta")
        v.handle_key(Key("Down", widget=entry))
        v.handle_key(Key("Down", widget=entry))
        v._complete_ledger(entry)                                # picked with Down: second Gupta
        self.assertEqual(entry.get(), "Gupta Traders")
        v.handle_key(Key("Escape"))
        self.assertFalse(v._ledger_list.visible)                 # first Esc: list only
        v._show_ledger_list(v._account)                          # Account: cash and bank only
        shown = [n for n in v._ledger_list._rows if n]
        self.assertEqual(shown, ["Cash", "HDFC Bank"])

    def test_new_names_are_kept(self):
        v = self.view
        entry = v._single_lines[0].ledger
        v._ledger_list.set_catalogue(CATALOGUE)
        v._show_ledger_list(entry)
        entry.insert(0, "Rent")
        v._ledger_list.filter("Rent")                            # "Office Rent" contains it, does not start with it
        v._complete_ledger(entry)
        self.assertEqual(entry.get(), "Rent")


class LedgerCatalogueTests(unittest.TestCase):
    def test_sources_merged_and_ordered(self):
        with tempfile.TemporaryDirectory() as tmp:
            db = Path(tmp) / "bizpulse_local.db"
            con = sqlite3.connect(db)
            con.executescript("""
                CREATE TABLE corporate_ledger_summary (account_id TEXT, account_name TEXT, outstanding_balance REAL,
                    credit_ceiling REAL);
                INSERT INTO corporate_ledger_summary VALUES ('C1', 'Gupta Stores', 0, 0);
                CREATE TABLE gst_sales_ledger (invoice_no TEXT, customer_name TEXT);
                INSERT INTO gst_sales_ledger VALUES ('SRJ/1', 'gupta stores'), ('SRJ/2', 'Bose & Co');
                CREATE TABLE bp_voucher_lines (voucher_id INT, line_no INT, side TEXT, ledger TEXT, amount_paise INT);
                INSERT INTO bp_voucher_lines VALUES (1, 1, 'Dr', 'Mystery', 100);
            """)
            con.commit()
            con.close()
            cats = dict(load_ledger_catalogue(db))
            order = [c for c, _n in load_ledger_catalogue(db)]
        self.assertEqual(cats["Sundry Debtors"], ["Bose & Co", "E-commerce Receivable", "Gupta Stores"])   # de-duplicated
        self.assertIn("Mystery", cats["Not grouped"])
        self.assertEqual(order[0], "Cash-in-Hand")
        self.assertEqual(order[-1], "Not grouped")

    def test_missing_database(self):
        cats = dict(load_ledger_catalogue(Path("/nonexistent/bizpulse_local.db")))
        self.assertIn("Cash", cats["Cash-in-Hand"])


if __name__ == "__main__":
    unittest.main()
