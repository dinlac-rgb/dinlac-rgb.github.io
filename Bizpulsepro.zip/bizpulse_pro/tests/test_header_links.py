"""
Header dropdown → backend script links, and the background runner that executes them.
Run from the bizpulse_pro folder:  python -m unittest discover -s tests -v
"""
from __future__ import annotations

import sys
import tempfile
import threading
import time
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from config import settings as S  # noqa: E402
from services.runner import ScriptRunner  # noqa: E402

EXPECTED = {
    ("Data", "Backup"): "backup_engine.py",
    ("Import", "Masters"): "db_migration_utility.py",
    ("Export", "Current Ledger"): "csv_balance_exporter.py",
    ("Export", "Final Accounts"): "profit_loss_statement.py",
    ("Print", "Current Invoice"): "thermal_invoice_formatter.py",
}


class HeaderLinkTests(unittest.TestCase):
    def test_options_run_their_scripts(self):
        actions = {(menu, label): action for menu, opts in S.HEADER_MENUS.items() for _k, label, action in opts}
        for where, script in EXPECTED.items():
            self.assertEqual(actions[where], ("script", script), where)

    def test_no_broken_links(self):
        """Every script option has a built-in fallback; every app option has a handler; only the two
        options the desktop edition cannot do are 'todo' (and they say what to do instead)."""
        import inspect
        sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
        import main as M
        src = inspect.getsource(M.BizPulseApp.run_header_action)
        for menu, opts in S.HEADER_MENUS.items():
            for _k, label, (kind, arg) in opts:
                if kind == "script":
                    self.assertIn(arg, M.SCRIPT_BUILTINS, (menu, label))
                    self.assertTrue(hasattr(M.BizPulseApp, M.SCRIPT_BUILTINS[arg]), arg)
                elif kind == "app":
                    self.assertIn(f'"{arg}"', src, (menu, label))
        todo = [(m, label) for m, opts in S.HEADER_MENUS.items() for _k, label, (kind, _a) in opts if kind == "todo"]
        self.assertEqual(sorted(todo), [("Data", "Split Company Data"), ("Exchange", "Synchronize")])
        self.assertEqual((S.BANKING_NOT_BUILT, S.MORE_REPORTS_NOT_BUILT, S.MASTER_NOT_BUILT), ({}, {}, {}))
        self.assertEqual(list(S.MACRO_NOT_BUILT), ["Period"])

    def test_hotkeys_unique_and_in_label(self):
        for menu, opts in S.HEADER_MENUS.items():
            keys = [k for k, _l, _a in opts]
            self.assertEqual(len(keys), len(set(keys)), menu)
            for key, label, _a in opts:
                self.assertIn(key, label.upper(), (menu, label))

    def test_utility_links_present(self):
        self.assertEqual(S.HEADER_RIGHT, [("S", "Settings"), ("D", "Dashboard"), ("T", "Tutorial"),
                                          ("U", "Upgrade Tier")])


class RunnerTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.dir = Path(self.tmp.name)
        self.posts: list[tuple[str, str, str]] = []

    def tearDown(self):
        self.tmp.cleanup()

    def _post(self, kind, payload):
        self.posts.append((kind, payload, threading.current_thread().name))

    def _wait_done(self, runner, timeout=20):
        end = time.time() + timeout
        while time.time() < end:
            for kind, payload, _t in list(self.posts):
                if kind == "done":
                    runner.mark_done(payload)
                    return
            time.sleep(0.05)
        self.fail("script did not finish")

    def test_script_runs_in_background_thread(self):
        (self.dir / "backup_engine.py").write_text("print('backup written')\n")
        runner = ScriptRunner(self._post, self.dir)
        self.assertTrue(runner.run_script("backup_engine.py", title="Data › Backup"))
        self.assertIn("backup_engine.py", runner.running)
        self._wait_done(runner)
        logs = [p for k, p, _t in self.posts if k == "log"]
        self.assertTrue(any("backup written" in line for line in logs), logs)
        worker_threads = {t for k, _p, t in self.posts if k == "done"}
        self.assertNotIn(threading.main_thread().name, worker_threads)   # never on the UI thread
        self.assertNotIn("backup_engine.py", runner.running)

    def test_missing_script_is_reported(self):
        runner = ScriptRunner(self._post, self.dir)
        self.assertFalse(runner.run_script("csv_balance_exporter.py", title="Export › Current Ledger"))
        self.assertTrue(any("not found" in p for _k, p, _t in self.posts))


if __name__ == "__main__":
    unittest.main()
