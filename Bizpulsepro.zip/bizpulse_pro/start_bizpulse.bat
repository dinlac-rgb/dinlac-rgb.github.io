@echo off
rem Starts BizPulse Pro without a console window. Needs Python 3.12+ (python.org installer).
cd /d "%~dp0"
where pythonw >nul 2>nul && (start "" pythonw main.py) || (python main.py)
