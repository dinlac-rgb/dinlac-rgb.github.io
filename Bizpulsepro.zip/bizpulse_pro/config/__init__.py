"""Colours, fonts and application settings."""
