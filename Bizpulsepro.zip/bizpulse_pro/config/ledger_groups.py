"""
Which group each ledger belongs to — this is what puts a ledger on the Balance Sheet or the
Profit & Loss A/c, and on which side.

Vouchers only record ledger NAMES, so every ledger used on a voucher must be listed here
(until the Create › Ledger screen exists). Names match without regard to capitals or spaces
at the ends. A ledger that is not listed, and is not a customer in corporate_ledger_summary,
appears as "Not grouped" on the reports — the totals still agree, but fix it here.

Groups (Tally's primary groups and the common sub-groups under them):

    Balance Sheet, Liabilities   Capital Account, Reserves & Surplus, Loans (Liability),
                                 Bank OD A/c, Secured Loans, Unsecured Loans,
                                 Current Liabilities, Duties & Taxes, Provisions, Sundry Creditors
    Balance Sheet, Assets        Fixed Assets, Investments, Current Assets, Bank Accounts,
                                 Cash-in-Hand, Deposits (Asset), Loans & Advances (Asset),
                                 Stock-in-Hand, Sundry Debtors
    Profit & Loss A/c            Sales Accounts, Direct Incomes, Purchase Accounts,
                                 Direct Expenses, Indirect Incomes, Indirect Expenses

Customers listed in corporate_ledger_summary are treated as Sundry Debtors automatically.
"""
from __future__ import annotations

LEDGER_GROUPS = {
    # Ledgers BizPulse Pro's own screens suggest
    "Cash": "Cash-in-Hand",
    "Sales": "Sales Accounts",
    "Output CGST": "Duties & Taxes",
    "Output SGST": "Duties & Taxes",
    "Output IGST": "Duties & Taxes",
    "Round Off": "Indirect Expenses",
    "Purchases": "Purchase Accounts",            # Item Invoice purchases
    "E-commerce Receivable": "Sundry Debtors",   # marketplace orders (O: Import › E-commerce Orders)
    "Input CGST": "Duties & Taxes",              # GST paid on purchases (GSTR-3B input tax credit)
    "Input SGST": "Duties & Taxes",
    "Input IGST": "Duties & Taxes",

    # Add your own, for example:
    # "Capital A/c - Srijee": "Capital Account",
    # "HDFC Bank": "Bank Accounts",
    # "Office Rent": "Indirect Expenses",
    # "Salaries": "Indirect Expenses",
    # "Purchases @ 18%": "Purchase Accounts",
    # "Freight Inward": "Direct Expenses",
    # "Computers": "Fixed Assets",
}

# The 28 reserved groups (Tally's chart of groups): group -> parent (None = primary group).
# New groups (Masters › Create › Group) go under one of these, or under another new group;
# the reports place them by following the chain up to the first reserved group.
RESERVED_GROUPS: dict[str, str | None] = {
    "Branch / Divisions": None,
    "Capital Account": None,
    "Reserves & Surplus": "Capital Account",
    "Current Assets": None,
    "Bank Accounts": "Current Assets",
    "Cash-in-Hand": "Current Assets",
    "Deposits (Asset)": "Current Assets",
    "Loans & Advances (Asset)": "Current Assets",
    "Stock-in-Hand": "Current Assets",
    "Sundry Debtors": "Current Assets",
    "Current Liabilities": None,
    "Duties & Taxes": "Current Liabilities",
    "Provisions": "Current Liabilities",
    "Sundry Creditors": "Current Liabilities",
    "Direct Expenses": None,
    "Direct Incomes": None,
    "Fixed Assets": None,
    "Indirect Expenses": None,
    "Indirect Incomes": None,
    "Investments": None,
    "Loans (Liability)": None,
    "Bank OD A/c": "Loans (Liability)",
    "Secured Loans": "Loans (Liability)",
    "Unsecured Loans": "Loans (Liability)",
    "Misc. Expenses (ASSET)": None,
    "Purchase Accounts": None,
    "Sales Accounts": None,
    "Suspense A/c": None,
}
PROFIT_AND_LOSS_GROUPS = ("Sales Accounts", "Direct Incomes", "Indirect Incomes", "Purchase Accounts",
                          "Direct Expenses", "Indirect Expenses")
