"""
Stock in the books — opening stock per financial year, and how closing stock is valued.

How stock enters the reports (services/reports.py):

    Profit & Loss A/c   Less: Opening Stock   = OPENING_STOCK for the financial year (below)
                        Add:  Closing Stock   = Stock Summary value at cost, today's quantities
    Balance Sheet       Current Assets › Stock-in-Hand › Closing Stock
                        Profit & Loss A/c › "Opening stock brought forward" = the opening stock
                        (last year's closing stock, which last year's profit already included)

So gross profit = Sales − (Opening Stock + Purchases + Direct Expenses − Closing Stock), and the
Balance Sheet still balances on its own: closing stock is added once on each side.

Rules that keep the margins honest:
    * Value stock at COST. If inventory_pricing_rules only gives a selling price or MRP, closing
      stock is left out of the books (the screens say so) rather than inflating gross profit.
    * Enter the opening stock for every financial year you report on: the value of the stock
      held on 1 April, at cost (normally last year's closing stock). If it is missing while
      closing stock is counted, the screens warn that gross profit is overstated.
    * Do not also post stock to a ledger grouped "Stock-in-Hand" on vouchers; that would count
      it twice (the reports warn if one exists).
"""
from __future__ import annotations

# Opening stock at cost, in rupees, per financial year ("2026-27" = 1 April 2026 to 31 March 2027).
# Write amounts as text so they stay exact, e.g. "125000.00".
OPENING_STOCK: dict[str, str] = {
    # "2026-27": "0.00",
}

# Turn off to keep stock out of the Balance Sheet, P&L and ratios (Stock Summary still shows it).
INCLUDE_STOCK_IN_BOOKS = True

# Rate column of inventory_pricing_rules used to value stock. None = the app picks a cost column
# (cost_price, unit_cost, purchase_rate …) and the Stock Summary names the one it used.
STOCK_RATE_COLUMN: str | None = None

# Names shown on the reports.
OPENING_STOCK_LEDGER = "Opening Stock"
CLOSING_STOCK_LEDGER = "Closing Stock"
