"""
BizPulse Pro — colours, fonts and ttk styles.

Every screen imports its look from here, so a colour or font changes in one place.
The Settings screen's choices (config/settings.py: THEME, FONT_SCALE, ROW_DENSITY,
GRID_LINES) are applied here when the app starts.
"""
from __future__ import annotations

import tkinter as tk
from tkinter import ttk

from config import settings as _S

# ----------------------------------------------------------------------------------------
# Colours
# ----------------------------------------------------------------------------------------
NAVY = "#0D2C54"          # corporate header (BizPulse landing page)
NAVY_ACTIVE = "#1B4A80"   # header label whose dropdown is open
LIGHT_BLUE = "#E6F0FA"    # side accent panels, List of Masters body
ORANGE = "#FD7E14"        # active highlight bar
WHITE = "#FFFFFF"         # central canvas
SLATE = "#6C757D"         # tagline, upper
SLATE_LIGHT = "#868E96"   # tagline, lower
TERMINAL_BG = "#212529"   # monitor background
NEON_GREEN = "#00FF66"    # monitor text
TEXT = "#1B2733"          # normal text on white
TEXT_DARK = "#212529"     # text on the orange bar (white on orange is too faint to read)
HOVER_TEXT = "#9EC5FE"    # header labels on hover (colour change instead of an underline)
BORDER = "#9DB7D5"        # subtle solid border round panels
LINE = "#D5DEE8"          # grid lines and field borders
MUTED = "#5A6772"         # captions, section headings
ROW_ALT = "#F5F8FC"       # alternate table rows
OK_GREEN = "#1E7E34"      # status: online / balanced
BAD_RED = "#B02A37"       # status: offline / errors

# Themes (Settings › T). Each one replaces only the accent colours; the working canvas stays
# white, text stays dark, and every header colour keeps white text readable on it.
THEMES = {
    "Pro Dark Blue": {},                                            # the colours above
    "Lite Classic": {"NAVY": "#1F5F99", "NAVY_ACTIVE": "#2E75B6", "LIGHT_BLUE": "#EEF5FC",
                     "ORANGE": "#F59F00", "HOVER_TEXT": "#D0E6FF", "BORDER": "#A9C4E2"},
    "Slate Minimal": {"NAVY": "#37414D", "NAVY_ACTIVE": "#4A5664", "LIGHT_BLUE": "#F1F3F5",
                      "ORANGE": "#F08C00", "HOVER_TEXT": "#DEE2E6", "BORDER": "#B8C0C8"},
}
THEME = _S.THEME if _S.THEME in THEMES else "Pro Dark Blue"
globals().update(THEMES[THEME])

# Row density (Settings › D) and grid lines (Settings › G).
COMPACT = _S.ROW_DENSITY == "Compact"
ROW_HEIGHT = 22 if COMPACT else 28          # table rows
CELL_PAD_Y = 1 if COMPACT else 4            # voucher grid cells (internal padding)
GRID_LINES = bool(_S.GRID_LINES)
CELL_LINE = LINE if GRID_LINES else "#F1F4F8"   # voucher grid cell borders: lines, or a flat sheet

# ----------------------------------------------------------------------------------------
# Fonts — one typography rule for the whole app:
#   every label, table item, menu, button and heading   Segoe UI 11 normal   (F_TEXT)
#   only the keyboard-shortcut letter of a menu item     Segoe UI 11 bold     (F_KEY)
# Hierarchy (titles, group rows, totals) is shown with colour and background, never weight
# or size. The shortcut letter is drawn flush against the rest of its word: no space, no
# underline (see views/masters_overlay.py: hotkey_labels).
# On computers without Segoe UI, Tk substitutes the platform's default sans-serif font.
# ----------------------------------------------------------------------------------------
FONT = "Segoe UI"
FONT_SIZE = 12 if _S.FONT_SCALE == 12 else 11     # Settings › F: 12 = high visibility
F_TEXT = (FONT, FONT_SIZE, "normal")
F_KEY = (FONT, FONT_SIZE, "bold")

# Named roles, kept so every screen still says what each piece of text is. All are F_TEXT
# except the two shortcut-letter roles.
F_BRAND = F_HEADER = F_TAG_UP = F_TAG_LOW = F_TEXT
F_MENU = F_MASTER = F_TEXT
F_MENU_KEY = F_MASTER_KEY = F_KEY
F_PANEL_HEAD = F_MACRO = F_STATUS_CAP = F_STATUS = F_LOG = F_HINT = F_BUTTON = F_TEXT
F_MASTER_SECTION = F_VIEW_TITLE = F_LABEL = F_LABEL_BOLD = F_GRID = F_GRID_HEAD = F_TEXT
F_AMOUNT = F_TOTAL = F_TILE = F_TEXT

# Event.state bits for Ctrl and Alt (Alt is 0x0008 on Linux, 0x20000 on Windows).
MOD_CTRL = 0x0004
MOD_ALT = 0x0008 | 0x20000


def apply_ttk_styles(root: tk.Tk) -> None:
    """Treeview look for the Day Book (the 'clam' theme lets headings take our colours)."""
    # Tk's own named fonts (entries, text boxes, scroll lists, dialogs) follow the same rule.
    from tkinter import font as tkfont
    for name in ("TkDefaultFont", "TkTextFont", "TkFixedFont", "TkMenuFont", "TkHeadingFont",
                 "TkCaptionFont", "TkSmallCaptionFont", "TkIconFont", "TkTooltipFont"):
        try:
            tkfont.nametofont(name).configure(family=FONT, size=FONT_SIZE, weight="normal", slant="roman",
                                              underline=0)
        except tk.TclError:
            pass
    style = ttk.Style(root)
    try:
        style.theme_use("clam")
    except tk.TclError:
        pass
    style.configure(
        "BizPulse.Treeview",
        background=WHITE, fieldbackground=WHITE, foreground=TEXT,
        rowheight=ROW_HEIGHT, font=F_TEXT, borderwidth=0,
    )
    style.map("BizPulse.Treeview", background=[("selected", ORANGE)], foreground=[("selected", TEXT_DARK)])
    style.configure(
        "BizPulse.Treeview.Heading",
        background=NAVY, foreground=WHITE, font=F_TEXT, padding=(6, 3 if COMPACT else 5),
        relief="solid" if GRID_LINES else "flat", bordercolor=BORDER if GRID_LINES else NAVY,
        lightcolor=NAVY, darkcolor=NAVY,
    )
    style.map("BizPulse.Treeview.Heading", background=[("active", NAVY)])
