"""
BizPulse Pro — application settings: menus, script mappings, file names, timeouts.

Scripts and the database are looked up in the project folder (the one holding main.py),
never in whatever folder the app happened to be started from.
"""
from __future__ import annotations

from decimal import Decimal
from pathlib import Path

APP_TITLE = "BizPulse Pro"
COMPANY_NAME = "Srijee Creations"      # shown on reports
WINDOW_GEOMETRY = "1100x720"
MIN_SIZE = (1100, 720)
APP_DIR = Path(__file__).resolve().parent.parent   # the folder that holds main.py

LICENCE_DISPLAY = "LIC-PRO-SRJ-2026-XXXX"   # display placeholder; not a licence check

# ----------------------------------------------------------------------------------------
# Preferences — chosen on the Settings screen ([S] Settings or Alt+S), which rewrites ONLY the
# lines between the two markers below (services/preferences.py). They are read when BizPulse
# starts, so a change takes effect at the next start (R on the Settings screen restarts now).
#   THEME            Pro Dark Blue (#0D2C54) | Lite Classic | Slate Minimal  (canvas stays white)
#   FONT_SCALE       11 (Segoe UI 11 normal, default) | 12 (high visibility)
#   ROW_DENSITY      Comfortable | Compact (thinner table rows and grid cells)
#   KEYBOARD_LAYOUT  Standard Tally | BizPulse Express  (voucher-type F-keys, see KEYBOARD_LAYOUTS)
#   GRID_LINES       True: separation lines on grids and tables | False: flat sheets
#   COMPANY_FILE     the company database BizPulse opens (Company › Select Company writes it)
#   PRINT_PAPER      A4 | 80 mm (thermal roll)          } Print › Configuration Setup
#   PRINT_SHOW_HSN   HSN/SAC column on printed invoices }
#   PRINT_FOOTER     line printed under every invoice   }
# ----------------------------------------------------------------------------------------
# >>> BIZPULSE PREFERENCES
THEME = 'Pro Dark Blue'
FONT_SCALE = 11
ROW_DENSITY = 'Comfortable'
KEYBOARD_LAYOUT = 'Standard Tally'
GRID_LINES = True
COMPANY_FILE = 'bizpulse_local.db'
PRINT_PAPER = 'A4'
PRINT_SHOW_HSN = True
PRINT_FOOTER = 'This is a computer-generated invoice.'
# <<< BIZPULSE PREFERENCES

# ----------------------------------------------------------------------------------------
# Header bar and macro column
# ----------------------------------------------------------------------------------------
HEADER_LEFT = [("K", "Company"), ("Y", "Data"), ("Z", "Exchange"), ("O", "Import"),
               ("E", "Export"), ("P", "Print"), ("F1", "Help")]
HEADER_RIGHT = [("S", "Settings"), ("D", "Dashboard"), ("T", "Tutorial"), ("U", "Upgrade Tier")]   # Alt+letter

# Right-hand action bar on the Corridor (each screen supplies its own; see components/macro_bar.py)
GATEWAY_MACROS = [("F2", "Period"), ("F3", "Company"), ("F4", "Go To")]
MACRO_NOT_BUILT = {      # F3 Company and F4 Go To work (main.macro_action)
    "Period": "Reports run for the financial year to date (Balance Sheet / P&L: C compares periods and quarters; "
              "GSTR-1 and GSTR-3B take a month).",
}
HEADER_NOT_BUILT: dict[str, str] = {}

APP_VERSION = "1.0.0"

# [U] Upgrade (Alt+U): the software-update check (services/updates.py). No prices or plans are
# shown in the app; they are on the BizPulse website. UPDATE_FEED_URL is the https address of
# the JSON feed your server publishes; blank = no check is made (the screen says so).
UPDATE_FEED_URL = ""
SECURITY_PATCH_LEVEL = "2026.10.0"     # raise after installing a security patch
TAX_TABLES_VERSION = "2026.10"         # raise after installing a GST rate / HSN table update
INSTALLED_VERSIONS = {"app": APP_VERSION, "security": SECURITY_PATCH_LEVEL, "tax_tables": TAX_TABLES_VERSION}
SUPPORT_CONTACT = "Srijee Creations · mybizpulse.in"

# ----------------------------------------------------------------------------------------
# Header dropdowns: header label -> [(hotkey, option, action)]
#   ("script", "file.py")   run a script beside main.py in the background (monitor shows output)
#   ("app", "name")         handled inside the app (see BizPulseApp.run_header_action)
#   ("todo", "reason")      cannot be done inside the app (says why in the status line)
#   A "script" option whose file is not beside main.py runs BizPulse's built-in version instead
#   (main.SCRIPT_BUILTINS): Backup, Import Masters, Export Current Ledger / Final Accounts, Print Invoice.
# Hotkeys are unique within each dropdown.
# ----------------------------------------------------------------------------------------
HEADER_MENUS = {
    "Company": [
        ("C", "Create Company", ("app", "create_company")),
        ("A", "Alter Company", ("app", "alter_company")),
        ("S", "Select Company", ("app", "select_company")),
        ("H", "Shut Company", ("app", "shut_company")),
    ],
    "Data": [
        ("B", "Backup", ("script", "backup_engine.py")),
        ("R", "Restore", ("app", "restore")),
        ("S", "Split Company Data", ("todo", "Splitting the books by financial year rewrites every table, so BizPulse "
                                             "does not do it automatically. Take a Backup, then create a new company "
                                             "(Company › Create Company) for the new year with the closing balances "
                                             "as opening balances.")),
    ],
    "Exchange": [
        ("S", "Synchronize", ("todo", "Synchronising needs a BizPulse sync server with sign-in; this desktop "
                                      "edition keeps the books in this file only. Use Data › Backup to copy them.")),
        ("L", "Client Share Pack", ("app", "client_pack")),
    ],
    "Import": [
        ("M", "Masters", ("script", "db_migration_utility.py")),
        ("V", "Vouchers CSV", ("app", "import_vouchers")),
        ("B", "Bank Statement", ("app", "bank_statement")),
        ("E", "E-commerce Orders", ("app", "ecommerce")),
    ],
    "Export": [
        ("C", "Current Ledger", ("script", "csv_balance_exporter.py")),
        ("F", "Final Accounts", ("script", "profit_loss_statement.py")),
        ("G", "GST Returns JSON", ("app", "gstr1")),
    ],
    "Print": [
        ("I", "Current Invoice", ("script", "thermal_invoice_formatter.py")),
        ("C", "Configuration Setup", ("app", "print_setup")),
    ],
    "Help": [
        ("A", "About Software", ("app", "about")),
        ("L", "Licence Activation", ("app", "licence")),
        ("T", "Troubleshooting", ("app", "troubleshoot")),
        ("G", "Activity Log", ("app", "audit_trail")),          # the audit trail (bp_system_audit_logs)
        ("M", "Session Messages", ("app", "activity_log")),     # this session's status-line messages
    ],
}

# ----------------------------------------------------------------------------------------
# CORRIDOR TO BIZPULSE
# ----------------------------------------------------------------------------------------
# Sections as on the Gateway of Tally. Hotkeys are unique across the whole menu, so Banking
# uses N (Ba-n-king, as in Tally) and B stays free for Balance Sheet.
GATEWAY_SECTIONS = [
    ("Masters", [("C", "Create"), ("A", "Alter"), ("H", "Chart of Accounts")]),
    ("Transactions", [("V", "Vouchers"), ("D", "Day Book")]),
    ("Utilities", [("N", "Banking"), ("L", "Audit Trail")]),
    ("Reports", [("B", "Balance Sheet"), ("P", "Profit & Loss A/c"), ("S", "Stock Summary"),
                 ("R", "Ratio Analysis"), ("M", "Display More Reports")]),
    ("", [("Q", "Quit")]),
]
GATEWAY_ITEMS = [item for _section, items in GATEWAY_SECTIONS for item in items]

# Banking - List of Actions: (section, [(label, hotkey)]). Not built yet: each says so.
BANKING_SECTIONS = [
    ("Reconciliation", [("Banking Activities", "B"), ("Imported Bank Data", "I")]),
    ("Cheque", [("Cheque Printing", "P"), ("Cheque Register", "R"), ("Post-dated Summary", "D")]),
    ("Other Reports", [("Deposit Slip", "S"), ("Payment Advice", "A")]),
]
BANKING_NOT_BUILT: dict[str, str] = {}     # every Banking action has a screen

# Display More Reports box: (section, [(label, hotkey)]). Letters are unique in the box.
MORE_REPORTS_SECTIONS = [
    ("Accounting", [("Balance Sheet", "B"), ("Profit & Loss A/c", "P"), ("Ratio Analysis", "R"),
                    ("Day Book", "D"), ("Dashboard", "H"), ("Trial Balance", "T"), ("Ledger Statement", "L"),
                    ("Cost Centre Summary", "C")]),
    ("Inventory", [("Stock Summary", "S"), ("Movement Analysis", "M")]),
    ("Statutory", [("GSTR-1", "G"), ("GSTR-3B Return", "U"), ("HSN/SAC Summary", "N")]),
]
MORE_REPORTS_NOT_BUILT: dict[str, str] = {}     # every report has a screen

# Stock valuation (rate column, opening stock per year) lives in config/stock_valuation.py.
from config.stock_valuation import STOCK_RATE_COLUMN  # noqa: E402,F401

# Masters with a Create / Alter form (views/master_form.py). Voucher Type and the company's own
# GST / PAN details have their own screens (see MASTER_NOT_BUILT).
MASTER_FORMS = ("Group", "Ledger", "GST Classification", "Stock Group", "Unit", "Stock Item", "Currency",
                "Stock Category", "Godown")
MASTER_NOT_BUILT: dict[str, str] = {}   # Voucher Type lists the fixed types; GST Registration, Company GST
                                         # Details and PAN/CIN open Company › Alter (main._on_master_chosen)

# Gateway items that open the centred List of Masters / Chart of Accounts box.
MASTER_MENU_ITEMS = ("Create", "Alter", "Chart of Accounts")

# Gateway items that run a script beside main.py (others open screens). Banking now opens
# its own menu, so pricing_config.py is no longer on the gateway.
GATEWAY_SCRIPTS: dict[str, str] = {}

# Not on the menu any more (Vouchers and Day Book are screens now), kept for reference:
#   payroll_engine.py, inspect_exports.py, db_migration_utility.py, database_config.py

# Scripts that write to the database ask "Yes / No" before running, wherever they are wired.
CONFIRM_BEFORE_RUN = {
    "db_migration_utility.py": "This appends records to the live database.",
    "database_config.py": "This runs the master database initialisation utility on the live database.",
}

# ----------------------------------------------------------------------------------------
# List of Masters: (section, [(label, hotkey letter)]). Every letter is unique in the list.
# ----------------------------------------------------------------------------------------
MASTER_SECTIONS = [
    ("Accounting Masters", [("Group", "G"), ("Ledger", "L"), ("Currency", "C"), ("Voucher Type", "V")]),
    ("Inventory Masters", [("Stock Group", "S"), ("Stock Category", "A"), ("Stock Item", "I"),
                           ("Unit", "U"), ("Godown", "D")]),
    ("Statutory Masters", [("GST Registration", "R"), ("GST Classification", "F")]),
    ("Statutory Details", [("Company GST Details", "M"), ("PAN/CIN Details", "P")]),
]

# ----------------------------------------------------------------------------------------
# Accounting vouchers (right-hand strip of the voucher screen)
# ----------------------------------------------------------------------------------------
# Voucher-type keys on the voucher screen's action bar; KEYBOARD_LAYOUT (Settings › K) picks one.
#   Standard Tally      F4 Contra, F5 Payment, F6 Receipt, F7 Journal, F8 Sales, F9 Purchase
#   BizPulse Express    the trading day's commonest first: F4 Sales, F5 Purchase, F6 Receipt,
#                       F7 Payment, F8 Journal, F9 Contra
KEYBOARD_LAYOUTS = {
    "Standard Tally": [("F4", "Contra"), ("F5", "Payment"), ("F6", "Receipt"), ("F7", "Journal"),
                       ("F8", "Sales"), ("F9", "Purchase")],
    "BizPulse Express": [("F4", "Sales"), ("F5", "Purchase"), ("F6", "Receipt"), ("F7", "Payment"),
                         ("F8", "Journal"), ("F9", "Contra")],
}
VOUCHER_TYPES = KEYBOARD_LAYOUTS.get(KEYBOARD_LAYOUT, KEYBOARD_LAYOUTS["Standard Tally"])
# Credit / Debit Note have their own keys (Tally's Ctrl+F8 / Ctrl+F9) instead of an F10
# "Other Vouchers" window.
NOTE_VOUCHER_TYPES = [("Ctrl+F8", "Credit Note"), ("Ctrl+F9", "Debit Note")]

# Inline submenu under Vouchers on the Corridor: (hotkey, voucher type). Letters are unique
# within the submenu; while it is open, letters choose from it, not from the rest of the box.
VOUCHER_SUBMENU = [("C", "Contra"), ("P", "Payment"), ("R", "Receipt"), ("J", "Journal"), ("S", "Sales"),
                   ("U", "Purchase"), ("N", "Credit Note"), ("T", "Debit Note")]
GATEWAY_SUBMENUS = {"Vouchers": VOUCHER_SUBMENU}

# Voucher screen background tint per type (the white canvas otherwise). Entry boxes stay white.
VOUCHER_TINTS = {"Credit Note": "#FDECEF", "Debit Note": "#FFF7D6"}     # soft pink, soft yellow

# The Dr / Cr cell's words per type. Journal uses Tally's By (= Dr) / To (= Cr).
SIDE_WORDS = {"Journal": ("By", "To")}
DEFAULT_VOUCHER_TYPE = "Payment"

# Voucher entry modes (Ctrl+H on the voucher screen, as in Tally):
#   Single Entry   one "Account" (cash / bank) at the top, then Particulars | Amount lines;
#                  the Account takes the total on the opposite side. Payment, Receipt, Contra.
#   Double Entry   every line has its own Dr / Cr side (By = Dr, To = Cr). All voucher types;
#                  Journal, Sales, Purchase, Credit Note and Debit Note always use it.
VOUCHER_MODES = [("Double Entry", "D"), ("Single Entry", "S")]
DEFAULT_VOUCHER_MODE = "Single Entry"
SINGLE_ENTRY_TYPES = ("Payment", "Receipt", "Contra")
# Side the Account takes in Single Entry (the Particulars lines take the other side):
#   Payment  Account Cr: money goes out of the cash / bank account to the Particulars
#   Receipt  Account Dr: money comes into the cash / bank account from the Particulars
#   Contra   Account Cr: money moves out of the Account into the Particulars (e.g. cash deposited
#            into HDFC Bank: Account = Cash, Particulars = HDFC Bank)
SINGLE_ENTRY_ACCOUNT_SIDE = {"Payment": "Cr", "Receipt": "Dr", "Contra": "Cr"}

# Foreign currency on vouchers (Single Entry, Double Entry and Accounting Invoice layouts).
# The Currency field sits after the date; INR (or blank) means rupees and Enter moves straight on.
# Any other code, or an amount typed as "USD 1,200" / "$1,200", opens the exchange-rate box.
# Lines are typed in the currency; the RUPEE value (amount x rate) is what is saved and reported.
# FOREX_ENABLED = False hides the Currency row (every voucher in rupees, one Enter fewer).
FOREX_ENABLED = True
CURRENCIES = [("USD", "US Dollar"), ("EUR", "Euro"), ("GBP", "Pound Sterling"), ("AED", "UAE Dirham"),
              ("SGD", "Singapore Dollar"), ("JPY", "Japanese Yen"), ("AUD", "Australian Dollar"),
              ("CAD", "Canadian Dollar")]     # offered in the rate box; any 3-letter code can be typed

# Sales and Purchase have their own modes in the Ctrl+H box (Tally's invoice modes):
#   Item Invoice        Name of Item | Quantity | Rate | per | Amount  (stock items; qty_on_hand changes)
#   Accounting Invoice  Particulars | Amount  (services: the party takes the total)
#   As Voucher          By / To | Particulars | Debit | Credit
INVOICE_TYPES = ("Sales", "Purchase")
INVOICE_MODES = [("Item Invoice", "I"), ("Accounting Invoice", "A"), ("As Voucher", "V")]
DEFAULT_INVOICE_MODE = "Item Invoice"
PARTY_SIDE = {"Sales": "Dr", "Purchase": "Cr"}             # the Party A/c is debited on Sales, credited on Purchase
ITEM_INVOICE_LEDGER = {"Sales": "Sales", "Purchase": "Purchases"}    # default ledger the items go to
OUTPUT_TAX_LEDGERS = {"cgst": "Output CGST", "sgst": "Output SGST", "igst": "Output IGST"}
DEFAULT_UNIT = "Nos"

# Extra details kept with a voucher (Ctrl+I drawer; Dispatch Details also opens after Party A/c name
# on Sales and Purchase). Saved in bp_voucher_details as "<short name> · <field>".
DETAIL_FORMS = {
    "Dispatch Details": ("Dispatch", ["Delivery Note No(s)", "Dispatch Doc No", "Dispatched through", "Destination",
                                      "Carrier Name/Agent", "Bill of Lading / RR No", "Date", "Motor Vehicle No"]),
    "Order Details": ("Order", ["Order No(s)", "Order Date", "Mode/Terms of Payment", "Other References",
                                "Terms of Delivery"]),
    "Consignee Details": ("Consignee", ["Name", "Address", "State", "GSTIN/UIN"]),
    # Payment / Receipt by cheque: the Cheque Register, Deposit Slip, Cheque Printing and
    # Payment Advice read these (Ctrl+I › Q on the voucher screen).
    "Cheque Details": ("Cheque", ["Cheque No.", "Cheque Date", "Bank Name", "Favouring"]),
}
COMPANY_STATE_NAME = "West Bengal"
COMPANY_GSTIN = ""            # your GSTIN, shown under GST Details (blank = not entered yet); GSTR-1 needs it
COMPANY_PAN = ""
COMPANY_CIN = ""
COMPANY_ADDRESS = ""
# The company values above are only the starting point: Company › Alter Company saves the real
# ones INSIDE each company's database (bp_company, services/company.py), and those are used.

# GSTR-1 export (services/gstr1.py). Check both against the current GST offline tool.
B2CL_LIMIT = Decimal("100000")    # B2C Large: inter-state invoice to an unregistered buyer above this value
GSTR1_JSON_VERSION = ""            # e.g. the "version" the offline tool writes; blank = left out of the file
EXPORT_DIR = APP_DIR / "exports"     # GSTR-1 JSON, ledger and final-accounts exports, client share packs
BACKUP_DIR = APP_DIR / "backups"     # Data › Backup writes here; Data › Restore reads from here
PRINT_DIR = APP_DIR / "prints"       # invoices, payment advices, deposit slips, cheques (HTML, Ctrl+P)

# GSTR-3B (Display More Reports): input tax credit is read from these ledgers (debits in the
# month). Post purchase GST to them (Dr Input CGST / SGST / IGST) for the ITC table to fill.
INPUT_TAX_LEDGERS = {"cgst": "Input CGST", "sgst": "Input SGST", "igst": "Input IGST"}

# Cheque Printing: positions in millimetres from the cheque's top-left corner. Print one on
# plain paper, hold it against a real leaf, and adjust these once for your bank.
CHEQUE_LAYOUT = {"size": (203, 92), "date": (152, 8), "payee": (22, 22), "words": (32, 31), "words_width": 150,
                 "figures": (158, 41)}

# ----------------------------------------------------------------------------------------
# Sales / GST (gst_sales_ledger)
# ----------------------------------------------------------------------------------------
INVOICE_PREFIX = "SRJ"            # invoice numbers look like SRJ/26-27/0001 (16 characters max)

# Srijee Creations' GST state code: 19 = West Bengal.
# Place of supply 19 -> CGST + SGST (half the rate each); any other state -> IGST (full rate).
COMPANY_STATE_CODE = "19"

# GST rates (%) accepted on Sales vouchers. Check them against the current notified slabs.
GST_RATES = ["0", "0.25", "3", "5", "18", "40"]

# Largest difference (rupees) allowed between taxable value + GST and the customer's debit.
ROUND_OFF_LIMIT = Decimal("1.00")

# ----------------------------------------------------------------------------------------
# E-commerce Orders (O: Import › E-commerce Orders; services/ecommerce.py)
#   Each order in the marketplace CSV becomes a Sales voucher (Item Invoice): Dr ECOM_PARTY_LEDGER,
#   Cr Sales and Output CGST + SGST (ship-to state = COMPANY_STATE_CODE) or Output IGST.
#   Every SKU must already be a product_sku in inventory_stock_registry; the GST rate and HSN come
#   from the CSV row, else from the Stock Item's GST Classification. Nothing is guessed: a row
#   without them is listed as an error and not posted.
# ----------------------------------------------------------------------------------------
ECOM_PARTY_LEDGER = "E-commerce Receivable"     # the marketplace owes you (Sundry Debtors)
ECOM_PRICES_INCLUDE_GST = True                  # marketplace prices are usually GST-inclusive
ECOM_ROUND_OFF_LEDGER = "Round Off"             # paise left by working back from inclusive prices
ECOM_ALLOW_NEGATIVE_STOCK = False               # False: an order that would take stock below zero is held back

# ----------------------------------------------------------------------------------------
# Cost centres (voucher lines; components/allocation_box.py, services/cost_centres.py)
#   Enter on the amount of a debit line whose ledger is in one of COST_CENTRE_GROUPS opens the
#   Cost Centre Allocation box. COST_CENTRES are offered there; any other name can be typed, and
#   names used before are offered too. Allocating is optional; once started it must add up.
# ----------------------------------------------------------------------------------------
COST_CENTRE_GROUPS = ("Direct Expenses", "Indirect Expenses", "Purchase Accounts")
COST_CENTRES = ["Marketing", "Operations", "Administration", "Sales Team", "Kolkata Branch", "Siliguri Branch"]

# ----------------------------------------------------------------------------------------
# Files and background checks
# ----------------------------------------------------------------------------------------
MAIN_DB = "bizpulse_local.db"     # the main company file (your own scripts use this one)
# The company database this run opens: COMPANY_FILE (above), or the main one. Every screen and
# service uses LOCAL_DB, so selecting a company (Company › Select Company) switches all of them.
LOCAL_DB = COMPANY_FILE if (APP_DIR / COMPANY_FILE).is_file() else MAIN_DB
SQLITE_HEADER = b"SQLite format 3\x00"
CREDIT_GUARD = "customer_credit_guard.py"
CREDIT_KEYWORDS = ("ALERT", "SUCCESS")

SCRIPT_TIMEOUT_S = 120          # a hung script never blocks the app; it is stopped after this
DB_CHECK_TIMEOUT_S = 20
NET_CHECK_EVERY_MS = 30_000     # internet indicator refresh
NET_PROBES = (("1.1.1.1", 53), ("8.8.8.8", 53))
