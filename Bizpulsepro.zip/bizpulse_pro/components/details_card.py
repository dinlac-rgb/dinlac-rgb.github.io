"""
A centred white details card on the voucher screen — Dispatch Details, Order Details,
Consignee Details (typed), and GST Details / Unused Vch No. (read-only information).

    card = DetailsCard(view, "Dispatch Details", fields=[...], values={...},
                       on_done=lambda values: ..., on_close=lambda values: ...)
    card.show()
    card.handle_key(event)   # the voucher screen forwards keys while the card is open

Keys: Enter moves to the next field and, on the last one, accepts the card (on_done);
Esc closes it (on_close) — what was typed is kept, nothing is lost. Tab / Shift+Tab also move.
Look: white background, thin grey border, Segoe UI 11 normal throughout.
"""
from __future__ import annotations

import tkinter as tk
from typing import Callable, Sequence

from config import theme as T

GREY = "#AEB7C2"


class DetailsCard(tk.Frame):
    def __init__(self, area: tk.Widget, title: str, fields: Sequence[str], values: dict[str, str] | None = None,
                 on_done: Callable[[dict], None] | None = None, on_close: Callable[[dict], None] | None = None,
                 readonly: bool = False, note: str = "", columns: int = 2) -> None:
        super().__init__(area, bg=T.WHITE, highlightthickness=1, highlightbackground=GREY, takefocus=1)
        self._area = area
        self.title = title
        self._on_done = on_done or (lambda _v: None)
        self._on_close = on_close or (lambda _v: None)
        self._entries: dict[str, tk.Entry] = {}
        values = values or {}

        tk.Label(self, text=title, bg=T.WHITE, fg=T.NAVY, font=T.F_TEXT, anchor="w", padx=14, pady=8).pack(
            side="top", fill="x")
        tk.Frame(self, bg=GREY, height=1).pack(side="top", fill="x")
        body = tk.Frame(self, bg=T.WHITE)
        body.pack(side="top", fill="both", padx=14, pady=10)
        for i, name in enumerate(fields):
            r, c = divmod(i, columns)
            tk.Label(body, text=name, bg=T.WHITE, fg=T.TEXT, font=T.F_TEXT, anchor="w").grid(
                row=r, column=c * 2, sticky="w", padx=(0 if c == 0 else 18, 8), pady=3)
            e = tk.Entry(body, width=22, font=T.F_TEXT, relief="flat", bd=0, highlightthickness=1,
                         highlightbackground=T.LINE, highlightcolor=T.ORANGE,
                         readonlybackground=T.ROW_ALT)
            e.insert(0, values.get(name, ""))
            if readonly:
                e.configure(state="readonly")
            e.grid(row=r, column=c * 2 + 1, sticky="ew", pady=3, ipady=3)
            self._entries[name] = e
        if note:
            tk.Label(self, text=note, bg=T.WHITE, fg=T.MUTED, font=T.F_HINT, anchor="w", justify="left",
                     wraplength=560, padx=14).pack(side="top", fill="x")
        hint = "Esc close" if readonly else "Enter next field (last field accepts)    Esc close, keeps what is typed"
        tk.Label(self, text=hint, bg=T.WHITE, fg=T.MUTED, font=T.F_HINT, pady=6).pack(side="top")
        self._readonly = readonly

    # ---- public ------------------------------------------------------------------------
    def show(self) -> None:
        self.place(in_=self._area, relx=0.5, rely=0.45, anchor="center")
        self.lift()
        first = next(iter(self._entries.values()), None)
        (first if first is not None and not self._readonly else self).focus_set()

    @property
    def values(self) -> dict[str, str]:
        return {k: e.get().strip() for k, e in self._entries.items()}

    def handle_key(self, event: tk.Event) -> str | None:
        if event.keysym == "Escape":
            self._on_close(self.values)
            return "break"
        if event.keysym in ("Return", "KP_Enter"):
            if self._readonly:
                self._on_close(self.values)
                return "break"
            names = list(self._entries)
            current = next((n for n, e in self._entries.items() if e is event.widget), None)
            if current is None or current == names[-1]:
                self._on_done(self.values)
            else:
                self._entries[names[names.index(current) + 1]].focus_set()
            return "break"
        return None
