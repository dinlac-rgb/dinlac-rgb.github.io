"""
Small column chart drawn on a Tk Canvas (no extra libraries), used by the Dashboard.

    chart = ColumnChart(parent, series=[("Sales", SERIES_IN)], categories=MONTHS, titles=month_names)
    chart.set_data([[...12 Decimals...]])

Look: one baseline, hairline solid gridlines in a recessive grey, columns at most 24 px wide
with a 2 px gap between neighbours, axis labels in compact Indian units (K, L, Cr). A legend
is drawn for two or more series (one series is named by the card title). Pointing at a month
shows a tooltip with the exact rupee figures. Text never takes the series colour.
"""
from __future__ import annotations

import tkinter as tk
from decimal import Decimal
from typing import Sequence

from config import theme as T

SERIES_IN = "#2A78D6"      # money coming in: sales, cash in   (categorical slot 1)
SERIES_OUT = "#EB6834"     # money going out: purchases, cash out (categorical slot 2)
GRID = "#E3E8EE"
AXIS = "#AEB9C5"
HOVER_BAND = "#EEF3F9"
MAX_BAR = 24
GAP = 2
PAD_L, PAD_R, PAD_T, PAD_B = 58, 12, 26, 24


def compact_inr(v: Decimal | float) -> str:
    v = float(v)
    for size, unit in ((1e7, "Cr"), (1e5, "L"), (1e3, "K")):
        if abs(v) >= size:
            n = v / size
            return f"{n:.1f}{unit}".replace(".0" + unit, unit)
    return f"{v:.0f}"


def nice_step(top: float, ticks: int = 4) -> float:
    raw = top / ticks
    mag = 10 ** (len(str(int(raw))) - 1) if raw >= 1 else 1
    for m in (1, 2, 2.5, 5, 10):
        if raw <= m * mag:
            return m * mag
    return 10 * mag


def full_inr(v: Decimal) -> str:
    from views.vouchers_view import fmt_inr      # local import: components stay free of view imports at load
    return ("-" if v < 0 else "") + "₹" + fmt_inr(abs(v))


class ColumnChart(tk.Canvas):
    def __init__(self, parent: tk.Widget, *, series: Sequence[tuple[str, str]], categories: Sequence[str],
                 titles: Sequence[str], empty_text: str = "Nothing to show yet") -> None:
        super().__init__(parent, bg=T.WHITE, highlightthickness=0, height=170)
        self._series = list(series)
        self._cats = list(categories)
        self._titles = list(titles)
        self._empty = empty_text
        self._values: list[list[Decimal]] = [[Decimal(0)] * len(self._cats) for _ in self._series]
        self._geom: tuple[float, float, float] | None = None      # (x0, slot width, plot bottom)
        self.bind("<Configure>", lambda _e: self.redraw())
        self.bind("<Motion>", self._hover)
        self.bind("<Leave>", lambda _e: self.delete("hover"))

    def set_data(self, values: Sequence[Sequence[Decimal]], titles: Sequence[str] | None = None) -> None:
        self._values = [list(v) for v in values]
        if titles is not None:
            self._titles = list(titles)
        self.redraw()

    # ---- drawing -----------------------------------------------------------------------
    def redraw(self) -> None:
        self.delete("all")
        w, h = self.winfo_width(), self.winfo_height()
        if w < 120 or h < 80:
            return
        x0, x1, y0, y1 = PAD_L, w - PAD_R, PAD_T, h - PAD_B
        top = max([float(v) for vs in self._values for v in vs] + [0.0])

        if len(self._series) > 1:                          # legend, top right; text in text colour
            x = x1
            for name, colour in reversed(self._series):
                tid = self.create_text(x, 10, text=name, anchor="e", fill=T.MUTED, font=T.F_HINT)
                bx = self.bbox(tid)[0] - 6
                self.create_rectangle(bx - 9, 5, bx, 14, fill=colour, outline="")
                x = bx - 18

        if top <= 0:
            self.create_line(x0, y1, x1, y1, fill=AXIS)
            self.create_text((x0 + x1) / 2, (y0 + y1) / 2, text=self._empty, fill=T.MUTED, font=T.F_LABEL)
            self._draw_categories(x0, x1, y1)
            self._geom = None
            return

        step = nice_step(top)
        ymax = step * -(-top // step)
        scale = (y1 - y0) / ymax
        t = 0.0
        while t <= ymax + 1e-9:                            # gridlines + y labels
            y = y1 - t * scale
            if t:
                self.create_line(x0, y, x1, y, fill=GRID)
            self.create_text(x0 - 8, y, text=compact_inr(t), anchor="e", fill=T.MUTED, font=T.F_HINT)
            t += step

        n = len(self._series)
        slot = (x1 - x0) / len(self._cats)
        bar = max(3.0, min(MAX_BAR, (slot - 8 - GAP * (n - 1)) / n))
        group = bar * n + GAP * (n - 1)
        for i in range(len(self._cats)):
            left = x0 + i * slot + (slot - group) / 2
            for s, (_name, colour) in enumerate(self._series):
                v = float(self._values[s][i])
                if v <= 0:
                    continue
                bx = left + s * (bar + GAP)
                self.create_rectangle(bx, y1 - v * scale, bx + bar, y1, fill=colour, outline="", tags=("bar",))
        self.create_line(x0, y1, x1, y1, fill=AXIS)        # baseline on top of the bars' feet
        self._draw_categories(x0, x1, y1)

        if n == 1:                                         # one direct label: the latest month with a figure
            last = max((i for i, v in enumerate(self._values[0]) if v > 0), default=None)
            if last is not None:
                cx = x0 + last * slot + slot / 2
                cy = y1 - float(self._values[0][last]) * scale
                self.create_text(cx, cy - 8, text=compact_inr(self._values[0][last]), fill=T.TEXT,
                                 font=T.F_HINT, anchor="s")
        self._geom = (x0, slot, y1)

    def _draw_categories(self, x0: float, x1: float, y1: float) -> None:
        slot = (x1 - x0) / len(self._cats)
        for i, c in enumerate(self._cats):
            self.create_text(x0 + i * slot + slot / 2, y1 + 12, text=c, fill=T.MUTED, font=T.F_HINT)

    def _hover(self, event: tk.Event) -> None:
        self.delete("hover")
        if self._geom is None:
            return
        x0, slot, y1 = self._geom
        i = int((event.x - x0) // slot)
        if not 0 <= i < len(self._cats) or event.y > y1 + 20:
            return
        self.create_rectangle(x0 + i * slot, PAD_T - 4, x0 + (i + 1) * slot, y1, fill=HOVER_BAND, outline="",
                              tags=("hover",))
        self.tag_lower("hover")
        lines = [self._titles[i]] + [f"{name}  {full_inr(self._values[s][i])}"
                                     for s, (name, _c) in enumerate(self._series)]
        tx = x0 + (i + 1) * slot + 6
        if tx + 190 > self.winfo_width():
            tx = x0 + i * slot - 196
        ty = PAD_T
        tid = self.create_text(tx + 22, ty + 6, text="\n".join(lines), anchor="nw", fill=T.TEXT, font=T.F_HINT,
                               tags=("hover",))
        bx0, by0, bx1, by1 = self.bbox(tid)
        box = self.create_rectangle(tx, by0 - 6, max(bx1 + 10, tx + 150), by1 + 6, fill=T.WHITE, outline=T.BORDER,
                                    tags=("hover",))
        self.tag_raise(tid, box)
        line_h = (by1 - by0) / len(lines)
        for s, (_name, colour) in enumerate(self._series):     # swatch beside each series line
            yy = by0 + line_h * (s + 1.5)
            self.create_rectangle(tx + 8, yy - 4, tx + 16, yy + 4, fill=colour, outline="", tags=("hover",))
