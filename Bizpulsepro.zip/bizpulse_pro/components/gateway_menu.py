"""
CORRIDOR TO BIZPULSE — the light-blue gateway box, sitting in the middle of the white canvas,
shifted a little to the right (under the right hand and the right eye).

    menu = GatewayMenu(canvas, sections=[("Masters", [("C", "Create"), ...]), ...],
                       on_select=callback, submenus={"Vouchers": [("C", "Contra"), ...]})
    menu.show()              # places the box
    menu.handle_key(event)   # call from the window's key dispatcher; returns "break" when used

Inline submenus (Vouchers): choosing an item that has a submenu (Enter, its letter, or a
click) opens the submenu directly under it, inside the same box, instead of a separate
window. While it is open the keyboard belongs to the submenu: its own letters, Up / Down,
Enter (on_select receives the sub-item, e.g. "Payment"), and Esc closes it and puts the
orange bar back on the parent row ("Vouchers"). If the open submenu would make the box taller
than the canvas, the other sections are tucked away until it closes, so nothing is cut off.

Keys at the top level: the item letter opens it, Up / Down move the orange bar (wrapping at
the ends, like the Gateway of Tally), Enter opens the highlighted item. Ctrl / Alt
combinations are left to the caller.

Typography: Segoe UI 11 normal; only the shortcut letter is bold, drawn flush inside its word
("Ba" + bold "n" + "king"), with no space, prefix or underline.
"""
from __future__ import annotations

import tkinter as tk
from typing import Callable, Mapping, Sequence

from components.pointer_guard import PointerGuard
from config import theme as T
from views.masters_overlay import hotkey_labels

OPEN_PARENT = "#CFE0F3"      # the parent row while its submenu is open


class _Row:
    def __init__(self, key: str, label: str, widgets: tuple[tk.Widget, ...], parent: str | None) -> None:
        self.key, self.label, self.widgets, self.parent = key, label, widgets, parent


class GatewayMenu(tk.Frame):
    WIDTH = 320
    CENTRE_X = 0.60      # fraction of the canvas width: a little right of the middle
    CENTRE_Y = 0.54      # a touch below the middle, clear of the tagline at the top
    TOP_CLEAR = 64       # keep the box below the maker's line at the top of the canvas

    def __init__(self, parent: tk.Widget, sections: Sequence[tuple[str, Sequence[tuple[str, str]]]],
                 on_select: Callable[[str], None],
                 submenus: Mapping[str, Sequence[tuple[str, str]]] | None = None,
                 on_change: Callable[[], None] | None = None) -> None:
        super().__init__(parent, bg=T.LIGHT_BLUE, highlightbackground=T.NAVY, highlightthickness=1)
        self._parent = parent
        self._on_select = on_select
        self._on_change = on_change or (lambda: None)      # a submenu opened or closed
        self._top: list[_Row] = []
        self._subs: dict[str, list[_Row]] = {}
        self._sub_frames: dict[str, tk.Frame] = {}
        self._section_frames: list[tuple[tk.Frame, set[str]]] = []
        self._expanded: str | None = None
        self._active = 0                     # index into the rows currently navigable
        self._hover_enabled = True
        self._pointer = PointerGuard()          # the bar follows the mouse only when it really moves
        submenus = submenus or {}

        tk.Label(self, text="CORRIDOR TO BIZPULSE", bg=T.NAVY, fg=T.WHITE, font=T.F_PANEL_HEAD,
                 pady=9).pack(side="top", fill="x")
        self._list = tk.Frame(self, bg=T.LIGHT_BLUE, takefocus=1)
        self._list.pack(side="top", fill="x", pady=(4, 6))

        for title, items in sections:
            sec = tk.Frame(self._list, bg=T.LIGHT_BLUE)
            sec.pack(side="top", fill="x")
            if title:     # section heading: not selectable
                tk.Label(sec, text=title.upper(), bg=T.LIGHT_BLUE, fg=T.MUTED, font=T.F_MASTER_SECTION,
                         anchor="w").pack(side="top", fill="x", padx=24, pady=(6, 0))
            else:
                tk.Frame(sec, bg=T.LIGHT_BLUE, height=6).pack(side="top", fill="x")
            labels = set()
            for key, label in items:
                self._top.append(self._add_row(sec, key, label, parent=None, indent=12))
                labels.add(label)
                if label in submenus:
                    frame = tk.Frame(sec, bg=T.LIGHT_BLUE)        # packed under its parent when opened
                    self._sub_frames[label] = frame
                    self._subs[label] = [self._add_row(frame, k, l, parent=label, indent=36)
                                         for k, l in submenus[label]]
            self._section_frames.append((sec, labels))

        self._hint = tk.Label(self, text="", bg=T.LIGHT_BLUE, fg=T.MUTED, font=T.F_HINT)
        self._hint.pack(side="top", pady=(0, 8))
        parent.bind("<Configure>", lambda _e: self._place() if self.winfo_manager() else None, add="+")
        self._paint()

    def _add_row(self, holder: tk.Frame, key: str, label: str, parent: str | None, indent: int) -> _Row:
        row = tk.Frame(holder, bg=T.LIGHT_BLUE, cursor="hand2")
        row.pack(side="top", fill="x", padx=12, pady=1)
        parts = hotkey_labels(row, label, key, T.LIGHT_BLUE, T.NAVY, first_padx=indent)
        item = _Row(key, label, (row, *parts), parent)
        for w in item.widgets:
            # Motion, not Enter: a row that slides under a resting pointer (the box re-lays out
            # when the submenu opens or closes) must not steal the keyboard selection.
            w.bind("<Motion>", lambda e, it=item: self._hover(it, e))
            w.bind("<Button-1>", lambda _e, it=item: self._click(it))
        return item

    # ---- public ------------------------------------------------------------------------
    def show(self) -> None:
        self._place()

    @property
    def expanded(self) -> str | None:
        """The parent whose inline submenu is open, if any."""
        return self._expanded

    @property
    def active_label(self) -> str:
        return self._nav()[self._active].label

    def focus_menu(self) -> None:
        self._list.focus_set()
        self._paint()

    def set_hover_enabled(self, enabled: bool) -> None:
        """Off while a box or screen is drawn over the workspace, so the bar doesn't jump."""
        self._hover_enabled = enabled
        self._pointer.reset()                   # back on: wait for a real movement before following

    def set_active(self, index: int) -> None:
        self._active = index % len(self._nav())
        self._paint()

    def activate(self, index: int) -> None:
        self.set_active(index)
        item = self._nav()[self._active]
        if item.parent is None and item.label in self._subs:
            self.expand(item.label)
        else:
            self._on_select(item.label)

    def expand(self, label: str) -> None:
        if label not in self._subs:
            return
        if self._expanded and self._expanded != label:
            self.collapse()
        self._expanded = label
        parent_row = next(r for r in self._top if r.label == label)
        self._sub_frames[label].pack(side="top", fill="x", after=parent_row.widgets[0])
        self._active = 0
        self._fit()
        self._paint()
        self._on_change()

    def collapse(self) -> None:
        """Esc in the submenu: close it and put the bar back on its parent row."""
        label = self._expanded
        if label is None:
            return
        self._sub_frames[label].pack_forget()
        self._expanded = None
        self._repack_sections()                          # brings back anything tucked away
        self._active = next(i for i, r in enumerate(self._top) if r.label == label)
        self._place()
        self._paint()
        self._on_change()

    def handle_key(self, event: tk.Event) -> str | None:
        """Keyboard override for the gateway. Returns "break" when the key was used."""
        if event.state & (T.MOD_CTRL | T.MOD_ALT):
            return None
        keysym = event.keysym
        if keysym == "Escape" and self._expanded:
            self.collapse()
            return "break"
        if keysym in ("Up", "Down"):
            self.set_active(self._active + (-1 if keysym == "Up" else 1))
            return "break"
        if keysym in ("Return", "KP_Enter"):
            self.activate(self._active)
            return "break"
        if len(keysym) == 1 and keysym.isalpha():
            letter = keysym.upper()
            hit = next((i for i, r in enumerate(self._nav()) if r.key == letter), None)
            if hit is not None:
                self.activate(hit)
            return "break"
        return None

    # ---- internal ----------------------------------------------------------------------
    def _nav(self) -> list[_Row]:
        return self._subs[self._expanded] if self._expanded else self._top

    def _paint(self) -> None:
        nav = self._nav()
        active = nav[self._active % len(nav)]
        for item in self._top + [r for rows in self._subs.values() for r in rows]:
            if item is active:
                bg, fg = T.ORANGE, T.TEXT_DARK
            elif item.label == self._expanded and item.parent is None:
                bg, fg = OPEN_PARENT, T.NAVY
            else:
                bg, fg = T.LIGHT_BLUE, T.NAVY
            for w in item.widgets:
                w.configure(bg=bg)
                if isinstance(w, tk.Label):
                    w.configure(fg=fg)
        self._hint.configure(text="Up / Down   Enter open   Esc close list" if self._expanded
                             else "Up / Down select   Enter open   Letter = shortcut")

    def _repack_sections(self) -> None:
        """Show every section again, in its original order."""
        for sec, _labels in self._section_frames:
            sec.pack_forget()
        for sec, _labels in self._section_frames:
            sec.pack(side="top", fill="x")

    def _fit(self) -> None:
        """If the open submenu makes the box taller than the canvas, tuck the other sections away."""
        self.update_idletasks()
        room = self._parent.winfo_height() - self.TOP_CLEAR - 6
        if room > 50 and self.winfo_reqheight() > room:
            for sec, labels in self._section_frames:
                if self._expanded not in labels:
                    sec.pack_forget()
        self._place()

    def _place(self) -> None:
        self.update_idletasks()
        height = self._parent.winfo_height()
        box = self.winfo_reqheight()
        if height > box + self.TOP_CLEAR:
            y = max(self.TOP_CLEAR, min(height * self.CENTRE_Y - box / 2, height - box - 6))
        else:
            y = self.TOP_CLEAR
        self.place(in_=self._parent, relx=self.CENTRE_X, y=int(y), anchor="n", width=self.WIDTH)

    def _hover(self, item: _Row, event=None) -> None:
        if not self._hover_enabled or (event is not None and not self._pointer.moved(event)):
            return
        nav = self._nav()
        if item in nav:
            self._active = nav.index(item)
            self._paint()

    def _click(self, item: _Row) -> None:
        if item.parent is None and self._expanded and item.label != self._expanded:
            self.collapse()
        nav = self._nav()
        if item in nav:
            self.activate(nav.index(item))
