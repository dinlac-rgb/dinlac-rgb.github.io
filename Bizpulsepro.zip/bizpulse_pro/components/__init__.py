"""Panels that stay on the main screen: the gateway menu and the subsystem monitor."""
