"""
"List of Ledger Accounts" — the white panel on the right of the voucher screen.

It appears while the cursor is in a ledger field (Account, or a Particulars cell) and hides
when the cursor moves to an amount, the date or the narration, or when Esc is pressed.

    panel = LedgerListPanel(parent, on_pick=fill_current_field)
    panel.set_catalogue([("Cash-in-Hand", ["Cash"]), ("Sundry Debtors", ["Gupta Stores", …]), …])
    panel.show(only=("Cash-in-Hand", "Bank Accounts"))   # or only=None for every category
    panel.filter("gup")      # as the user types: keeps names containing the text
    panel.move(+1)           # Up / Down from the ledger field
    panel.choice(typed)      # the name Enter should put in the field, or None to keep what was typed

Choosing: Up / Down (or a click) picks a name, and Enter puts it in the field. Without that,
Enter keeps what was typed, except when exactly one name starts with the typed text, which is
then completed. New names can still be typed (there is no ledger master screen yet).
"""
from __future__ import annotations

import tkinter as tk
from typing import Callable, Sequence

from config import theme as T

Catalogue = Sequence[tuple[str, Sequence[str]]]


class LedgerListPanel(tk.Frame):
    WIDTH = 270

    def __init__(self, parent: tk.Widget, on_pick: Callable[[str], None]) -> None:
        super().__init__(parent, bg=T.WHITE, width=self.WIDTH, highlightthickness=1, highlightbackground=T.NAVY)
        self.pack_propagate(False)
        self._on_pick = on_pick
        self._catalogue: list[tuple[str, list[str]]] = []
        self._only: set[str] | None = None
        self._text = ""
        self._rows: list[str | None] = []           # listbox index -> ledger name (None = heading)
        self._armed = False                         # True once the user picked with Up / Down / click
        self.visible = False
        self.pack_before: tk.Widget | None = None    # keep the panel right of this widget

        self._title = tk.Label(self, text="List of Ledger Accounts", bg=T.NAVY, fg=T.WHITE, font=T.F_TEXT, pady=6)
        self._title.pack(side="top", fill="x")
        self._hint = tk.Label(self, text="", bg=T.WHITE, fg=T.MUTED, font=T.F_HINT, anchor="w", padx=8)
        self._hint.pack(side="bottom", fill="x", pady=(0, 4))
        box = tk.Frame(self, bg=T.WHITE)
        box.pack(side="top", fill="both", expand=True, padx=(6, 0), pady=6)
        sb = tk.Scrollbar(box, orient="vertical")
        sb.pack(side="right", fill="y")
        self._list = tk.Listbox(box, bg=T.WHITE, fg=T.TEXT, font=T.F_TEXT, relief="flat", bd=0,
                                highlightthickness=0, activestyle="none", exportselection=False,
                                selectbackground=T.ORANGE, selectforeground=T.TEXT_DARK,
                                yscrollcommand=sb.set, takefocus=0)
        self._list.pack(side="left", fill="both", expand=True)
        sb.configure(command=self._list.yview)
        self._list.bind("<ButtonRelease-1>", self._click)
        self._list.bind("<Double-Button-1>", self._click)

    # ---- data --------------------------------------------------------------------------
    def set_catalogue(self, catalogue: Catalogue) -> None:
        self._catalogue = [(cat, list(names)) for cat, names in catalogue]
        self._redraw()

    def set_title(self, title: str) -> None:
        self._title.configure(text=title)

    def names(self) -> set[str]:
        return {n.lower() for _c, names in self._catalogue for n in names}

    # ---- showing -----------------------------------------------------------------------
    def show(self, only: Sequence[str] | None = None, text: str = "") -> None:
        self._only = set(only) if only else None
        self._text = text.strip().lower()
        self._armed = False
        self._redraw()
        if not self.visible:
            before = {"before": self.pack_before} if self.pack_before is not None else {}
            self.pack(side="right", fill="y", padx=(0, 14), pady=10, **before)
            self.visible = True

    def hide(self) -> None:
        if self.visible:
            self.pack_forget()
            self.visible = False

    def filter(self, text: str) -> None:
        text = text.strip().lower()
        if text != self._text:
            self._text = text
            self._armed = False
            self._redraw()

    # ---- choosing ----------------------------------------------------------------------
    def move(self, step: int) -> None:
        picks = [i for i, name in enumerate(self._rows) if name is not None]
        if not picks:
            return
        cur = self._current()
        if cur is None:
            target = picks[0] if step > 0 else picks[-1]
        else:
            pos = picks.index(cur) + step
            target = picks[max(0, min(pos, len(picks) - 1))]
        self._select(target)
        self._armed = True

    def choice(self, typed: str) -> str | None:
        """What Enter should put in the field (None = keep the typed text)."""
        cur = self._current()
        if self._armed and cur is not None:
            return self._rows[cur]
        typed = typed.strip().lower()
        if not typed or typed in self.names():
            return None
        starts = [n for n in self._rows if n is not None and n.lower().startswith(typed)]
        return starts[0] if len(starts) == 1 else None

    # ---- internal ----------------------------------------------------------------------
    def _current(self) -> int | None:
        sel = self._list.curselection()
        return sel[0] if sel and self._rows[sel[0]] is not None else None

    def _select(self, index: int) -> None:
        self._list.selection_clear(0, "end")
        self._list.selection_set(index)
        self._list.see(index)

    def _redraw(self) -> None:
        self._list.delete(0, "end")
        self._rows = []
        count = 0
        only = self._only
        if only and not any(cat in only for cat, _n in self._catalogue):
            only = None                             # no cash / bank ledgers yet: offer everything
        for cat, names in self._catalogue:
            if only is not None and cat not in only:
                continue
            shown = [n for n in names if self._text in n.lower()]
            if not shown:
                continue
            self._list.insert("end", cat.upper())
            self._list.itemconfigure("end", fg=T.MUTED, bg=T.LIGHT_BLUE, selectbackground=T.LIGHT_BLUE,
                                     selectforeground=T.MUTED)
            self._rows.append(None)
            for n in shown:
                self._list.insert("end", f"   {n}")
                self._rows.append(n)
                count += 1
        if not self._rows:
            self._list.insert("end", "No matching ledger.")
            self._list.itemconfigure("end", fg=T.MUTED)
            self._rows.append(None)
        self._hint.configure(text=f"{count} name(s) · Up / Down pick · Enter use" if count
                             else "Enter keeps the name you typed")

    def _click(self, event: tk.Event) -> None:
        index = self._list.nearest(event.y)
        if 0 <= index < len(self._rows) and self._rows[index] is not None:
            self._select(index)
            self._armed = True
            self._on_pick(self._rows[index])
