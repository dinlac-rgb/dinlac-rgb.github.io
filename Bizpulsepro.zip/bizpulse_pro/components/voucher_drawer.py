"""
Voucher Entry Utilities — the drawer that slides out over the left of the voucher screen
(Ctrl+I, or "Ctrl+I: More Details" on the action bar).

    STATUS MANAGEMENT          Regular | Optional | Post-Dated      (orange = current)
    ADVANCED DATA DETAILS      Dispatch, Order, Consignee, Cheque (Q) and GST Details
    CONFIGURATION ASSISTANTS   Autofill, Unused Vch No.

Each block's bold letter chooses it (unique within the drawer, so Order Details uses E;
O is Optional). Esc slides the drawer away and gives the keyboard back to the voucher lines.
White background, thin grey border; Segoe UI 11 normal with the shortcut letter in bold.
"""
from __future__ import annotations

import tkinter as tk
from typing import Callable, Sequence

from config import theme as T
from views.masters_overlay import hotkey_labels

GREY = "#AEB7C2"
STATUSES = [("Regular", "R"), ("Optional", "O"), ("Post-Dated", "P")]
DETAILS = [("Dispatch Details", "D"), ("Order Details", "E"), ("Consignee Details", "C"), ("Cheque Details", "Q"),
           ("GST Details", "G")]
ASSISTANTS = [("Autofill", "A"), ("Unused Vch No.", "U")]


class UtilitiesDrawer(tk.Frame):
    WIDTH = 330
    TOP = 34            # below the voucher screen's title bar

    def __init__(self, view: tk.Widget, status: str, on_status: Callable[[str], None],
                 on_action: Callable[[str], None]) -> None:
        super().__init__(view, bg=T.WHITE, highlightthickness=1, highlightbackground=GREY, takefocus=1)
        self._view = view
        self._on_status = on_status
        self._on_action = on_action
        self._blocks: dict[str, tuple[str, list[tk.Widget]]] = {}     # key -> (label, widgets)
        self._status = status

        tk.Label(self, text="Voucher Entry Utilities", bg=T.WHITE, fg=T.NAVY, font=T.F_KEY, anchor="w",
                 padx=14, pady=10).pack(side="top", fill="x")
        tk.Frame(self, bg=GREY, height=1).pack(side="top", fill="x")
        self._group("Status Management", STATUSES, columns=3)
        self._group("Advanced Data Details", DETAILS, columns=1)
        self._group("Configuration Assistants", ASSISTANTS, columns=1)
        tk.Label(self, text="Letter = choose    Esc close", bg=T.WHITE, fg=T.MUTED, font=T.F_HINT).pack(
            side="bottom", pady=8)
        self.paint()

    def _group(self, title: str, items: Sequence[tuple[str, str]], columns: int) -> None:
        tk.Label(self, text=title.upper(), bg=T.WHITE, fg=T.MUTED, font=T.F_HINT, anchor="w", padx=14).pack(
            side="top", fill="x", pady=(12, 4))
        grid = tk.Frame(self, bg=T.WHITE)
        grid.pack(side="top", fill="x", padx=14)
        for c in range(columns):
            grid.columnconfigure(c, weight=1, uniform="b")
        for i, (label, key) in enumerate(items):
            block = tk.Frame(grid, bg=T.LIGHT_BLUE, cursor="hand2", highlightthickness=1,
                             highlightbackground=T.LINE)
            block.grid(row=i // columns, column=i % columns, sticky="ew", padx=2, pady=2)
            inner = tk.Frame(block, bg=T.LIGHT_BLUE)
            inner.pack(padx=8, pady=4, anchor="w" if columns == 1 else "center")
            parts = hotkey_labels(inner, label, key, T.LIGHT_BLUE, T.NAVY)
            widgets = [block, inner, *parts]
            for w in widgets:
                w.bind("<Button-1>", lambda _e, k=key: self.choose(k))
            self._blocks[key] = (label, widgets)

    # ---- public ------------------------------------------------------------------------
    def open(self, animate: bool = True) -> None:
        """Slide in from the left edge of the voucher screen."""
        self.place(in_=self._view, x=-self.WIDTH if animate else 0, y=self.TOP, width=self.WIDTH,
                   relheight=1, height=-self.TOP)
        self.lift()
        self.focus_set()
        if animate:
            self._slide(-self.WIDTH)

    def _slide(self, x: int) -> None:
        if not self.winfo_exists():
            return
        x = min(0, x + self.WIDTH // 6)
        self.place_configure(x=x)
        if x < 0:
            self.after(12, self._slide, x)

    def set_status(self, status: str) -> None:
        self._status = status
        self.paint()

    def paint(self) -> None:
        for key, (label, widgets) in self._blocks.items():
            on = label == self._status
            for w in widgets:
                w.configure(bg=T.ORANGE if on else T.LIGHT_BLUE)
                if isinstance(w, tk.Label):
                    w.configure(fg=T.TEXT_DARK if on else T.NAVY)

    def choose(self, key: str) -> None:
        label = self._blocks[key][0]
        if key in {k for _l, k in STATUSES}:
            self._on_status(label)
        else:
            self._on_action(label)

    def handle_key(self, event: tk.Event) -> str | None:
        if event.state & (T.MOD_CTRL | T.MOD_ALT):
            return None
        if len(event.keysym) == 1 and event.keysym.upper() in self._blocks:
            self.choose(event.keysym.upper())
            return "break"
        return None          # Esc is handled by the voucher screen (it owns the drawer)
