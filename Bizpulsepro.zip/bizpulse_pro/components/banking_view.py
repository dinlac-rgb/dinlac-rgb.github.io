"""
Banking - List of Actions (N - Banking, under Utilities on the gateway).

The same centred light-blue box as the List of Masters, with Banking's own sections:

    RECONCILIATION   Banking Activities, Imported Bank Data
    CHEQUE           Cheque Printing, Cheque Register, Post-dated Summary
    OTHER REPORTS    Deposit Slip, Payment Advice

Keys: bold letter chooses, Up / Down, Enter, Esc closes. Imported Bank Data opens the bank
reconciliation helper (views/bank_reco_view.py: bank book against a statement file, M - Match
Entries); every other action opens its list screen (views/tool_screens.py): Banking Activities,
Cheque Printing, Cheque Register, Post-dated Summary, Deposit Slip, Payment Advice.
"""
from __future__ import annotations

import tkinter as tk
from typing import Callable

from config.settings import BANKING_NOT_BUILT, BANKING_SECTIONS
from views.masters_overlay import MastersOverlay

TITLE = "Banking - List of Actions"


def banking_menu(area: tk.Widget, on_choose: Callable[[str, str], None],
                 on_close: Callable[[], None]) -> MastersOverlay:
    """Builds the box (not shown yet: call .show()). on_choose(mode, action) as for masters."""
    return MastersOverlay(area, mode="Banking", on_choose=on_choose, on_close=on_close,
                          sections=BANKING_SECTIONS, title=TITLE, caption="Utilities",
                          not_built=BANKING_NOT_BUILT.keys())
