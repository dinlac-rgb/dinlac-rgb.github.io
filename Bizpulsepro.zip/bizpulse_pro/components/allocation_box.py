"""
Cost Centre Allocation — the inline box that slides out under an expense or purchase line when
Enter is pressed on its amount (views/vouchers_view.py).

    +-- Cost Centre Allocation · Office Rent · 25,000.00 ---------------------+
    |  Cost Centre            %        Amount                                 |
    |  [Marketing        ]  [ 60 ]  [ 15,000.00 ]                             |
    |  [Operations       ]  [ 40 ]  [ 10,000.00 ]                             |
    |  [                 ]  [    ]  [           ]                             |
    |  Allocated 25,000.00 · Remaining 0.00                                   |
    |  Known: Marketing, Operations, Administration, Kolkata Branch, …        |
    |  Enter next   empty Cost Centre finishes   Esc closes, keeps the line   |
    +-------------------------------------------------------------------------+

    box = AllocationBox(view, anchor, ledger=..., amount=Decimal, allocations=[...], centres=[...],
                        on_done=lambda allocations: ..., on_close=lambda: ...)
    box.show(); box.handle_key(event)

Typing: a Cost Centre name (the first known name that starts with what is typed is filled in);
% (the amount follows: line × % ÷ 100; the share that brings the total to 100 % takes whatever
is left, so the paise always add up); or an amount directly (blank % and amount = the rest).
Enter on an empty Cost Centre finishes: with nothing allocated the line stays unsplit; otherwise
the shares must add up to the line. Esc closes the box and changes nothing (the line keeps the
split it had). Segoe UI 11 normal; white box with a thin grey border.
"""
from __future__ import annotations

import tkinter as tk
from decimal import Decimal, InvalidOperation
from typing import Callable, Sequence

from config import theme as T
from services.cost_centres import check, share

GREY = "#AEB7C2"
ROWS_START = 3


def _fmt(v: Decimal) -> str:
    q = v.quantize(Decimal("0.01"))
    whole, frac = f"{abs(q):.2f}".split(".")
    if len(whole) > 3:
        head, tail, groups = whole[:-3], whole[-3:], []
        while len(head) > 2:
            groups.insert(0, head[-2:])
            head = head[:-2]
        whole = ",".join(([head] if head else []) + groups + [tail])
    return ("-" if q < 0 else "") + whole + "." + frac


class AllocationBox(tk.Frame):
    def __init__(self, area: tk.Widget, anchor: tk.Widget, *, ledger: str, amount: Decimal, allocations: list[dict],
                 centres: Sequence[str], on_done: Callable[[list[dict]], None], on_close: Callable[[], None]) -> None:
        super().__init__(area, bg=T.WHITE, highlightthickness=1, highlightbackground=GREY)
        self._area, self._anchor = area, anchor
        self.amount, self._centres = amount, list(centres)
        self._on_done, self._on_close = on_done, on_close
        tk.Label(self, text=f"Cost Centre Allocation · {ledger} · {_fmt(amount)}", bg=T.WHITE, fg=T.NAVY,
                 font=T.F_TEXT, anchor="w", padx=12, pady=6).pack(side="top", fill="x")
        tk.Frame(self, bg=GREY, height=1).pack(side="top", fill="x")
        self._grid = tk.Frame(self, bg=T.WHITE)
        self._grid.pack(side="top", fill="x", padx=12, pady=(6, 2))
        for col, (text, anchor) in enumerate((("Cost Centre", "w"), ("%", "e"), ("Amount", "e"))):
            tk.Label(self._grid, text=text, bg=T.WHITE, fg=T.MUTED, font=T.F_TEXT, anchor=anchor).grid(
                row=0, column=col, sticky="ew", padx=2)
        self.rows: list[tuple[tk.Entry, tk.Entry, tk.Entry]] = []
        for a in allocations:
            self._add_row(a["cost_centre"], str(a.get("percent") or ""), _fmt(a["amount"]))
        while len(self.rows) < max(ROWS_START, len(allocations) + 1):
            self._add_row()
        self._total = tk.Label(self, bg=T.WHITE, fg=T.TEXT, font=T.F_TEXT, anchor="w", padx=12)
        self._total.pack(side="top", fill="x")
        known = ", ".join(self._centres[:8]) + (" …" if len(self._centres) > 8 else "")
        tk.Label(self, text=f"Known: {known}" if known else "Type a department, project or branch name.",
                 bg=T.WHITE, fg=T.MUTED, font=T.F_TEXT, anchor="w", padx=12, wraplength=520,
                 justify="left").pack(side="top", fill="x")
        self._error = tk.Label(self, bg=T.WHITE, fg=T.BAD_RED, font=T.F_TEXT, anchor="w", padx=12)
        self._error.pack(side="top", fill="x")
        tk.Label(self, text="Enter next    empty Cost Centre finishes    Esc closes, keeps the line", bg=T.WHITE,
                 fg=T.MUTED, font=T.F_TEXT, pady=6).pack(side="top")
        self._refresh()

    def _add_row(self, name: str = "", pct: str = "", amount: str = "") -> None:
        r = len(self.rows) + 1
        cell = dict(font=T.F_TEXT, relief="flat", bd=0, highlightthickness=1, highlightbackground=T.LINE,
                    highlightcolor=T.ORANGE)
        name_e = tk.Entry(self._grid, width=24, **cell)
        pct_e = tk.Entry(self._grid, width=6, justify="right", **cell)
        amt_e = tk.Entry(self._grid, width=14, justify="right", **cell)
        for col, (e, text) in enumerate(((name_e, name), (pct_e, pct), (amt_e, amount))):
            e.insert(0, text)
            e.grid(row=r, column=col, sticky="ew", padx=2, pady=2, ipady=2)
            e.bind("<KeyRelease>", lambda _e: self._refresh(), add="+")
        self.rows.append((name_e, pct_e, amt_e))

    # ---- values --------------------------------------------------------------------------
    @staticmethod
    def _num(text: str) -> Decimal | None:
        raw = text.replace(",", "").replace("%", "").replace("₹", "").strip()
        if not raw:
            return None
        try:
            v = Decimal(raw)
        except InvalidOperation:
            raise ValueError(f"'{text}' is not a number") from None
        if not v.is_finite() or v <= 0:
            raise ValueError(f"'{text}' must be above 0")
        return v

    def allocations(self) -> list[dict]:
        out = []
        for name_e, pct_e, amt_e in self.rows:
            name = name_e.get().strip()
            if not name:
                continue
            amount = self._num(amt_e.get())
            out.append({"cost_centre": name, "amount": (amount or Decimal("0")).quantize(Decimal("0.01")),
                        "percent": pct_e.get().replace("%", "").strip()})
        return out

    def _allocated(self) -> Decimal:
        total = Decimal("0")
        for _n, _p, amt_e in self.rows:
            try:
                total += self._num(amt_e.get()) or 0
            except ValueError:
                pass
        return total

    def _refresh(self) -> None:
        done = self._allocated()
        left = self.amount - done
        self._total.configure(text=f"Allocated {_fmt(done)} · Remaining {_fmt(left)}",
                              fg=T.OK_GREEN if not left else (T.BAD_RED if left < 0 else T.TEXT))

    # ---- moving --------------------------------------------------------------------------
    def show(self) -> None:
        self._area.update_idletasks()
        x = self._anchor.winfo_rootx() - self._area.winfo_rootx()
        y = self._anchor.winfo_rooty() - self._area.winfo_rooty() + self._anchor.winfo_height() + 2
        width = self.winfo_reqwidth()
        x = max(0, min(x, self._area.winfo_width() - width - 4))
        self.place(in_=self._area, x=x, y=y)
        self.lift()
        first = next((r[0] for r in self.rows if not r[0].get().strip()), self.rows[0][0])
        first.focus_set()

    def _fail(self, text: str, widget: tk.Widget) -> str:
        self._error.configure(text=text[0].upper() + text[1:].rstrip(".") + ".")
        widget.focus_set()
        return "break"

    def _enter(self, widget: tk.Widget) -> str:
        self._error.configure(text="")
        pos = next(((i, j) for i, row in enumerate(self.rows) for j, e in enumerate(row) if e is widget), None)
        if pos is None:
            return "break"
        i, j = pos
        name_e, pct_e, amt_e = self.rows[i]
        if j == 0:
            name = name_e.get().strip()
            if not name:                                     # empty name: finish
                try:
                    shares = self.allocations()
                except ValueError as exc:
                    return self._fail(str(exc), widget)
                problem = check(self.amount, shares)
                if problem:
                    return self._fail(f"{problem}; finish the split, or Esc to leave the line as it was", widget)
                self._on_done(shares)
                return "break"
            match = next((c for c in self._centres if c.lower().startswith(name.lower())), None)
            if match and match.lower() != name.lower():
                name_e.delete(0, "end")
                name_e.insert(0, match)
            pct_e.focus_set()
        elif j == 1:
            try:
                pct = self._num(pct_e.get())
                if pct is not None:
                    if pct > 100:
                        return self._fail("% cannot be above 100", pct_e)
                    others = [r for k, r in enumerate(self.rows) if k != i]
                    if sum((self._num(r[1].get()) or 0) for r in others) + pct == 100:   # last share: what is left
                        value = self.amount - sum((self._num(r[2].get()) or 0) for r in others)
                    else:
                        value = share(self.amount, pct)
                    if value <= 0:
                        return self._fail("nothing is left to allocate", pct_e)
                    amt_e.delete(0, "end")
                    amt_e.insert(0, _fmt(value))
            except ValueError as exc:
                return self._fail(str(exc), pct_e)
            amt_e.focus_set()
        else:
            try:
                value = self._num(amt_e.get())
            except ValueError as exc:
                return self._fail(str(exc), amt_e)
            if value is None:                                  # blank: the rest of the line
                rest = self.amount - self._allocated()
                if rest <= 0:
                    return self._fail("nothing is left to allocate", amt_e)
                value = rest
            amt_e.delete(0, "end")
            amt_e.insert(0, _fmt(value))
            if i + 1 == len(self.rows):
                self._add_row()
            self.rows[i + 1][0].focus_set()
        self._refresh()
        return "break"

    def handle_key(self, event: tk.Event) -> str | None:
        if event.keysym == "Escape":
            self._on_close()
            return "break"
        if event.keysym in ("Return", "KP_Enter", "Tab"):
            return self._enter(event.widget)
        return None
