"""
Right-hand action bar — the thin light-blue strip down the far right edge of the window.

Its buttons belong to whatever is on screen, so they change with the screen:

    Corridor (gateway)     F2: Period   F3: Company   F4: Go To
    Voucher screen         F4: Contra … F9: Purchase, Ctrl+F8: Credit Note, Ctrl+F9: Debit Note,
                           Ctrl+H: Change Mode, Ctrl+A: Accept, Esc: Back
    Reports / Dashboard    F5: Refresh, Esc: Back
    A box (List of …)      Esc: Close

    bar = MacroBar(root)
    bar.set([Macro("F5", "Refresh", reload)], active="F5")
    bar.handle_key(event)      # the window's dispatcher calls this first; F-keys run their macro

Keyboard mode (F12 on any screen; the window routes the keys, see main.py):
    F12          the bar takes the keyboard; the orange cursor starts on the current button
                 (the voucher type on a voucher screen)
    Up / Down    move the cursor, round and round (Contra … Purchase, Credit / Debit Note,
                 Change Mode, More Details, Accept, Back)
    Enter        runs that button, exactly as clicking it or pressing its own key
    Esc / F12    leave the bar; the cursor goes back to the field it came from
    A click elsewhere also leaves keyboard mode.

    bar.enter_keyboard(); bar.move(+1); bar.current() -> Macro; bar.leave_keyboard()

The licence and internet status blocks stay at the bottom of the bar on every screen.
"""
from __future__ import annotations

import tkinter as tk
from dataclasses import dataclass
from typing import Callable, Sequence

from config import theme as T


@dataclass(frozen=True)
class Macro:
    key: str                              # shown on the button: "F5", "Ctrl+A", "Esc"
    label: str
    command: Callable[[], None]
    keysym: str | None = None             # key the bar itself answers (F-keys); None = the screen handles it
    ctrl: bool = False                    # the key is pressed with Ctrl (Ctrl+F8)

    @classmethod
    def fkey(cls, key: str, label: str, command: Callable[[], None]) -> "Macro":
        """'F5' or 'Ctrl+F8': the bar answers the key itself."""
        ctrl = key.startswith("Ctrl+")
        return cls(key, label, command, keysym=key.split("+")[-1], ctrl=ctrl)


class MacroBar(tk.Frame):
    WIDTH = round(186 * T.FONT_SIZE / 11)     # fits 'Ctrl+F8: Credit Note' (Settings › F: 11 or 12 pt)

    def __init__(self, parent: tk.Widget) -> None:
        super().__init__(parent, bg=T.LIGHT_BLUE, width=self.WIDTH, highlightbackground=T.BORDER,
                         highlightthickness=1)
        self.pack_propagate(False)
        self._macros: list[Macro] = []
        self._buttons: dict[str, tk.Button] = {}
        self._active: str | None = None
        self.keyboard = False                       # F12: the bar has the keys
        self._cursor = 0
        self.configure(takefocus=1)
        self.bind("<FocusOut>", lambda _e: self.keyboard and self.leave_keyboard())
        self._top = tk.Frame(self, bg=T.LIGHT_BLUE)
        self._top.pack(side="top", fill="x", padx=8, pady=(10, 0))
        self.bottom = tk.Frame(self, bg=T.LIGHT_BLUE)
        self.bottom.pack(side="bottom", fill="x", padx=8, pady=(0, 12))

    # ---- buttons -----------------------------------------------------------------------
    def set(self, macros: Sequence[Macro], active: str | None = None) -> None:
        """Replace the buttons. Unchanged lists are only repainted (no flicker while typing)."""
        macros = list(macros)
        same = [(m.key, m.label) for m in macros] == [(m.key, m.label) for m in self._macros]
        self._macros = macros
        if not same:
            for b in self._buttons.values():
                b.destroy()
            self._buttons = {}
            for m in macros:
                b = tk.Button(self._top, text=f"{m.key}: {m.label}", command=lambda mm=m: mm.command(),
                              relief="flat", bd=0, font=T.F_MACRO, anchor="w", padx=12, pady=7,
                              cursor="hand2", takefocus=0, activebackground=T.ORANGE,
                              activeforeground=T.TEXT_DARK)
                b.pack(side="top", fill="x", pady=2)
                self._buttons[m.key] = b
        if self._cursor >= len(self._macros):
            self._cursor = max(0, len(self._macros) - 1)
        self.set_active(active)

    def set_active(self, key: str | None) -> None:
        self._active = key
        self._paint()

    def _paint(self) -> None:
        cursor_key = self._macros[self._cursor].key if self.keyboard and self._macros else None
        for k, b in self._buttons.items():
            on = k == cursor_key if self.keyboard else k == self._active
            b.configure(bg=T.ORANGE if on else T.NAVY, fg=T.TEXT_DARK if on else T.WHITE)

    # ---- keyboard mode (F12) -------------------------------------------------------------
    def enter_keyboard(self) -> bool:
        """The bar takes the keyboard. False when there is no button to move through."""
        if not self._macros:
            return False
        keys = [m.key for m in self._macros]
        self._cursor = keys.index(self._active) if self._active in keys else 0
        self.keyboard = True
        self.focus_set()
        self._paint()
        return True

    def leave_keyboard(self) -> None:
        self.keyboard = False
        self._paint()

    def move(self, step: int) -> None:
        if self._macros:
            self._cursor = (self._cursor + step) % len(self._macros)
            self._paint()

    def current(self) -> Macro | None:
        return self._macros[self._cursor] if self._macros else None

    def handle_key(self, event: tk.Event) -> str | None:
        if event.state & T.MOD_ALT:
            return None
        ctrl = bool(event.state & T.MOD_CTRL)
        for m in self._macros:
            if m.keysym and event.keysym == m.keysym and m.ctrl == ctrl:
                m.command()
                return "break"
        return None

    @property
    def labels(self) -> list[str]:
        return [f"{m.key}: {m.label}" for m in self._macros]

    # ---- status blocks (bottom) --------------------------------------------------------
    def status_block(self, caption: str, value: str) -> tk.Label:
        box = tk.Frame(self.bottom, bg=T.WHITE, highlightbackground=T.BORDER, highlightthickness=1)
        box.pack(side="top", fill="x", pady=3)
        tk.Label(box, text=caption, bg=T.WHITE, fg=T.MUTED, font=T.F_STATUS_CAP, anchor="w",
                 wraplength=self.WIDTH - 28, justify="left").pack(fill="x", padx=8, pady=(5, 0))
        val = tk.Label(box, text=value, bg=T.WHITE, fg=T.MUTED, font=T.F_STATUS, anchor="w",
                       wraplength=self.WIDTH - 28, justify="left")
        val.pack(fill="x", padx=8, pady=(0, 6))
        return val
