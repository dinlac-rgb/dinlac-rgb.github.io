"""
Subsystem Monitor — now a one-line status bar along the bottom of the window, plus the full
activity history behind it (Help › Session Messages, keys F1 then M, shows the history).

The left side of the window stays a clean white canvas, so messages no longer get a panel
there. Everything that used to be written to the monitor still is: the latest line shows in
the status bar, and every line is kept for Session Messages.

Background threads (scripts, database checks, the internet probe) must never touch Tk
widgets. They call `monitor.post(kind, payload)`, which only puts a message on a queue.
The UI thread drains that queue every 80 ms and hands each message to the handler
registered for its kind:

    monitor.on("net", show_internet_status)   # any kind you like
    monitor.post("log", "text")                 # "log" is built in
"""
from __future__ import annotations

import queue
import tkinter as tk
from datetime import datetime
from typing import Callable

from config import theme as T

DRAIN_EVERY_MS = 80
KEEP_LINES = 2000


class SubsystemMonitor(tk.Frame):
    HEIGHT = 26

    def __init__(self, parent: tk.Widget) -> None:
        super().__init__(parent, bg=T.WHITE, height=self.HEIGHT, highlightthickness=1,
                         highlightbackground=T.LINE)
        self.pack_propagate(False)
        self._queue: "queue.Queue[tuple[str, str]]" = queue.Queue()
        self._handlers: dict[str, Callable[[str], None]] = {"log": self.log}
        self._listeners: list[Callable[[str], None]] = []
        self._draining = False
        self.history: list[str] = []

        tk.Label(self, text="All messages: F1 › M Session Messages", bg=T.WHITE, fg=T.MUTED,
                 font=T.F_HINT).pack(side="right", padx=10)
        self._line = tk.Label(self, text="", bg=T.WHITE, fg=T.TEXT, font=T.F_HINT, anchor="w")
        self._line.pack(side="left", fill="x", expand=True, padx=10)

    # ---- UI thread only ----------------------------------------------------------------
    def log(self, message: str) -> None:
        """Show the line in the status bar and keep it (time-stamped) in the history."""
        line = f"{datetime.now().strftime('%H:%M:%S')}  {message}"
        self.history.append(line)
        del self.history[:-KEEP_LINES]
        self._line.configure(text=line.replace("\n", "  "))
        for listener in list(self._listeners):
            listener(line)

    def clear(self) -> None:
        self.history.clear()
        self._line.configure(text="")

    def text(self) -> str:
        return "\n".join(self.history) + ("\n" if self.history else "")

    def subscribe(self, listener: Callable[[str], None]) -> Callable[[], None]:
        """Live updates (the Session Messages screen). Returns the unsubscribe function."""
        self._listeners.append(listener)

        def unsubscribe() -> None:
            if listener in self._listeners:
                self._listeners.remove(listener)
        return unsubscribe

    def on(self, kind: str, handler: Callable[[str], None]) -> None:
        """Register what the UI thread does with messages of this kind."""
        self._handlers[kind] = handler

    def start(self) -> None:
        if not self._draining:
            self._draining = True
            self.after(DRAIN_EVERY_MS, self._drain)

    # ---- any thread --------------------------------------------------------------------
    def post(self, kind: str, payload: str) -> None:
        """Safe from worker threads: queues the message for the UI thread."""
        self._queue.put((kind, payload))

    # ---- internal ----------------------------------------------------------------------
    def _drain(self) -> None:
        try:
            while True:
                kind, payload = self._queue.get_nowait()
                handler = self._handlers.get(kind)
                if handler is not None:
                    try:
                        handler(payload)
                    except Exception as exc:  # a faulty handler must not stop the queue
                        self.log(f"[monitor] {kind} handler failed: {exc}")
        except queue.Empty:
            pass
        if self.winfo_exists():
            self.after(DRAIN_EVERY_MS, self._drain)
