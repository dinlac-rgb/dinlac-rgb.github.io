"""
Display More Reports (M, under Reports on the Corridor) — centred light-blue box.

    ACCOUNTING   Balance Sheet, Profit & Loss A/c, Ratio Analysis, Day Book, Dashboard, Trial Balance
    INVENTORY    Stock Summary, Movement Analysis
    STATUTORY    GSTR-1, GSTR-3B Return, HSN/SAC Summary

Same box as the List of Masters: bold hotkey letter (no underline), Up / Down, Enter, Esc
closes and returns to the Corridor. Every report opens its screen; an entry in
MORE_REPORTS_NOT_BUILT (config/settings.py; empty now) would show a muted tag instead.
"""
from __future__ import annotations

import tkinter as tk
from typing import Callable

from config.settings import MORE_REPORTS_NOT_BUILT, MORE_REPORTS_SECTIONS
from views.masters_overlay import MastersOverlay

TITLE = "Display More Reports"


def more_reports_menu(area: tk.Widget, on_choose: Callable[[str, str], None],
                      on_close: Callable[[], None]) -> MastersOverlay:
    """Builds the box (call .show()). on_choose(mode, report) as for the List of Masters."""
    return MastersOverlay(area, mode="Reports", on_choose=on_choose, on_close=on_close,
                          sections=MORE_REPORTS_SECTIONS, title=TITLE, caption="Reports",
                          not_built=MORE_REPORTS_NOT_BUILT.keys())
