"""
The inline exchange-rate box of the voucher screen. It opens just under the Currency field when
a voucher is given a foreign currency (typed in the Currency field, or as "USD 1,200" / "$1,200"
in an amount).

    +-- Exchange Rate ----------------------------+
    |  USD   US Dollar                            |
    |  EUR   Euro               (Up / Down)       |
    |  ...                                        |
    |  1 USD = ₹ [ 83.25      ]                   |
    |  Up/Down currency   Enter accept   Esc back |
    +---------------------------------------------+

    box = CurrencyBox(view, anchor_widget, currency="USD", rate="", currencies=[(code, name), ...],
                      on_done=lambda code, rate: ..., on_close=lambda: ...)
    box.show()
    box.handle_key(event)        # the voucher screen forwards keys while the box is open
    box.offer_rate(code, rate)   # last rate used for that currency (filled in if the field is empty)

The cursor stays in the rate field. Enter checks the rate (services/forex.parse_rate) and hands
back (code, Decimal rate); a wrong rate keeps the box open with the reason. Esc closes it and
changes nothing. Look: white, thin grey border, Segoe UI 11 normal.
"""
from __future__ import annotations

import tkinter as tk
from decimal import Decimal
from typing import Callable, Sequence

from config import theme as T
from services.forex import parse_rate, rate_text

GREY = "#AEB7C2"


class CurrencyBox(tk.Frame):
    def __init__(self, area: tk.Widget, anchor: tk.Widget, *, currency: str, rate: str,
                 currencies: Sequence[tuple[str, str]], on_done: Callable[[str, Decimal], None],
                 on_close: Callable[[], None]) -> None:
        super().__init__(area, bg=T.WHITE, highlightthickness=1, highlightbackground=GREY)
        self._area, self._anchor = area, anchor
        self._on_done, self._on_close = on_done, on_close
        self._codes = [c for c, _n in currencies]
        names = dict(currencies)
        if currency not in self._codes:
            self._codes.insert(0, currency)
        tk.Label(self, text="Exchange Rate", bg=T.WHITE, fg=T.NAVY, font=T.F_TEXT, anchor="w", padx=12,
                 pady=6).pack(side="top", fill="x")
        tk.Frame(self, bg=GREY, height=1).pack(side="top", fill="x")
        self._list = tk.Listbox(self, height=min(8, len(self._codes)), font=T.F_TEXT, relief="flat", bd=0,
                                highlightthickness=0, activestyle="none", exportselection=False, takefocus=0,
                                selectbackground=T.ORANGE, selectforeground=T.TEXT_DARK, bg=T.WHITE, fg=T.TEXT)
        for code in self._codes:
            self._list.insert("end", f"  {code}   {names.get(code, '')}")
        self._list.pack(side="top", fill="x", padx=8, pady=(6, 4))
        self._list.bind("<<ListboxSelect>>", lambda _e: self._chosen())
        row = tk.Frame(self, bg=T.WHITE)
        row.pack(side="top", fill="x", padx=12, pady=4)
        self._per = tk.Label(row, bg=T.WHITE, fg=T.TEXT, font=T.F_TEXT)
        self._per.pack(side="left")
        self.rate = tk.Entry(row, width=12, font=T.F_TEXT, justify="right", relief="flat", bd=0, highlightthickness=1,
                             highlightbackground=T.LINE, highlightcolor=T.ORANGE)
        self.rate.pack(side="left", padx=(6, 0), ipady=3)
        self.rate.insert(0, rate)
        self._error = tk.Label(self, bg=T.WHITE, fg=T.BAD_RED, font=T.F_HINT, anchor="w", padx=12)
        self._error.pack(side="top", fill="x")
        tk.Label(self, text="Up/Down currency    Enter accept    Esc back", bg=T.WHITE, fg=T.MUTED,
                 font=T.F_HINT, pady=6).pack(side="top")
        self._select(self._codes.index(currency))

    # ---- public ------------------------------------------------------------------------
    @property
    def currency(self) -> str:
        return self._codes[self._index]

    def show(self) -> None:
        self._area.update_idletasks()
        x = self._anchor.winfo_rootx() - self._area.winfo_rootx()
        y = self._anchor.winfo_rooty() - self._area.winfo_rooty() + self._anchor.winfo_height() + 2
        self.place(in_=self._area, x=max(0, x), y=y)
        self.lift()
        self.rate.focus_set()
        self.rate.select_range(0, "end")

    def offer_rate(self, code: str, rate: Decimal | None) -> None:
        if rate is not None and code == self.currency and self.winfo_exists() and not self.rate.get().strip():
            self.rate.insert(0, rate_text(rate))
            self.rate.select_range(0, "end")

    def handle_key(self, event: tk.Event) -> str | None:
        if event.keysym == "Escape":
            self._on_close()
            return "break"
        if event.keysym in ("Up", "Down"):
            self._select(self._index + (-1 if event.keysym == "Up" else 1))
            return "break"
        if event.keysym in ("Return", "KP_Enter", "Tab"):
            try:
                rate = parse_rate(self.rate.get())
            except ValueError as exc:
                self._error.configure(text=str(exc).rstrip(".") + ".")
                self.rate.focus_set()
                return "break"
            self._on_done(self.currency, rate)
            return "break"
        return None                         # typing goes into the rate field

    # ---- inside ------------------------------------------------------------------------
    def _select(self, index: int) -> None:
        index = max(0, min(index, len(self._codes) - 1))
        if getattr(self, "_index", index) != index:
            self.rate.delete(0, "end")              # another currency: its own rate
            self._error.configure(text="")
        self._index = index
        self._list.selection_clear(0, "end")
        self._list.selection_set(self._index)
        self._list.see(self._index)
        self._per.configure(text=f"1 {self.currency} = ₹")
        self.event_generate("<<CurrencyChanged>>", when="tail")

    def _chosen(self) -> None:
        sel = self._list.curselection()
        if sel and sel[0] != self._index:
            self._select(sel[0])
        self.rate.focus_set()
