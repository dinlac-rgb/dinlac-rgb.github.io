"""
The mouse-highlight guard shared by every menu box (Corridor, List of Masters, Banking, Display
More Reports, header dropdowns).

The orange bar follows the mouse ONLY when the mouse really moves. A box that opens under a
resting pointer, rows that shift while Up / Down scroll, or the synthetic mouse-move Windows sends
when a window appears under the cursor all produce <Enter> / <Motion> events without any movement;
acting on those would snatch the bar away from the row the keyboard chose.

    guard = PointerGuard()
    widget.bind("<Motion>", lambda e: guard.moved(e) and set_active(n))

moved(event) is True only when the pointer's screen position differs from the last one seen; the
first event after the box opens just records where the pointer is resting.
"""
from __future__ import annotations


class PointerGuard:
    def __init__(self) -> None:
        self._last: tuple[int, int] | None = None

    def moved(self, event) -> bool:
        pos = (getattr(event, "x_root", None), getattr(event, "y_root", None))
        if self._last is None:
            self._last = pos
            return False
        if pos == self._last:
            return False
        self._last = pos
        return True

    def reset(self) -> None:
        """Forget the last position (the box was rebuilt or reopened)."""
        self._last = None
