"""
Header bar with Tally-style dropdown menus (K: Company, Y: Data, Z: Exchange, O: Import,
E: Export, P: Print, F1: Help) on the left, and the utility links on the right:
[S] Settings | [D] Dashboard | [T] Tutorial | [U] Upgrade Tier  (Alt+letter; Alt+D = Dashboard).

    header = HeaderBar(root, menus=S.HEADER_MENUS, on_choose=cb, on_plain=cb, on_closed=cb)
    header.toggle_menu("Company")        # click or Alt+K
    header.handle_key(event)             # route keys here first while header.is_open
    header.contains(widget)              # for click-away detection

Opening: click a header label, its Alt+letter (F1 for Help). While one dropdown is open,
moving the mouse onto another header label opens that one instead (menu-bar behaviour).

In a dropdown: the bold letter chooses, Up / Down move the orange bar, Enter chooses,
Left / Right switch to the neighbouring dropdown, Esc closes. Clicking anywhere outside
closes it (the window calls close_menu). The two options the desktop edition does not do itself
(Split Company Data, Synchronize) carry a muted "guide" tag and explain what to do instead.

Choosing only reports the choice (on_choose); the window does the work, in a background
thread where it takes time, so the menus never freeze the window.
"""
from __future__ import annotations

import tkinter as tk
from typing import Callable, Sequence, Tuple

from components.pointer_guard import PointerGuard
from config import theme as T
from views.masters_overlay import hotkey_labels

MenuOption = Tuple[str, str, Tuple[str, str]]          # (hotkey, label, action)


class DropdownMenu(tk.Frame):
    """The white box under a header label: one row per option, hotkey letter in bold."""

    WIDTH = 260

    def __init__(self, root: tk.Misc, title: str, options: Sequence[MenuOption],
                 on_choose: Callable[[int], None]) -> None:
        super().__init__(root, bg=T.WHITE, highlightthickness=1, highlightbackground=T.NAVY,
                         highlightcolor=T.NAVY, takefocus=1)
        self.title = title
        self._items = list(options)   # not '_options': that name is a Tk method
        self._on_choose = on_choose
        self._rows: list[tuple[tk.Widget, ...]] = []
        self._pointer = PointerGuard()          # the bar follows the mouse only when it really moves
        self._tags: set[tk.Widget] = set()     # "guide" notes keep their muted colour
        self._active = 0

        for i, (key, label, action) in enumerate(self._items):
            row = tk.Frame(self, bg=T.WHITE, cursor="hand2")
            row.pack(side="top", fill="x")
            # Segoe UI 11; only the hotkey letter is bold, flush with its word. No underline.
            parts: list[tk.Widget] = list(hotkey_labels(row, label, key, T.WHITE, T.NAVY, first_padx=14))
            if action[0] == "todo":
                tag = tk.Label(row, text="guide", bg=T.WHITE, fg=T.MUTED, font=T.F_HINT, padx=10)
                tag.pack(side="right")
                parts.append(tag)
                self._tags.add(tag)
            for w in (row, *parts):
                w.bind("<Motion>", lambda e, n=i: self._pointer.moved(e) and self.set_active(n))
                w.bind("<Button-1>", lambda _e, n=i: self.choose(n))
            self._rows.append((row, *parts))
        self.set_active(0)

    def set_active(self, index: int) -> None:
        self._active = index % len(self._rows)
        for i, widgets in enumerate(self._rows):
            on = i == self._active
            for w in widgets:
                w.configure(bg=T.ORANGE if on else T.WHITE)
                if isinstance(w, tk.Label):
                    if w in self._tags:
                        w.configure(fg=T.TEXT_DARK if on else T.MUTED)
                    else:
                        w.configure(fg=T.TEXT_DARK if on else T.NAVY)

    def move(self, step: int) -> None:
        self.set_active(self._active + step)

    def choose(self, index: int | None = None) -> None:
        if index is not None:
            self.set_active(index)
        self._on_choose(self._active)

    def index_of_key(self, letter: str) -> int | None:
        return next((i for i, (k, _l, _a) in enumerate(self._items) if k == letter), None)


class HeaderBar(tk.Frame):
    HEIGHT = 45

    def __init__(self, root: tk.Tk, *, left: Sequence[tuple[str, str]], right: Sequence[tuple[str, str]],
                 menus: dict[str, Sequence[MenuOption]],
                 on_choose: Callable[[str, str, tuple[str, str]], None],
                 on_plain: Callable[[str], None],
                 on_closed: Callable[[tk.Widget | None], None]) -> None:
        super().__init__(root, bg=T.NAVY, height=self.HEIGHT)
        self.pack_propagate(False)
        self._app = root          # not "_root": that name is a Tk method
        self._menus = menus
        self._on_choose = on_choose
        self._on_plain = on_plain
        self._on_closed = on_closed
        self._links: dict[str, tk.Frame] = {}
        self._link_parts: dict[str, list[tk.Widget]] = {}
        self._order = [label for _k, label in left if label in menus]   # for Left / Right
        self._dropdown: DropdownMenu | None = None
        self._return_focus: tk.Widget | None = None

        tk.Label(self, text="BIZPULSE PRO", bg=T.NAVY, fg=T.WHITE, font=T.F_BRAND).pack(side="left", padx=(12, 10))
        for key, label in left:
            self._add_link(key, label, side="left")
        # Right-hand utility links:  [S] Settings | [D] Dashboard | [T] Tutorial | [U] Upgrade Tier
        tk.Frame(self, bg=T.NAVY, width=8).pack(side="right")
        for i, (key, label) in enumerate(reversed(right)):   # packed right-to-left, so reverse
            if i:
                tk.Label(self, text="|", bg=T.NAVY, fg=T.HOVER_TEXT, font=T.F_HEADER).pack(side="right")
            self._add_link(key, label, side="right", text=f"[{key}] {label}")

    # ---- public ------------------------------------------------------------------------
    @property
    def is_open(self) -> bool:
        return self._dropdown is not None

    @property
    def open_title(self) -> str | None:
        return self._dropdown.title if self._dropdown else None

    def has_menu(self, label: str) -> bool:
        return label in self._menus

    def toggle_menu(self, label: str) -> None:
        if self._dropdown is not None and self._dropdown.title == label:
            self.close_menu()
        else:
            self.open_menu(label)

    def open_menu(self, label: str) -> None:
        if label not in self._menus:
            self._on_plain(label)
            return
        if self._dropdown is None:
            focus = self._app.focus_get()
            self._return_focus = focus if focus is not None and not self.contains(focus) else None
        else:
            self._discard_dropdown()
        link = self._links[label]
        dd = DropdownMenu(self._app, label, self._menus[label], on_choose=lambda i, l=label: self._choose(l, i))
        self._dropdown = dd
        self._app.update_idletasks()
        x = link.winfo_rootx() - self._app.winfo_rootx()
        y = self.winfo_rooty() - self._app.winfo_rooty() + self.winfo_height()
        x = max(0, min(x, self._app.winfo_width() - DropdownMenu.WIDTH - 2))   # keep it on screen
        dd.place(x=x, y=y, width=DropdownMenu.WIDTH)
        dd.lift()
        dd.focus_set()
        self._paint_links()

    def close_menu(self, restore_focus: bool = True) -> None:
        if self._dropdown is None:
            return
        self._discard_dropdown()
        self._paint_links()
        target, self._return_focus = self._return_focus, None
        if restore_focus:
            self._on_closed(target)

    def contains(self, widget: tk.Misc | None) -> bool:
        """True if the widget is this header bar or the open dropdown (or inside them)."""
        if widget is None:
            return False
        name = str(widget)
        for owner in (self, self._dropdown):
            if owner is not None and (name == str(owner) or name.startswith(str(owner) + ".")):
                return True
        return False

    def handle_key(self, event: tk.Event) -> str | None:
        """While a dropdown is open, every key comes here first."""
        dd = self._dropdown
        if dd is None:
            return None
        if event.state & T.MOD_CTRL:
            return "break"
        if event.state & T.MOD_ALT:
            return None                          # Alt+letter bindings switch menus
        keysym = event.keysym
        if keysym == "Escape":
            self.close_menu()
        elif keysym in ("Up", "Down"):
            dd.move(-1 if keysym == "Up" else 1)
        elif keysym in ("Left", "Right"):
            i = self._order.index(dd.title)
            self.open_menu(self._order[(i + (-1 if keysym == "Left" else 1)) % len(self._order)])
        elif keysym in ("Return", "KP_Enter"):
            dd.choose()
        elif len(keysym) == 1 and keysym.isalpha():
            hit = dd.index_of_key(keysym.upper())
            if hit is not None:
                dd.choose(hit)
        elif keysym == "F1":
            self.toggle_menu("Help")
        return "break"                           # nothing reaches the screen underneath

    # ---- internal ----------------------------------------------------------------------
    def _add_link(self, key: str, label: str, side: str, text: str | None = None) -> None:
        """One header link: Segoe UI 11, the shortcut key in bold, flush with the text around it
        ("K" + ": Company", or "[" + "S" + "] Settings"). No underline."""
        shown = text or f"{key}: {label}"
        i = shown.index(key)
        link = tk.Frame(self, bg=T.NAVY, cursor="hand2", padx=4)   # 11-pt text: keeps all links on a 1100-px header
        link.pack(side=side, fill="y")
        parts: list[tk.Widget] = [link]
        for piece, font in ((shown[:i], T.F_TEXT), (key, T.F_KEY), (shown[i + len(key):], T.F_TEXT)):
            if piece:
                lbl = tk.Label(link, text=piece, bg=T.NAVY, fg=T.WHITE, font=font, padx=0, pady=0, bd=0,
                               highlightthickness=0, cursor="hand2")
                lbl.pack(side="left", fill="y")
                parts.append(lbl)
        for w in parts:
            w.bind("<Enter>", lambda _e: self._hover(label))
            w.bind("<Leave>", lambda _e: self._paint_links())
            w.bind("<Button-1>", lambda _e: self.toggle_menu(label) if label in self._menus else self._on_plain(label))
        self._links[label] = link
        self._link_parts[label] = parts

    def _hover(self, label: str) -> None:
        # Menu-bar behaviour: with a dropdown open, pointing at another header opens that one.
        if self._dropdown is not None and label in self._menus and self._dropdown.title != label:
            self.open_menu(label)
        self._paint_links(hover=label)

    def _paint_links(self, hover: str | None = None) -> None:
        open_title = self.open_title
        for label, parts in self._link_parts.items():
            bg, fg = ((T.NAVY_ACTIVE, T.WHITE) if label == open_title
                      else (T.NAVY, T.HOVER_TEXT) if label == hover else (T.NAVY, T.WHITE))
            for w in parts:
                w.configure(bg=bg)
                if isinstance(w, tk.Label):
                    w.configure(fg=fg)

    def _choose(self, title: str, index: int) -> None:
        key, label, action = self._menus[title][index]
        self.close_menu()
        self._on_choose(title, label, action)

    def _discard_dropdown(self) -> None:
        if self._dropdown is not None:
            self._dropdown.destroy()
            self._dropdown = None
